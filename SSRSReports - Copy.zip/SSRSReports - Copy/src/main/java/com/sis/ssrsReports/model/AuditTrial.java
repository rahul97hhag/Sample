package com.sis.ssrsReports.model;

/**
 * Created by BhavaniPrasadReddy on 5/4/2020.
 */
public class AuditTrial implements Comparable<AuditTrial> {

    String auditDateDisplay;
    String patientName;
    String caseId;
    String surgeryDate;
    String auditType;
    String area;
    String formName;
    String auditDescription;
    String userName;
    String newValue;

    public String getAuditDateDisplay() {
        return auditDateDisplay;
    }

    public void setAuditDateDisplay(String auditDateDisplay) {
        this.auditDateDisplay = auditDateDisplay;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getSurgeryDate() {
        return surgeryDate;
    }

    public void setSurgeryDate(String surgeryDate) {
        this.surgeryDate = surgeryDate;
    }

    public String getAuditType() {
        return auditType;
    }

    public void setAuditType(String auditType) {
        this.auditType = auditType;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    public String getAuditDescription() {
        return auditDescription;
    }

    public void setAuditDescription(String auditDescription) {
        this.auditDescription = auditDescription;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuditTrial)) return false;

        AuditTrial that = (AuditTrial) o;

        if (!getAuditDateDisplay().equals(that.getAuditDateDisplay())) return false;
        if (!getPatientName().equals(that.getPatientName())) return false;
        if (!getCaseId().equals(that.getCaseId())) return false;
        if (!getSurgeryDate().equals(that.getSurgeryDate())) return false;
        if (!getAuditType().equals(that.getAuditType())) return false;
        if (!getArea().equals(that.getArea())) return false;
        if (!getFormName().equals(that.getFormName())) return false;
        if (!getAuditDescription().equals(that.getAuditDescription())) return false;
        if (!getUserName().equals(that.getUserName())) return false;
        return getNewValue().equals(that.getNewValue());
    }

    @Override
    public int hashCode() {
        int result = getAuditDateDisplay().hashCode();
        result = 31 * result + getPatientName().hashCode();
        result = 31 * result + getCaseId().hashCode();
        result = 31 * result + getSurgeryDate().hashCode();
        result = 31 * result + getAuditType().hashCode();
        result = 31 * result + getArea().hashCode();
        result = 31 * result + getFormName().hashCode();
        result = 31 * result + getAuditDescription().hashCode();
        result = 31 * result + getUserName().hashCode();
        result = 31 * result + getNewValue().hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "AuditTrial{" +
                "auditDateDisplay='" + auditDateDisplay + '\'' +
                ", patientName='" + patientName + '\'' +
                ", caseId='" + caseId + '\'' +
                ", surgeryDate='" + surgeryDate + '\'' +
                ", auditType='" + auditType + '\'' +
                ", area='" + area + '\'' +
                ", formName='" + formName + '\'' +
                ", auditDescription='" + auditDescription + '\'' +
                ", userName='" + userName + '\'' +
                ", newValue='" + newValue + '\'' +
                '}';
    }

    @Override
    public int compareTo(AuditTrial o) {
        return this.caseId.compareTo(o.caseId);
    }
}