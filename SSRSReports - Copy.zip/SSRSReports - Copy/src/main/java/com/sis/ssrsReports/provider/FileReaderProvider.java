package com.sis.ssrsReports.provider;

import com.sis.ssrsReports.service.FileReaderService;
import com.sis.ssrsReports.service.impl.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Created by BhavaniPrasadReddy on 5/3/2020.
 */
@Component
public class FileReaderProvider {

    @Autowired
    @Qualifier("CsvReader")
    private FileReaderService csvReader;

    @Autowired
    @Qualifier("ExcelReader")
    private FileReaderService excelReader;

    @Autowired
    @Qualifier("PdfReader")
    private FileReaderService pdfReader;

    @Autowired
    @Qualifier("PptReader")
    private FileReaderService pptReader;

    @Autowired
    @Qualifier("TiffReader")
    private FileReaderService tiffReader;

    @Autowired
    @Qualifier("WordReader")
    private FileReaderService wordReader;

    @Autowired
    @Qualifier("XmlReader")
    private FileReaderService xmlReader;


    public FileReaderService getFileReader(String fileType) {

        switch (fileType) {
            case "csv":
                csvReader = new CsvReader();
                return csvReader;
            case "xml":
                xmlReader = new XmlReader();
                return xmlReader;
            case "tiff":
                tiffReader = new TiffReader();
                return tiffReader;
            case "pdf":
                pdfReader = new PdfReader();
                return pdfReader;
            case "excel":
            case "xls":
                excelReader = new ExcelReader();
                return excelReader;
            case "ppt":
                pptReader = new PptReader();
                return pptReader;
            default:
                return null;
        }
    }
}