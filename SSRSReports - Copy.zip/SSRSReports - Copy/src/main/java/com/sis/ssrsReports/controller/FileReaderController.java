package com.sis.ssrsReports.controller;

import com.sis.ssrsReports.provider.FileReaderProvider;
import com.sis.ssrsReports.service.FileReaderService;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.FileNotFoundException;

/**
 * Created by BhavaniPrasadReddy on 5/3/2020.
 */
@Controller
public class FileReaderController {

    private static Logger log = LoggerFactory.getLogger(FileReaderController.class);

    @Autowired
    FileReaderProvider fileReaderProvider;

    public String getFileData(String filePath) throws FileNotFoundException {
        String fileType = FilenameUtils.getExtension(filePath);
        FileReaderService fileReader = fileReaderProvider.getFileReader(fileType);
        fileReader.readFile(filePath);
        return filePath;
    }


}