package com.sis.ssrsReports.service;

import java.io.FileNotFoundException;

/**
 * Created by BhavaniPrasadReddy on 5/3/2020.
 */
public interface FileReaderService {

    String readFile(String filePath) throws FileNotFoundException;
}