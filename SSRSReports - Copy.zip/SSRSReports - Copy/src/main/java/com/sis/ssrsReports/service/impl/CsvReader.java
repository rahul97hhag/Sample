package com.sis.ssrsReports.service.impl;

import com.sis.ssrsReports.service.FileReaderService;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by BhavaniPrasadReddy on 5/3/2020.
 */
@Service
@Qualifier("CsvReader")
public class CsvReader implements FileReaderService {

    private static Logger log = LoggerFactory.getLogger(CsvReader.class);

    public String readFile(String filePath) throws FileNotFoundException {
        Path path = Paths.get(filePath);
        File file = new File(filePath);
        if(!(file.exists())) {
            throw new FileNotFoundException();
        }
        

        log.info(String.format("Reading %s %s", "", FilenameUtils.getName(filePath)));
        return null;
    }
}