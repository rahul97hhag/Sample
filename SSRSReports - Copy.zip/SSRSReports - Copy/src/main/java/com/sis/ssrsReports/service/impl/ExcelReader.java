package com.sis.ssrsReports.service.impl;

import com.sis.ssrsReports.service.FileReaderService;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by BhavaniPrasadReddy on 5/3/2020.
 */
@Service
@Qualifier("ExcelReader")
public class ExcelReader implements FileReaderService {

    private static Logger log = LoggerFactory.getLogger(ExcelReader.class);

    public String readFile(String filePath) {
        log.info(String.format("Reading %s", FilenameUtils.getName(filePath)));

        return null;
    }

}