package com.sis.extentReports;

import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.xml.XmlTest;

import java.lang.reflect.Method;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public class BaseTest extends AbstractTestNGSpringContextTests {

    @BeforeSuite
    public void beforeSuite(ITestContext testContext) {

    }

    @BeforeGroups
    public void beforeGroups() {

    }

    @BeforeMethod
    public void beforeMethod() {

    }

    @BeforeTest
    public void beforeTest() {

    }

    @AfterTest
    public void afterTest() {

    }

    @AfterMethod
    public void afterMethod() {

    }

    @AfterGroups
    public void afterGroups() {

    }

    @AfterSuite
    public void afterSuite() {

    }

    @Parameters({ "expectedFile", "actualFile" })
    @BeforeClass
    public void initializeTestBaseSetup(String expectedFile, String actualFile) {

    }

    @AfterClass
    public void tearDown() {

    }
}





