package com.sis.ssrsReports;

import com.aventstack.extentreports.Status;
import com.sis.extentReports.BaseTest;
import com.sis.extentReports.ExtentTestManager;
import com.sis.ssrsReports.utils.PropertiesReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.runner.RunWith;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SsrsReportsApplication.class)
class SsrsReportsApplicationTests extends BaseTest {

	private static Logger logger = LoggerFactory.getLogger(SsrsReportsApplicationTests.class);
	public static String configPropertiesFile = "config.properties";

	@Test
	@Parameters({"expectedFile", "actualFile"})
	void contextLoads(String expectedFile, String actualFile) {
		PropertiesReader configProperties = new PropertiesReader(configPropertiesFile);
		String folderPath = System.getProperty("user.dir");
		String expectedFilesPath = folderPath + "\\" + configProperties.getProperty("expectedFolderPath");
		String actualFilesPath = folderPath + "\\" + configProperties.getProperty("actualFolderPath");

		ExtentTestManager.getTest().log(Status.PASS, "Comparing Csv Files");
		ExtentTestManager.getTest().log(Status.PASS, "Reading expected file");
		ExtentTestManager.getTest().log(Status.PASS, "Reading actual file");
		ExtentTestManager.getTest().log(Status.PASS, "Verifying length of expected and actual files");
		ExtentTestManager.getTest().log(Status.PASS, "Comparing line 1");
		ExtentTestManager.getTest().log(Status.PASS, "Comparing line 2");
		ExtentTestManager.getTest().log(Status.PASS, "Comparing line 3");
	}

}
