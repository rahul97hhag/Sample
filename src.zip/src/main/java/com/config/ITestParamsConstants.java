package com.config;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public interface ITestParamsConstants {
    String CONFIG_FILE = "src/test/resources/config.properties";
    String LOCATION_SEEDDATA_EXCEL = "locSeedDataExcel";
    String LOCATION_SEEDDATA_JSON = "locSeedDataJSON";
    String LOCATION_WEBSERVICE_TEMPLATES = "locWSTemplates";
    String GEMINI_WEBSERVICE_URL = "webserviceGeminiBaseURL";
    String EXTENT_TEST_VISIBILITY_MODE = "extentTestVisibilityMode";
    String SEEDDATA_EXECUTION_REPORT = "htmlReport";
    String EXTENT_CONFIG_FILE = "extentConfigFile";
    String COMMA_SEPARATED_SEEDDATA_SHEETS = "commaSeparatedSeedDataSheets";
}