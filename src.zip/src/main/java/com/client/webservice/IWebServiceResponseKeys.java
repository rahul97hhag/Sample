package com.client.webservice;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public interface IWebServiceResponseKeys {

    String keyToken = "token";
}