package com.client.webservice;

import com.utils.ReusableWebserviceUtils;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class WebServiceClient extends ReusableWebserviceUtils {

    protected WebServiceClient(String baseURL) {
        super(baseURL);
    }
}