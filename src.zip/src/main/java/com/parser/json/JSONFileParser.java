package com.parser.json;


import com.utils.JsonUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class JSONFileParser {

    private String path = null;
    private JsonUtils jsonUtils = null;
    private JSONObject jsonObject = null;
    private static final Logger LOG = Logger.getLogger(JSONFileParser.class);

    public JSONFileParser(String path) {
        try {
            this.path = path;
            this.jsonUtils = new JsonUtils();
            this.jsonObject = (JSONObject) this.jsonUtils.getJsonFileAsObject(this.path);
        } catch (Exception e) {
            LOG.error(e);
            LOG.debug("");
            LOG.debug("");
            System.exit(-1);
        }
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public JsonUtils getJsonUtils() {
        return jsonUtils;
    }

    public void setJsonUtils(JsonUtils jsonUtils) {
        this.jsonUtils = jsonUtils;
    }

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public String getValueFromJsonObject(String text) {
        return null;
    }



}