package com.parser.textfile;


import com.utils.ReusableUtils;
import org.apache.log4j.Logger;

import java.util.Properties;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class PropertiesFileReader {
    private static final Logger LOG = Logger.getLogger(PropertiesFileReader.class);
    private String path = null;
    Properties properties = null;

    public PropertiesFileReader(String path) {
        try {
            this.path = path;
            LOG.info(path);
            this.properties = ReusableUtils.getConfigPropertyObject(this.path);
        } catch (Exception e) {
            LOG.error(e);
            LOG.info(String.format(""));
        }
    }

    public String getConfigProperty(String key) {
        return this.properties.getProperty(key);
    }
}