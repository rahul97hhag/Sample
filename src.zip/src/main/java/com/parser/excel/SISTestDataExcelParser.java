package com.parser.excel;


import org.apache.log4j.Logger;

import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class SISTestDataExcelParser {

    private ExcelParser excelParser = null;
    private String[] exclusiveSheets = null;
    private static final Logger LOG = Logger.getLogger(SISTestDataExcelParser.class);

    public SISTestDataExcelParser(String path) {
        this.excelParser = new ExcelParser(path);
    }

    public SISTestDataExcelParser(String path, String[] exclusiveSheets) {
        this.excelParser = new ExcelParser(path);
        this.exclusiveSheets = exclusiveSheets;
    }

    public String getDataFromTestDataFile(String text) {
        return null;
    }

    private int getColumnCount(String sheetName, int rowNum) {
        return 0;
    }

    private Map<String, Integer> getRowColForCellData(String sheetName, String cellData) {
        return null;
    }

    private int getColForCellData(String sheetName, String cellData, int rowNum) {
        return 0;
    }
}