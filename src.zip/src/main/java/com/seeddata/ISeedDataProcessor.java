package com.seeddata;

import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public interface ISeedDataProcessor {

    String seedDataTypeLongTerm = "SD";
    String seedDataTypeShortTerm = "JIT";
    String testCaseColName = "TestCase";
    String testCasesFilterColName = "SeedDataType";

    public List<SeedData> getAllSeedData(String seedDataType);
    public List<SeedData> getAllSeedData(String sheetName, String seedDataType);
    public List<SeedData> getAllSeedData(String[] exclusiveSheetNames, String seedDataType);
}