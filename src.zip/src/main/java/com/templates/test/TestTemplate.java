package com.templates.test;

import com.config.ITestParamsConstants;
import com.parser.textfile.PropertiesFileReader;
import com.report.ExtentReport;
import com.report.IReporter;
import org.apache.log4j.Logger;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.xml.XmlTest;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public abstract class TestTemplate {

    private static IReporter testReport = null;
    private String excelFilePath = null;
    private String commaSeperatedSeedDataSheets = null;
    private String jsonFilePath = null;
    private String propertiesFilePath = null;
    private PropertiesFileReader propertiesFileReader = null;
    private String geminiWebServiceBaseURL = null;
    private static final Logger LOG = Logger.getLogger(TestTemplate.class);

    protected String getExcelFilePath() {
        return this.excelFilePath;
    }

    protected String getCommaSeperatedSeedDataSheets() {
        return this.commaSeperatedSeedDataSheets;
    }

    protected String getJsonFilePath() {
        return this.jsonFilePath;
    }

    protected String getPropertiesFilePath() {
        return this.propertiesFilePath;
    }

    protected PropertiesFileReader getPropertiesFileReader() {
        return this.propertiesFileReader;
    }

    protected IReporter getTestReporter() {
        return TestTemplate.testReport;
    }

    protected String getGeminiWebServiceBaseURL() {
        return this.geminiWebServiceBaseURL;
    }

    protected String getTestParameter(ITestContext testContext, String parameter) {
        String parameterVal = testContext.getCurrentXmlTest().getParameter(parameter) == null
                ? this.propertiesFileReader.getConfigProperty(parameter)
                : testContext.getCurrentXmlTest().getParameter(parameter);
        LOG.info(String.format("Test Execution Input Parameter = %s, Value = %s", parameter, parameterVal));
        return parameterVal;
    }

    @BeforeSuite
    protected void beforeSuite(ITestContext testContext, XmlTest xmlTest) throws Exception {
        LOG.info(String.format(""));
        this.propertiesFilePath = testContext.getCurrentXmlTest().getParameter(ITestParamsConstants.CONFIG_FILE) == null
                ? ITestParamsConstants.CONFIG_FILE
                : testContext.getCurrentXmlTest().getParameter(ITestParamsConstants.CONFIG_FILE);
        this.propertiesFileReader = new PropertiesFileReader(this.propertiesFilePath);
        this.excelFilePath = this.getTestParameter(testContext, ITestParamsConstants.LOCATION_SEEDDATA_EXCEL);
        this.commaSeperatedSeedDataSheets = this.getTestParameter(testContext, ITestParamsConstants.COMMA_SEPARATED_SEEDDATA_SHEETS);
        this.jsonFilePath = this.getTestParameter(testContext, ITestParamsConstants.LOCATION_SEEDDATA_JSON);
        this.geminiWebServiceBaseURL = this.getTestParameter(testContext, ITestParamsConstants.GEMINI_WEBSERVICE_URL);
        String filePath = this.getTestParameter(testContext, ITestParamsConstants.SEEDDATA_EXECUTION_REPORT);
        String extentConfigFile = this.getTestParameter(testContext, ITestParamsConstants.EXTENT_CONFIG_FILE);
        String extentTestVisibilityMode = this.getTestParameter(testContext, ITestParamsConstants.EXTENT_TEST_VISIBILITY_MODE);
        LOG.info(String.format("%s", this.propertiesFilePath));
        LOG.info(String.format("%s", commaSeperatedSeedDataSheets));
        LOG.info(String.format("%s", this.excelFilePath));
        LOG.info(String.format("%s", jsonFilePath));
        LOG.info(String.format("%s", geminiWebServiceBaseURL));
        LOG.info(String.format("%s", filePath));
        LOG.info(String.format("%s", extentConfigFile));
        LOG.info(String.format("%s", extentTestVisibilityMode));
        TestTemplate.testReport = new ExtentReport(filePath, extentConfigFile,
                false, false,
                ExtentReport.ExtentTestVisibilityMode.valueOf(extentTestVisibilityMode));
    }

    @AfterSuite
    protected void afterSuite(ITestContext testContext) {
        LOG.info(String.format(""));
        TestTemplate.testReport.updateTestCaseStatus();
    }

    @BeforeTest
    protected void beforeTest(ITestContext testContext) {
        LOG.info(String.format(""));
        if(((ExtentReport) TestTemplate.testReport).getExtentTestVisibilityMode() == ExtentReport.ExtentTestVisibilityMode.TestNGTestTagAsTestsAtLeft) {
            TestTemplate.testReport.createTestNgXMLTestTag(String.format("%s", testContext.getCurrentXmlTest().getName()));
        }
    }

    @AfterTest
    protected void afterTest(ITestContext testContext) {
        LOG.info(String.format(""));
        TestTemplate.testReport.updateTestCaseStatus();
    }


}