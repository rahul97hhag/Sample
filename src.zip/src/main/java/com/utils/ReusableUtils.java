package com.utils;


import org.apache.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.util.Locale;
import java.util.Properties;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class ReusableUtils {

    private static final Logger LOG = Logger.getLogger(ReusableUtils.class);

    public static Properties getConfigPropertyObject(String fileName) {
        try {
            Properties properties = new Properties();
            FileInputStream fileInputStream = new FileInputStream(fileName);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
            properties.load(inputStreamReader);
            inputStreamReader.close();
            fileInputStream.close();
            return properties;
        } catch (Exception e) {
            return null;
        }
    }

    public String getConfigProperty(String fileName, String keyName) {
        return null;
    }

    public static String getDate(String format) {
        return null;
    }

    public static String addDate(String value) throws Exception {
        return null;
    }

    public static boolean fileExists(String filePath) {
        return false;
    }

    public static boolean makeDir(String filePath) {
        return false;
    }

    public static String getLocalizedKeyValue(Locale locale, String sbaseName, String skey) {
        return null;
    }

    public static int getResponseCode(String url) throws MalformedURLException, IOException {
        return 0;
    }

    public static String encodeString2Base64(String text2Encode) {
        return null;
    }

    public static String decodeString2Base64(String text2Decode) {
        return null;
    }

    public static String generateRandomNumeric(int count) {
        return null;
    }

    public static String generateRandomAlphabet(int count) {
        return null;
    }

}