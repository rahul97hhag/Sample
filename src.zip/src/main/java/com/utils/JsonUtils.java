package com.utils;


import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class JsonUtils {

    private static final Logger LOG = Logger.getLogger(JsonUtils.class);

    public Object getJsonFileAsObject(String filePath) throws Exception {
        return null;
    }

    public String getValueFromJsonObject(String json, String key) throws Exception {
        return null;
    }

    public JSONObject returnJsonObjectFromString(String json) throws Exception {
        return null;
    }

    public JSONArray returnJsonArrayFromString(String json) throws Exception {
        return null;
    }

    public JSONObject getSubJsonElementFromJsonObject(String json, String key) throws Exception {
        return null;
    }




}