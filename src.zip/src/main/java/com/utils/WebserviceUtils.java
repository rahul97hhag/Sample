package com.utils;

import com.report.IReporter;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import org.apache.log4j.Logger;

import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class WebserviceUtils {

    private static final Logger LOG = Logger.getLogger(WebserviceUtils.class);
    protected String token = null;
    protected String baseURL = null;
    protected IReporter reporter = null;
    protected JsonUtils jsonUtils = new JsonUtils();
    protected Map<String, Object> mapWebServiceResponses = null;

    protected WebserviceUtils(String baseURL) {
        this.baseURL = baseURL;
        RestAssured.baseURI = this.baseURL;
    }

    protected Response runWebServiceRequest(String contentType, String payload, String endPoint, Method requestType) {
        return null;
    }

    protected Map<String, Object> getWebServiceResponses() {
        return this.mapWebServiceResponses;
    }
}