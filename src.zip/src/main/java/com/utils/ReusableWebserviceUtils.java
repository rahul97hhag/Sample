package com.utils;


import io.restassured.response.Response;
import org.apache.log4j.Logger;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public abstract class ReusableWebserviceUtils extends WebserviceUtils {

    private static final Logger LOG = Logger.getLogger(ReusableWebserviceUtils.class);

    protected ReusableWebserviceUtils(String baseURL) {
        super(baseURL);
    }

    protected String getUserSessionOrg(String response, String orgName) {
        return null;
    }

    protected Response saveInsuranceCarrier() throws Exception {
        return null;
    }

    protected Response insertInsuranceClaimOffice() throws Exception {
        return null;
    }

    protected Response saveInsurancePlan() throws Exception {
        return null;
    }

    protected Response getFeeScheduleByCptCode() throws Exception {
        return null;
    }

    protected Response getICDCode() throws Exception {
        return null;
    }

    protected Response createJustAPatient() throws Exception {
        return null;
    }

    protected Response CreateCaseSummary() throws Exception {
        return null;
    }

    protected Response getRoomsForOrganization() throws Exception {
        return null;
    }


}