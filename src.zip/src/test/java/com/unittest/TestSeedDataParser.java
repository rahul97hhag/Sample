package com.unittest;

import com.parser.excel.ExcelParser;
import com.seeddata.ISeedDataProcessor;
import com.seeddata.SeedData;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 4/19/2020.
 */
public class TestSeedDataParser {

    String filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\";
    String excelSheetName = "TestData.xlsx";

    private static final Logger LOG = Logger.getLogger(TestSeedDataParser.class);
    private ExcelParser excelParser = new ExcelParser(filePath + excelSheetName );
    private String sheetName = "SeedData";
    private String seedDataType = "SD";

    @Test(enabled = true)
    public void readTestData() {
        List<SeedData> seedDataList = new ArrayList<>();
        if(!(seedDataType.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm)) || seedDataType.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm)) {
            throw  new RuntimeException(String.format("The Input Parameter - %s is not valid. The allowed parameters should be one among - %s, %s", seedDataType, ISeedDataProcessor.seedDataTypeLongTerm, ISeedDataProcessor.seedDataTypeShortTerm));
        }
        List<String> columns = this.excelParser.getAllColumnNamesAfterColumn(sheetName, ISeedDataProcessor.testCasesFilterColName);
        LOG.info(String.format("Column names to be parsed are %s", columns));
        for(String col: columns) {
            LOG.info(String.format(" %s", col));
            List<Integer> testCaseRowNums = this.excelParser.getCellsRowNumber(sheetName, ISeedDataProcessor.testCasesFilterColName, seedDataType);
            LOG.info(String.format("Rows selected from sheet - %s, Are - %s", sheetName, testCaseRowNums));
            for(int testCaseRowNum: testCaseRowNums) {
                LOG.info(String.format("Rows - %d", testCaseRowNum));
                String testCase = this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName, testCaseRowNum);
                LOG.info(String.format("Test Case Selected - %s, At Row Number - %d", testCase, testCaseRowNum));
                List<Integer> usedRangeRowNums = this.excelParser.getUsedRangeRowNumbers(sheetName, ISeedDataProcessor.testCaseColName, testCase);
                LOG.info(String.format("Used Range of rows for test case %s", usedRangeRowNums));
                for(int usedRangeRowNum: usedRangeRowNums) {
                    Map<String, Map<String, String>> mapColSubColDataPair = new LinkedHashMap<String, Map<String, String>>();
                    for(String colName: columns) {
                        if(!this.excelParser.isColumnEmpty(sheetName, colName, usedRangeRowNum)) {
                            Map<String, String> mapSubColDataPair = new LinkedHashMap<String, String>();
                            List<Integer> listSpannedColNums = this.excelParser.getMergedColumnNumbers(sheetName, colName);
                            LOG.info(String.format("Spanned column numbers for column - %s - %s", colName, listSpannedColNums));
                            for(int colNum : listSpannedColNums) {
                                String subColName = this.excelParser.getCellData(sheetName, colNum, 2);
                                LOG.info(String.format("Column - %s has sub column - %s at column number - %d", colName, subColName, colNum));
                                String testColData = this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName, testCase, colName, subColName, usedRangeRowNum);
                                LOG.info(String.format("Text at row number - %d, for %s at colName - %s, subColName - %s = %s", usedRangeRowNum, testCase, colName, subColName, testColData));
                                mapSubColDataPair.put(subColName, testColData);
                                LOG.info(String.format("map for subColName - %s and testColData - %s was added to map - %s", subColName, testColData, "mapSubColDataPair"));
                            }
                            mapColSubColDataPair.put(colName, mapSubColDataPair);
                            LOG.info(String.format("map for colName - %s and map - %s was added to map - %s", colName, "mapSubColDataPair", "mapColSubColDataPair"));
                        }
                    }
                    SeedData seedData = new SeedData(testCase, usedRangeRowNum, mapColSubColDataPair);
                    LOG.info(String.format("Seed Data was created with information - %s", seedData.toString()));
                    seedDataList.add(seedData);
                    LOG.info(String.format("Seed Data was added to list - %s", seedDataList));
                }
            }
        }
    }
}