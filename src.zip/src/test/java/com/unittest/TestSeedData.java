package com.unittest;


import com.templates.test.TestTemplate;
import com.seeddata.ISeedDataProcessor;
import com.seeddata.SeedData;
import com.seeddata.WebServiceSeedDataProcessor;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Created by BhavaniPrasadReddy on 4/19/2020.
 */
public class TestSeedData extends TestTemplate {
    private static final Logger LOG = Logger.getLogger(TestSeedData.class);

    @Test(enabled = true)
    public void testGetAllSeedData() {
        ISeedDataProcessor seedDataProcessor = new WebServiceSeedDataProcessor(this.getExcelFilePath(), this.getJsonFilePath());
        String commaSeparatedSeedDataSheets = this.getCommaSeperatedSeedDataSheets();
        LOG.info(commaSeparatedSeedDataSheets);
        for(String sheetName: commaSeparatedSeedDataSheets.split(",")) {
            List<SeedData> seedDataList = seedDataProcessor.getAllSeedData(sheetName, ISeedDataProcessor.seedDataTypeLongTerm);
            for(SeedData seedData : seedDataList) {
                String testCase = seedData.getTestCase();
                int rowNum = seedData.getRowNumber();
                String colName = null;
                LOG.info(seedData.getMapOperNameParamValueKVPair().toString());
                Map<String, Map<String, String>> wsNameAttrValPair = seedData.getMapOperNameParamValueKVPair();
                for(Entry<String, Map<String, String>> entry: wsNameAttrValPair.entrySet()) {
                    colName = entry.getKey();
                    Map<String, String> subColNameValueKP = entry.getValue();
                    for(Entry<String, String> entrySubColVal: subColNameValueKP.entrySet()) {
                        String subColName = entrySubColVal.getKey();
                        String subColValue = entrySubColVal.getValue();
                        LOG.info(String.format("Test Case = %s, rowNumber = %d, colName = %s, subColName = %s, subColValue = %s", testCase, rowNum, colName, subColName, subColValue));
                    }
                }
            }
        }
    }

}