package com.unittest;

import com.templates.test.TestTemplate;
import com.seeddata.ISeedDataProcessor;
import com.seeddata.SeedData;
import com.seeddata.WebServiceSeedDataProcessor;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class DLUExecution extends TestTemplate {
    private static final Logger LOG = Logger.getLogger(DLUExecution.class);

    @Test(enabled = true)
    public void executeDataLoadUtility() {
        ISeedDataProcessor seedDataProcessor = new WebServiceSeedDataProcessor(this.getExcelFilePath(), this.getJsonFilePath());
        String commaSeperatedSeedDataSheets = this.getCommaSeperatedSeedDataSheets();
       // LOG.info(commaSeperatedSeedDataSheets);
        System.out.println("21 :: "+commaSeperatedSeedDataSheets);

        for(String sheetName : commaSeperatedSeedDataSheets.split(",")) {
         //   LOG.info("");
            LOG.info(sheetName);
            List<SeedData> listSeedData = seedDataProcessor.getAllSeedData(sheetName, ISeedDataProcessor.seedDataTypeLongTerm);
            for(SeedData seedData: listSeedData) {
                System.out.println(seedData);
                Map<String, Map<String, String>> webServiceNameAttrValPair = seedData.getMapOperNameParamValueKVPair();
                for(Entry<String, Map<String, String>> entryWSNameAttrValPair : webServiceNameAttrValPair.entrySet()) {
                    String webServiceReference = entryWSNameAttrValPair.getKey();
                    LOG.info(String.format("%s", webServiceReference));
                    Map<String, String> subColNameValKeyPair = entryWSNameAttrValPair.getValue();


                    switch (webServiceReference) {
                        case "RoomDetails":
                            LOG.info(String.format("%s %s", subColNameValKeyPair.get("facility"), subColNameValKeyPair.get("roomName")));
                            break;
                        case "InsuranceCreation":
                            // RelationshipToSubscriber	insuranceFirstName	insuranceLastName	gender	SubscriberID	facility	insuranceName	planName	Insurance Classification	officeName	line1	city	contactName	phone	zip	extendedZip	state	generateTrue

                            break;
                        case "PatientCreation":
                            // facility	firstName	lastName	procedureDt	physicianUser	roomName	startTime	endTime	appointmentType	cptCode	Laterality	anesthesiaType	address1	address2	zipCode	guarantorFirstName	guarantorLastName	guarantorDateOfBirth	guarantorCountry	guarantorIsActive	primaryGuarantor	secondaryGuarantor	CarrierName

                            break;
                    }

                }
            }
        }

        /*
        for(int index = 0; index < 10; index++) {
            this.getTestReporter().initTestCase(String.format("%s[%d]", "Test Case One", (index + 1) ));
            this.getTestReporter().logSuccess("Step One", "Successfully executed step one");
            this.getTestReporter().logSuccess("Step Two", "Successfully executed step two");
            this.getTestReporter().logSuccess("Step Three", "Successfully executed step three");
            this.getTestReporter().logSuccess("Step Four", "Successfully executed step four");
            this.getTestReporter().logSuccess("Step Five", "Successfully executed step five");
            this.getTestReporter().logSuccess("Step Six", "Successfully executed step six");
            this.getTestReporter().logSuccess("Step Seven", "Successfully executed step seven");
            this.getTestReporter().logSuccess("Step Eight", "Successfully executed step eight");
            this.getTestReporter().logSuccess("Step Nine", "Successfully executed step nine");
            this.getTestReporter().logSuccess("Step Ten", "Successfully executed step ten");
        }
       */


    }
}