package com.unittest;

import com.parser.excel.ExcelParser;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;

/**
 * Created by BhavaniPrasadReddy on 4/19/2020.
 */
public class TestExcelParser {
    String filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\";
    String excelSheetName = "TestData.xlsx";

    private static final Logger LOG = Logger.getLogger(TestExcelParser.class);
    private ExcelParser excelParser = new ExcelParser(filePath + excelSheetName );
    private String sheetName = "SeedData";

    @Test(enabled = true)
    public void testRange() {
        LOG.info(String.format("Total Row Count = %d", this.excelParser.getRowCount(sheetName)));
        LOG.info(String.format("Total Column Count = %d", this.excelParser.getColumnCount(sheetName)));
    }

    @Test(enabled = true)
    public void testReadData() {
        LOG.info(String.format("Text = %s", this.excelParser.getCellData(sheetName, "TestCase", 3)));
        LOG.info(String.format("Text = %s", this.excelParser.getCellData(sheetName, 1, 3)));
        LOG.info(String.format("Text = %s", this.excelParser.getCellData(sheetName, "RoomDetails", 2)));
        LOG.info(String.format("Text = %s", this.excelParser.getCellData(sheetName, "RoomDetails", 3)));
        LOG.info(String.format("Text = %s", this.excelParser.getCellData(sheetName, "PatientCreation", "Laterality", 3)));
    }


}