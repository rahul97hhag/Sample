const fs = require('fs');
const rawToParsed1 = JSON.parse(fs.readFileSync('./users_one.json'));
const rawToParsed2 = JSON.parse(fs.readFileSync('./users_two.json'));

/* function will run if params are JSON arrays
   assumes array elements are objects
   this may not be a safe assumption, moving forward until
   refactor is necessary */

function arrayDiff(arr1, arr2) {
    const arrDiffCollection = [];
    for (var i = 0; i < arr1.length || i < arr2.length; i++) {
        const diff = computeDiff(arr1[i], arr2[i]);
        arrDiffCollection.push(diff);
    }
    return arrDiffCollection;
}

/* function will run if params are JSON objects
   performance note: instead of iterating over the properties of each object,
   we produce a set of unique properties from the objects
   doing this should be more performant than doing the computeDiff twice,
   since computeDiff has a chance of needing to call objectDiff again,
   even though the two objects have already been diff'd */

function objectDiff(object1, object2) {
    let diff = {};
    let differ = false;
    let keys = new Set(Object.keys(object1));

    for (let key in object2) {
        keys.add(key);
    }
    for (let key of keys) {
        let foundDiff = computeDiff(object1[key], object2[key]);
        if (foundDiff) {
            diff[key] = foundDiff;
            differ = true;
        }
    }
    if (differ) {
        return diff;
    }
}

/* function is essentially the 'brains' of the algorithm, it
   compares two 'things'
    checks that the params are not primitives
     if true, confirm the params are arrays &
     return the output of params passed to arrayDiff
    otherwise, return the output of params passed to objectDiff
   checks if params are not equal
     if true, return an array with both items
   if 'things' are equal, don't return anything (there's no diff) */

function computeDiff(thing1, thing2) {
    if (typeof thing1 === 'object' && typeof thing2 === 'object') {
        if (Array.isArray(thing1) && Array.isArray(thing2)) {
            return arrayDiff(thing1, thing2);
        }
        return objectDiff(thing1, thing2);
    }
    if (thing1 !== thing2) {
        return [thing1, thing2];
    }
}

console.log(
    'These arrays represent the elements that are different in the test JSON files. null represents missing elements:',
    JSON.stringify(computeDiff(rawToParsed1, rawToParsed2), null, 2)
);



