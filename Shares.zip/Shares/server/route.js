const express = require('express');
const app = express();
const fs = require('fs');
const routes = express.Router();
const sharesInformation = require("../sharedFiles/shares_details.json");

const nseSharesFileName = "../sharedFiles/bhav_copy.csv";
const bseSharesFileName = "../sharedFiles/EQ_ISINCODE_090420.CSV";
let nseSharesData = [];
let bseSharesData = [];

function getFileContent(filePath) {
	return new Promise(function(resolve, reject) {
		let fileContent = "";
		let lineReader = require("readline").createInterface({
			input: fs.createReadStream(filePath)
		});

		lineReader.on('line', function(line) {
			if(!(line === '')) {
				fileContent = fileContent + line + "\n";
			}
		});

		lineReader.on('close', function() {
			resolve(fileContent);
		});

	});
}

function convertCsvToJson(csvData) {
	return new Promise(function(resolve, reject) {
		var jsonContent = [];
		var csvArray = csvData.split("\n");
		var csvColumns = csvArray[0].split(",");
		csvArray.forEach(function(csvRow) {
			var csvRowArray = csvRow.split(",");
			var jsonRow = new Object();
			for(var colNum = 0; colNum < csvRowArray.length; colNum++) {
				var colData = csvRowArray[colNum].replace(/^['"]|['"]$/g, "");
				jsonRow[csvColumns[colNum]] = colData;
			}
			jsonContent.push(jsonRow);
		});
		resolve(jsonContent);
	});


}


routes.route('/getAllBSEShares').get(async function(req, res) {
	let csvContent = await getFileContent(bseSharesFileName);
	// console.log(csvContent);
	bseSharesData = await convertCsvToJson(csvContent);
	// console.log(JSON.stringify(sharesData));
	return res.status(200).json(bseSharesData);
});


routes.route('/getAllNSEShares').get(async function(req, res) {
	let csvContent = await getFileContent(nseSharesFileName);
	// console.log(csvContent);
	nseSharesData = await convertCsvToJson(csvContent);
	// console.log(JSON.stringify(sharesData));
	return res.status(200).json(nseSharesData);
});

routes.route('/getGatheredInformation').get(async function(req, res) {
	return res.status(200).json(sharesInformation);
});


module.exports = routes;

