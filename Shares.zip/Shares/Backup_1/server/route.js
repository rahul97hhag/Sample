const express = require('express');
const app = express();
const fs = require('fs');
const routes = express.Router();

const fileName = "../sharedFiles/bhav_copy.csv";
let sharesData = [];

function getFileContent(filePath) {
	return new Promise(function(resolve, reject) {
		let fileContent = "";
		let lineReader = require("readline").createInterface({
			input: fs.createReadStream(filePath)
		});

		lineReader.on('line', function(line) {
			if(!(line === '')) {
				fileContent = fileContent + line + "\n";
			}
		});

		lineReader.on('close', function() {
			resolve(fileContent);
		});

	});
}

function convertCsvToJson(csvData) {
	return new Promise(function(resolve, reject) {
		var jsonContent = [];
		var csvArray = csvData.split("\n");
		var csvColumns = csvArray[0].split(",");
		csvArray.forEach(function(csvRow) {
			var csvRowArray = csvRow.split(",");
			var jsonRow = new Object();
			for(var colNum = 0; colNum < csvRowArray.length; colNum++) {
				var colData = csvRowArray[colNum].replace(/^['"]|['"]$/g, "");
				jsonRow[csvColumns[colNum]] = colData;
			}
			jsonContent.push(jsonRow);
		});
		resolve(jsonContent);
	});


}




routes.route('/getAllShares').post(function(req, res) {
	res.status(200).json({'res': 'success'});
});

routes.route('/getAllShares').get(async function(req, res) {
	let csvContent = await getFileContent(fileName);
	// console.log(csvContent);
	sharesData = await convertCsvToJson(csvContent);
	// console.log(JSON.stringify(sharesData));
	return res.status(200).json(sharesData);
});

module.exports = routes;

