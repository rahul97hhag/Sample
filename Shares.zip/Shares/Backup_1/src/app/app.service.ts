import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

import {Observable} from "rxjs/Observable";
import 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class SharesDataService {
    public endpoint_url:String = "http://localhost:3000/";
    constructor(private http: HttpClient) {
    }

    getAllSharesData(): Observable<any> {
        const url = 'getAllShares';
        // return this.http.get("http://localhost:3000"+url).map(res => res.json());
        return this.http.get(this.endpoint_url+url)
                        .map((response) => {
                            return response;
                        });
    }
}
