import { Component, OnInit } from '@angular/core';
import {SharesDataService} from '../../../app.service';

@Component({
    selector: 'app-nse-shares',
    templateUrl: './nse_shares.component.html',
    styleUrls: ['./nse_shares.component.css']
})
export class NseSharesComponent implements OnInit {
    public nseSharesData = [];
    constructor(
        private sharesDataService: SharesDataService
    ) {
        console.log("NSE Shares Component Created");
    }

    ngOnInit() {
        this.getNSESharesData();
    }

    getNSESharesData() {
        this.sharesDataService.getAllNSESharesData().subscribe((data) => {
            this.nseSharesData = data;
            console.log("Getting shares data");
            console.log(this.nseSharesData);
        });
    }
}

