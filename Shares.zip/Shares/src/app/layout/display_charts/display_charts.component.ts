import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-display-charts',
    templateUrl: './display_charts.component.html',
    styleUrls: ['./display_charts.component.css']
})
export class DisplayChartsComponents implements OnInit {

    constructor(

    ) {

    }

    ngOnInit(): void {
        console.log("App Component Initialized ..");

    }




}
