import { Component, OnInit } from '@angular/core';
import {SharesDataService} from '../../../app.service';

@Component({
    selector: 'app-bse-shares',
    templateUrl: './bse_shares.component.html',
    styleUrls: ['./bse_shares.component.css']
})
export class BseSharesComponent implements OnInit {
    public bseSharesData = [];

    constructor(private sharesDataService: SharesDataService) { }

    ngOnInit() {
        this.getBSESharesData();
    }

    getBSESharesData() {
        this.sharesDataService.getAllBSESharesData().subscribe((data) => {
            this.bseSharesData = data;
            console.log("Getting shares data");
            console.log(this.bseSharesData);
        });
    }

}
