import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-bank-shares',
    templateUrl: './bank_shares.component.html',
    styleUrls: ['./bank_shares.component.css']
})
export class BankSharesComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}

