import { Component, OnInit } from '@angular/core';
import {SharesDataService} from '../../../app.service';

@Component({
    selector: 'app-gathered-information',
    templateUrl: './gathered_information.component.html',
    styleUrls: ['./gathered_information.component.css']
})
export class GatheredInformationComponent implements OnInit {
    public gatheredInformation = [];

    constructor(private sharesDataService: SharesDataService) { }

    ngOnInit() {
        this.getGatheredInformation();
    }

    getGatheredInformation() {
        this.sharesDataService.getGatheredInformation().subscribe((data) => {
            this.gatheredInformation = data;
            console.log("Getting shares data");
            console.log(this.gatheredInformation);
        });
    }
}

//

/*


    constructor() { }

    ngOnInit() {

    }

    getBSESharesData() {

    }

 */
