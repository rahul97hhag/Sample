import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisplayChartsRoutingModule } from './display_charts-routing.module';

import {BankSharesComponent} from "./bank_shares/bank_shares.component";
import {PetrolSharesComponent} from "./petrol_shares/petrol_shares.component";
import {SoftwareSharesComponent} from "./software_shares/software_shares.component";
import {NseSharesComponent} from "./nse_shares/nse_shares.component";
import {BseSharesComponent} from "./bse_shares/bse_shares.component";
import { GatheredInformationComponent } from './gathered_information/gathered_information.component';
import { AutomobileSharesComponent} from "./automobile_shares/automobile_shares.component";
import { DisplayChartsComponents } from './display_charts.component';
import { ChartsModule } from 'ng2-charts';

@NgModule({
    imports: [
        CommonModule,
        ChartsModule,
        DisplayChartsRoutingModule
    ],
    declarations: [
        AutomobileSharesComponent,
        BankSharesComponent,
        BseSharesComponent,
        NseSharesComponent,
        GatheredInformationComponent,
        PetrolSharesComponent,
        SoftwareSharesComponent,
        DisplayChartsComponents
    ]
})
export class DisplayChartsModule {}
