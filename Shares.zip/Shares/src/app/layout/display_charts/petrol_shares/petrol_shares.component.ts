import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-petrol-shares',
    templateUrl: './petrol_shares.component.html',
    styleUrls: ['./petrol_shares.component.css']
})
export class PetrolSharesComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}

