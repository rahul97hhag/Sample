import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-software-shares',
    templateUrl: './software_shares.component.html',
    styleUrls: ['./software_shares.component.css']
})
export class SoftwareSharesComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}

