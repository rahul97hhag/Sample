import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutomobileSharesComponent} from "./automobile_shares/automobile_shares.component";
import {BankSharesComponent} from "./bank_shares/bank_shares.component";
import {PetrolSharesComponent} from "./petrol_shares/petrol_shares.component";
import {SoftwareSharesComponent} from "./software_shares/software_shares.component";
import {NseSharesComponent} from "./nse_shares/nse_shares.component";
import {BseSharesComponent} from "./bse_shares/bse_shares.component";
import { GatheredInformationComponent } from './gathered_information/gathered_information.component';
import { DisplayChartsComponents } from './display_charts.component';

const routes: Routes = [
    { path: '', component: DisplayChartsComponents },
    { path: 'automobile', component: AutomobileSharesComponent },
    { path: 'bank', component: BankSharesComponent },
    { path: 'bse', component: BseSharesComponent },
    { path: 'nse', component: NseSharesComponent },
    { path: 'gathered', component: GatheredInformationComponent },
    { path: 'petrol', component: PetrolSharesComponent },
    { path: 'software', component: SoftwareSharesComponent },


];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class DisplayChartsRoutingModule {
}
