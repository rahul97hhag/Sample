package com.bhavani.json_comparison;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.bhavani.json_comparison.JSONComparator;
import com.bhavani.json_comparison.JSONComparisonResult;
import com.bhavani.json_comparison.difference.asserts.OnlyDifferentValueOnFields;
import com.bhavani.json_comparison.util.file.FileContentReader;

public class SampleDogComparisonTest {

    @Test
    public void compareEqualDogsTest() {
        String actualDog = FileContentReader.readFromFile("dogs/actualDog.json");
        String expectedDog = FileContentReader.readFromFile("dogs/expectedEqualDog.json");
        JSONComparisonResult result = JSONComparator.compare(expectedDog, actualDog);
        Assert.assertFalse(result.areEqual());
        OnlyDifferentValueOnFields.check(result, ".lastReadTime");
    }

    @Test
    public void compareDifferentDogsTest() {
        String actualDog = FileContentReader.readFromFile("dogs/actualDog.json");
        String expectedDog = FileContentReader.readFromFile("dogs/expectedDifferentDog.json");
        JSONComparisonResult result = JSONComparator.compare(expectedDog, actualDog);
        Assert.assertFalse(result.areEqual());
        OnlyDifferentValueOnFields.check(result, ".lastReadTime");
    }

}
