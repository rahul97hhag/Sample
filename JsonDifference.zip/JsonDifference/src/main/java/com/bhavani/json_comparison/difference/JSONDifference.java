package com.bhavani.json_comparison.difference;

public interface JSONDifference {
	
	public String getMessage();
	
}
