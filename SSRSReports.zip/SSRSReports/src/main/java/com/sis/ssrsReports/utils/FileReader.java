package com.sis.ssrsReports.utils;

import com.sis.ssrsReports.model.OnlineCourse;

import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public class FileReader {

    public static List<String> readCsvFile() {
        return null;
    }
}