package com.sis.ssrsReports.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public class PropertiesReader {

    Properties properties = null;

    public PropertiesReader(String fileName) {
        loadPropertiesFile(fileName);
    }

    public void loadPropertiesFile(String fileName) {
        String folderPath = System.getProperty("user.dir") + "\\config\\";
        try (InputStream input = new FileInputStream(folderPath + fileName)) {
            properties = new Properties();
            properties.load(input);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getProperty(String key) {
        return this.properties.getProperty(key);
    }
}