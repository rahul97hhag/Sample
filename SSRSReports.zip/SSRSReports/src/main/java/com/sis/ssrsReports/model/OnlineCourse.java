package com.sis.ssrsReports.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public class OnlineCourse implements Comparable<OnlineCourse> {
    String title;
    String author;
    int price;

    public OnlineCourse() {

    }

    public String getTitle() {
        return title;
    }

    @JsonProperty("Title")
    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    @JsonProperty("Author")
    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPrice() {
        return price;
    }

    @JsonProperty("Price")
    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public int compareTo(OnlineCourse o) {
        return this.title.compareTo(o.title);
    }

    @Override
    public String toString() {
        return "OnlineCourse{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OnlineCourse)) return false;

        OnlineCourse that = (OnlineCourse) o;

        if (getPrice() != that.getPrice()) return false;
        if (!getTitle().equals(that.getTitle())) return false;
        return getAuthor().equals(that.getAuthor());
    }

    @Override
    public int hashCode() {
        int result = getTitle().hashCode();
        result = 31 * result + getAuthor().hashCode();
        result = 31 * result + getPrice();
        return result;
    }
}