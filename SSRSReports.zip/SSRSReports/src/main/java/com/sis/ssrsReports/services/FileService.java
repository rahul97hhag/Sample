package com.sis.ssrsReports.services;

import com.sis.ssrsReports.model.OnlineCourse;

import java.io.IOException;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public interface FileService {

    List<OnlineCourse> readFileIntoList(String fileName) throws IOException;
    void sortList(List<OnlineCourse> list);
}
