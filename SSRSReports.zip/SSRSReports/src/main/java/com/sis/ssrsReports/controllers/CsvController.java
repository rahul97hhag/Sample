package com.sis.ssrsReports.controllers;

import com.sis.ssrsReports.model.OnlineCourse;
import com.sis.ssrsReports.services.FileService;
import com.sis.ssrsReports.services.impl.CsvService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
@Controller
public class CsvController {

    @Autowired
    FileService fileService;

    public CsvController() {

    }

    public List<OnlineCourse> readCsvFile(String fileName) throws IOException {
        fileService = new CsvService();
        return fileService.readFileIntoList(fileName);
    }

    public List<OnlineCourse> getSortedCsvFile(String fileName) throws IOException {
        List<OnlineCourse> onlineCourses = readCsvFile(fileName);
        fileService.sortList(onlineCourses);
        return onlineCourses;
    }

}