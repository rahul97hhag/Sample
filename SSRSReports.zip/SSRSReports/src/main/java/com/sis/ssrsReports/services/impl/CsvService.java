package com.sis.ssrsReports.services.impl;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.sis.ssrsReports.model.OnlineCourse;
import com.sis.ssrsReports.services.FileService;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
@Service
public class CsvService implements FileService {

    @Override
    public List<OnlineCourse> readFileIntoList(String filepath) throws IOException {
        CsvMapper csvMapper = new CsvMapper();
        CsvSchema schema = CsvSchema.emptySchema().withHeader();
        ObjectReader oReader = csvMapper.reader(OnlineCourse.class).with(schema);
        List<OnlineCourse> onlineCourseList = new ArrayList<OnlineCourse>();
        try (Reader reader = new FileReader(filepath)) {
            MappingIterator<OnlineCourse> mi = oReader.readValues(reader);
            while (mi.hasNext()) {
                OnlineCourse onlineCourse = mi.next();
                onlineCourseList.add(onlineCourse);                
            }
        }
        return onlineCourseList;
    }

    @Override
    public void sortList(List<OnlineCourse> onlineCourses) {
        Collections.sort(onlineCourses);
    }
}