package com.report;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public interface IReporter {

    void initTestCase(String testCaseName);

    void createTestNgXMLTestTag(String testCaseName);

    void logSuccess(String stepName);
    void logSuccess(String stepName, String stepDescription);
    void logSuccess(String stepName, String stepDescription, String screenshotPath);

    void logFailure(String stepName);
    void logFailure(String stepName, String stepDescription);
    void logFailure(String stepName, String stepDescription, String screenshotPath);

    void logWarning(String stepName);
    void logWarning(String stepName, String stepDescription);
    void logWarning(String stepName, String stepDescription, String screenshotPath);

    void logInfo(String stepName);
    void logInfo(String stepName, String screenshotPath);

    void logException(Throwable ex);
    void logException(Throwable ex, String screenshotPath);

    void logFatal(Throwable ex);
    void logFatal(Throwable ex, String screenshotPath);

    void updateTestCaseStatus();
    void close();

}
