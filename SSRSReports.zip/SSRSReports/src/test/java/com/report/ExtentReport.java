package com.report;


import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.sis.ssrsReports.services.SystemInfo;
import com.sis.ssrsReports.services.impl.MySystemInfo;
import org.slf4j.Logger;
import com.report.IReporter;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class ExtentReport implements IReporter {

    private static Logger LOG = LoggerFactory.getLogger(ExtentReport.class);
    private boolean boolAppendExisting = false;
    private boolean isCompanyLogoRequired = false;
    private ExtentReports objectExtentReport = null;
    private static ThreadLocal<ExtentTest> threadLocalExtentTest = new InheritableThreadLocal();
    private ExtentTestVisibilityMode extentTestVisibilityMode;

    public enum ExtentTestVisibilityMode {
        TestNGTestTagAsTestsAtLeft,
        TestNGTestMethodsAsTestsAtLeft
    }

    public ExtentReport(String filePath, String extentConfigFile, boolean boolAppendExisting, boolean isCompanyLogoRequired, ExtentTestVisibilityMode extentTestVisibilityMode) throws Exception {
        this.boolAppendExisting = boolAppendExisting;
        this.isCompanyLogoRequired = isCompanyLogoRequired;
        this.extentTestVisibilityMode = extentTestVisibilityMode;
        SystemInfo systemInfo = new MySystemInfo();
        Map<String, String> sysInfo = systemInfo.getSystemInfo();
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(filePath);
        LOG.info(extentConfigFile);
        if(extentConfigFile != null) {
            htmlReporter.loadXMLConfig(extentConfigFile);
        }
        htmlReporter.setAppendExisting(this.boolAppendExisting);
        this.objectExtentReport = new ExtentReports();
        this.objectExtentReport.attachReporter(htmlReporter);
        this.objectExtentReport.setSystemInfo("IP", sysInfo.get("IP"));
        this.objectExtentReport.setSystemInfo("Host Name", sysInfo.get("Host Name"));
        this.objectExtentReport.setSystemInfo("User Name", sysInfo.get("User Name"));

    }

    public ExtentTestVisibilityMode getExtentTestVisibilityMode() {
        return this.extentTestVisibilityMode;
    }

    @Override
    public void initTestCase(String testCaseName) {
        ExtentTest extentTest = null;
        if(this.extentTestVisibilityMode == ExtentTestVisibilityMode.TestNGTestMethodsAsTestsAtLeft) {
            extentTest = this.objectExtentReport.createTest(testCaseName);
            ExtentReport.threadLocalExtentTest.set(extentTest);
            LOG.info(String.format("ExtentTest Created -%s Created, with name - %s", objectExtentReport, testCaseName));
        } else if(this.extentTestVisibilityMode == ExtentTestVisibilityMode.TestNGTestTagAsTestsAtLeft) {
            extentTest = ExtentReport.threadLocalExtentTest.get().createNode(testCaseName);
            ExtentReport.threadLocalExtentTest.set(extentTest);
            LOG.info(String.format("Node Created -%s For Test Case %s Started, New ExtentTest - %s", testCaseName, ExtentReport.threadLocalExtentTest.get(), extentTest));
        }
    }

    @Override
    public void createTestNgXMLTestTag(String testCaseName) {
        ExtentTest extentTest = null;
        extentTest = this.objectExtentReport.createTest(testCaseName);
        ExtentReport.threadLocalExtentTest.set(extentTest);
        LOG.info(String.format(""));
    }

    @Override
    public void logSuccess(String stepName) {
        ExtentReport.threadLocalExtentTest.get().log(Status.PASS, stepName);
        LOG.info(String.format(""));
    }

    @Override
    public void logSuccess(String stepName, String stepDescription) {
        ExtentReport.threadLocalExtentTest.get().log(Status.PASS, String.format("StepName - %s, stepDescription - %s", stepName, stepDescription));
        LOG.info(String.format("StepName - %s, stepDescription - %s", stepName, stepDescription));
    }

    @Override
    public void logSuccess(String stepName, String stepDescription, String screenshotPath) {
        try {
            this.takeScreenShot(screenshotPath);
            ExtentReport.threadLocalExtentTest.get().log(Status.PASS, String.format("StepName - %s, stepDescription - %s", stepName, stepDescription), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            LOG.info(String.format("StepName - %s, stepDescription - %s Passed, Screenshot - %s", stepName, stepDescription, screenshotPath));
        } catch (IOException | AWTException e) {
            LOG.error(String.format("Exception encountered - %s ", e.getMessage()));
        }
    }

    @Override
    public void logFailure(String stepName) {
        ExtentReport.threadLocalExtentTest.get().log(Status.FAIL, stepName);
        LOG.info(String.format(""));
    }

    @Override
    public void logFailure(String stepName, String stepDescription) {
        ExtentReport.threadLocalExtentTest.get().log(Status.FAIL, String.format("StepName - %s, stepDescription - %s", stepName, stepDescription));
        LOG.info(String.format("StepName - %s, stepDescription - %s Failed", stepName, stepDescription));
    }

    @Override
    public void logFailure(String stepName, String stepDescription, String screenshotPath) {
        try {
            this.takeScreenShot(screenshotPath);
            ExtentReport.threadLocalExtentTest.get().log(Status.FAIL, String.format("StepName - %s, stepDescription - %s", stepName, stepDescription), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            LOG.info(String.format("StepName - %s, stepDescription - %s Failed, Screenshot - %s", stepName, stepDescription, screenshotPath));
        } catch (IOException | AWTException e) {
            LOG.error(String.format("Exception encountered - %s ", e.getMessage()));
        }
    }

    @Override
    public void logWarning(String stepName) {
        ExtentReport.threadLocalExtentTest.get().log(Status.WARNING, stepName);
        LOG.info(String.format(""));
    }

    @Override
    public void logWarning(String stepName, String stepDescription) {
        ExtentReport.threadLocalExtentTest.get().log(Status.WARNING, String.format("StepName - %s, stepDescription - %s", stepName, stepDescription));
        LOG.info(String.format("StepName - %s, stepDescription - %s Warning", stepName, stepDescription));
    }

    @Override
    public void logWarning(String stepName, String stepDescription, String screenshotPath) {
        try {
            this.takeScreenShot(screenshotPath);
            ExtentReport.threadLocalExtentTest.get().log(Status.WARNING, String.format("StepName - %s, stepDescription - %s", stepName, stepDescription), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            LOG.info(String.format("StepName - %s, stepDescription - %s Failed, Screenshot - %s", stepName, stepDescription, screenshotPath));
        } catch (IOException | AWTException e) {
            LOG.error(String.format("Exception encountered - %s ", e.getMessage()));
        }
    }

    @Override
    public void logInfo(String message) {
        ExtentReport.threadLocalExtentTest.get().log(Status.INFO, message);
        LOG.info(message);
    }

    @Override
    public void logInfo(String message, String screenshotPath) {
        try {
            this.takeScreenShot(screenshotPath);
            ExtentReport.threadLocalExtentTest.get().log(Status.INFO, String.format("StepName - %s", message), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            LOG.info(message);
        } catch (IOException | AWTException e) {
            LOG.error(String.format("Exception encountered - %s ", e.getMessage()));
        }
    }

    @Override
    public void logException(Throwable ex) {
        ExtentReport.threadLocalExtentTest.get().log(Status.ERROR, ex);
        LOG.error(ex.getMessage(), ex);
    }

    @Override
    public void logException(Throwable ex, String screenshotPath) {
        try {
            this.takeScreenShot(screenshotPath);
            ExtentReport.threadLocalExtentTest.get().log(Status.ERROR, ex, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            LOG.info(ex.getMessage(), ex);
        } catch (IOException | AWTException e) {
            LOG.error(String.format("Exception encountered - %s, StackTrace - %s ", e.getMessage(), e.getStackTrace()));
        }
    }

    @Override
    public void logFatal(Throwable ex) {
        ExtentReport.threadLocalExtentTest.get().log(Status.FATAL, ex);
        LOG.warn(ex.getMessage(), ex);
    }

    @Override
    public void logFatal(Throwable ex, String screenshotPath) {
        try {
            this.takeScreenShot(screenshotPath);
            ExtentReport.threadLocalExtentTest.get().log(Status.FATAL, ex, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            LOG.warn(ex.getMessage(), ex);
        } catch (IOException | AWTException e) {
            LOG.error(String.format("Exception encountered - %s, StackTrace - %s ", e.getMessage(), e.getStackTrace()));
        }
    }

    @Override
    public void updateTestCaseStatus() {
        this.objectExtentReport.flush();
    }

    @Override
    public void close() {
        this.objectExtentReport.flush();
    }

    private synchronized void takeScreenShot(String screenShotPath) throws IOException, AWTException {
        Robot robot = new Robot();
        Rectangle rectangle = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage screenFullImage = robot.createScreenCapture(rectangle);
        String format = screenShotPath.substring(screenShotPath.indexOf(".") + 1);
        ImageIO.write(screenFullImage, format, new File(screenShotPath));
    }
}