package com.sis.ssrsReports;

import com.report.IReporter;
import com.sis.ssrsReports.controllers.CsvController;
import com.sis.ssrsReports.model.OnlineCourse;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public class CompareCsvFiles {

    private static IReporter reporter = null;

    @Autowired
    CsvController csvController;

    public CompareCsvFiles(IReporter reporter) {
        this.reporter = reporter;
    }

    @Test
    public void compareCsvFiles(String expectedFile, String actualFile) {
        List<OnlineCourse> expectedList = null;
        List<OnlineCourse> actualList = null;
        try {
            csvController = new CsvController();
            expectedList = csvController.getSortedCsvFile(expectedFile);
            reporter.logSuccess("Loading expected CSV file", "Successfully loaded expected CSV file");
            actualList = csvController.getSortedCsvFile(actualFile);
            reporter.logSuccess("Loading actual CSV file", "Successfully loaded actual CSV file");
        } catch (IOException e) {
            e.printStackTrace();
        }

        reporter.logInfo("Verifying size of expected and actual csv files");
        if(expectedList.size() == actualList.size()) {
            reporter.logSuccess("Expected list and actual list has "+expectedList.size()+" records");
            for(int index = 0; index < expectedList.size(); index++) {
                reporter.logInfo("Comparing "+(index + 1)+" "+expectedList.get(index).getTitle()+" record ");
                if(expectedList.get(index).equals(actualList.get(index))) {
                    reporter.logSuccess("Comparing "+(index + 1)+" "+expectedList.get(index).getTitle()+" record ", "Both records were matching");
                } else {
                    reporter.logFailure("Comparing "+(index + 1)+" "+expectedList.get(index).getTitle()+" record ", "Both records were not matching");
                }
             }
        } else {
            reporter.logFailure("Expected list has "+expectedList.size()+"and actual list has "+expectedList.size()+" records");
        }
    }
}