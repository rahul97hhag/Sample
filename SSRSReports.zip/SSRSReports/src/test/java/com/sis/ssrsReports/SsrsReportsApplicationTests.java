package com.sis.ssrsReports;


import com.sis.ssrsReports.controllers.CsvController;
import com.sis.ssrsReports.model.OnlineCourse;
import com.sis.ssrsReports.utils.PropertiesReader;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SsrsReportsApplication.class)
public class SsrsReportsApplicationTests extends BaseTest {

	private static Logger logger = LoggerFactory.getLogger(SsrsReportsApplicationTests.class);
	public static String configPropertiesFile = "config.properties";

	@Autowired
	CsvController csvController;

	@Test
	@Parameters({"expectedFile", "actualFile"})
	void contextLoads(String expectedFile, String actualFile) {		

		PropertiesReader configProperties = new PropertiesReader(configPropertiesFile);
		String folderPath = System.getProperty("user.dir");
		String expectedFilesPath = folderPath + "\\" + configProperties.getProperty("expectedFolderPath");
		String actualFilesPath = folderPath + "\\" + configProperties.getProperty("actualFolderPath");		
		this.getTestReporter().initTestCase(String.format("%s - %s[%d]", Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getName(), " ", 1));
		if(expectedFile.endsWith(".csv") && actualFile.endsWith(".csv")) {
			CompareCsvFiles compareCsvFiles = new CompareCsvFiles(this.getTestReporter());
			compareCsvFiles.compareCsvFiles(expectedFilesPath + "\\" +expectedFile, actualFilesPath + "\\" +actualFile);
		}
	}

}
