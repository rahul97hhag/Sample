package com.sis.ssrsReports;

import com.report.ExtentReport;
import com.report.IReporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.xml.XmlTest;

import java.lang.reflect.Method;

/**
 * Created by BhavaniPrasadReddy on 4/30/2020.
 */
public abstract class BaseTest extends AbstractTestNGSpringContextTests {

    private static IReporter testReport = null;
    private static final Logger logger = LoggerFactory.getLogger(BaseTest.class);

    protected IReporter getTestReporter() {
        return BaseTest.testReport;
    }

    protected String getTestParameter(ITestContext testContext, String parameter) {
        String parameterVal = testContext.getCurrentXmlTest().getParameter(parameter);
        logger.info(String.format("Test Execution Input Parameter = %s, Value = %s", parameter, parameterVal));
        return parameterVal;
    }

    @BeforeSuite
    public void beforeSuite(ITestContext testContext, XmlTest xmlTest) throws Exception {
        logger.info(String.format(""));
        String filePath = System.getProperty("user.dir") + "\\Reports\\TestReport.html";
        String extentConfigFile = System.getProperty("user.dir") + "\\src\\test\\resources\\" + "extent-config.xml";
        System.out.println(extentConfigFile);
        BaseTest.testReport = new ExtentReport(filePath, extentConfigFile,
                false, false,
                ExtentReport.ExtentTestVisibilityMode.valueOf("TestNGTestMethodsAsTestsAtLeft"));
    }

    @BeforeGroups
    public void beforeGroups() {

    }

    @BeforeClass
    public void beforeClass() {

    }

    @BeforeMethod
    public void beforeMethod(ITestContext testContext, Method m) {
        /*
        logger.info(String.format(""));
        if(BaseTest.testReport instanceof ExtentReporter) {
            if(((ExtentReporter) BaseTest.testReport).getExtentTestVisibilityMode() == ExtentReport.ExtentTestVisibilityMode.TestNGTestTagAsTestsAtLeft) {
                BaseTest.testReport.initTestCase(String.format(""));
            } else if((ExtentReporter) BaseTest.testReport).getExtentTestVisibilityMode() == ExtentReport.ExtentTestVisibilityMode.TestNGTestMethodsAsTestsAtLeft) {
                BaseTest.testReport.initTestCase(String.format(""));
            }
            BaseTest.testReport.logInfo(String.format(""));
        }
        */
    }

    @BeforeTest
    public void beforeTest(ITestContext testContext) {
        logger.info(String.format(""));
        if(((ExtentReport) BaseTest.testReport).getExtentTestVisibilityMode() == ExtentReport.ExtentTestVisibilityMode.TestNGTestTagAsTestsAtLeft) {
            BaseTest.testReport.createTestNgXMLTestTag(String.format("%s", testContext.getCurrentXmlTest().getName()));
        }
    }

    @AfterTest
    public void afterTest(ITestContext testContext) {
        logger.info(String.format(""));
        BaseTest.testReport.updateTestCaseStatus();
    }

    @AfterMethod
    public void afterMethod(ITestContext testContext, ITestResult testResult, Method m) {
        /*
        testReporter.log(LogStatus.PASS, "");
        logger.info(Thread.currentThread().getId()+" "+ m.getName());
        BaseTest.testReport.logInfo(String.format("Thread - %d completes executing test method - %s", Thread.currentThread().getId(), m.getName()));
        BaseTest.testReport.updateTestCaseStatus();
        */
    }

    @AfterClass
    public void afterClass() {

    }

    @AfterGroups
    public void afterGroups() {

    }

    @AfterSuite
    public void afterSuite(ITestContext testContext) {
        logger.info(String.format(""));
        BaseTest.testReport.updateTestCaseStatus();
    }
}





