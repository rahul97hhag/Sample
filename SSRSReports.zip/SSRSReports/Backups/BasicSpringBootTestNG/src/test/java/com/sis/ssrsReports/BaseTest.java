package com.sis.ssrsReports;

import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.xml.XmlTest;

import java.lang.reflect.Method;

/**
 * Created by BhavaniPrasadReddy on 5/2/2020.
 */
public class BaseTest extends AbstractTestNGSpringContextTests {

    @BeforeSuite
    public void beforeSuite(ITestContext testContext, XmlTest xmlTest) throws Exception {

    }

    @BeforeGroups
    public void beforeGroups() {

    }

    @BeforeClass
    public void beforeClass() {

    }

    @BeforeMethod
    public void beforeMethod(ITestContext testContext, Method m) {

    }

    @BeforeTest
    public void beforeTest(ITestContext testContext) {

    }

    @AfterTest
    public void afterTest(ITestContext testContext) {

    }

    @AfterMethod
    public void afterMethod(ITestContext testContext, ITestResult testResult, Method m) {

    }

    @AfterClass
    public void afterClass() {

    }

    @AfterGroups
    public void afterGroups() {

    }

    @AfterSuite
    public void afterSuite(ITestContext testContext) {

    }
}





