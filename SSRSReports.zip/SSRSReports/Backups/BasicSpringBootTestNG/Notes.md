mvn clean compile install test


mvn exec:java -Dexec.mainClass="com.sis.ssrsReports.SsrsReportsApplication"

[INFO] Scanning for projects...
[INFO]
[INFO] ------------------------------------------------------------------------
[INFO] Building SSRSReports 0.0.1-SNAPSHOT
[INFO] ------------------------------------------------------------------------
[INFO]
[INFO] --- exec-maven-plugin:1.6.0:java (default-cli) @ SSRSReports ---

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.9.RELEASE)

2020-05-02 19:50:58 INFO  SsrsReportsApplication - Starting SsrsReportsApplication on Bhavani_Mounica with PID 7240 (G:\Java_Projects\Cigniti_Frameworks\SSRSReports\Backups\BasicSpringBootTestNG\target\classes started by BhavaniPrasadReddy in G:\Java_Projects\Cigniti_Frameworks\SSRSReports\Backups\BasicSpringBootTestNG)
2020-05-02 19:50:58 INFO  SsrsReportsApplication - No active profile set, falling back to default profiles: default
2020-05-02 19:50:59 INFO  SsrsReportsApplication - Started SsrsReportsApplication in 0.808 seconds (JVM running for 3.123)
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 2.101 s
[INFO] Finished at: 2020-05-02T19:50:59+05:30
[INFO] Final Memory: 30M/116M
[INFO] ------------------------------------------------------------------------



 mvn test
[INFO] Scanning for projects...
[INFO]
[INFO] ------------------------------------------------------------------------
[INFO] Building SSRSReports 0.0.1-SNAPSHOT
[INFO] ------------------------------------------------------------------------
[INFO]
[INFO] --- maven-resources-plugin:3.0.2:resources (default-resources) @ SSRSReports ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] Copying 1 resource
[INFO] Copying 1 resource
[INFO]
[INFO] --- maven-compiler-plugin:3.8.0:compile (default-compile) @ SSRSReports ---
[INFO] Nothing to compile - all classes are up to date
[INFO]
[INFO] --- maven-resources-plugin:3.0.2:testResources (default-testResources) @ SSRSReports ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] skip non existing resourceDirectory G:\Java_Projects\Cigniti_Frameworks\SSRSReports\Backups\BasicSpringBootTestNG\src\test\resources
[INFO]
[INFO] --- maven-compiler-plugin:3.8.0:testCompile (default-testCompile) @ SSRSReports ---
[INFO] Nothing to compile - all classes are up to date
[INFO]
[INFO] --- maven-surefire-plugin:2.22.1:test (default-test) @ SSRSReports ---
[INFO]
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running TestSuite

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.9.RELEASE)

2020-05-02 19:51:10 INFO  SsrsReportsApplicationTests - Starting SsrsReportsApplicationTests on Bhavani_Mounica with PID 1436 (G:\Java_Projects\Cigniti_Frameworks\SSRSReports\Backups\BasicSpringBootTestNG\target\test-classes started by BhavaniPrasadReddy in G:\Java_Projects\Cigniti_Frameworks\SSRSReports\Backups\BasicSpringBootTestNG)
2020-05-02 19:51:10 INFO  SsrsReportsApplicationTests - No active profile set, falling back to default profiles: default
2020-05-02 19:51:10 INFO  SsrsReportsApplicationTests - Started SsrsReportsApplicationTests in 0.63 seconds (JVM running for 1.374)
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.334 s - in TestSuite

[INFO]
[INFO] Results:
[INFO]
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 3.365 s
[INFO] Finished at: 2020-05-02T19:51:11+05:30
[INFO] Final Memory: 20M/350M
[INFO] ------------------------------------------------------------------------

























