package com.bhavani;

import org.apache.log4j.Logger;

import java.util.*;

/**
 * Created by BhavaniPrasadReddy on 4/25/2020.
 */
public class WebServiceSeedDataProcessor implements ISeedDataProcessor {

    private ExcelParser excelParser = null;
    private static final Logger LOG = Logger.getLogger(WebServiceSeedDataProcessor.class);
    private SISTestDataExcelParser sisTestDataExcelParser = null;

    public WebServiceSeedDataProcessor(String excelFilePath, String jsonFilePath) {
        this.excelParser = new ExcelParser(excelFilePath, jsonFilePath);
        this.sisTestDataExcelParser = new SISTestDataExcelParser(excelFilePath);
    }

    @Override
    public List<SeedData> getAllSeedData(String seedDataType) {
        List<SeedData> seedDataList = new ArrayList<>();
        List<String> listSheets = this.excelParser.getAllSheets();
        for(String sheetName: listSheets) {
            List<SeedData> listSheetWiseSeedData = this.getAllSeedData(sheetName, seedDataType);
            for(SeedData seedData: listSheetWiseSeedData) {
                seedDataList.add(seedData);
            }
        }
        return seedDataList;
    }

    @Override
    public List<SeedData> getAllSeedData(String sheetName, String seedDataType) {
        List<SeedData> seedDataList = new ArrayList<>();
        if(!(seedDataType.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm)) || seedDataType.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm)) {
            throw  new RuntimeException(String.format("The Input Parameter - %s is not valid. The allowed parameters should be one among - %s, %s", seedDataType, ISeedDataProcessor.seedDataTypeLongTerm, ISeedDataProcessor.seedDataTypeShortTerm));
        }
        List<String> columns = this.excelParser.getAllColumnNamesAfterColumn(sheetName, ISeedDataProcessor.testCasesFilterColName);
        LOG.info(String.format(" "));

        /*
        for(String col: columns) {
            LOG.info(String.format(" %s", col));
        }
        */
        LOG.info(String.format("column names to be parsed are %s", columns));


        Set<Integer> testCaseRowNums = this.sisTestDataExcelParser.getTestCaseRowNumbers(sheetName, ISeedDataProcessor.testCasesFilterColName, seedDataType);
        LOG.info(String.format("Rows selected from sheet %s are %s", sheetName, testCaseRowNums));

        for(int testCaseRowNum: testCaseRowNums) {
            String testCase = this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName, testCaseRowNum);
            LOG.info(String.format("Test case selected %s at row number %d", testCase, testCaseRowNum));
            List<Integer> usedRangeRowNums = this.excelParser.getUsedRangeRowNumbers(sheetName, ISeedDataProcessor.testCaseColName, testCase);
            LOG.info(String.format("Used range of rows for test case %s are %s", testCase, usedRangeRowNums));
            for(int usedRangeRowNum : usedRangeRowNums) {
                if(this.sisTestDataExcelParser.isRowSeededOrJIT(sheetName, ISeedDataProcessor.testCasesFilterColName, seedDataType, usedRangeRowNum)) {
                    Map<String, Map<String, String>> mapColSubColDataPair = new LinkedHashMap<String, Map<String, String>>();
                    for(String colName: columns) {
                        //   LOG.info("58 :: "+colName);
                        if(!(this.sisTestDataExcelParser.isColumnEmpty(sheetName, colName, usedRangeRowNum))) {
                            Map<String, String> mapSubColDataPair = new LinkedHashMap<>();
                            List<Integer> listSpannedColNums = this.excelParser.getMergedColumnNumbers(sheetName, colName);
                            LOG.info(String.format(""));
                            for(int colNum : listSpannedColNums) {
                                String subColName = this.excelParser.getCellData(sheetName, colNum, 2);
                                LOG.info(String.format(""));
                                String testColData = this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName, testCase, colName, subColName, usedRangeRowNum);
                                LOG.info(String.format(""));
                                mapSubColDataPair.put(subColName, testColData);
                                LOG.info(String.format("map for subColName %s and testColData %s was added to map %s", subColName, testColData, "mapSubColDataPair"));
                            }
                            mapColSubColDataPair.put(colName, mapSubColDataPair);
                            LOG.info(String.format(""));
                        }
                    }
                    SeedData seedData = new SeedData(testCase, usedRangeRowNum, mapColSubColDataPair);
                    LOG.info(String.format(""));
                    seedDataList.add(seedData);
                    LOG.info(String.format("Seed Data was added to list %s", "seedDataList"));
                }
            }
        }
        return seedDataList;
    }

}