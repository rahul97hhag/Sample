package com.bhavani;

import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 4/25/2020.
 */
public class SeedData {
    private String testCase = null;
    private int rowNumber = -1;
    Map<String, Map<String, String>> mapOperNameParamValueKVPair = null;

    public SeedData(String testCase, int rowNumber, Map<String, Map<String, String>> mapOperNameParamValueKVPair) {
        this.testCase = testCase;
        this.rowNumber = rowNumber;
        this.mapOperNameParamValueKVPair = mapOperNameParamValueKVPair;
    }

    public String getTestCase() {
        return this.testCase;
    }

    public void setTestCase(String testCase) {
        this.testCase = testCase;
    }

    public int getRowNumber() {
        return this.rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public Map<String, Map<String, String>> getMapOperNameParamValueKVPair() {
        return this.mapOperNameParamValueKVPair;
    }

    public void setMapOperNameParamValueKVPair(Map<String, Map<String, String>> mapOperNameParamValueKVPair) {
        this.mapOperNameParamValueKVPair = mapOperNameParamValueKVPair;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SeedData)) return false;

        SeedData seedData = (SeedData) o;

        if (getRowNumber() != seedData.getRowNumber()) return false;
        if (!getTestCase().equals(seedData.getTestCase())) return false;
        return getMapOperNameParamValueKVPair().equals(seedData.getMapOperNameParamValueKVPair());
    }

    @Override
    public int hashCode() {
        int result = getTestCase().hashCode();
        result = 31 * result + getRowNumber();
        result = 31 * result + getMapOperNameParamValueKVPair().hashCode();
        return result;
    }
}