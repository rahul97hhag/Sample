package com.bhavani;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.json.JSONObject;

import java.util.*;

/**
 * Created by BhavaniPrasadReddy on 4/25/2020.
 */
public class SISTestDataExcelParser {

    private ExcelParser excelParser = null;
    private String[] exclusiveSheets = null;
    private static final Logger LOG = Logger.getLogger(SISTestDataExcelParser.class);

    public SISTestDataExcelParser(String path) {
        this.excelParser = new ExcelParser(path);
    }

    public SISTestDataExcelParser(String path, String[] exclusiveSheets) {
        this.excelParser = new ExcelParser(path);
        this.exclusiveSheets = exclusiveSheets;
    }

    public String getDataFromTestDataFile(String text) {
        // get test data from json
        return null;
    }

    private int getColumnCount(String sheetName, int rowNum) {
        return 0;
    }

    private Map<String, Integer> getRowColForCellData(String sheetName, String cellData) {
        Map<String, Integer> mapRowCol = new HashMap<>();
        int totalRows = this.excelParser.getRowCount(sheetName);
        mapRowCol.put("rowNum", -1);
        mapRowCol.put("colNum", -1);
        for(int rowNum = 1; rowNum <= totalRows; rowNum++) {
            LOG.info(String.format(""));
            int totalColumns = this.excelParser.getColumnCount(sheetName, rowNum);
            for(int colNum = 1; colNum <= totalColumns; colNum++) {
                LOG.info(String.format(""));
                String text = this.excelParser.getCellData(sheetName, colNum, rowNum);
                if(text.equalsIgnoreCase(cellData)) {
                    mapRowCol.put("rowNum", rowNum);
                    mapRowCol.put("colNum", colNum);
                    return mapRowCol;
                }
            }
        }
        return mapRowCol;
    }

    private int getColForCellData(String sheetName, String cellData, int rowNum) {
        int totalColumns = this.excelParser.getColumnCount(sheetName, rowNum);
        for(int colNum = 1; colNum <= totalColumns; colNum++) {
            String text = this.excelParser.getCellData(sheetName, colNum, rowNum);
            if(text.equalsIgnoreCase(cellData)) {
                return colNum;
            }
        }
        return -1;
    }

    private int getTestCaseRowInTestDataSheets(String sheetName, int rowNum) {
        while(!this.excelParser.getCellData(sheetName, 1, rowNum).trim().equalsIgnoreCase("Testcase_Name")) {
            rowNum --;
        }
        return rowNum;
    }

    private int getTestCaseRowInSeedDataSheets(String sheetName, int rowNum) {
        while(this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName, rowNum).trim().isEmpty()) {
            rowNum --;
        }
        return rowNum;
    }

    public boolean isRowSeededOrJIT(String sheetName, String colName, String expectedColValue, int rowNum) {
        LOG.debug(String.format(""));
        String cellData = this.excelParser.getCellData(sheetName, colName, rowNum);
        switch (expectedColValue) {
            case ISeedDataProcessor.seedDataTypeShortTerm:
                return (cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm));
            case ISeedDataProcessor.seedDataTypeLongTerm:
                return (cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm) || cellData.isEmpty());
            default:
                return false;
        }
    }

    public Set<Integer> getTestCaseRowNumbers(String sheetName, String colName, String expectedColValue) {
        LOG.debug(String.format(""));
        List<Integer> listSDRows = new ArrayList<>();
        for(int rowNum = 3; rowNum <= this.excelParser.getRowCount(sheetName); rowNum++) {
            String cellData = this.excelParser.getCellData(sheetName, colName, rowNum);
            switch (expectedColValue) {
                case ISeedDataProcessor.seedDataTypeShortTerm:
                    if(cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm)) {
                        listSDRows.add(rowNum);
                    }
                break;
                case ISeedDataProcessor.seedDataTypeLongTerm:
                    if(cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm) || cellData.isEmpty()) {
                        listSDRows.add(rowNum);
                    }
                break;
            }
        }
        LOG.debug(String.format(""));
        Set<Integer> setTestCaseRows = new HashSet<>();
        for(int sdRow: listSDRows) {
            setTestCaseRows.add(this.getTestCaseRowInSeedDataSheets(sheetName, sdRow));
        }
        LOG.debug("");
        return setTestCaseRows;
    }

    private boolean isTestCaseRowInTestDataSheets(String sheetName, int rowNum) {
        if(this.excelParser.getCellData(sheetName, 1, rowNum).trim().equalsIgnoreCase("Testcase_Name")) {
            return true;
        }
        return false;
    }

    public JSONObject convertToJSON(String sheetName) {
        return null;
    }

    public JSONObject convertToJSONObject(String[] sheetNames) {
        return null;
    }

    public JSONObject convertToJSONObjectWithExcludedFiles(String commaSeparatedSeedDataSheets) {
        return null;
    }

    public JSONObject convertToJSONObjectWithExcludedFiles() {
        return null;
    }

    public String getCellData(String sheetName, int colNum, int rowNum) {
        String text = null;
        try {
            if(rowNum <= 0) {
                LOG.info("");
                return null;
            }
            colNum = colNum -1;
            if(colNum < 0) {
                LOG.info("");
                return null;
            }
            XSSFRow row = excelParser.getSheet(sheetName).getRow(rowNum - 1);
            if(row == null) {
                LOG.info("");
                return null;
            }
            XSSFCell cell = row.getCell(colNum);
            if(cell == null) {
                return "";
            }
            if(cell.getCellType() == CellType.STRING || cell.getCellType() == CellType.FORMULA) {
                LOG.info("");
                text = cell.getStringCellValue();
            } else if(cell.getCellType() == CellType.NUMERIC) {
                String cellText = String.valueOf(cell.getNumericCellValue());
                if(DateUtil.isCellDateFormatted(cell)) {
                    double d = cell.getNumericCellValue();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(DateUtil.getJavaDate(d));
                    cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
                    cellText = cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cellText;
                }
                text = cellText;
            } else if(cell.getCellType() == CellType.BLANK) {
                return "";
            } else {
                text = String.valueOf(cell.getBooleanCellValue());
                return text;
            }
            return text;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean isColumnEmpty(String sheetName, String colName, int rowNum) {
        List<Integer> listSpannedColNums = excelParser.getMergedColumnNumbers(sheetName, colName);
        for(int colNum: listSpannedColNums) {
            if(!(this.getCellData(sheetName, colNum, rowNum).trim().isEmpty())) {
                return false;
            }
        }
        return true;
    }


}