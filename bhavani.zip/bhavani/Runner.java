package com.bhavani;

import java.util.List;
import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 4/25/2020.
 */
public class Runner {

    public static String getMapValuesAsString(Map<String, String> map) {
        StringBuilder values = new StringBuilder();
        for(Map.Entry<String, String> entry: map.entrySet()) {
            values = values.append("|| "+entry.getKey()+" :: "+entry.getValue()+ " || ").append("\n");
        }
        return values.toString();
    }
    
    public void runMethod() {
        String excelPath = "G:\\Java_Projects\\Cigniti_Frameworks\\SIS_WebServices_Three\\Version_One\\TestData_4.xlsx";
        String jsonPath = "G:\\Java_Projects\\Cigniti_Frameworks\\SIS_WebServices_Three\\Version_One\\src\\test\\resources\\testData.json";
        ISeedDataProcessor seedDataProcessor = new WebServiceSeedDataProcessor(excelPath, jsonPath);
        String commaSeperatedSeedDataSheets = "SeedData";
        for (String sheetName : commaSeperatedSeedDataSheets.split(",")) {
            //   System.out.println("");
            System.out.println(sheetName);
            List<SeedData> listSeedData = seedDataProcessor.getAllSeedData(sheetName, ISeedDataProcessor.seedDataTypeLongTerm);
            for (SeedData seedData : listSeedData) {
                // System.out.println(seedData);
                Map<String, Map<String, String>> webServiceNameAttrValPair = seedData.getMapOperNameParamValueKVPair();
                System.out.println(String.format("%s - [%d]", seedData.getTestCase(), seedData.getRowNumber()));
                System.out.println(seedData.getTestCase() + " " + seedData.getRowNumber());
                for (Map.Entry<String, Map<String, String>> entryWSNameAttrValPair : webServiceNameAttrValPair.entrySet()) {
                    String webServiceReference = entryWSNameAttrValPair.getKey();
                    System.out.println(String.format("%s", webServiceReference));
                    Map<String, String> subColNameValKeyPair = entryWSNameAttrValPair.getValue();
                    System.out.println(String.format("<*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*>"));
                    switch (webServiceReference) {

                        case "RoomDetails":

                            System.out.println(String.format("Creating room ", getMapValuesAsString(subColNameValKeyPair)));
                            System.out.println(String.format("Creating room %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                        case "InsuranceCreation":

                            System.out.println(subColNameValKeyPair.get("RelationshipToSubscriber"));
                            System.out.println(subColNameValKeyPair.get("insuranceFirstName"));
                            System.out.println(subColNameValKeyPair.get("insuranceLastName"));
                            System.out.println(subColNameValKeyPair.get("gender"));
                            System.out.println(subColNameValKeyPair.get("SubscriberID"));
                            System.out.println(subColNameValKeyPair.get("facility"));
                            System.out.println(subColNameValKeyPair.get("insuranceName"));
                            System.out.println(subColNameValKeyPair.get("planName"));
                            System.out.println(subColNameValKeyPair.get("Insurance Classification"));
                            System.out.println(subColNameValKeyPair.get("officeName"));
                            System.out.println(subColNameValKeyPair.get("line1"));
                            System.out.println(subColNameValKeyPair.get("city"));
                            System.out.println(subColNameValKeyPair.get("contactName"));
                            System.out.println(subColNameValKeyPair.get("phone"));
                            System.out.println(subColNameValKeyPair.get("zip"));
                            System.out.println(subColNameValKeyPair.get("extendedZip"));
                            System.out.println(subColNameValKeyPair.get("state"));
                            System.out.println(subColNameValKeyPair.get("generateTrue"));

                            System.out.println(String.format("Creating insurance %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                        case "PatientCreation":

                            System.out.println(subColNameValKeyPair.get("facility"));
                            System.out.println(subColNameValKeyPair.get("firstName"));
                            System.out.println(subColNameValKeyPair.get("lastName"));
                            System.out.println(subColNameValKeyPair.get("procedureDt"));
                            System.out.println(subColNameValKeyPair.get("physicianUser"));
                            System.out.println(subColNameValKeyPair.get("roomName"));
                            System.out.println(subColNameValKeyPair.get("startTime"));
                            System.out.println(subColNameValKeyPair.get("endTime"));
                            System.out.println(subColNameValKeyPair.get("appointmentType"));
                            System.out.println(subColNameValKeyPair.get("cptCode"));
                            System.out.println(subColNameValKeyPair.get("Laterality"));
                            System.out.println(subColNameValKeyPair.get("anesthesiaType"));
                            System.out.println(subColNameValKeyPair.get("address1"));
                            System.out.println(subColNameValKeyPair.get("address2"));
                            System.out.println(subColNameValKeyPair.get("zipCode"));
                            System.out.println(subColNameValKeyPair.get("guarantorFirstName"));
                            System.out.println(subColNameValKeyPair.get("guarantorLastName"));
                            System.out.println(subColNameValKeyPair.get("guarantorDateOfBirth"));
                            System.out.println(subColNameValKeyPair.get("guarantorCountry"));
                            System.out.println(subColNameValKeyPair.get("guarantorIsActive"));
                            System.out.println(subColNameValKeyPair.get("primaryGuarantor"));
                            System.out.println(subColNameValKeyPair.get("secondaryGuarantor"));
                            System.out.println(subColNameValKeyPair.get("CarrierName"));
                            System.out.println(subColNameValKeyPair.get("RelationshipToSubscriber"));
                            System.out.println(subColNameValKeyPair.get("insuranceFirstName"));
                            System.out.println(subColNameValKeyPair.get("insuranceLastName"));
                            System.out.println(subColNameValKeyPair.get("gender"));
                            System.out.println(subColNameValKeyPair.get("SubscriberID"));
                            System.out.println(subColNameValKeyPair.get("DischargeByUserName"));
                            System.out.println(subColNameValKeyPair.get("DiagnosisCode"));
                            System.out.println(subColNameValKeyPair.get("Units"));
                            System.out.println(subColNameValKeyPair.get("PeriodName"));
                            System.out.println(subColNameValKeyPair.get("BatchName"));
                            System.out.println(subColNameValKeyPair.get("Amounts"));

                            System.out.println(String.format("Creating patient %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                        case "WorklistAddition":

                            System.out.println(subColNameValKeyPair.get("facility"));
                            System.out.println(subColNameValKeyPair.get("worklistType"));
                            System.out.println(subColNameValKeyPair.get("worklistName"));
                            System.out.println(subColNameValKeyPair.get("generalFlag"));
                            System.out.println(subColNameValKeyPair.get("painFlag"));
                            System.out.println(subColNameValKeyPair.get("giFlag"));
                            System.out.println(subColNameValKeyPair.get("eyeFlag"));
                            System.out.println(subColNameValKeyPair.get("laserFlag"));

                            System.out.println(String.format("Creating worklist %s ", getMapValuesAsString(subColNameValKeyPair)));

                            break;
                        case "ConsentsCreation":
                            System.out.println(subColNameValKeyPair.get("consentName"));
                            System.out.println(subColNameValKeyPair.get("generalFlag"));
                            System.out.println(subColNameValKeyPair.get("painFlag"));
                            System.out.println(subColNameValKeyPair.get("giFlag"));
                            System.out.println(subColNameValKeyPair.get("eyeFlag"));
                            System.out.println(subColNameValKeyPair.get("laserFlag"));
                            System.out.println(subColNameValKeyPair.get("physicianScheduleFlag"));
                            System.out.println(subColNameValKeyPair.get("diagnosisScheduleFlag"));
                            System.out.println(subColNameValKeyPair.get("consentStatementText"));
                            System.out.println(String.format("Creating consents %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                        case "PeriodCreation":
                            System.out.println(subColNameValKeyPair.get("userName"));
                            System.out.println(subColNameValKeyPair.get("password"));
                            System.out.println(subColNameValKeyPair.get("facility"));
                            System.out.println(subColNameValKeyPair.get("periodName"));
                            System.out.println(subColNameValKeyPair.get("periodBeginDate"));
                            System.out.println(subColNameValKeyPair.get("periodEndDate"));
                            System.out.println(subColNameValKeyPair.get("isActive"));
                            System.out.println(subColNameValKeyPair.get("batchName"));
                            System.out.println(subColNameValKeyPair.get("batchDescription"));
                            System.out.println(String.format("Creating period %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                        case "FeeScheduleCreation":
                            System.out.println(subColNameValKeyPair.get("Username"));
                            System.out.println(subColNameValKeyPair.get("Password"));
                            System.out.println(subColNameValKeyPair.get("Facility"));
                            System.out.println(subColNameValKeyPair.get("CPTCode"));
                            System.out.println(subColNameValKeyPair.get("Amount"));
                            System.out.println(subColNameValKeyPair.get("DisplayName"));
                            System.out.println(String.format("Creating feeschedule %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                        case "MedicationCreation":
                            System.out.println(subColNameValKeyPair.get("Username"));
                            System.out.println(subColNameValKeyPair.get("Password"));
                            System.out.println(subColNameValKeyPair.get("Facility"));
                            System.out.println(subColNameValKeyPair.get("Medication"));
                            System.out.println(subColNameValKeyPair.get("TemplateName"));
                            System.out.println(subColNameValKeyPair.get("TotalUnits"));
                            System.out.println(subColNameValKeyPair.get("BolusUnits"));
                            System.out.println(subColNameValKeyPair.get("BolusDose"));
                            System.out.println(subColNameValKeyPair.get("DispensableDrug"));
                            System.out.println(subColNameValKeyPair.get("RouteDesc"));
                            System.out.println(subColNameValKeyPair.get("MedicationStrength"));
                            System.out.println(subColNameValKeyPair.get("MedicationStrengthUnit"));
                            System.out.println(subColNameValKeyPair.get("MedicationExtras"));
                            System.out.println(String.format("Creating medication %s ", getMapValuesAsString(subColNameValKeyPair)));
                            break;
                    }

                }
            }
        }
        System.out.println(String.format("<*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*>"));
    }
    
    public static void main(String[] args) {
        Runner runner = new Runner(); 
        runner.runMethod();
    }
    
}
    