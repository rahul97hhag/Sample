package com.bhavani.parsers;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

/**
 * Created by BhavaniPrasadReddy on 4/18/2020.
 */
public class ExcelParser {

    private String excelFilepath;
    private String jsonFilepath;
    protected XSSFWorkbook workbook = null;
    private static Logger LOG = LoggerFactory.getLogger(ExcelParser.class);

    public ExcelParser(String path) {
        LOG.info(String.format("Excel file being processed - %s", path));
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(path);
            ZipSecureFile.setMinInflateRatio(0.005);
            this.workbook = new XSSFWorkbook(fileInputStream);
            LOG.info(String.format("Workbook for %s Opened by reading input stream", path));
            fileInputStream.close();
        } catch (IOException e) {

        } finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ExcelParser(String excelFilepath, String jsonFilepath) {
        LOG.info(String.format("Excel file being processed - %s", excelFilepath));
        this.excelFilepath = excelFilepath;
        this.jsonFilepath = jsonFilepath;
        FileInputStream fileInputStream = null;
        LOG.info(excelFilepath);
        LOG.info(jsonFilepath);
        String folderName = System.getProperty("user.dir") + "\\" + "src\\test\\resources\\";
        try {
            fileInputStream = new FileInputStream(folderName + excelFilepath);
            ZipSecureFile.setMinInflateRatio(0.005);
            this.workbook = new XSSFWorkbook(fileInputStream);
            LOG.info(String.format("Workbook for %s Opened by reading input stream", excelFilepath));
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error(e.getMessage());
        }
    }

    public String getExcelFilepath() {
        return this.excelFilepath;
    }

    public String getJsonFilepath() {
        return this.jsonFilepath;
    }

    public boolean isSheetExist(String sheetName) {
        boolean result = false;
        int index = workbook.getSheetIndex(sheetName);
        if(index == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isMergedCell(String sheetName, String colName) {
        boolean result = false;
        int colNum = this.getColumnNumber(sheetName, colName);
        colNum = colNum - 1;
        XSSFRow row = this.getSheet(sheetName).getRow(0);
        for(int i = colNum + 1; i < row.getLastCellNum();) {
            if(row.getCell(i).getCellType() == CellType.BLANK) {
                result = true;
                return result;
            } else {
                result = false;
                return result;
            }
        }
        return result;
    }

    public boolean isColumnEmpty(String sheetName, String colName, int rowNum) {
        List<Integer> listSpannedColNums = this.getMergedColumnNumbers(sheetName, colName);
        for(int colNum: listSpannedColNums) {
            if(!(this.getCellData(sheetName, colNum, rowNum).trim().isEmpty())) {
                return false;
            }
        }
        return true;
    }

    public XSSFSheet getSheet(String sheetName) {
        int index = workbook.getSheetIndex(sheetName);
        if(index == -1) {
            return null;
        } else {
            XSSFSheet sheet = workbook.getSheetAt(index);
            return sheet;
        }
    }

    public CellType getCellType(String sheetName, int colNum, int rowNum) {
        return this.getSheet(sheetName).getRow(rowNum - 1).getCell(colNum - 1).getCellType();
    }

    public CellType getCellType(String sheetName, String colName, int rowNum) {
        int colNum = this.getColumnNumber(sheetName, colName);
        return this.getSheet(sheetName).getRow(rowNum - 1).getCell(colNum - 1).getCellType();
    }

    public boolean isRowEmpty(String sheetName, int rowNum) {
        for(int i = 1; i <= this.getColumnCount(sheetName, rowNum); i++) {
            if(!(this.getCellData(sheetName, i, rowNum).trim().isEmpty())) {
                LOG.info("");
                return false;
            }
        }
        return true;
    }

    public int getColumnNumber(String sheetName, String colName) {
        XSSFRow row = this.getSheet(sheetName).getRow(0);
        int colNum = -1;
        for(int i = 0; i < row.getLastCellNum(); i++) {
            if(row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName)) {
                colNum = i;
                break;
            }
        }
        return colNum + 1;
    }

    public int getColumnNumber(String sheetName, String columnName, int headerRowNumber) {
        XSSFRow row = this.getSheet(sheetName).getRow(headerRowNumber - 1);
        int colNum = -1;
        for(int i = 0; i < row.getLastCellNum(); i++) {
            if(row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(columnName)) {
                colNum = i;
                break;
            }
        }
        return colNum + 1;
    }

    public int getCellRowNumber(String sheetName, String columnName, String cellValue) {
        for(int i = 2; i < getRowCount(sheetName); i++) {
            if(getCellData(sheetName, columnName, i).equalsIgnoreCase(cellValue)) {
                return i;
            }
        }
        return -1;
    }

    public List<Integer> getCellsRowNumber(String sheetName, String columnName, String cellValue) {
        LOG.info(String.format("Input parameters - SheetName = %s, colName = %s, cellValue = %s", sheetName, columnName, cellValue));
        List<Integer> listRows = new ArrayList<>();
        for(int i = 2; i <= getRowCount(sheetName); i++) {
            if(getCellData(sheetName, columnName, i).equalsIgnoreCase(cellValue)) {
                listRows.add(i);
            }
        }
        LOG.info(String.format("Rows found in sheet - %s, colName - %s, with cellValue - %s = %s", sheetName, columnName, cellValue, Arrays.toString(listRows.toArray())));
        return listRows;
    }

    public List<Integer> getMergedColumnNumbers(String sheetName, String columnName) {
        List<Integer> listColumns = new ArrayList<>();
        int colNum = this.getColumnNumber(sheetName, columnName);
        listColumns.add(colNum);
        XSSFRow row = this.getSheet(sheetName).getRow(0);
        for(int i = colNum; i < row.getLastCellNum(); i++) {
            if(row.getCell(i).getCellType() == CellType.BLANK) {
                listColumns.add(i + 1);
            } else {
                return listColumns;
            }
        }
        return listColumns;
    }

    public List<Integer> getUsedRangeRowNumbers(String sheetName, String colName, String cellValue) {
        List<Integer> cellUsedRange = new ArrayList<>();
        int startRowForCellValueInSearch = -1;
        int totalRowsInSheet = this.getRowCount(sheetName);
        for(startRowForCellValueInSearch = 2; startRowForCellValueInSearch <= totalRowsInSheet; startRowForCellValueInSearch++) {
            if(!this.isRowEmpty(sheetName, startRowForCellValueInSearch) && this.getCellData(sheetName, colName, startRowForCellValueInSearch).trim().equalsIgnoreCase(cellValue)) {
                cellUsedRange.add(startRowForCellValueInSearch);
                break;
            }
        }
        if(startRowForCellValueInSearch < totalRowsInSheet) {
            for(int nextRowForCellValueInSearch = startRowForCellValueInSearch + 1; nextRowForCellValueInSearch <= totalRowsInSheet; nextRowForCellValueInSearch++) {
                if(!this.isRowEmpty(sheetName, nextRowForCellValueInSearch) && this.getCellData(sheetName, colName, nextRowForCellValueInSearch).trim().equalsIgnoreCase(cellValue) ||
                        this.getCellData(sheetName, colName, nextRowForCellValueInSearch).trim().isEmpty()) {
                    cellUsedRange.add(nextRowForCellValueInSearch);
                } else {
                    break;
                }
            }
        }
        return cellUsedRange;
    }

    public List<String> getAllSheets() {
        List<String> sheets = new ArrayList<>();
        for(int i = 0; i < this.workbook.getNumberOfSheets(); i++) {
            sheets.add(this.workbook.getSheetName(i));
        }
        return sheets;
    }

    public List<String> getAllSheetsExcluding(List<String> exclusiveSheets) {
        List<String> sheets = getAllSheets();
        List<String> newSheets = getAllSheets();
        if(exclusiveSheets != null) {
            for(String sheetName: sheets) {
                if(!(exclusiveSheets.contains(sheetName))) {
                    newSheets.add(sheetName);
                }
            }
        }
        return newSheets;
    }

    public int getRowCount(String sheetName) {
        return this.getSheet(sheetName).getLastRowNum() + 1;
    }

    public int getColumnCount(String sheetName) {
        if(!isSheetExist(sheetName))
            return -1;
        XSSFSheet sheet = this.getSheet(sheetName);
        XSSFRow row = sheet.getRow(0);
        if(row == null) {
            return -1;
        }
        return row.getLastCellNum();
    }

    public int getColumnCount(String sheetName, int rowNumber) {
        if(!isSheetExist(sheetName))
            return -1;
        XSSFSheet sheet = this.getSheet(sheetName);
        XSSFRow row = sheet.getRow(rowNumber - 1);
        if(row == null) {
            return -1;
        }
        return row.getLastCellNum();
    }

    public String getCellData(String sheetName, String columnName, int rowNum) {
        int colNum = this.getColumnNumber(sheetName, columnName);
        return this.getCellData(sheetName, colNum, rowNum);
    }

    public String getCellData(String sheetName, int colNum, int rowNum) {
        String text = null;
        try {
            if(rowNum <= 0) {
                return null;
            }
            colNum = colNum -1;
            if(colNum < 0) {
                return null;
            }
            XSSFRow row = this.getSheet(sheetName).getRow(rowNum - 1);
            if(row == null) {
                return "";
            }
            XSSFCell cell = row.getCell(colNum);
            if(cell == null) {
                LOG.debug(String.format("Returing empty as cell is found to be null"));
                return "";
            }
            if(cell.getCellType() == CellType.STRING || cell.getCellType() == CellType.FORMULA) {
                text = cell.getStringCellValue();
            } else if(cell.getCellType() == CellType.NUMERIC) {
                String cellText = String.valueOf(cell.getNumericCellValue());
                if(DateUtil.isCellDateFormatted(cell)) {
                    double d = cell.getNumericCellValue();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(DateUtil.getJavaDate(d));
                    cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
                    cellText = cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cellText;
                }
                text = cellText;
            } else if(cell.getCellType() == CellType.BLANK) {
                return "";
            } else {
                text = String.valueOf(cell.getBooleanCellValue());
            }
            return text;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<String> getAllColumnNames(String sheetName) {
        List<String> listColumn = new ArrayList<>();
        int index = workbook.getSheetIndex(sheetName);
        if(index == -1) {
            return listColumn;
        }
        XSSFSheet sheet = workbook.getSheetAt(index);
        XSSFRow row = sheet.getRow(0);
        for(int i = 0; i < row.getLastCellNum(); i++) {
            String colName = row.getCell(i).getStringCellValue().trim();
            listColumn.add(colName);
        }
        return listColumn;
    }

    public List<String> getAllColumnNamesAfterColumn(String sheetName, String columnName) {
        int colNum = this.getColumnNumber(sheetName, columnName);
        List<String> listColumn = new ArrayList<>();
        int index = workbook.getSheetIndex(sheetName);
        if(index == -1) {
            return listColumn;
        }
        XSSFSheet sheet = workbook.getSheetAt(index);
        XSSFRow row = sheet.getRow(0);
        for(int i = colNum; i < row.getLastCellNum(); i++) {
            if(row.getCell(i).getCellType() != CellType.BLANK) {
                String colName = row.getCell(i).getStringCellValue().trim();
                listColumn.add(colName);
            }
        }
        return listColumn;
    }

    public Map<String, Integer> getRowColForCellData(String sheetName, String cellData) {
        int totalRows = this.getRowCount(sheetName);
        int totalColumns = this.getColumnCount(sheetName);
        Map<String, Integer> mapRowCol = new HashMap<>();
        mapRowCol.put("rowNum", -1);
        mapRowCol.put("colNum", -1);
        for(int rowNum = 1; rowNum <= totalRows; rowNum++) {
            for(int colNum = 1; colNum <= totalColumns; colNum++) {
                String text = this.getCellData(sheetName, colNum, rowNum);
                if(text.equalsIgnoreCase(cellData)) {
                    mapRowCol.put("rowNum", rowNum);
                    mapRowCol.put("colNum", colNum);
                    return mapRowCol;
                }
            }
        }
        return mapRowCol;
    }

    public int getColForCellData(String sheetName, String cellData, int rowNum) {
        int totalColumns = this.getColumnCount(sheetName);
        for(int colNum = 1; colNum <= totalColumns; colNum++) {
            String text = this.getCellData(sheetName, colNum, rowNum);
            if(text.equalsIgnoreCase(cellData)) {
                return colNum;
            }
        }
        return -1;
    }

    /*** Apis to handle merged cells in sheet  */
    public String getCellData(String sheetName, String colName, String subColName, int rowNum) {
        if(isMergedCell(sheetName, colName)) {
            LOG.info(String.format("Column -%s is merged cell", colName));
            int colNum = -1;
            XSSFRow row = this.getSheet(sheetName).getRow(1);
            List<Integer> subColsRange = this.getMergedColumnNumbers(sheetName, colName);
            for(int col: subColsRange) {
                if(row.getCell(col - 1).getStringCellValue().trim().equalsIgnoreCase(subColName)) {
                    colNum = col;
                    break;
                }
            }
            return this.getCellData(sheetName, colNum, rowNum);
        } else {
            LOG.info(String.format("Column -%s is not merged cell", colName));
            return this.getCellData(sheetName, colName, rowNum);
        }
    }

    public String getCellData(String sheetName, String filterColName, String filterColData, String dataColName, String dataSubColName, int rowNum) {
        List<Integer> dataUsedRangeRows = this.getUsedRangeRowNumbers(sheetName, filterColName, filterColData);
        if(dataUsedRangeRows.contains(rowNum)) {
            return this.getCellData(sheetName, dataColName, dataSubColName, rowNum);
        } else {
            return null;
        }
    }

    public List<String> getCellsData(String sheetName, String filterColName, String filterColData, String dataColName, String dataSubColName) {
        List<String> listData = new ArrayList<>();
        List<Integer> dataUsedRangeRows = this.getUsedRangeRowNumbers(sheetName, filterColName, filterColData);
        for(int rowNum: dataUsedRangeRows) {
            listData.add(this.getCellData(sheetName, dataColName, dataSubColName, rowNum));
        }
        return listData;
    }

    public boolean setCellData(String sheetName, String colName, int rowNum, String data) {
        boolean result = false;
        return result;
    }

    public boolean highlightCell(String sheetName, String colName, int rowNum, HSSFColor.HSSFColorPredefined colorCode) {
        boolean result = false;
        return result;
    }

    public boolean setCellData(String sheetName, String colName, int rowNum, String data, String url) {
        boolean result = false;
        return result;
    }

    public boolean addSheet(String sheetName) {
        boolean result = false;
        return result;
    }

    public boolean removeSheet(String sheetName) {
        boolean result = false;
        return result;
    }

    public boolean addColumn(String sheetName, String colName) {
        boolean result = false;
        return result;
    }

    public boolean addColumn(String sheetName, String colName, HSSFColor.HSSFColorPredefined color) {
        boolean result = false;
        return result;
    }

    public boolean removeColumn(String sheetName, int colNum) {
        boolean result = false;
        return result;
    }

    public boolean removeColumn(String sheetName, String colName) {
        boolean result = false;
        return result;
    }

    public boolean addHyperLink(String sheetName, String colName, int rowNum, String url, String message) {
        boolean result = false;
        return result;
    }


}