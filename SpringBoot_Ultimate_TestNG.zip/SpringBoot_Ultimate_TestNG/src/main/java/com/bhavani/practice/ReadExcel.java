package com.bhavani.practice;

import com.bhavani.dao.NSEExcelSheet;
import com.bhavani.parsers.ExcelParser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/23/2020.
 */
public class ReadExcel {
    public static void main(String[] args) {
        String filePath = "G:\\Java_Projects\\Cigniti_Frameworks\\SpringBoot_Ultimate_TestNG\\Shares2.xlsx";
        ExcelParser excelParser = new ExcelParser(filePath);
        String sheetName = "Shares";
        int rows = excelParser.getRowCount(sheetName);
        int columns = excelParser.getColumnCount(sheetName);
        System.out.println(rows +  " " + columns);

    }
}
