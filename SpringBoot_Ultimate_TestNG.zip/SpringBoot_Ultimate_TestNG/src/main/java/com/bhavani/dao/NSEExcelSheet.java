package com.bhavani.dao;

import java.util.Date;

/**
 * Created by BhavaniPrasadReddy on 8/23/2020.
 */
public class NSEExcelSheet {

    private int rowIndex;
    private String symbol;
    private String series;
    private double open;
    private double high;
    private double low;
    private double close;
    private double last;
    private double prevClose;
    private long totalTradeQuantity;
    private double totalTradeValue;
    private Date timestamp;
    private long totalTrades;
    private String isin;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int i) {
        this.rowIndex = i;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public double getOpen() {
        return open;
    }

    public void setOpen(double open) {
        this.open = open;
    }

    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
    }

    public double getLow() {
        return low;
    }

    public void setLow(double low) {
        this.low = low;
    }

    public double getClose() {
        return close;
    }

    public void setClose(double close) {
        this.close = close;
    }

    public double getLast() {
        return last;
    }

    public void setLast(double last) {
        this.last = last;
    }

    public double getPrevClose() {
        return prevClose;
    }

    public void setPrevClose(double prevClose) {
        this.prevClose = prevClose;
    }

    public long getTotalTradeQuantity() {
        return totalTradeQuantity;
    }

    public void setTotalTradeQuantity(long totalTradeQuantity) {
        this.totalTradeQuantity = totalTradeQuantity;
    }

    public double getTotalTradeValue() {
        return totalTradeValue;
    }

    public void setTotalTradeValue(double totalTradeValue) {
        this.totalTradeValue = totalTradeValue;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public long getTotalTrades() {
        return totalTrades;
    }

    public void setTotalTrades(long totalTrades) {
        this.totalTrades = totalTrades;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NSEExcelSheet that = (NSEExcelSheet) o;

        if (Double.compare(that.open, open) != 0) return false;
        if (Double.compare(that.high, high) != 0) return false;
        if (Double.compare(that.low, low) != 0) return false;
        if (Double.compare(that.close, close) != 0) return false;
        if (Double.compare(that.last, last) != 0) return false;
        if (Double.compare(that.prevClose, prevClose) != 0) return false;
        if (totalTradeQuantity != that.totalTradeQuantity) return false;
        if (Double.compare(that.totalTradeValue, totalTradeValue) != 0) return false;
        if (totalTrades != that.totalTrades) return false;
        if (!symbol.equals(that.symbol)) return false;
        if (!series.equals(that.series)) return false;
        if (!timestamp.equals(that.timestamp)) return false;
        return isin.equals(that.isin);
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = symbol.hashCode();
        result = 31 * result + series.hashCode();
        temp = Double.doubleToLongBits(open);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(high);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(low);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(close);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(last);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(prevClose);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (int) (totalTradeQuantity ^ (totalTradeQuantity >>> 32));
        temp = Double.doubleToLongBits(totalTradeValue);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + timestamp.hashCode();
        result = 31 * result + (int) (totalTrades ^ (totalTrades >>> 32));
        result = 31 * result + isin.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "NSEExcelSheet{" +
                "row="+ rowIndex + '\'' +
                "symbol='" + symbol + '\'' +
                ", series='" + series + '\'' +
                ", open=" + open +
                ", high=" + high +
                ", low=" + low +
                ", close=" + close +
                ", last=" + last +
                ", prevClose=" + prevClose +
                ", totalTradeQuantity=" + totalTradeQuantity +
                ", totalTradeValue=" + totalTradeValue +
                ", timestamp=" + timestamp +
                ", totalTrades=" + totalTrades +
                ", isin='" + isin + '\'' +
                '}';
    }
}
