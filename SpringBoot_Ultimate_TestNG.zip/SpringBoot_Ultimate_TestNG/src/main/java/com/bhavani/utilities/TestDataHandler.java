package com.bhavani.utilities;

import com.bhavani.dao.NSEExcelSheet;
import com.bhavani.parsers.ExcelParser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/23/2020.
 */
public class TestDataHandler {

    public void setDataFromCell(int colNo, String data, NSEExcelSheet nseExcelSheet) {
        if(data != null || !(data.isEmpty()) || !(data.contentEquals("")) || !(data.length() == 0)) {
            switch (colNo + 1) {
                case 1:
                    nseExcelSheet.setSymbol(data);
                    break;
                case 2:
                    nseExcelSheet.setSeries(data);
                    break;
                case 3:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setOpen(Double.valueOf(data));
                    }
                    break;
                case 4:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setHigh(Double.valueOf(data));
                    }
                    break;
                case 5:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setLow(Double.valueOf(data));
                    }
                    break;
                case 6:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setClose(Double.valueOf(data));
                    }
                    break;
                case 7:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setLast(Double.valueOf(data));
                    }
                    break;
                case 8:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setPrevClose(Double.valueOf(data));
                    }
                    break;
                case 9:
                    try {
                        nseExcelSheet.setTotalTradeQuantity(Long.valueOf((int) Math.round(Double.valueOf(data))));
                    } catch (NumberFormatException e) {
                        System.out.print( data);
                    }
                    break;
                case 10:
                    if(!data.isEmpty()) {
                        nseExcelSheet.setTotalTradeValue(Double.valueOf(data));
                    }
                    break;
                case 11:
                    try {
                        nseExcelSheet.setTimestamp(new SimpleDateFormat("MM/dd/yyyy").parse(data));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    break;
                case 12:
                    try {
                        nseExcelSheet.setTotalTrades(Long.valueOf((int) Math.round(Double.valueOf(data))));
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    break;
                case 13:
                    nseExcelSheet.setIsin(data);
                    break;
            }
        }
    }

    public Object[][] getNseData(String excelFile, String sheetName) {
        String filePath = "G:\\Java_Projects\\Cigniti_Frameworks\\SpringBoot_Ultimate_TestNG\\"+excelFile+".xlsx";
        ExcelParser excelParser = new ExcelParser(filePath);
        int rows = excelParser.getRowCount(sheetName);
        int columns = excelParser.getColumnCount(sheetName);
        System.out.println(rows +  " " + columns);
        Object[][] data = new Object[rows][1];
        for(int rowNo = 2; rowNo < rows; rowNo++) {
            NSEExcelSheet nseExcelSheet = new NSEExcelSheet();
            nseExcelSheet.setRowIndex(rowNo);
            for (int colNo = 0; colNo < columns; colNo++) {
                String dataFromExcel = excelParser.getCellData(sheetName, colNo + 1, rowNo);
                setDataFromCell(colNo, dataFromExcel, nseExcelSheet);
            }
            data[rowNo-2][0] = nseExcelSheet;
        }
        return data;
    }

}
