package com.bhavani.runner;

import org.testng.TestNG;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/28/2020.
 */
public class TestNGRunner {
    public static void main(String[] args) {
        List<String> suites = new ArrayList<String>();
        TestNG testng = new TestNG();

        suites.add(".\\testng_parallel.xml");
        testng.setTestSuites(suites);
        testng.setParallel("parallel");
        testng.setSuiteThreadPoolSize(5);
        testng.setOutputDirectory("path to output");
        testng.setDataProviderThreadCount(5);


        testng.run();
    }
}
