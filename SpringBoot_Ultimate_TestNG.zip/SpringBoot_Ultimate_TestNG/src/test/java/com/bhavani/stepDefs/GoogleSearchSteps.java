package com.bhavani.stepDefs;


import cucumber.api.java.en.Given;
import cucumber.api.java8.En;

/**
 * Created by BhavaniPrasadReddy on 8/21/2020.
 */
public class GoogleSearchSteps implements En {


    public GoogleSearchSteps() {
        Given("I go to google", () -> {
            System.out.println("15");
        });

        When("^I query for \"([^\"]*)\"$", (String searchString) -> {
            System.out.println("19 " + searchString);
        });

        And("click search", () -> {

        });

        Then("google page title should become \"([^\"]*)\"$", (String result) -> {
            System.out.println("23 " + result);
        });

        Then("i should see \"([^\"]*)\" as \"([^\"]*)\" of the suggested search$", (String result, String count) -> {
            System.out.println("27 " + result + " " + Integer.valueOf(count));
        });
    }
}
