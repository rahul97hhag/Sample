package com.bhavani.unitTests;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.junit.Test;





/**
 * Created by BhavaniPrasadReddy on 8/24/2020.
 */
public class DateExamples {

    @Test
    public void testOne() {
        String dateString = "2020-08-20T11:00:00+00:00";
        DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTimeParser();
        DateTime dateTime = dateTimeFormatter.parseDateTime(dateString);
        System.out.println(dateTime);
    }
}
