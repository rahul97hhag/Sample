package com.bhavani.unitTests;

import com.bhavani.dao.NSEExcelSheet;
import com.bhavani.utilities.TestDataHandler;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 8/23/2020.
 */
public class FrameworkTests {
    private static Logger LOG = LoggerFactory.getLogger(FrameworkTests.class);
    @Test
    public void testExcelSheetData() {
        TestDataHandler testDataHandler = new TestDataHandler();
        Object[][] data = testDataHandler.getNseData("Shares2", "Shares");
        for(int i = 0; i < data.length; i++) {
            NSEExcelSheet nseExcelSheet = (NSEExcelSheet) data[i][0];
        //    LOG.info(nseExcelSheet.toString());
            try {
                nseExcelSheet.getSymbol();
            } catch (Exception e) {
                LOG.info(nseExcelSheet.toString());
            }
        }
    }

}
