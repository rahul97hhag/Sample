package com.bhavani.google;

import com.bhavani.SpringBootAppTests;
import com.bhavani.baseTest.BaseTest;
import com.bhavani.dao.NSEExcelSheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

/**
 * Created by BhavaniPrasadReddy on 8/11/2020.
 */
public class SearchSomething extends SpringBootAppTests {

    private static Logger LOG = LoggerFactory.getLogger(SearchSomething.class);
    @Test(dataProvider = "nseData")
    public void testOne(Object object) {
        NSEExcelSheet nseExcelSheet = (NSEExcelSheet) object;
        LOG.info(nseExcelSheet.toString());
        this.extent.createTest(nseExcelSheet.getRowIndex() + " " + nseExcelSheet.getSymbol());
        this.extent.setTestRunnerOutput(" "+nseExcelSheet.toString());
        this.extent.setTestRunnerOutput(" " );
    }
}
