package com.bhavani.baseTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.bhavani.utilities.TestDataHandler;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.lang.reflect.Method;

/**
 * Created by BhavaniPrasadReddy on 8/11/2020.
 */
public class BaseTest extends AbstractTestNGSpringContextTests {

    public ExtentHtmlReporter	htmlReporter;
    public ExtentReports extent;
    public ExtentTest test;

    @BeforeSuite
    public void beforeSuite() {
        htmlReporter = new ExtentHtmlReporter("./reports/extent.html");
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setDocumentTitle("TestCase1 Automation Report");
        htmlReporter.config().setReportName("TestCase1 Automation Test Results");
        htmlReporter.config().setTheme(Theme.DARK);

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("Automation Tester", "Tejas Gandhi");
        extent.setSystemInfo("Orgainzation", "com.github.GandhiTC");
        extent.setSystemInfo("Build No", "TG00-0001");
    }

    @BeforeGroups
    public void beforeGroups() {

    }

    @BeforeClass
    public void beforeClass() {
        //Ideal place to perform some setup which is shared among all tests.
        //E.g. Initializing DB connection, setting environment properties
        System.out.println("@BeforeClass: I run only once, before first test start.");
    }

    @AfterClass
    public void afterClass() {
        //Ideal place to perform some cleanup of setup which is shared among all tests.
        System.out.println("@AfterClass: I run only once, after all tests have been done.\n");
    }

    @BeforeMethod
    public void beforeEachTestMethod(Method method) {//Parameter are optional
        //May perform some initialization/setup before each test.
        //E.g. Initializing User whose properties may be altered by actual @Test
        System.out.println("\n@BeforeMethod: I run before each test method. Test to be executed is : " + method.getName());
    }

    @AfterMethod
    public void afterEachTestMethod(Method method) {//Parameter are optional
        //May perform cleanup of initialization/setup after each test.
        System.out.println("@AfterMethod: I run after each test method. Test just executed is : " + method.getName() + "\n");
    }

    @BeforeTest
    public void beforeTest() {
        System.out.println("Executing Login Test");
    }

    @AfterTest
    public void afterTest() {

    }

    @AfterGroups
    public void afterGroups() {

    }

    @AfterSuite
    public void afterSuite() {
        extent.flush();
    }

    // @DataProvider(name = "nseData")
    @DataProvider(name = "nseData", parallel = true)
    public Object[][] dataProvider() throws IOException {
        TestDataHandler testDataHandler = new TestDataHandler();
        return testDataHandler.getNseData("Shares2", "Shares");
    }

}
