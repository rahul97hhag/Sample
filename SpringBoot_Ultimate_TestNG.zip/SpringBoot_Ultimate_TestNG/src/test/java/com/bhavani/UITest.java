package com.bhavani;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.PickleEventWrapper;

import cucumber.api.testng.TestNGCucumberRunner;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by BhavaniPrasadReddy on 8/21/2020.
 */
@CucumberOptions(
    plugin = {"pretty", "json:target/report/cucumber2.json"},
    strict = true,
    features = {"src/test/resources/features"},
    glue = {"com.bhavani"}
)
public class UITest {
    private TestNGCucumberRunner testNGCucumberRunner;

    @BeforeClass(alwaysRun = true)
    public void setUpClass() throws Exception {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());

    }

    @Test(groups = "Cucumber", description = "Cucumber Feature", dataProvider = "scenarios")
    public void scenario(PickleEventWrapper pickleEventWrapper, CucumberFeatureWrapper cucumberFeatureWrapper) {
       // testNGCucumberRunner.runScenario(pickleWrapper.getPickleEvent());
        try {
            testNGCucumberRunner.runScenario(pickleEventWrapper.getPickleEvent());
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @DataProvider
    public Object[][] scenarios() {
        return testNGCucumberRunner.provideScenarios();
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() {
        testNGCucumberRunner.finish();
    }

}
