package com.bhavani;

import com.bhavani.baseTest.BaseTest;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.Test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.junit.runner.RunWith;

/**
 * Created by BhavaniPrasadReddy on 8/11/2020.
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = SpringBootApp.class)
// @ContextConfiguration(loader=AnnotationConfigContextLoader.class, classes = SpringBootApp.class)
@SpringBootTest(classes = SpringBootApp.class)
public class SpringBootAppTests extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(SpringBootAppTests.class);
}
