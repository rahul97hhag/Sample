package com.bhavani.utilties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class JsonUtilities {

    private static final JsonUtilities instance = new JsonUtilities();
    private static Logger logger = LoggerFactory.getLogger(JsonUtilities.class);

    private JsonUtilities() {
    }

    public static JsonUtilities getInstance(){
        return instance;
    }

    public String readFile(String filename) {
        String result = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line);
                line = br.readLine();
            }
            result = sb.toString();
        } catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public JSONObject getJSONObject(String jsonFilePath) {
        logger.info(jsonFilePath);
        JSONObject jsonObject = new JSONObject(readFile(jsonFilePath));
        return jsonObject;
    }

    public JSONArray getJSONArray(String jsonFilePath) {
        logger.info(jsonFilePath);
        JSONArray jsonArray = new JSONArray(readFile(jsonFilePath));
        return jsonArray;
    }

    public JSONObject getJSONObjectFromJSONArray(JSONArray jsonArray, String key, String value) {
        for(int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if(jsonObject.getString(key).equalsIgnoreCase(value)) {
                return jsonObject;
            }
        }
        return null;
    }


}