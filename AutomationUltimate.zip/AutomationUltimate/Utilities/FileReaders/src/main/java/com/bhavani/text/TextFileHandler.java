package com.bhavani.text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class TextFileHandler {

    public static boolean writeStringToFile(String content, String fileName) {
        File file = new File(fileName);
        if(file.exists()) {
            file.delete();
        }

        try {
            file.createNewFile();
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] array = content.getBytes();
            fileOutputStream.write(array);
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
