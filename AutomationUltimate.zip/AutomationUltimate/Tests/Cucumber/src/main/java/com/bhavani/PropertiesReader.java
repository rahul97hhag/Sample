package com.bhavani;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by BhavaniPrasadReddy on 6/5/2020.
 */
public class PropertiesReader {

    private static Properties properties = null;

    private static Properties loadPropertiesFile() {
        if(properties == null) {
            properties = new Properties();
            String folderPath = System.getProperty("user.dir");
            try {
                FileInputStream ip = new FileInputStream(folderPath + "\\src\\main\\resources\\config.properties");
                properties.load(ip);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return properties;
    }

    public static String getPropertyValue(String key) {
        return loadPropertiesFile().getProperty(key);
    }

}