package com.bhavani.pages.heroku;

import com.bhavani.pages.BasePage;
import org.openqa.selenium.WebDriver;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class CheckBoxesPage extends BasePage {

    public CheckBoxesPage(WebDriver driver) {
        super(driver);
    }
}