package com.bhavani.utilities;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class LocatorUtilities {

    private static final LocatorUtilities instance = new LocatorUtilities();
    private static Logger logger = LoggerFactory.getLogger(LocatorUtilities.class);

    private LocatorUtilities() {
    }

    public static LocatorUtilities getInstance(){
        return instance;
    }


    public List<String> getLocatorFromJSONString(JSONObject jsonObject, String locatorName) {
        String jsonValue = jsonObject.getString(locatorName);
        List<String> locatorsList = new ArrayList<String>();
        if(jsonValue.contains("||")) {
            List<String> locators = Arrays.asList(jsonValue.split("\\|\\|"));
            for (String locator : locators) {
                if (locator.contains(",")) {
                    String locatorType = locator.substring(0, locator.indexOf(","));
                    String locatorValue = locator.substring(locator.indexOf(locatorType + ","));
                    locatorValue = locatorValue.replace(locatorType + ",", "").trim();
                    locatorsList.add(locatorType+""+locatorValue);
                }
            }
        } else {
            String locatorType = jsonValue.substring(0, jsonValue.indexOf(","));
            String locatorValue = jsonValue.substring(jsonValue.indexOf(locatorType + ","));
            locatorValue = locatorValue.replace(locatorType + ",", "").trim();
            locatorsList.add(locatorType+"::"+locatorValue);
        }
        return locatorsList;
    }
}