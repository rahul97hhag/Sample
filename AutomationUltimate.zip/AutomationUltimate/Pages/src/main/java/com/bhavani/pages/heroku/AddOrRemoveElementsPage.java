package com.bhavani.pages.heroku;

import com.bhavani.pages.BasePage;
import org.openqa.selenium.WebDriver;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class AddOrRemoveElementsPage extends BasePage {

    public AddOrRemoveElementsPage(WebDriver driver) {
        super(driver);
    }
}