package com.bhavani.pages.heroku;

import com.bhavani.pages.BasePage;
import org.openqa.selenium.WebDriver;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class FormAuthenticationPage extends BasePage {

    public FormAuthenticationPage(WebDriver driver) {
        super(driver);
    }
}