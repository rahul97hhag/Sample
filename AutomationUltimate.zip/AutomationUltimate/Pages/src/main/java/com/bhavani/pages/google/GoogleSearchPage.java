package com.bhavani.pages.google;

import com.bhavani.elements.Elements;
import com.bhavani.pages.BasePage;
import com.bhavani.utilities.LocatorUtilities;
import com.bhavani.utilties.JsonUtilities;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class GoogleSearchPage extends BasePage {

    public static JSONObject locators = null;
    private static Logger logger = LoggerFactory.getLogger(GoogleSearchPage.class);

    public GoogleSearchPage(WebDriver webDriver) {
        super(webDriver);
        fileName = fileName + "google\\google_search_page.json";
        locators = JsonUtilities.getInstance().getJSONObject(folderPath + "\\" + fileName);
    }

    public boolean searchForSomething(String searchString) {
        try {
            logger.debug(searchString);
            logger.debug(locators.toString());
            WebElement searchField = getWebElement(locators, "search_field");
            WebElement searchButton = getWebElement(locators, "search_button");
            searchField.sendKeys(searchString);
            searchButton.click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

}