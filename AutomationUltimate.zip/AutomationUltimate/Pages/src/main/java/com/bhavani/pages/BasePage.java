package com.bhavani.pages;

import com.bhavani.elements.Elements;
import com.bhavani.utilities.LocatorUtilities;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class BasePage {

    public WebDriver webDriver;
    public static String folderPath = "G:\\Java_Projects\\Cigniti_Frameworks\\AutomationUltimate\\Pages";
    public static String fileName = "src\\main\\resources\\locators\\";

    public BasePage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    public WebElement getWebElement(JSONObject locators, String jsonKey) {
        List<String> locatorsList = LocatorUtilities.getInstance().getLocatorFromJSONString(locators, jsonKey);
        return Elements.findElement(webDriver, locatorsList);
    }
}