package com.bhavani;

import com.bhavani.driverActions.Waits;
import com.bhavani.elements.Elements;
import com.bhavani.elements.Locator;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class ElementsTest {

    private static Logger logger = LoggerFactory.getLogger(ElementsTest.class);

    @Test
    public void testElements() {
        WebDriverProvider webDriverProvider = new WebDriverProvider();
        WebDriver webDriver = webDriverProvider.getWebDriver();
        String googleURL = "https://www.google.com/";
        webDriver.get(googleURL);
        Waits.forPageReady(webDriver);
        Waits.threadSleep(20l, "");

        WebElement searchField = Elements.findElement(webDriver, "xpath", "//input[@name='q']");
        WebElement searchButton = Elements.findElement(webDriver, "xpath", "(//input[@name='btnK'])[2]");

        searchField.sendKeys("Hello Song");
        searchButton.click();

        webDriver.close();
        webDriver.quit();
    }

}