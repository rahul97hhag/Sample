package com.bhavani;

import com.bhavani.driverActions.ExecuteJavaScript;
import com.bhavani.driverActions.Waits;
import com.bhavani.elements.*;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class ReflectionUsage {

    private static Logger logger = LoggerFactory.getLogger(ReflectionUsage.class);

    @Test
    public void getAllMethods() {

        Class<WebDriverProvider> webDriverProviderClass = WebDriverProvider.class;
        logger.info("<<<<<<<<<< Package WebDriverProvider >>>>>>>>>>");

        Method[] webDriverProviderMethods = webDriverProviderClass.getMethods();
        logger.info("WebDriverProvider methods ");
        for(Method method: webDriverProviderMethods) {
            logger.info(" "+method);
        }

        logger.info("<<<<<<<<<< Package exceptions >>>>>>>>>>");


        logger.info("<<<<<<<<<< Package driverActions >>>>>>>>>>");
        Class<ExecuteJavaScript>  executeJavaScriptClass = ExecuteJavaScript.class;
        Class<Waits> waitsClass = Waits.class;

        Method[] executeJavaScriptMethods = executeJavaScriptClass.getMethods();
        logger.info("ExecuteJavaScript methods ");
        for(Method method: executeJavaScriptMethods) {
            logger.info(" "+method);
        }

        Method[] waitsMethods = waitsClass.getMethods();
        logger.info("Waits methods ");
        for(Method method: waitsMethods) {
            logger.info(" "+method);
        }

        logger.info("<<<<<<<<<< Package elements >>>>>>>>>>");
        Class<CheckBoxes> checkboxesClass = CheckBoxes.class;
        Class<Forms> formsClass = Forms.class;
        Class<TextAreas> textAreasClass = TextAreas.class;
        Class<TextBoxes> textBoxesClass = TextBoxes.class;
        Class<Locator> locatorClass = Locator.class;
        Class<Elements> elementsClass = Elements.class;
        Class<Clicks> clicksClass = Clicks.class;
        Class<Dropdowns> dropdownsClass = Dropdowns.class;
        Class<Keyboards> keyboardsClass = Keyboards.class;
        Class<RadioButtons> radioButtonsClass = RadioButtons.class;

        Method[] checkBoxMethods = checkboxesClass.getMethods();
        logger.info("CheckBoxes methods ");
        for(Method method: checkBoxMethods) {
            logger.info(" "+method);
        }

        Method[] textBoxesMethods = textBoxesClass.getMethods();
        logger.info("TextBoxes methods ");
        for(Method method: textBoxesMethods) {
            logger.info(" "+method);
        }

        Method[] formsMethods = formsClass.getMethods();
        logger.info("Forms methods ");
        for(Method method: formsMethods) {
            logger.info(" "+method);
        }

        Method[] textAreaMethods = textAreasClass.getMethods();
        logger.info("TextAreas methods ");
        for(Method method: textAreaMethods) {
            logger.info(" "+method);
        }

        Method[] locatorMethods = locatorClass.getMethods();
        logger.info("Locator methods ");
        for(Method method: locatorMethods) {
            logger.info(" "+method);
        }

        Method[] elementsMethods = elementsClass.getMethods();
        logger.info("Elements methods ");
        for(Method method: elementsMethods) {
            logger.info(" "+method);
        }

        Method[] clicksMethods = clicksClass.getMethods();
        logger.info("Clicks methods ");
        for(Method method: clicksMethods) {
            logger.info(" "+method);
        }

        Method[] keyboardsMethods = keyboardsClass.getMethods();
        logger.info("Keyboards methods ");
        for(Method method: keyboardsMethods) {
            logger.info(" "+method);
        }

        Method[] dropdownsMethods = dropdownsClass.getMethods();
        logger.info("Dropdowns methods ");
        for(Method method: dropdownsMethods) {
            logger.info(" "+method);
        }

        Method[] radioButtonsMethods = radioButtonsClass.getMethods();
        logger.info("RadioButtons methods ");
        for(Method method: radioButtonsMethods) {
            logger.info(" "+method);
        }

    }
}