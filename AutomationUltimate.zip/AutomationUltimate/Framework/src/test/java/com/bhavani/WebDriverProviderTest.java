package com.bhavani;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class WebDriverProviderTest {

    private static Logger logger = LoggerFactory.getLogger(WebDriverProviderTest.class);

    @Test
    public void testGetWebDriver() {
        WebDriverProvider webDriverProvider = new WebDriverProvider();
        WebDriver webDriver = webDriverProvider.getWebDriver();
        logger.info("");
        webDriver.close();
        webDriver.quit();
    }
}