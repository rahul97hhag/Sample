package com.bhavani.driverActions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class AlertActions {

    public static Alert switchToAlert(WebDriver driver) {
        Waits.threadSleep(3000, "");
        return driver.switchTo().alert();
    }

    public static void switchToAlertAndAccept(WebDriver driver) {
        Waits.threadSleep(3000, "");
        Alert alert = switchToAlert(driver);
        alert.accept();
    }

    public static void switchToAlertAndDismiss(WebDriver driver) {
        Waits.threadSleep(3000, "");
        Alert alert = switchToAlert(driver);
        alert.dismiss();
    }

    public static void switchToAlertAndSendKeys(WebDriver driver, String text) {
        Waits.threadSleep(3000, "");
        Alert alert = switchToAlert(driver);
        alert.sendKeys(text);
    }

    public static String switchToAlertAndGetText(WebDriver driver) {
        Waits.threadSleep(3000, "");
        Alert alert = switchToAlert(driver);
        return alert.getText();
    }
}
