package com.bhavani.elements;

import com.bhavani.driverActions.ExecuteJavaScript;
import com.bhavani.driverActions.Waits;
import org.openqa.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class Elements {

    private static Logger logger = LoggerFactory.getLogger(Elements.class);

    public static WebElement findElement(WebDriver driver, String locatorType, String locator) {
        return findElement(driver, Locator.getInstance().getLocatorBy(locatorType, locator));
    }

    public static List<WebElement> findElements(WebDriver driver, String locatorType, String locator) {
        return findElements(driver, Locator.getInstance().getLocatorBy(locatorType, locator));
    }

    public static WebElement findElement(WebDriver driver, By by) {
        try {
            Waits.forPageReady(driver);
            List<WebElement> elements = driver.findElements(by);
            if (elements == null || elements.size() == 0) {
                throw new NoSuchElementException("Unable to locate an element using selector : ");
            }
            if (elements.size() > 1) {
                List<WebElement> visible = elements.stream().filter(WebElement::isDisplayed)
                        .collect(Collectors.toList());
                if (!visible.isEmpty()) {
                    elements = visible;
                }
            }
            return elements.get(0);
        } catch (NoSuchElementException ex) {
            logger.warn("No element found with selector : ");
            logger.debug("Unable to find element : ", ex);
        }
        return null;
    }

    public static List<WebElement> findElements(WebDriver driver, By by) {
        try {
            Waits.forPageReady(driver);
            List<WebElement> elements = driver.findElements(by);
            if (elements == null || elements.size() == 0) {
                throw new NoSuchElementException("Unable to locate an element using selector : ");
            }
            if (elements.size() > 1) {
                List<WebElement> visible = elements.stream().filter(WebElement::isDisplayed)
                        .collect(Collectors.toList());
                if (!visible.isEmpty()) {
                    elements = visible;
                }
            }
            return elements;
        } catch (NoSuchElementException ex) {
            logger.warn("No element found with selector : ");
            logger.debug("Unable to find element : ", ex);
        }
        return null;
    }

    public static int getElementCount(WebDriver driver, By by) {
        return findElements(driver, by).size();
    }

    public static WebElement findElement(WebDriver driver, List<String> locators) {
        for(int i = 0; i < locators.size(); i++) {
            String loc = locators.get(i);
            String locatorType = loc.split("::")[0];
            String locator = loc.split("::")[1];
            logger.debug(locatorType + " " + locator);
            By locatorBy = Locator.getInstance().getLocatorBy(locatorType, locator);
            if(findElement(driver, locatorBy).isDisplayed()) {
                logger.debug("Locator is found for "+ loc);
                return findElement(driver, locatorBy);
            }
        }
        return null;
    }

    public static List<WebElement> findElements(WebDriver driver, List<String> locators) {
        for(int i = 0; i < locators.size(); i++) {
            String loc = locators.get(i);
            String locatorType = loc.split("::")[0];
            String locator = loc.split("::")[1];
            logger.debug(locatorType + " " + locator);
            By locatorBy = Locator.getInstance().getLocatorBy(locatorType, locator);
            List<WebElement> webElements = findElements(driver, locatorBy);
            if(webElements.get(0).isDisplayed()) {
                return webElements;
            }
        }
        return null;
    }

    public static List<String> getTextFromWebElements(List<WebElement> webElements) {
        List<String> valuesList = new ArrayList<String>();
        if(webElements.get(0).isDisplayed()) {
            for(WebElement webElement : webElements) {
                valuesList.add(webElement.getText());
            }
        }
        return valuesList;
    }

    public static String getTextFromWebElement(WebElement webElement) {
        String value = null;
        if(webElement.isDisplayed()) {
            value = webElement.getText();
        }
        return value;
    }

    public static List<String> getAttributeFromWebElements(List<WebElement> webElements, String attributeType) {
        List<String> valuesList = new ArrayList<String>();
        if(webElements.get(0).isDisplayed()) {
            for(WebElement webElement : webElements) {
                valuesList.add(webElement.getAttribute(attributeType));
            }
        }
        return valuesList;
    }

    public static List<String> getAttributeFromChildWebElements(List<WebElement> webElements, String childElementLocator, String attributeType) {
        List<String> valuesList = new ArrayList<String>();
        if(webElements.get(0).isDisplayed()) {
            for(WebElement webElement : webElements) {
                WebElement childElement = findChildElement(webElement, childElementLocator);
                valuesList.add(childElement.getAttribute(attributeType));
            }
        }
        return valuesList;
    }

    public static List<String> getTextFromChildWebElements(List<WebElement> webElements, String childElementLocator) {
        List<String> valuesList = new ArrayList<String>();
        if(webElements.get(0).isDisplayed()) {
            for(WebElement webElement : webElements) {
                WebElement childElement = findChildElement(webElement, childElementLocator);
                valuesList.add(childElement.getText());
            }
        }
        return valuesList;
    }

    public static String getTextFromChildWebElement(WebElement webElement, String childElementLocator) {
        String value = "";
        if(webElement.isDisplayed()) {
            WebElement childElement = findChildElement(webElement, childElementLocator);
            value = childElement.getText();
        }
        return value;
    }

    public static String getAttributeFromWebElement(WebElement webElement, String attributeType) {
        String value = null;
        if(webElement.isDisplayed()) {
            value = webElement.getAttribute(attributeType);
        }
        return value;
    }

    public static String getCssValueFromWebElement(WebElement webElement, String key) {
        return webElement.getCssValue(key);
    }

    public static void highlightElement(WebDriver webDriver, WebElement webElement) {
        ExecuteJavaScript.highlightElement(webDriver, webElement);
    }

    public static By getBy(List<String> locators, int index) {
        String loc = locators.get(index);
        String locatorType = loc.split("::")[0];
        String locator = loc.split("::")[1];
        logger.debug(locatorType + " " + locator);
        return Locator.getInstance().getLocatorBy(locatorType, locator);
    }

    public static boolean highlightElementInList(WebDriver driver, List<WebElement> elements) {
        try {
            for(int i = 0; i < elements.size(); i++) {
                ExecuteJavaScript.scrollToElement(driver, elements.get(i));
                ExecuteJavaScript.highlightElement(driver, elements.get(i));
                Waits.threadSleep(1000, "");
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static WebElement findChildElement(WebElement webElement, String locator) {
        String locatorType = locator.split("::")[0];
        String locatorValue = locator.split("::")[1];
        logger.debug(locatorType + " " + locatorValue);
        By locatorBy = Locator.getInstance().getLocatorBy(locatorType, locatorValue);
        return webElement.findElement(locatorBy);
    }

    public static boolean isDisplayed(WebDriver driver, By by) {
       return isDisplayed(driver.findElement(by));
    }

    public static boolean isDisplayed(WebElement webElement) {
        return webElement.isDisplayed();
    }

    public static boolean isSelected(WebDriver driver, By by) {
        return isSelected(driver.findElement(by));
    }

    public static boolean isSelected(WebElement webElement) {
        return webElement.isSelected();
    }

    public static boolean isEnabled(WebDriver driver, By by) {
        return isEnabled(driver.findElement(by));
    }

    public static boolean isEnabled(WebElement webElement) {
        return webElement.isEnabled();
    }
}