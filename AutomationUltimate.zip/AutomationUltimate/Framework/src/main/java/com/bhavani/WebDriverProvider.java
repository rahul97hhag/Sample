package com.bhavani;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class WebDriverProvider {

    private static Logger logger = LoggerFactory.getLogger(WebDriverProvider.class);
    private static String resourcesPath = "G:\\Java_Projects\\Cigniti_Frameworks\\AutomationUltimate\\Resources\\";
    private static String driverPath = "drivers";
    private static String extensionsPath = "extensions";
    private static String chromeDriverPath = resourcesPath + driverPath + "\\chromedriver.exe";

    public WebDriver getWebDriver() {
        String folderPath = System.getProperty("user.dir");
        logger.debug(" "+folderPath);
        folderPath = folderPath.replace("\\Framework", "\\Resources");
        String driverPath = folderPath + "\\drivers\\";
       // String extensionsPath = folderPath + "\\extensions\\";
        logger.debug(" "+driverPath + "chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", chromeDriverPath);
        ChromeOptions options = new ChromeOptions();
        options.addArguments("–start-maximized");
        List<File> extensionPaths = new ArrayList<File>();
        /*
        extensionPaths.add(new File(resourcesPath + extensionsPath + "\\CSS-and-XPath-checker_v0.20.0.crx"));
        extensionPaths.add(new File(resourcesPath + extensionsPath + "\\EditThisCookie_v1.5.0.crx"));
        extensionPaths.add(new File(resourcesPath + extensionsPath + "\\jQuery-Injector_v1.1.2.crx"));
        extensionPaths.add(new File(resourcesPath + extensionsPath + "\\Protractor-Recorder_v2.0.0.crx"));
        */
        extensionPaths.add(new File(resourcesPath + extensionsPath + "\\fngmhnnpilhplaeedifhccceomclgfbg.zip"));
        extensionPaths.add(new File(resourcesPath + extensionsPath + "\\aoinfihhckpkkcpholfhmkeplbhddipe.zip"));
        options.addExtensions(extensionPaths);
        WebDriver webDriver = new ChromeDriver(options);
        return webDriver;
    }
}