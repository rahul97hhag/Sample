package com.bhavani.driverActions;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class CookiesHandler {

    private static Logger logger = LoggerFactory.getLogger(CookiesHandler.class);

    public static void clearBrowserSession(WebDriver driver) {
        ExecuteJavaScript.execJavascript(driver, "window.sessionStorage.clear();", null);
        ExecuteJavaScript.execJavascript(driver, "window.localStorage.clear();", null);
    }

}
