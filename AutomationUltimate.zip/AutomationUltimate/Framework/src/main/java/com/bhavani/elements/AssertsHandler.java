package com.bhavani.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class AssertsHandler {

    private static Logger logger = LoggerFactory.getLogger(AssertsHandler.class);

    public static void assertTextPresent(WebDriver driver, By by, String expectedText) {

    }

    public static void assertTextNotPresent(WebDriver driver, By by, String expectedText) {

    }

    public static void assertSubTextPresent(WebDriver driver, By by, String expectedSubText) {

    }

    public static void assertSubTextNotPresent(WebDriver driver, By by, String expectedSubText) {

    }


}
