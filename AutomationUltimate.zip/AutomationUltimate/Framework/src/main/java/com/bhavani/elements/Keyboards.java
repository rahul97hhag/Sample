package com.bhavani.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class Keyboards {

    private static final Logger log = LoggerFactory.getLogger(Keyboards.class);

    public static void sendEnter(WebDriver driver, String locatorType, String locator) {
        sendEnter(driver, Locator.getInstance().getLocatorBy(locatorType, locator));
    }

    public static void sendEnter(WebDriver driver, By selector) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            sendEnter(el);
        }
    }

    public static void sendEnter(WebElement webElement) {
        if (webElement != null) {
            webElement.sendKeys(Keys.ENTER);
        }
    }

    public static void clearText(WebDriver driver, String locatorType, String locator) {
        clearText(driver, Locator.getInstance().getLocatorBy(locatorType, locator));
    }

    public static void clearText(WebDriver driver, By selector) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            clearText(el);
        }
    }

    public static void clearText(WebElement webElement) {
        if (webElement != null) {
            webElement.clear();
        }
    }

    public static void setText(WebDriver driver, String locatorType, String locator, String text) {
        setText(driver, Locator.getInstance().getLocatorBy(locatorType, locator), text);
    }

    public static void setText(WebDriver driver, By selector, String text) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            setText(el, text);
        }
    }

    public static void setText(WebElement webElement, String text) {
        if (webElement != null) {
            webElement.sendKeys(text);
        }
    }

    public static void clearAndSetText(WebDriver driver, String locatorType, String locator, String text) {
        clearAndSetText(driver, Locator.getInstance().getLocatorBy(locatorType, locator), text);
    }

    public static void clearAndSetText(WebDriver driver, By selector, String text) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            clearAndSetText(el, text);
        }
    }

    public static void clearAndSetText(WebElement webElement, String text) {
        if (webElement != null) {
            clearText(webElement);
            webElement.sendKeys(text);
        }
    }

    public static void setTextAndSendKeys(WebDriver driver, String locatorType, String locator, String text, String key) {
        setTextAndSendKeys(driver, Locator.getInstance().getLocatorBy(locatorType, locator), text, key);
    }

    public static void setTextAndSendKeys(WebDriver driver, By selector, String text, String key) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            setTextAndSendKeys(el, text, key);
        }
    }

    public static void setTextAndSendKeys(WebElement webElement, String text, String key) {
        if (webElement != null) {
            webElement.sendKeys(text);
            sendKeys(webElement, key.toLowerCase());
        }
    }

    public static void setTextByChars(WebDriver driver, String locatorType, String locator, String text) {
        setTextByChars(driver, Locator.getInstance().getLocatorBy(locatorType, locator), text);
    }

    public static void setTextByChars(WebDriver driver, By selector, String text) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            setTextByChars(el, text);
        }
    }

    public static void setTextByChars(WebElement webElement, String text) {
        if (webElement != null) {
            for (char ch: text.toCharArray()) {
                webElement.sendKeys(String.valueOf(ch));
            }
        }
    }

    public static void clearAndSetTextByChars(WebDriver driver, String locatorType, String locator, String text) {
        clearAndSetTextByChars(driver, Locator.getInstance().getLocatorBy(locatorType, locator), text);
    }

    public static void clearAndSetTextByChars(WebDriver driver, By selector, String text) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            clearAndSetTextByChars(el, text);
        }
    }

    public static void clearAndSetTextByChars(WebElement webElement, String text) {
        clearText(webElement);
        if (webElement != null) {
            for (char ch: text.toCharArray()) {
                webElement.sendKeys(String.valueOf(ch));
            }
        }
    }

    public static void sendKeys(WebDriver driver, String locatorType, String locator, String key) {
        sendKeys(driver, Locator.getInstance().getLocatorBy(locatorType, locator), key);
    }

    public static void sendKeys(WebDriver driver, By selector, String key) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            sendKeys(el, key);
        }
    }

    public static void sendFunctionKeys(WebDriver driver, String locatorType, String locator, int number) {
        sendFunctionKeys(driver, Locator.getInstance().getLocatorBy(locatorType, locator), number);
    }

    public static void sendFunctionKeys(WebDriver driver, By selector, int number) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            sendFunctionKeys(el, number);
        }
    }

    public static void sendFunctionKeys(WebElement el, int number) {
        if (el != null) {
            switch(number) {
                case 1:
                    el.sendKeys(Keys.F1);
                    break;
                case 2:
                    el.sendKeys(Keys.F2);
                    break;
                case 3:
                    el.sendKeys(Keys.F3);
                    break;
                case 4:
                    el.sendKeys(Keys.F4);
                    break;
                case 5:
                    el.sendKeys(Keys.F5);
                    break;
                case 6:
                    el.sendKeys(Keys.F6);
                    break;
                case 7:
                    el.sendKeys(Keys.F7);
                    break;
                case 8:
                    el.sendKeys(Keys.F8);
                    break;
                case 9:
                    el.sendKeys(Keys.F9);
                    break;
                case 10:
                    el.sendKeys(Keys.F10);
                    break;
                case 11:
                    el.sendKeys(Keys.F11);
                    break;
                case 12:
                    el.sendKeys(Keys.F12);
                    break;
                default:
                    break;
            }
        }
    }

    public static void sendNumericKeys(WebDriver driver, String locatorType, String locator, int number) {
        sendNumericKeys(driver, Locator.getInstance().getLocatorBy(locatorType, locator), number);
    }

    public static void sendNumericKeys(WebDriver driver, By selector, int number) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            sendNumericKeys(el, number);
        }
    }

    public static void sendNumericKeys(WebElement el, int number) {
        if (el != null) {
            switch(number) {
                case 0:
                    el.sendKeys(Keys.NUMPAD0);
                    break;
                case 1:
                    el.sendKeys(Keys.NUMPAD1);
                    break;
                case 2:
                    el.sendKeys(Keys.NUMPAD2);
                    break;
                case 3:
                    el.sendKeys(Keys.NUMPAD3);
                    break;
                case 4:
                    el.sendKeys(Keys.NUMPAD4);
                    break;
                case 5:
                    el.sendKeys(Keys.NUMPAD5);
                    break;
                case 6:
                    el.sendKeys(Keys.NUMPAD6);
                    break;
                case 7:
                    el.sendKeys(Keys.NUMPAD7);
                    break;
                case 8:
                    el.sendKeys(Keys.NUMPAD8);
                    break;
                case 9:
                    el.sendKeys(Keys.NUMPAD9);
                    break;
                default:
                    break;
            }
        }
    }

    public static void sendArrowKeys(WebDriver driver, String locatorType, String locator, String key) {
        sendArrowKeys(driver, Locator.getInstance().getLocatorBy(locatorType, locator), key);
    }

    public static void sendArrowKeys(WebDriver driver, By selector, String key) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            sendArrowKeys(el, key);
        }
    }

    public static void sendArrowKeys(WebElement el, String key) {
        if (el != null) {
            switch(key) {
                case "down":
                    el.sendKeys(Keys.ARROW_DOWN);
                    break;
                case "left":
                    el.sendKeys(Keys.ARROW_LEFT);
                    break;
                case "right":
                    el.sendKeys(Keys.ARROW_RIGHT);
                    break;
                case "up":
                    el.sendKeys(Keys.ARROW_UP);
                    break;
                default:
                    break;
            }
        }
    }

    public static void sendKeys(WebElement webElement, String key) {
        if (webElement != null) {
            switch(key.toLowerCase()) {
                case "enter":
                    webElement.sendKeys(Keys.ENTER);
                    break;
                case "alt":
                    webElement.sendKeys(Keys.ALT);
                    break;
                case "backspace":
                    webElement.sendKeys(Keys.BACK_SPACE);
                    break;
                case "cancel":
                    webElement.sendKeys(Keys.CANCEL);
                    break;
                case "clear":
                    webElement.sendKeys(Keys.CLEAR);
                    break;
                case "command":
                    webElement.sendKeys(Keys.COMMAND);
                    break;
                case "control":
                    webElement.sendKeys(Keys.CONTROL);
                    break;
                case "leftcontrol":
                    webElement.sendKeys(Keys.LEFT_CONTROL);
                    break;
                case "leftshift":
                    webElement.sendKeys(Keys.LEFT_SHIFT);
                    break;
                case "shift":
                    webElement.sendKeys(Keys.SHIFT);
                    break;
                case "decimal":
                    webElement.sendKeys(Keys.DECIMAL);
                    break;
                case "delete":
                    webElement.sendKeys(Keys.DELETE);
                    break;
                case "divide":
                    webElement.sendKeys(Keys.DIVIDE);
                    break;
                case "down":
                    webElement.sendKeys(Keys.DOWN);
                    break;
                case "equals":
                    webElement.sendKeys(Keys.EQUALS);
                    break;
                case "escape":
                    webElement.sendKeys(Keys.ESCAPE);
                    break;
                case "help":
                    webElement.sendKeys(Keys.HELP);
                    break;
                case "home":
                    webElement.sendKeys(Keys.HOME);
                    break;
                case "insert":
                    webElement.sendKeys(Keys.INSERT);
                    break;
                case "left":
                    webElement.sendKeys(Keys.LEFT);
                    break;
                case "leftalt":
                    webElement.sendKeys(Keys.LEFT_ALT);
                    break;
                case "pagedown":
                    webElement.sendKeys(Keys.PAGE_DOWN);
                    break;
                case "meta":
                    webElement.sendKeys(Keys.META);
                    break;
                case "multiply":
                    webElement.sendKeys(Keys.MULTIPLY);
                    break;
                case "null":
                    webElement.sendKeys(Keys.NULL);
                    break;
                case "pageup":
                    webElement.sendKeys(Keys.PAGE_UP);
                    break;
                case "pause":
                    webElement.sendKeys(Keys.PAUSE);
                    break;
                case "return":
                    webElement.sendKeys(Keys.RETURN);
                    break;
                case "right":
                    webElement.sendKeys(Keys.RIGHT);
                    break;
                case "semicolon":
                    webElement.sendKeys(Keys.SEMICOLON);
                    break;
                case "separator":
                    webElement.sendKeys(Keys.SEPARATOR);
                    break;
                case "space":
                    webElement.sendKeys(Keys.SPACE);
                    break;
                case "subtract":
                    webElement.sendKeys(Keys.SUBTRACT);
                    break;
                case "tab":
                    webElement.sendKeys(Keys.TAB);
                    break;
                case "up":
                    webElement.sendKeys(Keys.UP);
                    break;
                default:
                    break;
            }
        }
    }

    public static void pressKey(WebDriver driver, String key) {
        Actions actions = new Actions(driver);
        switch (key.toLowerCase()) {
            case "enter":
                actions.sendKeys(Keys.ENTER).build().perform();
                break;
            case "space":
                actions.sendKeys(Keys.SPACE).build().perform();
                break;
            case "tab":
                actions.sendKeys(Keys.TAB).build().perform();
                break;
            default:
                break;
        }
    }


}