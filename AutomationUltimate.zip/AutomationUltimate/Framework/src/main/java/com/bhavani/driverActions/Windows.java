package com.bhavani.driverActions;

import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class Windows {
    private static final Logger log = LoggerFactory.getLogger(Windows.class);

    public static void selectWindowByIndex(WebDriver driver, int index) {
        Set<String> windows = getWindowHandles(driver);
        List<String> windowStrings = new ArrayList<>(windows);
        if(!(index >= windowStrings.size() - 1)) {
            String reqWindow = windowStrings.get(index);
            driver.switchTo().window(reqWindow);
            log.info("Switched to " + driver.getTitle());
        } else {
            log.info("Invalid index was given "+ index);
        }
    }

    public static void selectWindowByTitle(WebDriver driver, String title) {
        Set<String> windows = getWindowHandles(driver);
        List<String> windowStrings = new ArrayList<>(windows);
        for(int i = 0; i < windowStrings.size(); i++) {
            String reqWindow = windowStrings.get(i);
            if(reqWindow.contains(title)) {
                driver.switchTo().window(reqWindow);
            }
        }
        log.info("Switched to " + driver.getTitle());
    }

    public static void closeOtherWindows(WebDriver driver, String title) {
        Set<String> windows = getWindowHandles(driver);
        List<String> windowStrings = new ArrayList<>(windows);
        for(int i = 0; i < windowStrings.size(); i++) {
            String reqWindow = windowStrings.get(i);
            if(!(reqWindow.contains(title))) {
                driver.switchTo().window(reqWindow);
                driver.close();
            }
        }
        driver.switchTo().window(title);
        log.info("Switched to " + driver.getTitle());
    }

    public static String getCurrentURL(WebDriver webDriver) {
        return webDriver.getCurrentUrl();
    }

    public static String getTitle(WebDriver webDriver) {
        return webDriver.getTitle();
    }

    public static Set<String> getWindowHandles(WebDriver webDriver) {
       return webDriver.getWindowHandles();
    }

    public boolean isAlive(WebDriver driver) {
        try {
            return driver.getWindowHandles().size() > 0;
        } catch (UnhandledAlertException ex) {
            return true;
        } catch (WebDriverException ex) {
            return false;
        }
    }

    public static String getPageSource(WebDriver webDriver) {
        String pageSource = webDriver.getPageSource();
        return pageSource;
    }


}
