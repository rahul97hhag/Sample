package com.bhavani.driverActions;

import com.google.common.base.Function;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import java.util.concurrent.TimeUnit;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class Waits {

    private static Logger logger = LoggerFactory.getLogger(Waits.class);

    public static boolean forPageReady(WebDriver driver) {
        int waitTime = 60;
        final long ts = System.currentTimeMillis();
        new WebDriverWait(driver, waitTime).until((WebDriver wDriver) -> {
            try {
                return ExecuteJavaScript.waitForAnimation(driver) && ExecuteJavaScript.isPageLoaded(driver);
            } catch (Exception e) {
                logger.debug("Exception while checking for page ready : " + e.getMessage());
                return false;
            }
        });
        return true;
    }

    public static boolean threadSleep(long sleepTime, String msg) {
        Thread cur = Thread.currentThread();
        try {
            if (msg != null) { logger.trace("Thread \"" + cur.getName() + "\" sleeping for: " + sleepTime + "ms"); }
            Thread.sleep(sleepTime);
            if (msg != null) { logger.trace("Thread \"" + cur.getName() + " is awake"); }
            return false;
        } catch (InterruptedException e) {
            if (msg != null) { logger.trace("Thread \"" + cur.getName() + " was interrupted:" + e.getMessage()); }
            return true;
        }
    }

    public static boolean untilElementNotPresent(WebDriver driver, By selector, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(selector));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for element not present  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementPresent(WebDriver driver, By selector, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.visibilityOfElementLocated(selector));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for element present  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilAlertIsPresent(WebDriver driver, By selector, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            if(wait.until(ExpectedConditions.alertIsPresent())==null) {
                logger.debug("Alert was not present");
            } else {
                logger.debug("Alert was present");
                return true;
            }
        } catch (Exception ex) {
            logger.debug("Exception while waiting for alert  " + ex.getMessage());
        }
        return false;
    }

    public static boolean untilAttributeToBe(WebDriver driver, WebElement webElement, String attributeName, String attributeValue, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.attributeToBe(webElement, attributeName, attributeValue));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking attribute present in webelement " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilAttributeToBe(WebDriver driver, By by, String attributeName, String attributeValue, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.attributeToBe(by, attributeName, attributeValue));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking attribute present " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilAttributeContains(WebDriver driver, WebElement webElement, String attributeName, String attributeValue, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.attributeContains(webElement, attributeName, attributeValue));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking attribute "+attributeName+" contains " + attributeValue+ " " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilAttributeContains(WebDriver driver, By by, String attributeName, String attributeValue, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.attributeContains(by, attributeName, attributeValue));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking attribute value " + attributeValue+ " is present in "+attributeName+ " " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementSelectionStateToBe(WebDriver driver, By selector, boolean selectionState, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.elementSelectionStateToBe(selector, selectionState));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementToBeClickable(WebDriver driver, By selector, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.elementToBeClickable(selector));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementToBeSelected(WebDriver driver, By selector, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.elementToBeSelected(selector));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilFrameToBeAvaialble(WebDriver driver, String frameName, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementIsInvisibleWithText(WebDriver driver, By selector, String text, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.invisibilityOfElementWithText(selector, text));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilPresenceOfNestedElementLocatedBy(WebDriver driver, By parentSelector, By nestedSelector, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.presenceOfNestedElementLocatedBy(parentSelector, nestedSelector));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementIsClickable(WebDriver driver, WebElement webElement, int seconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            logger.info("");
            wait.until(ExpectedConditions.elementToBeClickable(webElement));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static boolean untilElementIsClickable(WebDriver driver, By by, int seconds) {
        try {
        //    logger.info("");
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(ExpectedConditions.elementToBeClickable(by));
            return true;
        } catch (Exception ex) {
            logger.debug("Exception while checking for page ready  " + ex.getMessage());
            return false;
        }
    }

    public static void fluentWait(WebDriver webDriver, By by, int seconds) {
        WebElement foo = webDriver.findElement(by);
        new FluentWait<WebElement>(foo)
            .withTimeout(java.time.Duration.ofSeconds(seconds))
            .pollingEvery(java.time.Duration.ofSeconds(2))
            .until(new Function<WebElement, String>() {
                @Override
                public String apply(WebElement element) {
                    return element.getText();
                }
            });
    }

}