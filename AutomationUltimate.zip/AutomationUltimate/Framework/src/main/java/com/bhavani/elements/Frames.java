package com.bhavani.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class Frames {
    private static final Logger log = LoggerFactory.getLogger(Frames.class);

    public static void switchToFrame(WebDriver driver, String locatorType, String locator) {
        switchToFrame(driver, Locator.getInstance().getLocatorBy(locatorType, locator));
    }

    public static void switchToFrame(WebDriver driver, By selector) {
        WebElement el = Elements.findElement(driver, selector);
        if (el != null) {
            switchToFrame(driver, el);
        }
    }

    public static void switchToFrame(WebDriver driver, WebElement webElement) {
        if (webElement != null) {
            driver.switchTo().frame(webElement);
        }
    }

    public static void switchToFrame(WebDriver driver, int index) {
        driver.switchTo().frame(index);
    }

    public static void switchToFrame(WebDriver driver, String name) {
        driver.switchTo().frame(name);
    }

    public static void switchToDefaultFrame(WebDriver driver) {
        driver.switchTo().defaultContent();
    }

    public static void switchToParentFrame(WebDriver driver) {
        driver.switchTo().parentFrame();
    }


}
