package com.bhavani.driverActions;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 8/9/2020.
 */
public class NavActions {
    private static Logger logger = LoggerFactory.getLogger(NavActions.class);

    public static void refreshBrowser(WebDriver driver) {
        driver.navigate().refresh();
        Waits.threadSleep(3000, "");
    }

    public static void navigateBack(WebDriver driver) {
        driver.navigate().back();
        Waits.threadSleep(3000, "");
    }

    public static void navigateForward(WebDriver driver) {
        driver.navigate().forward();
        Waits.threadSleep(3000, "");
    }

}
