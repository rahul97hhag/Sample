package com.bhavani.elements;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class Locator {

    private static final Locator instance = new Locator();
    private static Logger logger = LoggerFactory.getLogger(Locator.class);

    private Locator() {
    }

    public static Locator getInstance(){
        return instance;
    }

    public By locateByName(final String name) {
        return By.name(name);
    }

    public By locateById(final String id) {
        return By.id(id);
    }

    public By locateByCSSSelector(final String cssSelector) {
        return By.cssSelector(cssSelector);
    }

    public By locateByXPath(final String xPath) {
        return By.xpath(xPath);
    }

    public By locateByLinkText(final String linkText) {
        return By.linkText(linkText);
    }

    public By locateByPartialLinkText(final String partialLinkText) {
        return By.partialLinkText(partialLinkText);
    }

    public By locateByClassName(final String className) {
        return By.className(className);
    }

    public By locateByTagName(final String tagName) {
        return By.tagName(tagName);
    }

    public By getLocatorBy(String locatorType, String locator) {
        if(isValidLocatorStrategy(locatorType)) {
            switch (locatorType.toLowerCase()) {
                case "id":
                    return locateById(locator);
                case "linktext":
                case "link text":
                    return locateByLinkText(locator);
                case "name":
                    return locateByName(locator);
                case "partiallinktext":
                case "partial link text":
                    return locateByPartialLinkText(locator);
                case "tagname":
                case "tag name":
                    return locateByTagName(locator);
                case "xpath":
                    return locateByXPath(locator);
                case "classname":
                case "class":
                case "class name":
                    return locateByClassName(locator);
                case "cssselector":
                case "css selector":
                case "css":
                    return locateByCSSSelector(locator);
                default:
                    return null;
            }
        }
        return null;
    }

    private boolean isValidLocatorStrategy(String locatorType) {
        switch (locatorType.toLowerCase()) {
            case "id":
            case "linktext":
            case "link text":
            case "name":
            case "partiallinktext":
            case "partial link text":
            case "tagname":
            case "tag name":
            case "xpath":
            case "classname":
            case "class":
            case "class name":
            case "cssselector":
            case "css selector":
            case "css":
                return true;
            default:
                return false;
        }
    }
}