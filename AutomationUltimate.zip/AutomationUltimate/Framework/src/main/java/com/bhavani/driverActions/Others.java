package com.bhavani.driverActions;

import com.bhavani.elements.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created by BhavaniPrasadReddy on 6/19/2020.
 */
public class Others {

    public static boolean openNewTab(WebElement element) {
        try {
            String openNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN);
            element.sendKeys(openNewTab);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean openNewTab(WebDriver webDriver, By by) {
        try {
            String openNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN);
            Waits.untilElementPresent(webDriver, by, 30);
            Elements.findElement(webDriver, by).sendKeys(openNewTab);
            return true;
        } catch (Exception e) {
            return false;
        }
    }




}