package com.bhavani.elements;

import com.bhavani.driverActions.ExecuteJavaScript;
import com.bhavani.driverActions.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class Clicks {

    public static boolean mouseMoveOnElement(WebDriver driver, WebElement element) {
        try {
            Actions action = new Actions(driver);
            action.moveToElement(element).build().perform();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean mouseMoveOnElement(WebDriver driver, WebElement element, int index) {
        try {
            Actions action = new Actions(driver);
            for(int i = 0; i < index; i++) {
                action.moveToElement(element).build().perform();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean scrollToEachElementInList(WebDriver driver, List<WebElement> elements) {
        try {
            for(int i = 0; i < elements.size(); i++) {
                ExecuteJavaScript.scrollToElement(driver, elements.get(i));
                Waits.threadSleep(1000, "");
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean moveToEachElementInList(WebDriver driver, List<WebElement> elements) {
        try {
            for(int i = 0; i < elements.size(); i++) {
                mouseMoveOnElement(driver, elements.get(i));
                Waits.threadSleep(1000, "");
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean click(WebDriver driver, WebElement element) {
        try {
            Waits.untilElementIsClickable(driver, element, 30);
            element.click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean click(WebDriver driver, By by) {
        try {
            Waits.untilElementIsClickable(driver, by, 30);
            driver.findElement(by).click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean mouseMoveAndClick(WebDriver driver, By by) {
        try {
            Waits.untilElementIsClickable(driver, by, 30);
            mouseMoveOnElement(driver, driver.findElement(by));
            click(driver, by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}