package com.bhavani.driverActions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/4/2020.
 */
public class ExecuteJavaScript {

    private static Logger logger = LoggerFactory.getLogger(ExecuteJavaScript.class);

    public static Object execJavascript(WebDriver driver, String script, Object... args) {
        try {
            JavascriptExecutor scriptExe = ((JavascriptExecutor) driver);
            return scriptExe.executeScript(script, args);
        } catch (Exception e) {
            logger.debug(String.format("Error in executing javascript : %s", e.toString().split("\\(Session")[0]));
            return "";
        }
    }

    private static String getPageSource(WebDriver driver) {
        try {
            return execJavascript(driver, "return document.documentElement.outerHTML").toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static void scrollPage(WebDriver driver, int horizontal, int vertical) {
        execJavascript(driver, "window.scrollBy(" + horizontal + ", " + vertical + ")");
    }

    public static boolean waitForAnimation(WebDriver driver) {
        Object done = execJavascript(driver, "return $(\":animated\").length == 0;");
        logger.trace("animation done js response : " + done);
        return done instanceof Boolean ? (Boolean) done : true;
    }

    public static boolean isPageLoaded(WebDriver driver) {
        String state = (String) execJavascript(driver, "return document.readyState;");
        logger.trace("document ready state : " + state);
        return state.matches("complete|loaded|interactive");
    }

    public static String getPageText(WebDriver driver) {
        try {
            return execJavascript(driver, "return document.body.textContent").toString();
        } catch (Exception ex) {
            return "";
        }
    }

    public static void scrollToElement(WebDriver driver, WebElement webElement) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", webElement);
    }

    public static void scrollToElementById(WebDriver driver, String id, int i) {
        ((JavascriptExecutor) driver).executeScript("$(\""+id+"\").animate({ scrollTop: \""+100*i+"px\" })");
    }

    public static void highlightElement(WebDriver webDriver, WebElement webElement) {
        String color1 = "arguments[0].setAttribute('style', 'background: yellow; color: blue; border: 3px solid red;');";
        String color2 = "arguments[0].setAttribute('style', 'background: black; color: yellow; border: 3px solid blue;');";

        for(int i = 0; i < 6; i++) {
            if(i%2 == 0) {
                ((JavascriptExecutor) webDriver).executeScript(color1, webElement);
            } else {
                ((JavascriptExecutor) webDriver).executeScript(color2, webElement);
            }
            Waits.threadSleep(1000, "");
        }
    }

    public void waitForAngularCustom(WebDriver webDriver) {
        String javaScriptCode = "return (window.angular !== undefined) && (angular.element(document).injector() !== undefined)";
        String result = ((JavascriptExecutor) webDriver).executeScript(javaScriptCode).toString();
        logger.info(result);

    }


}