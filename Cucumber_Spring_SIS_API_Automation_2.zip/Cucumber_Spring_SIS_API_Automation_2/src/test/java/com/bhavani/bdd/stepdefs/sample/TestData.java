package com.bhavani.bdd.stepdefs.sample;

import com.bhavani.models.others.ZipCode;
import com.bhavani.models.patient.*;
import com.bhavani.models.patientCases.caseSummary.CaseDetailInformation;
import com.bhavani.models.patientCases.chargeEntry.ChargeEntry;
import com.bhavani.models.patientCases.newCaseSummary.CaseGuarantor;
import com.bhavani.models.patientCases.newCaseSummary.CaseInsurance;
import com.bhavani.models.room.Room;

/**
 * Created by BhavaniPrasadReddy on 9/1/2020.
 */
public class TestData {

    private Room room;
    private Patient patient;
    private Address address;
    private MpiPatientPhone patientPhone;
    private EmergencyContact emergencyContact;
    private Employer employer;
    private ZipCode zipCode;

    private CaseDetailInformation caseDetailInformation;
    private CaseGuarantor patientGuarantor;
    private CaseInsurance patientInsurance;

    private ChargeEntry chargeEntry;



}
