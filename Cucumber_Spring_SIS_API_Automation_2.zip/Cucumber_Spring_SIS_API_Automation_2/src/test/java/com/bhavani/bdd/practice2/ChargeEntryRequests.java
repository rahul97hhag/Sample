package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.patientCases.chargeEntry.ChargeEntry;
import com.bhavani.models.patientCases.chargeEntryResponse.ChargeEntryResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/29/2020.
 */
public class ChargeEntryRequests extends AbstractSteps {
    private static Logger LOG = LoggerFactory.getLogger(ChargeEntryRequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public List<ChargeEntryResponse> performChargeEntry(List<ChargeEntry> chargeEntries) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(chargeEntries));
            super.executePost("api/CaseToCharge/SavePerformedProcedure/");
            Response chargeEntryResponse = testContext().getResponse();
            LOG.info(chargeEntryResponse.asString());
            List<ChargeEntryResponse> chargeEntryResponseObject = null;
            chargeEntryResponseObject = Arrays.asList(mapper.readValue(chargeEntryResponse.asString(), ChargeEntryResponse[].class));
            return chargeEntryResponseObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
