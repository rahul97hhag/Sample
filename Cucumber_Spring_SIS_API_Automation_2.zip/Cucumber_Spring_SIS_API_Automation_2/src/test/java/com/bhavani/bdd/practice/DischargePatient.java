package com.bhavani.bdd.practice;

public class DischargePatient {

	public static void main(String[] args) {
		
	}
}
