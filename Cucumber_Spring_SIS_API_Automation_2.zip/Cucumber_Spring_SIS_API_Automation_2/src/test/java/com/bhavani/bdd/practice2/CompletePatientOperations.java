package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.builder.*;
import com.bhavani.models.appointmentType.AppointmentType;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.icdCodes.IcdCodes;
import com.bhavani.models.patient.Address;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.patientCases.caseSummary.*;
import com.bhavani.models.patientCases.casesToCode.*;
import com.bhavani.models.patientCases.casesToCodeResponse.CasesToCodeResponse;
import com.bhavani.models.patientCases.chargeEntry.*;
import com.bhavani.models.patientCases.chargeEntryResponse.ChargeEntryResponse;
import com.bhavani.models.patientCases.dischargePatient.*;
import com.bhavani.models.patientCases.newCaseSummary.CaseProcedure;
import com.bhavani.models.patientCases.newCaseSummary.CaseSummary;
import com.bhavani.models.room.ActiveRoom;
import com.bhavani.models.scheduledProcedures.ScheduledProcedures;
import com.bhavani.models.staff.Staff;
import com.bhavani.utils.DateUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.minidev.json.JSONArray;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

/**
 * Created by BhavaniPrasadReddy on 8/29/2020.
 */
public class CompletePatientOperations extends AbstractSteps {

    private static Logger LOG = LoggerFactory.getLogger(CompletePatientOperations.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public void completePatientOperations() {
        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";

        String roomName = "Gemuser2_Room1";
        String appointmentTypeName = "Gem_General2";
        String cptCode = "22899";
        String physicianName = "Gem_user10";
        String preOpDiagnosisCode = "H44.001";

        String insuranceName = "Carrier1906_3";

        String randomString = RandomStringUtils.randomAlphabetic(6);
        String patientFirstName = "AAAAAAA" + randomString;
        String patientLastName = "AAAAAAA" + randomString;
        String patientMiddleInitial = "M";
        String patientDateOfBirth = "11/11/1991";
        String patientGender = "Male";

        String date = DateUtilities.getInstance().addDate("today", "yyyy-MM-dd");
        String today = date + "T01:00:39.422Z";
        String country = "United States";
        String addressKind = "RESIDENTIAL";
        String startTime = "11:00";
        String endTime = "12:00";
        int duration = 60;
        String dateOfService = DateUtilities.getInstance().addDate("today", "MM/dd/yyyy");
        String procedureStartTime = date + "T"+startTime+":00.000Z";
        String procedureStopTime = date + "T"+endTime+":00.000Z";
        String procedureStartDt = date + "T"+startTime+":00.000Z";
        String procedureStopDt = date+ "T"+endTime+":00.000Z";

        String procedureDate = null;
        String formName = "Patient Panel";
        String formLastUpdatedDate = date + "T02:00:00.000Z";

        String inTime = date + "T11:20:00.000Z";
        String outTime = date + "T11:30:00.000Z";

        String transferTime = date + "T07:00:00+05:30";
        String transferTimeOfTime = DateUtilities.getInstance().addDate("today", "MM-dd-yyyy") + " 07:20";
        String transferTimeWfTime = DateUtilities.getInstance().addDate("today", "MM-dd-yyyy") + " 03:30";

        String admissionTime = date+ "T06:30:00+05:30";

        String moduleName = "Recovery";
        String transferModuleName = "Recovery";
        Module module = null;
        Module transferModule = null;

        String icdCode = "H44.001";
        String periodName = "A_2018";
        String batchName = "batch_10";
        int amount = 2000;
        int units = 1;

        CommonRequests commonRequests = new CommonRequests();
        PatientRequests patientRequests = new PatientRequests();
        DischargePatientRequests dischargePatientRequests = new DischargePatientRequests();
        CasesToCodeRequests casesToCodeRequests = new CasesToCodeRequests();
        ChargeEntryRequests chargeEntryRequests = new ChargeEntryRequests();

        commonRequests.createSession(username, password, facility);

        AppointmentType appointmentType = commonRequests.getAppointmentType(appointmentTypeName);
        LOG.info(appointmentType.toString());
        Staff staff = commonRequests.getPhysicianDetails(physicianName);
        LOG.info(staff.toString());
        FeeSchedule feeSchedule = commonRequests.getFeeScheduleByCptCode(cptCode);
        LOG.info(feeSchedule.toString());

        ActiveRoom room = commonRequests.getRoomByName(roomName);
        LOG.info(room.toString());
        LOG.info(room.getName()+" "+ room.getRoomId() + " " + room.getOrganizationId());

        Patient patient = PatientObjects.buildPatientObject(patientFirstName, patientLastName, patientMiddleInitial, patientGender, patientDateOfBirth);
        patient = patientRequests.createPatient(patient);
        patient = patientRequests.getPatientFromFirstNameAndLastName(patientFirstName, patientLastName);

        CaseSummary caseSummary = new CaseSummary();
        caseSummary.setCaseEquipments(new JSONArray());
        caseSummary.setToday(today);
        caseSummary.setCaseSummaryId(0);
        patient.setAddress(new Address());
        caseSummary.setPatient(patient);
        caseSummary.setPatientId(patient.getPatientId());
        caseSummary.getPatient().getAddress().setCountry(country);
        caseSummary.getPatient().getAddress().setPatientId(patient.getPatientId());
        caseSummary.getPatient().getAddress().setAddressKindName(addressKind);
        caseSummary.setCaseGuarantor(GuarantorObjects.getEmptyPatientGuarantors(patient));
        caseSummary.getPatient().setDateOfBirth("11/11/1991");
        caseSummary.setCaseInsurances(InsuranceObjects.getEmptyPatientInsurances());
        caseSummary.setCaseMSPInsuranceTypeMap(null);

        List<CaseProcedure> caseProcedures = new ArrayList<>();
        CaseProcedure caseProcedure = ProcedureObjects.buildCaseProcedure(cptCode, physicianName, staff, feeSchedule);
        caseProcedures.add(caseProcedure);
        caseSummary.setCaseProcedures(caseProcedures);

        caseSummary.setCasePreferenceCards(new JSONArray());
        caseSummary.setRoomId(room.getRoomId());
        caseSummary.setRoomName(room.getName());

        caseSummary.setProcedureStopDt(procedureStopDt);
        caseSummary.setProcedureStartDt(procedureStartDt);
        caseSummary.setProcedureStartTime(procedureStartTime);
        caseSummary.setProcedureStopTime(procedureStopTime);

        caseSummary.setStartTime(startTime);
        caseSummary.setEndTime(endTime);
        caseSummary.setDuration(duration);
        caseSummary.setAppointmentTypeId(appointmentType.getAppointmentTypeId());
        caseSummary.setAppointmentTypeName(appointmentType.getAppointmentTypeDesc());
        caseSummary.setCaseType(appointmentType.getCaseTypeAfterStartDate());
        caseSummary.setProcedureDt(procedureStartTime);
        caseSummary.setDateOfService(dateOfService);
        caseSummary.setAdditionalClaimInfo(CaseSummaryObjects.getAdditionalClaimInfo());
        caseSummary.setPrimaryPhysicianId(staff.getPersonId());

        patientRequests.upsertCaseSummary(caseSummary);

        staff = commonRequests.getPhysicianDetails(username);

        CaseSummaryFromPatientId caseSummaryFromPatientId = patientRequests.getCaseSummaryByPatientId(patient.getPatientId());
        CaseSummaryFromCaseSummaryId caseSummaryFromCaseSummaryId = patientRequests.getCaseSummaryByCaseSummaryId(caseSummaryFromPatientId.getCaseSummaryId());
        CaseSummaryInfo caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        CaseInformation caseInformation = patientRequests.getCaseInformation(caseSummaryFromCaseSummaryId.getCaseSummaryId());

        dischargePatientRequests.getModulesAndFormsByCaseId(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        dischargePatientRequests.getModules();
        patientRequests.getBasicModuleInfoByCaseSummaryId(caseSummaryFromCaseSummaryId.getCaseSummaryId());

        AreaOfCareStaffDetails saveAreaOfCareStaffDetails = null;
        AreaCareInformationResponse areaCareInformationResponse = null;
        AreaOfCareStaffDetails areaOfCareStaffDetailsResponse = null;

        org.json.JSONArray admitSources = null;
        org.json.JSONArray admitTypes = null;
        admitSources = commonRequests.getResponseFromURL("PatientCoverPage/AreaOfCare/PreOperative/admit_source.json");
        admitTypes = commonRequests.getResponseFromURL("PatientCoverPage/AreaOfCare/PreOperative/admit_type.json");

        CaseDetailInformation caseDetailInformation = patientRequests.getCaseDetailInformation(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());
        List<Module> modules = caseDetailInformation.getModules();
        module = modules.stream().filter(obj ->
                moduleName.contentEquals(obj.getModuleName())).findAny().orElse(null);
        transferModule = modules.stream().filter(obj ->
                transferModuleName.contentEquals(obj.getModuleName())).findAny().orElse(null);

        patientRequests.getCaseDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), module.getModuleId());

        dischargePatientRequests.getPrimaryPhysicianFromCase(caseSummaryInfo.getCaseSummaryId());
        commonRequests.getBusinssEntitySettings();
        patientRequests.getCurrentBEByPatientId(patient.getPatientId());
        commonRequests.getPatientRecord(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());
        commonRequests.getPatientRecordByCaseSummaryId(caseSummaryInfo.getCaseSummaryId());
        commonRequests.getCoverPageInformation(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());
        commonRequests.getPatientMonitorConfiguration();
        procedureDate = caseSummaryFromCaseSummaryId.getProcedureDt();

        FormByName formByName = dischargePatientRequests.getFormByName(formName);
        int moduleId = module.getModuleId();
        FormUsageByFormOwner formUsageByFormOwner = dischargePatientRequests.getFormUsageByFormOwner(caseSummaryInfo.getCaseSummaryId(), moduleId, formByName.getFormId());

        formUsageByFormOwner.setLastUpdated(formLastUpdatedDate);
        formUsageByFormOwner.setStaffId(staff.getStaffId());
        formUsageByFormOwner.setStaffName(staff.getFullName());
        formUsageByFormOwner = dischargePatientRequests.updateFormUsageByFormOwner(formUsageByFormOwner);
        formUsageByFormOwner = dischargePatientRequests.getFormUsageByFormOwner(caseSummaryInfo.getCaseSummaryId(), moduleId, formByName.getFormId());

        caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryInfo.getCaseSummaryId());
        dischargePatientRequests.isModuleExistsForCase(caseSummaryInfo.getCaseSummaryId());
        areaOfCareStaffDetailsResponse = dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");
        dischargePatientRequests.getModulesByCaseId(caseSummaryFromCaseSummaryId.getCaseSummaryId(), Integer.valueOf(super.testContext().get("organizationId").toString()));

        caseSummaryFromCaseSummaryId = patientRequests.getCaseSummaryByCaseSummaryId(caseSummaryInfo.getCaseSummaryId());

        org.json.JSONObject requestLockObject = new org.json.JSONObject();
        requestLockObject.put("CaseSummaryId", String.valueOf(caseSummaryFromCaseSummaryId.getCaseSummaryId()));
        requestLockObject.put("RecordLockTypeId", 16);
        requestLockObject.put("ModuleId", moduleId);
        patientRequests.requestLock(requestLockObject);

        dischargePatientRequests.getSpecialtyByCase(caseSummaryFromCaseSummaryId.getCaseSummaryId());

        dischargePatientRequests.getAreaCareInformationByCase(patient.getPatientId(), caseSummaryFromCaseSummaryId.getCaseSummaryId(), 0);
        dischargePatientRequests.getAreaCareInformationByCase(patient.getPatientId(), caseSummaryFromCaseSummaryId.getCaseSummaryId(), module.getModuleId());
        dischargePatientRequests.getRoomsFromDictionary("Gemuser2_Room1");
        caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryInfo.getCaseSummaryId());

        dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "undefined");

        AreaOfCareStaffDetails saveAreaOfCareStaffDetailsResponse = new AreaOfCareStaffDetails();

        List<AreaofCareStaffEntryDetail> areaofCareStaffEntryDetailsList = new ArrayList<>();
        AreaofCareStaffEntryDetail areaofCareStaffEntryDetail = new AreaofCareStaffEntryDetail();
        areaofCareStaffEntryDetail.setStaffId(staff.getStaffId());
        areaofCareStaffEntryDetail.setStaffRoleId(staff.getRoleId());
        areaofCareStaffEntryDetail.setInTimeDt(formLastUpdatedDate);
        areaofCareStaffEntryDetailsList.add(areaofCareStaffEntryDetail);
        saveAreaOfCareStaffDetailsResponse.setAreaofCareStaffEntryDetails(areaofCareStaffEntryDetailsList);
        saveAreaOfCareStaffDetailsResponse.setIsUpdateAllTransferDt(true);
        saveAreaOfCareStaffDetailsResponse.setIsUpdateAllAdmissionDt(true);
        saveAreaOfCareStaffDetailsResponse.setCaseSummaryId(caseSummaryInfo.getCaseSummaryId());
        saveAreaOfCareStaffDetailsResponse.setModuleId(module.getModuleId());
        saveAreaOfCareStaffDetailsResponse.setIsCopyPreviousStaff(true);

        AreaCareInformationRequest areaCareInformationRequest = new AreaCareInformationRequest();
        areaCareInformationRequest.setCaseSummaryId(String.valueOf(caseSummaryInfo.getCaseSummaryId()));
        areaCareInformationRequest.setAdmittedById(staff.getStaffId());
        areaCareInformationRequest.setModuleId(moduleId);
        areaCareInformationRequest.setAdmissionTime(admissionTime);
        areaCareInformationRequest.setPatientId(String.valueOf(patient.getPatientId()));
        LOG.info("243 ------------------ " + admitTypes.getJSONObject(3).getString("value"));
        LOG.info("244 ------------------ " + admitSources.getJSONObject(4).getString("value"));

        org.json.JSONObject requestObject = null;
        try {
            requestObject = new org.json.JSONObject(mapper.writeValueAsString(areaCareInformationRequest));
            saveAreaOfCareStaffDetailsResponse = dischargePatientRequests.saveAreaOfCareStaffDetails(saveAreaOfCareStaffDetailsResponse);
            dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "undefined");
            areaCareInformationResponse = dischargePatientRequests.insertAreaCareInformation(requestObject);
            dischargePatientRequests.getSpecialtyByCase(caseSummaryFromCaseSummaryId.getCaseSummaryId());
            patientRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), String.valueOf(4));
            dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");
            PatientHandsOffData patientHandsOffData = dischargePatientRequests.getPatientHandsOffData(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId);
            patientHandsOffData = dischargePatientRequests.getPatientHandsOffData(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId);

            patientHandsOffData.setTransferTime(transferTime);
            patientHandsOffData.setTransferredById(null); // if recovery set this to null
            patientHandsOffData.setDischargeNormalTf(true);
            patientHandsOffData.setAbnormalDischargeCircumstance("");
            patientHandsOffData.setDischargedOnDt(transferTime);
            patientHandsOffData.setTransferTimeOFTime(transferTimeOfTime);
            patientHandsOffData.setTransferModuleId(null); // if recovery set this to null
            patientHandsOffData.setIsUpdated(false);
            patientHandsOffData.setTransferredByValue(staff.getFullName());
            patientHandsOffData.setTransferTimeWFTime(null); // if recovery set this to null
            patientHandsOffData.setCaseStatus(10); // if recovery set this to 10
            patientHandsOffData.setDefaultCaseStatusId(10); // if recovery set this to 10
            patientHandsOffData.setDischargeNormalTf(true);

            patientHandsOffData = dischargePatientRequests.insertPatientHandsOffData(patientHandsOffData);
            AreaOfCareStaffDetails sd = dischargePatientRequests.getAreaOfCareStaffEntry(caseSummaryFromCaseSummaryId.getCaseSummaryId(), module.getModuleId());
            LOG.info("");
            sd.getAreaofCareStaffEntryDetails().get(0).setInTimeDt(date + "T20:56:00+00:00");
            sd.getAreaofCareStaffEntryDetails().get(0).setOutTimeDt(date + "T21:56:00+00:00");
            sd.setPatientId(patient.getPatientId());
            sd.setIsCopyPreviousStaff(true);
            sd.setIsUpdateAllAdmissionDt(true);
            sd.setIsUpdateAllTransferDt(true);
            dischargePatientRequests.saveAreaOfCareStaffDetails(sd);
            dischargePatientRequests.insertPatientHandsOffData(patientHandsOffData);

            caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        staff = commonRequests.getPhysicianDetails(username);
        caseSummaryFromPatientId = patientRequests.getCaseSummaryByPatientId(patient.getPatientId());
        caseSummaryFromCaseSummaryId = patientRequests.getCaseSummaryByCaseSummaryId(caseSummaryFromPatientId.getCaseSummaryId());
        caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        caseInformation = patientRequests.getCaseInformation(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        caseDetailInformation = patientRequests.getCaseDetailInformation(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());

        List<ScheduledProcedures> scheduledProcedures = casesToCodeRequests.getScheduledProcedures(caseSummaryInfo.getCaseSummaryId());
        IcdCodes icdCodes = commonRequests.getICDCodes(icdCode);

        PerformedProcedures performedProcedures = new PerformedProcedures();

        DiagnosisList diagnosisList = new DiagnosisList();
        DictionaryItem dictionaryItem = new DictionaryItem();
        dictionaryItem.setOnlyClinical(true);
        dictionaryItem.setId(icdCodes.getIcdCodeId());
        dictionaryItem.setQuickCode(icdCodes.getIcdCode());
        dictionaryItem.setValue(icdCodes.getIcdCodeDescription());
        diagnosisList.setDictionaryItem(dictionaryItem);
        diagnosisList.setDiagnosisId(icdCodes.getIcdCodeId());
        diagnosisList.setSortOrder(0);
        List<DiagnosisList> diagnosisListObject = new ArrayList<>();
        diagnosisListObject.add(diagnosisList);

        performedProcedures.setDeletedPerformedItems(new ArrayList<Object>());
        PerformedItem performedItem = new PerformedItem();
        feeSchedule = commonRequests.getFeeScheduleByCptCode(cptCode);
        feeSchedule.setCptProcedure(null);
        performedItem.setFeeScheduleItem(feeSchedule);
        performedItem.setUnableToCode(false);
        performedItem.setPanelCollapsed(false);
        performedItem.setPrimaryInsurancesList(new ArrayList<Object>());
        performedItem.setSecondaryInsurancesList(new ArrayList<Object>());
        performedItem.setTertiaryInsurancesList(new ArrayList<Object>());
        performedItem.setControlsModifiedInEditChargeMode(true);
        performedItem.setFullChargeCorrectionRequired(false);
        performedItem.setGenerateBillStateModified(false);
        PerformedCaseSupply performedCaseSupply = new PerformedCaseSupply();
        performedItem.setPerformedCaseSupply(performedCaseSupply);
        performedItem.setSelectedSupplyToInventory(null);
        performedItem.setIsReadOnlyPeriodBatch(false);
        performedItem.setResetClosedPeriodBatch(false);
        performedItem.setIsNewProcedureAdded(false);
        performedItem.setIsAmountChanged(false);
        performedItem.setInsuranceModification(0);
        performedItem.setGuarantorModification(0);
        performedItem.setIsGCode(false);
        performedItem.setIsCombinedCodingChargeEntry(false);
        performedItem.setIsCorrected(false);
        performedItem.setUnits(1);
        performedItem.setPerformedCaseItemTypeId(0);
        performedItem.setSortorder(0);
        performedItem.setHovered(false);
        performedItem.setDiagnosisList(diagnosisListObject);

        performedItem.setCaseSummaryId(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        performedItem.setCaseProcedureId(scheduledProcedures.get(0).getCaseProcedureId());
        performedItem.setCptProcedureId(scheduledProcedures.get(0).getCptProcedureId());
        performedItem.setCptCode(scheduledProcedures.get(0).getCptCode());
        performedItem.setCptProcedureDescription(scheduledProcedures.get(0).getCptDescription());
        performedItem.setProviderId(scheduledProcedures.get(0).getPhysicianId());
        performedItem.setPhysicianName(scheduledProcedures.get(0).getPhysicianName());
        performedItem.setFeeScheduleId(scheduledProcedures.get(0).getFeeScheduleId());
        performedItem.setGenerateBill(scheduledProcedures.get(0).getGenerateBill());

        List<PerformedItem> performedItemList = new ArrayList<>();
        performedItemList.add(performedItem);
        performedProcedures.setPerformedItems(performedItemList);

        CasesToCodeResponse casesToCodeResponse = casesToCodeRequests.performCasesToCode(performedProcedures);

        patientRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), "11");
        caseSummaryInfo.setStatus(11);
        caseSummaryInfo.setPreviousStatus(10);
        caseSummaryInfo.setStatusAtDischarge(10);
        patientRequests.upsertCaseSummaryInfo(caseSummaryInfo);

        JSONArray chargeEntryRequestBody = new JSONArray();
        Period period = commonRequests.getPeriodByPeriodName(periodName);
        List<Batch> batches = period.getBatches();
        List<Batch> newBatches = new ArrayList<>();

        List<com.bhavani.models.patientCases.casesToCodeResponse.PerformedItem> performedItemsList = casesToCodeResponse.getPerformedItems();
        List<ChargeEntry> chargeEntryList = new ArrayList<>();

        ListIterator<Batch> batchIterator = batches.listIterator();
        while(batchIterator.hasNext()) {
            Batch batchObject = batchIterator.next();
            batchObject.setValue(batchObject.getBatchId());
            batchObject.setLabel(batchObject.getBatchDescription());
            newBatches.add(batchObject);
        }

        Batch newBatch = newBatches.stream().filter(obj ->
                batchName.contentEquals(obj.getBatchDescription())).findAny().orElse(null);

        for(int i = 0; i < performedItemsList.size(); i++) {
            com.bhavani.models.patientCases.casesToCodeResponse.PerformedItem performedItemObject = performedItemsList.get(i);
            ChargeEntry chargeEntryObject = new ChargeEntry();
            TransactionList transactionList = new TransactionList();
            List<TransactionList> transactionLists = new ArrayList<TransactionList>();
            ChargeDetails chargeDetails = new ChargeDetails();
            ChargeTransaction chargeTransaction = new ChargeTransaction();

            chargeEntryObject.setCptProcedureId(performedItemObject.getCptProcedureId());
            chargeEntryObject.setPatientId(performedItemObject.getPatientId());
            chargeEntryObject.setCaseProcedureId(performedItemObject.getCaseProcedureId());
            chargeEntryObject.setCptCode(performedItemObject.getCptCode());
            chargeEntryObject.setPhysicianName(performedItemObject.getPhysicianName());
            chargeEntryObject.setPerformedCaseProcedureId(performedItemObject.getPerformedCaseProcedureId());
            chargeEntryObject.setIsReadOnlyPeriodBatch(false);
            chargeEntryObject.setPanelCollapsed(false);
            chargeEntryObject.setAppointmentId(0);
            chargeEntryObject.setIsGCode(false);
            chargeEntryObject.setIsCorrected(false);
            chargeEntryObject.setEventSource("DoneBtn");
            chargeEntryObject.setUnableToCode(false);

            DebitTransaction debitTransaction = new DebitTransaction();
            debitTransaction.setIsHidden(false);
            debitTransaction.setIsDeleted(false);
            debitTransaction.setAmount(0);
            debitTransaction.setLastModifiedAmount(0);
            debitTransaction.setTransactionTypeId(6);

            chargeEntryObject.setDebitTransaction(debitTransaction);
            chargeEntryObject.setIsCorrected(false);
            chargeEntryObject.setChargeTransactionIndex(0);
            chargeEntryObject.setIsCaseProcedureSelfPay(true);
            chargeEntryObject.setIsCombinedCodingChargeEntry(false);

            chargeDetails.setPeformedCaseProcedureId(performedItemObject.getPerformedCaseProcedureId());
            chargeDetails.setBalance(amount);
            chargeDetails.setActualBalance(null);
            chargeDetails.setSourceOfRevenueId(null);
            chargeDetails.setTransactionId(0);
            chargeDetails.setSelfPay(true);
            chargeDetails.setRevenueCodeId(248);
            chargeDetails.setRevenueCode(null);
            chargeDetails.setDeductibleAmount(null);
            chargeDetails.setCoInsuranceAmount(null);
            chargeDetails.setCoPaymentAmount(null);
            chargeDetails.setBillId(null);
            chargeDetails.setGenerateBill(false);

            chargeDetails.setPatientResponsibilityCoPayments(null);
            chargeDetails.setWorkersCompensation(false);
            chargeDetails.setTypeOfBill("0831");
            chargeDetails.setChargeEntryLevelTransactionsAmount(0);
            chargeDetails.setGenerateBillStateModified(false);
            chargeDetails.setCorrected(false);

            chargeEntryObject.setUnits(units);
            chargeEntryObject.setSortorder(i);
            chargeEntryObject.setIsNewProcedureAdded(false);
            chargeEntryObject.setFeeScheduleItem(performedItemObject.getFeeScheduleItem());
            chargeEntryObject.setCptProcedureDescription(performedItemObject.getCptProcedureDescription());
            chargeEntryObject.setCaseSummaryId(performedItemObject.getCaseSummaryId());
            chargeEntryObject.setProviderId(performedItemObject.getProviderId());
            chargeEntryObject.setFeeScheduleId(performedItemObject.getFeeScheduleId());

            for(int j = 0; j < performedItemObject.getDiagnosisList().size(); j++) {
                performedItemObject.getDiagnosisList().get(j).getDictionaryItem().setOnlyClinical(false);
            }

            chargeEntryObject.setDiagnosisList(performedItemObject.getDiagnosisList());
            chargeEntryObject.setChargeAutoCorrected(false);
            chargeEntryObject.setGenerateBill(true);
            chargeEntryObject.setResetClosedPeriodBatch(false);
            chargeEntryObject.setWorkersCompensation(false);
            chargeEntryObject.setGuarantorModification(0);
            chargeEntryObject.setDiagnosisCodesRemoved(false);
            chargeEntryObject.setSelfPay(true);
            chargeEntryObject.setIsAmountChanged(false);
            chargeEntryObject.setGenerateBillStateModified(false);
            chargeEntryObject.setInsuranceModification(0);
            chargeEntryObject.setPrimaryInsuranceId(null);
            chargeEntryObject.setSecondaryInsuranceId(null);
            chargeEntryObject.setTertiaryInsuranceId(null);
            chargeEntryObject.setPerformedCaseItemTypeId(0);
            chargeEntryObject.setControlsModifiedInEditChargeMode(true);

            PeriodBatch periodBatch = new PeriodBatch();
            periodBatch.setIsActive(true);
            periodBatch.setPeriodId(0);
            periodBatch.setPeriodName(null);
            chargeEntryObject.setPeriodBatch(periodBatch);

            chargeTransaction.setPeriod(period);
            chargeTransaction.setBatch(newBatch);
            chargeTransaction.setBatchId(newBatch.getBatchId());
            chargeTransaction.setTransactionId(0);
            chargeTransaction.setTransactionResponsiblePartyId(null);
            chargeTransaction.setBatchDescription(newBatch.getBatchDescription());
            chargeTransaction.setIsHidden(false);
            chargeTransaction.setCreatorId(0);
            chargeTransaction.setIsEditable(null);
            chargeTransaction.setCreatedUserId(0);
            chargeTransaction.setTransactionParentId(0);
            chargeTransaction.setIsDeleted(false);
            chargeTransaction.setAmount(amount);
            chargeTransaction.setTransactionRootId(0);
            chargeTransaction.setPeriodId(period.getPeriodId());
            chargeTransaction.setTransactionTypeId(1);
            chargeTransaction.setBatchIsActive(false);
            chargeTransaction.setIsPaymentTransfer(false);
            chargeTransaction.setCreatedDate("0001-01-01T00:00:00+00:00");

            chargeEntryObject.setBatch(newBatch);

            transactionList.setBatch(newBatch);
            transactionList.setPeriod(period);
            transactionList.getPeriod().setBatches(newBatches);
            transactionList.setPeriodId(period.getPeriodId());
            transactionList.setBatchId(newBatch.getBatchId());
            transactionList.setTransactionId(0);
            transactionList.setTransactionRootId(0);
            transactionList.setAmount(amount);
            transactionList.setBatchDescription(newBatch.getBatchDescription());
            transactionList.setTransactionParentId(0);
            transactionList.setCreatedUserId(0);
            transactionList.setIsDeleted(false);
            transactionList.setCreatorId(0);
            transactionList.setIsPaymentTransfer(false);
            transactionList.setTransactionTypeId(1);
            transactionList.setBatchIsActive(false);
            transactionList.setWriteOffDetails(null);
            transactionList.setPaymentDetails(null);
            transactionList.setCreatedDate("0001-01-01T00:00:00+00:00");
            transactionList.setPostedDate(null);
            transactionList.setTransactionDate(null);
            transactionList.setTransactionCodeId(null);
            transactionList.setTransactionResponsiblePartyId(null);
            transactionList.setCurrentResponsiblePartyId(null);
            transactionList.setCurrentResponsiblePartyType(null);
            transactionList.setTransactionResponsiblePartyName(null);
            transactionList.setIsHidden(false);
            transactionList.setTransactionCodeName(null);
            transactionList.setReceivedFrom(null);
            transactionList.setIsEditable(null);
            transactionList.setLastModifiedAmount(null);
            transactionList.setContractProcedureId(null);
            transactionList.setCreatorId(0);
            transactionList.setCheckInPaymentId(null);
            transactionList.setBatchCloserUserId(null);
            transactionList.setPeriodCloserUserId(null);
            transactionList.setPeriodName(null);
            transactionList.setTransferTo(null);
            transactionList.setImpactedTransactions(null);
            transactionList.setChargeDetails(chargeDetails);

            transactionLists.add(transactionList);
            chargeEntryObject.setTransactionList(transactionLists);
            chargeTransaction.setChargeDetails(chargeDetails);
            chargeEntryObject.setChargeTransaction(chargeTransaction);

            chargeEntryList.add(chargeEntryObject);
        }

        List<ChargeEntryResponse> chargeEntryResponse = chargeEntryRequests.performChargeEntry(chargeEntryList);
        String chargeEntryResponseJson = null;
        try {
        chargeEntryResponseJson = mapper.writeValueAsString(chargeEntryResponse);
        } catch (JsonProcessingException e) {
        e.printStackTrace();
        }
        LOG.info(chargeEntryResponseJson);

        commonRequests.logout();
    }

    public static void main(String[] args) {
        CompletePatientOperations completePatientOperations = new CompletePatientOperations();
        completePatientOperations.completePatientOperations();
    }
}
