package com.bhavani.bdd.practice3;

import com.bhavani.models.anesthesiaType.AnesthesiaType;
import com.bhavani.models.appointmentType.AppointmentType;
import com.bhavani.models.patientCases.caseSummary.*;
import com.bhavani.models.patientCases.casesToCode.PerformedProcedures;
import com.bhavani.models.patientCases.casesToCodeResponse.CasesToCodeResponse;
import com.bhavani.models.patientCases.chargeEntry.ChargeEntry;
import com.bhavani.models.patientCases.chargeEntry.Period;
import com.bhavani.models.patientCases.chargeEntryResponse.ChargeEntryResponse;
import com.bhavani.models.commons.ChildOrganizations;
import com.bhavani.models.commons.MappedOrganizations;
import com.bhavani.models.patientCases.dischargePatient.*;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.icdCodes.IcdCodes;
import com.bhavani.models.others.ZipCode;
import com.bhavani.models.patient.Employer;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.room.ActiveRoom;
import com.bhavani.models.room.DictionaryRoom;
import com.bhavani.models.scheduledProcedures.ScheduledProcedures;
import com.bhavani.models.staff.Staff;
import com.bhavani.models.staff.StaffByRole;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/15/2020.
 */
public class PPERequests extends AbstractStepsForPPE {

    private static Logger LOG = LoggerFactory.getLogger(PPERequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public void createSession(String username, String password, String facility) {

        testContext().reset();
        JSONObject loginObject = new JSONObject();
        try {
            loginObject.put("Password", password);
            loginObject.put("UserName", username);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        super.testContext().setPayload(loginObject);
        super.executePost("api/Gateway/Login");
        Response loginResponse = testContext().getResponse();
        String token = loginResponse.asString();
        token = token.replaceAll("\"", "");
        LOG.info(token);
        super.testContext().set("token", token);

        super.executeGet("api/Gateway/User/UserOrgMap");
        Response getUserOrgMapResponse = testContext().getResponse();

        try {
            JSONObject mappedOrgs = new JSONArray(getUserOrgMapResponse.asString()).getJSONObject(0);
            MappedOrganizations mappedOrganizations = mapper.readValue(mappedOrgs.toString(), MappedOrganizations.class);
            List<ChildOrganizations> childOrganizations = new ArrayList<ChildOrganizations>();
            childOrganizations = mappedOrganizations.getChildOrgs();
            for(int i = 0; i < childOrganizations.size(); i++) {
                ChildOrganizations childOrganization = childOrganizations.get(i);
                String organizationName = childOrganization.getName().trim();
                if(organizationName.equalsIgnoreCase(facility)) {
                    int organizationId = childOrganizations.get(i).getOrganizationId();
                    super.testContext().set("organizationId", organizationId);
                    LOG.info(""+organizationId);
                }
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        super.testContext().setPayload("");
        super.executePost("api/UserSession/UserSessionOrg/" + super.testContext().get("organizationId").toString());
        Response mapUserResponse = super.testContext().getResponse();
        LOG.info(mapUserResponse.asString());
    }

    public void logout() {
        super.executeGet("api/UserSession/logout");
        Response logoutResponse = testContext().getResponse();
        String token = logoutResponse.asString().replaceAll("\"", "");
        LOG.info(token);
    }

    public ActiveRoom getRoomByName(String roomName) {
        super.executeGet("api/Room/GetActiveORRoomsForOrganization");
        Response roomsResponse = testContext().getResponse();
        try {
            List<ActiveRoom> activeRooms = Arrays.asList(mapper.readValue(roomsResponse.asString(), ActiveRoom[].class));
            ActiveRoom room = activeRooms.stream().filter(obj ->
                    roomName.equalsIgnoreCase(obj.getName())).findAny().orElse(null);
            return room;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActiveRoom getRoomByNameInNursingDesktop(String roomName) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("isAlphabeticalOrder", true);
        jsonObject.put("showInClinicalTf", true);
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/Room/GetRooms/");
        Response roomsResponse = testContext().getResponse();
        try {
            List<ActiveRoom> activeRooms = Arrays.asList(mapper.readValue(roomsResponse.asString(), ActiveRoom[].class));
            ActiveRoom room = activeRooms.stream().filter(obj ->
                    roomName.equalsIgnoreCase(obj.getItemName().toString())).findAny().orElse(null);
            return room;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public StaffByRole getStaffByRole(String staffName) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pageNumber", 1);
        jsonObject.put("isAlphabeticalOrder", true);
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/Staff/GetStaffByRole");
        Response staffResponse = testContext().getResponse();
        try {
            List<StaffByRole> staffs = Arrays.asList(mapper.readValue(staffResponse.asString(), StaffByRole[].class));
            StaffByRole staff = staffs.stream().filter(obj ->
                    staffName.equalsIgnoreCase(obj.getLastName().toString())).findAny().orElse(null);
            return staff;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public DictionaryRoom getDictionaryRooms(List<String> departments, String roomName) {
        JSONArray jsonArray = new JSONArray();
        departments.forEach(department -> jsonArray.put(department));
        super.testContext().setPayload(jsonArray.toString());
        super.executePost("api/RoomDictionary/GetDictionaryRooms");
        Response roomsResponse = testContext().getResponse();
        try {
            List<DictionaryRoom> activeRooms = Arrays.asList(mapper.readValue(roomsResponse.asString(), DictionaryRoom[].class));
            DictionaryRoom room = activeRooms.stream().filter(obj ->
                    roomName.equalsIgnoreCase(obj.getItemName().toString())).findAny().orElse(null);
            return room;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void isModuleExistsForCase(int caseSummaryId) {
        super.executeGet("api/ModuleComplex/IsModuleExistsForCase/"+caseSummaryId+"/2050");
        Response roomsResponse = testContext().getResponse();
    }

    public AnesthesiaType getAnesthesiaType(String anesthesiaType) {
        super.executeGet("api/Dictionary/v2/152");
        Response anesthesiaTypesResponse = testContext().getResponse();
        try {
            List<AnesthesiaType> anesthesiaTypes = Arrays.asList(mapper.readValue(anesthesiaTypesResponse.asString(), AnesthesiaType[].class));
            AnesthesiaType anesthesiaTypeObject = anesthesiaTypes.stream().filter(obj ->
                    anesthesiaType.equalsIgnoreCase(obj.getValue())).findAny().orElse(null);
            return anesthesiaTypeObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public AnesthesiaType getRoomsFromDictionary(String anesthesiaType) {
        super.executeGet("api/Dictionary/v2/8/All");
        Response anesthesiaTypesResponse = testContext().getResponse();
        try {
            List<AnesthesiaType> anesthesiaTypes = Arrays.asList(mapper.readValue(anesthesiaTypesResponse.asString(), AnesthesiaType[].class));
            AnesthesiaType anesthesiaTypeObject = anesthesiaTypes.stream().filter(obj ->
                    anesthesiaType.equalsIgnoreCase(obj.getValue())).findAny().orElse(null);
            return anesthesiaTypeObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Patient createPatient(Patient patient) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(patient));
            super.executePost("api/PatientData/Gemini/CreatePatient/2030");
            Response createPatientResponse = testContext().getResponse();
            LOG.info(createPatientResponse.asString());
            patient = mapper.readValue(createPatientResponse.asString(), Patient.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patient;
    }

    public void savePatientEmployer(Employer employer) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(employer));
            super.executePost("api/PatientEmployer/SavePatientEmployer");
            Response employeeResponse = testContext().getResponse();
            LOG.info(employeeResponse.asString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public Patient getDuplicatePatient(String firstName, String lastName) {
        JSONObject patientSearchObject = new JSONObject();
        try {
            patientSearchObject.put("firstName", firstName);
            patientSearchObject.put("lastName", lastName);
            super.testContext().setPayload(patientSearchObject.toString());
            super.executePost("api/PatientData/GetDuplicatePatients");
            Response duplicatePatientsResponse = testContext().getResponse();
            List<Patient> availablePatients = null;
            availablePatients = Arrays.asList(mapper.readValue(duplicatePatientsResponse.asString(), Patient[].class));
            return availablePatients.get(0);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Patient getPatientByPatientId(int patientId) {
        super.executeGet("api/PatientData/Patients/" + patientId);
        Response patientsResponse = testContext().getResponse();
        Patient patient = null;
        try {
            patient = mapper.readValue(patientsResponse.asString(), Patient.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patient;
    }

    public Patient getPatientFromFirstNameAndLastName(String firstName, String lastName) {
        Patient patient = getDuplicatePatient(firstName, lastName);
        patient = getPatientByPatientId(patient.getPatientId());
        return patient;
    }

    public ZipCode getAddressFromZipCode(String zipCode) {
        super.executeGet("api/ZipCode/" + zipCode);
        Response zipCodeResponse = testContext().getResponse();
        ZipCode zipCodeObject = null;
        try {
            zipCodeObject = mapper.readValue(zipCodeResponse.asString(), ZipCode.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return zipCodeObject;
    }

    public AppointmentType getAppointmentType(String appointmentTypeName) {
        super.executeGet("api/ApptypeCasepackMap/GetApptypeCasepackMapData");
        Response appointmentTypeResponse = testContext().getResponse();
        AppointmentType appointmentType = null;
        try {
            List<AppointmentType> appointmentTypes = Arrays.asList(mapper.readValue(appointmentTypeResponse.asString(), AppointmentType[].class));
            appointmentType = appointmentTypes.stream().filter(obj ->
                    appointmentTypeName.equalsIgnoreCase(obj.getAppointmentTypeDesc())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return appointmentType;
    }

    public Staff getPhysicianDetails(String physicianName) {
        super.testContext().setPayload("");
        super.executePost("api/StaffList/GetStaffForFacility");
        Response staffForFacilityResponse = testContext().getResponse();
        Staff staff = null;
        try {
            List<Staff> staffDetails = Arrays.asList(mapper.readValue(staffForFacilityResponse.asString(), Staff[].class));
            staff = staffDetails.stream().filter(obj ->
                    physicianName.equalsIgnoreCase(obj.getLastName())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return staff;
    }

    public FeeSchedule getFeeScheduleByCptCode(String cptCode) {
        String encodedCptCode = Base64.getEncoder().encodeToString(cptCode.getBytes());
        super.testContext().setPayload("\""+encodedCptCode+"\"");
        super.executePost("api/FeeSchedule/Search");
        Response feeScheduleResponse = testContext().getResponse();
        FeeSchedule feeSchedule = null;
        try {
            List<FeeSchedule> feeSchedules = Arrays.asList(mapper.readValue(feeScheduleResponse.asString(), FeeSchedule[].class));
            feeSchedule = feeSchedules.stream().filter(obj ->
                    cptCode.contentEquals(obj.getCptProcedure().getCptCode())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return feeSchedule;
    }

    public CaseSummaryFromPatientId getCaseSummaryByPatientId(int patientId) {
        super.executeGet("api/CaseSummary/PPEPatient/" + patientId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseSummaryFromPatientId caseSummaryFromPatientId = null;
        try {
            List<CaseSummaryFromPatientId> caseSummaries = Arrays.asList(mapper.readValue(caseSummaryResponse.asString(), CaseSummaryFromPatientId[].class));
            caseSummaryFromPatientId = caseSummaries.get(0);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryFromPatientId;
    }

    public CaseSummaryFromCaseSummaryId getCaseSummaryByCaseSummaryId(int caseSummaryId) {
        super.executeGet("api/CaseSummary/" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseSummaryFromCaseSummaryId caseSummaryFromCaseSummaryId = null;
        try {
            caseSummaryFromCaseSummaryId = mapper.readValue(caseSummaryResponse.asString(), CaseSummaryFromCaseSummaryId.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryFromCaseSummaryId;
    }

    public CaseSummaryInfo getCaseSummaryInfo(int caseSummaryId) {
        super.executeGet("api/CaseSummary/GetCaseSummaryInfo/" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseSummaryInfo caseSummaryInfo = null;
        try {
            caseSummaryInfo = mapper.readValue(caseSummaryResponse.asString(), CaseSummaryInfo.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryInfo;
    }

    public CaseInformation getCaseInformation(int caseSummaryId) {
        super.executeGet("api/CaseSummary/GetCaseInformation/" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseInformation caseInformation = null;
        try {
            caseInformation = mapper.readValue(caseSummaryResponse.asString(), CaseInformation.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseInformation;
    }


    public CaseDetailInformation getCaseDetailInformation(int patientId, int caseSummaryId) {
        super.executeGet("api/PatientFacesheet/GetCaseDetailInformation/" + patientId+ "/" + caseSummaryId);
        Response caseDetailInformationResponse = testContext().getResponse();
        CaseDetailInformation caseDetailInformation = null;
        try {
            caseDetailInformation = mapper.readValue(caseDetailInformationResponse.asString(), CaseDetailInformation.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseDetailInformation;
    }

    public FormByName getFormByName(String formName) {
        super.executeGet("api/RecordHeader/"+formName+"/GetFormbyName");
        Response formByNameResponse = testContext().getResponse();
        FormByName formByName = null;
        try {
            formByName = mapper.readValue(formByNameResponse.asString(), FormByName.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return formByName;
    }

    public FormUsageByFormOwner getFormUsageByFormOwner(int caseSummaryId, int moduleId, int formId) {
        JSONObject requestObject = new JSONObject();
        requestObject.put("caseSummaryId", String.valueOf(caseSummaryId));
        requestObject.put("moduleId", moduleId);
        requestObject.put("formId", formId);
        super.testContext().setPayload(requestObject.toString(4));
        super.executePost("api/FormUsage/GetFormUsagebyByFormOwner/");
        Response formUsageByFormOwnerResponse = testContext().getResponse();
        FormUsageByFormOwner formUsageByFormOwner = null;
        try {
            formUsageByFormOwner = mapper.readValue(formUsageByFormOwnerResponse.asString(), FormUsageByFormOwner.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return formUsageByFormOwner;
    }

    public FormUsageByFormOwner updateFormUsageByFormOwner(FormUsageByFormOwner formUsageByFormOwner) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(formUsageByFormOwner));
            super.executePost("api/FormUsage/GetFormUsagebyByFormOwner/");
            Response formUsageByFormOwnerResponse = testContext().getResponse();
            formUsageByFormOwner = null;
            try {
                formUsageByFormOwner = mapper.readValue(formUsageByFormOwnerResponse.asString(), FormUsageByFormOwner.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return formUsageByFormOwner;
    }

    public void getAreaCareInformationByCase(int patientId, int caseSummaryId, int moduleId) {
        JSONObject requestObject = new JSONObject();
        requestObject.put("caseSummaryId", String.valueOf(caseSummaryId));
        requestObject.put("patientId", String.valueOf(patientId));
        if(moduleId != 0) {
            requestObject.put("moduleId", moduleId);
        }
        super.testContext().setPayload(requestObject.toString());
        super.executePost("api/AreaCareInformationRequest/GetAreaCareInformationsbyCase");
        Response areaCareInformation = testContext().getResponse();
    }

    public void getModulesByCaseId(int caseSummaryId, int organizationId) {
        super.executeGet("api/Module/GetModulesBycaseId/"+ caseSummaryId+ "/undefined?organisationId=" + organizationId);
        Response modulesByCaseResponse = testContext().getResponse();
    }

    public void updateCaseStatus(int caseSummaryId, String caseStatus) {
        super.testContext().setPayload(caseStatus);
        super.executePost("api/CaseSummary/UpdateCaseSatus/" + caseSummaryId);
        Response caseStatusResponse = testContext().getResponse();
    }

    public void requestLock(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/Security/RecordLock/RequestLock");
        Response requestLockResponse = testContext().getResponse();
    }

    public void releaseLock(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/Security/RecordLock/ReleaseLock");
        Response requestLockResponse = testContext().getResponse();
    }

    public AreaCareInformationResponse insertAreaCareInformation(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/AreaCareInformationRequest/InsertAreaCareInformation");
        Response areaCareInformation = testContext().getResponse();
        AreaCareInformationResponse areaCareInformationResponse = null;
        try {
            areaCareInformationResponse = mapper.readValue(areaCareInformation.asString(), AreaCareInformationResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return areaCareInformationResponse;
    }

    public void getSpecialtyByCase(int caseSummaryId) {
        super.executePost("api/CaseSummary/GetSpecialityByCase/" + caseSummaryId);
        Response specialtyByCase = testContext().getResponse();
    }

    public AreaOfCareStaffDetails saveAreaOfCareStaffDetails(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/AreaOfCareStaffEntry/SaveAreaOfCareStaffDetails");
        Response saveAreaOfCareStaffDetailsResponse = testContext().getResponse();
        AreaOfCareStaffDetails saveAreaOfCareStaffDetailsResponseObject = null;
        try {
            saveAreaOfCareStaffDetailsResponseObject = mapper.readValue(saveAreaOfCareStaffDetailsResponse.asString(), AreaOfCareStaffDetails.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return saveAreaOfCareStaffDetailsResponseObject;
    }

    public void getAreaOfCareStaffDetails(int caseSummaryId, int moduleId, String staffId) {
        super.executeGet("api/AreaOfCareStaffEntry/GetAreaofCareStaffDetails/"+caseSummaryId+"?moduleId="+moduleId+"&staffId=" + staffId);
        Response caseStatusResponse = testContext().getResponse();
    }

    public void updateAreaCareInformation(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/AreaCareInformation/UpdateAreaCareInformation");
        Response areaCareInformationResponse = testContext().getResponse();
    }

    public PatientHandsOffData getPatientHandsOffData(int caseSummaryId, int moduleId) {
        super.executeGet("api/patientHandOff/GetPatientHandsOffData?casesummaryId="+caseSummaryId+"&moduleId=" + moduleId);
        Response patientHandOffResponse = testContext().getResponse();
        PatientHandsOffData patientHandsOffData = null;
        try {
            patientHandsOffData = mapper.readValue(patientHandOffResponse.asString(), PatientHandsOffData.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patientHandsOffData;
    }

    public PatientHandsOffData insertPatientHandsOffData(PatientHandsOffData patientHandsOffData) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(patientHandsOffData));
            super.executePost("api/patientHandOff/InsertPatientHandOffData");
            Response patientHandsOffDataResponse = testContext().getResponse();
            patientHandsOffData = mapper.readValue(patientHandsOffDataResponse.asString(), PatientHandsOffData.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patientHandsOffData;
    }

    public void upsertCaseSummaryInfo(CaseSummaryInfo caseSummaryInfo) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(caseSummaryInfo));
            super.executePut("api/CaseSummary/UpsertCaseSummaryInfo");
            Response upsertCaseSummaryInfoResponse = testContext().getResponse();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public void signDepartment(int caseSummaryId, int moduleId) {
        super.testContext().setPayload("");
        super.executePut("api/BasicModuleInfoSignature/SignByCurrentUser/"+caseSummaryId+"/" + moduleId);
        Response upsertCaseSummaryInfoResponse = testContext().getResponse();
    }

    public List<ScheduledProcedures> getScheduledProcedures(int caseSummaryId) {
        super.executeGet("api/ScheduledCaseProcedure/GetScheduledProcedures/"+caseSummaryId+"/false");
                             //  /api/ScheduledCaseProcedure/GetScheduledProcedures/46704/false
        Response scheduledProceduresResponse = testContext().getResponse();
        List<ScheduledProcedures> scheduledProcedures = null;
        try {
            scheduledProcedures = Arrays.asList(mapper.readValue(scheduledProceduresResponse.asString(), ScheduledProcedures[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return scheduledProcedures;
    }

    public IcdCodes getICDCodes(String ICDCode) {
        super.testContext().setPayload("\""+ICDCode.substring(0, 3)+"\"");
        super.executePost("api/ICDCodeClassification/GetICDCodeClassifications");
        Response icdCodesResponse = testContext().getResponse();
        List<IcdCodes> icdCodes = null;
        IcdCodes icdCode = null;
        try {
            icdCodes = Arrays.asList(mapper.readValue(icdCodesResponse.asString(), IcdCodes[].class));
            icdCode = icdCodes.stream().filter(obj ->
                    ICDCode.contentEquals(obj.getIcdCode())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return icdCode;
    }

    public CasesToCodeResponse performCasesToCode(PerformedProcedures performedProcedures) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(performedProcedures));
            super.executePost("api/CaseToCode/SavePerformedItems/");
            Response casesToCodeResponse = testContext().getResponse();
           // LOG.info(casesToCodeResponse.asString());
            CasesToCodeResponse casesToCodeResponseObject = mapper.readValue(casesToCodeResponse.asString(), CasesToCodeResponse.class);
            return casesToCodeResponseObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Period getPeriodByPeriodName(String periodName) {
        super.executeGet("api/PeriodBatch/GetPeriodBatch/false");
        Response periodResponse = testContext().getResponse();
        List<Period> periods = null;
        Period period = null;
        try {
            periods = Arrays.asList(mapper.readValue(periodResponse.asString(), Period[].class));
            period = periods.stream().filter(obj ->
                    periodName.contentEquals(obj.getPeriodName())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return period;
    }

    public List<ChargeEntryResponse> performChargeEntry(List<ChargeEntry> chargeEntries) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(chargeEntries));
            super.executePost("api/CaseToCharge/SavePerformedProcedure/");
            Response chargeEntryResponse = testContext().getResponse();
            LOG.info(chargeEntryResponse.asString());
            List<ChargeEntryResponse> chargeEntryResponseObject = null;
            chargeEntryResponseObject = Arrays.asList(mapper.readValue(chargeEntryResponse.asString(), ChargeEntryResponse[].class));
            return chargeEntryResponseObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONArray getResponseFromURL(String url) {
        String baseURL = "https://sisenterpriseweb171051-gem-pr.azurewebsites.net/";
        String completeURL = baseURL + url;
        JSONArray jsonArray = new JSONArray(super.executeRequest(completeURL, "GET"));
        return jsonArray;
    }



}
