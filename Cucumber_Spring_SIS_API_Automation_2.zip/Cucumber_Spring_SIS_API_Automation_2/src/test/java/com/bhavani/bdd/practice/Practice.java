package com.bhavani.bdd.practice;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.commons.ChildOrganizations;
import com.bhavani.models.commons.MappedOrganizations;
import com.bhavani.models.configuration.business.feeSchedule.CptProcedure;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.room.ActiveRoom;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 7/25/2020.
 */
public class Practice extends AbstractSteps {
    private static Logger LOG = LoggerFactory.getLogger(Practice.class);
    public void stepOne() throws JSONException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        testContext().reset();
        String facility = "Gem_Org002";
        // String organizationId = null;
        JSONObject loginObject = new JSONObject();        
        loginObject.put("UserName", "Gem_user2");
        loginObject.put("Password", "Test#123");

        super.testContext().setPayload(loginObject);
        super.executePost("api/Login/LoginUser");
        Response loginResponse = testContext().getResponse();
        String token = loginResponse.asString();
        token = token.replaceAll("\"", "");
        LOG.info(token);
        super.testContext().set("token", token);
        
        super.executeGet("api/User/UserOrgMap");
        Response getUserOrgMapResponse = testContext().getResponse();


        try {
            MappedOrganizations mappedOrganizations = mapper.readValue(new JSONArray(getUserOrgMapResponse.asString()).getJSONObject(0).toString(), MappedOrganizations.class);
            List<ChildOrganizations> childOrganizations = new ArrayList<ChildOrganizations>();
            childOrganizations = mappedOrganizations.getChildOrgs();
            for(int i = 0; i < childOrganizations.size(); i++) {
                String organizationName = childOrganizations.get(i).getName().trim();
                if(organizationName.equalsIgnoreCase(facility)) {
                    int organizationId = childOrganizations.get(i).getOrganizationId();
                    super.testContext().set("organizationId", organizationId);
                    LOG.info(""+organizationId);
                }
            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        super.executePost("api/UserSession/UserSessionOrg/" + super.testContext().get("organizationId").toString());
        Response mapUserResponse = super.testContext().getResponse();
      //  LOG.info(mapUserResponse.asString());
        
        /*
        JSONObject newPatientObject = new JSONObject();
        newPatientObject.put("firstName", "TestB");
        newPatientObject.put("lastName", "TestB");

        super.testContext().setPayload(newPatientObject);        
        super.executePost("api/PatientData/GetDuplicatePatients");
        Response newPatientResponse = super.testContext().getResponse();
        
        PPEPatient patient = mapper.readValue(new JSONArray(newPatientResponse.asString()).getJSONObject(0).toString(), PPEPatient.class);
       // LOG.info(patient.toString());
		*/
        
        
        
        
        String roomName = "Gemuser2_Room1";
        String cptProcedure = "29893";
        String appointmentType = "Gem_General2";
        String physicianName = "gem_user10";
        
        super.executeGet("api/FeeSchedule/GetFeeSchedules");
        Response feeScheduleResponse = super.testContext().getResponse();
        FeeSchedule[] feeSchedules = mapper.readValue(new JSONArray(feeScheduleResponse.asString()).toString(), FeeSchedule[].class);
        FeeSchedule feeSchedule = null;
        for(FeeSchedule fs: feeSchedules) {
        	if(fs.getCptProcedure() != null) {
        		// CptProcedure cpProcedureObject = mapper.readValue(new JSONObject(fs.getCptProcedure().toString()), CptProcedure.class);
        		// CptProcedure cpProcedureObject = (CptProcedure) fs.getCptProcedure();
        		CptProcedure cpProcedureObject = mapper.readValue(mapper.writeValueAsString(fs.getCptProcedure()), CptProcedure.class);
            	if(cpProcedureObject.getCptCode().indexOf(cptProcedure) > -1) {
            		feeSchedule = fs;
            	}	
        	}        	
        }
    //    LOG.info(feeSchedule.toString());
        
        super.executeGet("api/Room/GetActiveORRoomsForOrganization");
        Response roomsResponse = super.testContext().getResponse();
        ActiveRoom[] activeRooms = mapper.readValue(new JSONArray(roomsResponse.asString()).toString(), ActiveRoom[].class);
        ActiveRoom activeRoom = null;
        
        for(ActiveRoom ar: activeRooms) {        	
        	if(ar.getName().equalsIgnoreCase(roomName)) {
        		activeRoom = ar;
        	}
        }
    //    LOG.info(activeRoom.toString());
        
        /*
        PPEPatient patientCreated = null;
        super.executeGet("api/PatientData/Gemini/GetPatient/" + patient.getPatientId());
        Response patientCreatedResponse = super.testContext().getResponse(); 
        patientCreated = mapper.readValue(new JSONObject(patientCreatedResponse.asString()).toString(), PPEPatient.class);
        LOG.info(patientCreated.toString());
        
        RequestLock requestLock = new RequestLock();
        requestLock.setModuleId(2030);
        requestLock.setObjectId(patient.getPatientId());
        requestLock.setPatientId(patient.getPatientId());
        requestLock.setRecordLockTypeId(13);
        super.testContext().setPayload(mapper.writeValueAsString(requestLock));   
       // super.executePost("api/Security/RecordLock/RequestLock");		
        Response requestLockResponse = super.testContext().getResponse();
        LOG.info(requestLockResponse.toString());
                
        super.executeGet("api/FacilityConfiguration/GetCurrentFacilityAddresses");
        Response currentFacilityAddressResponse = super.testContext().getResponse(); 
        CurrentFacilityAddress[] currentFacilityAddress = mapper.readValue(new JSONArray(currentFacilityAddressResponse.asString()).toString(), CurrentFacilityAddress[].class);
        LOG.info(currentFacilityAddress.toString());
        
        super.executeGet("/api/Dictionary/v2/151/All");
        DictionaryType[] race = mapper.readValue(new JSONArray(super.testContext().getResponse().asString()).toString(), DictionaryType[].class);
        super.executeGet("/api/Dictionary/v2/158/All");
        DictionaryType[] appointmentTypes = mapper.readValue(new JSONArray(super.testContext().getResponse().asString()).toString(), DictionaryType[].class);
        DictionaryType appointment = null;

        for(DictionaryType at: appointmentTypes) {        	
        	if(at.getValue().equalsIgnoreCase(appointmentType)) {
        		appointment = at;
        	}
        }
        LOG.info(appointment.toString());
        
        super.executeGet("/api/Dictionary/v2/152");        
        DictionaryType[] anesthesias = mapper.readValue(new JSONArray(super.testContext().getResponse().asString()).toString(), DictionaryType[].class);
        LOG.info(anesthesias.toString());
        
        super.executeGet("/api/StaffList/GetStaffForOrganization/2/false");
        Staff[] staffs = mapper.readValue(new JSONArray(super.testContext().getResponse().asString()).toString(), Staff[].class);
        Staff staff = null;
        for(Staff at: staffs) {        	
        	if(at.getLastName().equalsIgnoreCase(physicianName)) {
        		staff = at;
        	}
        }
        LOG.info(staff.toString());
        
        super.executeGet("/api/ApptypeCasepackMap/GetApptypeCasepackMapData");
        AppointmentType[] appointmentTypes2 = mapper.readValue(new JSONArray(super.testContext().getResponse().asString()).toString(), AppointmentType[].class);
        AppointmentType appointmentType3 = null;
        for(AppointmentType at: appointmentTypes2) {        	
        	if(at.getAppointmentTypeDesc().equalsIgnoreCase(appointmentType)) { 
        		appointmentType3 = at;
        	}
        }
        LOG.info(appointmentType3.toString());
        
        CaseProcedure caseProcedure = new CaseProcedure();
    	FeeScheduleItem feeScheduleItem = new FeeScheduleItem();
		
		int physicianId = 10;
	//	String physicianName = "sis Gem_user10, Dr";
		String procedureDescription = "ENDOSCOPIC PLANTAR FASCIOTOMY";
		int feeScheduleId = 2665;
		String procedureDisplayName = "29893; ENDOSCOPIC PLANTAR FASCIOTOMY";
		String cptCode = "29893";
		// String cptProcedure = "29893";
		
		LOG.info(feeSchedule.toString());
		com.bhavani.models.patientCases.caseSummary.CptProcedure cptProcedureObj = new com.bhavani.models.patientCases.caseSummary.CptProcedure();
        cptProcedureObj.setCptProcedureId(feeSchedule.getCptProcedure().getCptProcedureId());
        cptProcedureObj.setCptCode(feeSchedule.getCptProcedure().getCptCode());
        cptProcedureObj.setCptDescription(feeSchedule.getCptProcedure().getCptDescription());
        cptProcedureObj.setIsHcpcsCode(false);
        cptProcedureObj.setSourceIdentifier("00000000-0000-0000-0000-000000000000");        
               
        feeScheduleItem.setCptProcedure(mapper.readValue(mapper.writeValueAsString(cptProcedureObj), CptProcedure.class));
        feeScheduleItem.setFeeScheduleId(feeSchedule.getFeeScheduleId());
        feeScheduleItem.setProcedure(feeSchedule.getProcedure());
        feeScheduleItem.setOrganizationId(feeSchedule.getOrganizationId());
        feeScheduleItem.setCptProcedureId(feeSchedule.getCptProcedure().getCptProcedureId());
        String mpd = (String) feeSchedule.getModifiedProcedureDescription();
        if(mpd == null) {
        	feeScheduleItem.setModifiedProcedureDescription(null);	
        } else {
        	feeScheduleItem.setModifiedProcedureDescription(mpd);
        }
        
        feeScheduleItem.setStatus(feeSchedule.getStatus());
        feeScheduleItem.setAmount((int)Math.round(feeSchedule.getAmount()));
        feeScheduleItem.setEffectiveDate(feeSchedule.getEffectiveDate());
        feeScheduleItem.setFeeScheduleHistoryId(feeSchedule.getFeeScheduleHistoryId());
        feeScheduleItem.setActiveTf(feeSchedule.getActiveTf());
        feeScheduleItem.setIsIncludeStateReportTf(feeSchedule.getIsIncludeStateReportTf());
        feeScheduleItem.setSourceIdentifier(feeSchedule.getSourceIdentifier());
        feeScheduleItem.setProcedureDisplayName(procedureDisplayName);
        feeScheduleItem.setFeeScheduleRootId(feeSchedule.getFeeScheduleRootId());
        feeScheduleItem.setModifiedProcedureDescription(null);
		caseProcedure.setPhysicianId(physicianId);
		caseProcedure.setPhysician(staff.getFullName());
		// caseProcedure.setLaterality(new JSONObject().NULL);
		caseProcedure.setLaterality(null);
		caseProcedure.setLateralityText(null);
		caseProcedure.setPreOpDiagnosisCode(null);
		caseProcedure.setPreOpDiagnosisCodeId(null);
		caseProcedure.setProcedureId(null);
		caseProcedure.setProcedureDescription(procedureDescription);
		caseProcedure.setPrimaryProcedureTf(true);
		caseProcedure.setAppointmentId(null);
		caseProcedure.setProcedureSequence(null);
		caseProcedure.setPreferenceCardId(null);
		caseProcedure.setFeeScheduleId(feeScheduleId);
		caseProcedure.setProcedureDisplayName(procedureDisplayName);
		caseProcedure.setIsEditable(false);
		caseProcedure.setSelfPayTf(true);
		caseProcedure.setWorkersCompensation(null);
		caseProcedure.setAnesTypeName(null);
		caseProcedure.setCasePackName(null);
		caseProcedure.setDummyCPTId(-10);
		caseProcedure.setModifiedProcedureDescription(null);
		caseProcedure.setIsDisplayTrashIcon(true);
		caseProcedure.setDiagnosisList(new ArrayList<>());
		caseProcedure.setCptCode(cptCode);
		caseProcedure.setFeeScheduleList(new ArrayList<>());
		caseProcedure.setFeeScheduleItem(feeScheduleItem);
		caseProcedure.setPrimaryProcedureTf(false);
		
		
		List<CaseProcedure> caseProcedures = new ArrayList<>(); 
		caseProcedures.add(caseProcedure); 
		
		com.bhavani.models.patientCases.caseSummary.PPEPatient p = new com.bhavani.models.patientCases.caseSummary.PPEPatient();
		p = mapper.readValue(new JSONObject(patientCreatedResponse.asString()).toString(), com.bhavani.models.patientCases.caseSummary.PPEPatient.class);
        CaseSummary caseSummary = new CaseSummary();
        String today = "2020-07-30T14:02:29.648Z";
		int caseSummaryId = 0;
				
        caseSummary.setPatient(mapper.readValue(mapper.writeValueAsString(p), PPEPatient.class));
        caseSummary.setPatientId(p.getPatientId());
        
        caseSummary.setToday(today);
		caseSummary.setCaseSummaryId(caseSummaryId);	
		caseSummary.setCaseProcedures(caseProcedures);
		caseSummary.setAppointmentTypeName(appointmentType);
		caseSummary.setStartTime("10:00");
		caseSummary.setEndTime("10:30");
		caseSummary.setDuration(60);
		caseSummary.setCaseType(1);
		caseSummary.setDateOfService("2020-07-30");
		caseSummary.setPrimaryPhysicianId(10);
		caseSummary.setRoomName(activeRoom.getName());
		caseSummary.setRoomId(activeRoom.getRoomId());
		
		
		
		AdditionalClaimInfo additionalClaimInfo = new AdditionalClaimInfo();
		CaseGuarantor primaryCaseGuarantor = new CaseGuarantor();
		PatientGuarantor primaryPatientGuarantor = new PatientGuarantor();
		
		primaryCaseGuarantor.setGuarantorId(-1);
		primaryCaseGuarantor.setIsSelf(true);
		primaryCaseGuarantor.setSortOrder(1);
		primaryCaseGuarantor.setIsActive(true);
		
		primaryPatientGuarantor.setPatientGuarantorId(-1);
		primaryPatientGuarantor.setPatientId(p.getPatientId());
		primaryPatientGuarantor.setFirstName("FN");
		primaryPatientGuarantor.setLastName("LN");
		primaryPatientGuarantor.setGender("Male");
		primaryPatientGuarantor.setDateOfBirth("11/11/1991");
		primaryPatientGuarantor.setAddress1("A1");
		primaryPatientGuarantor.setAddress2("A2");
		primaryPatientGuarantor.setCity("New City");
		primaryPatientGuarantor.setState("NY");
		primaryPatientGuarantor.setZip("123452313");
		primaryPatientGuarantor.setCountry("United States");
		primaryPatientGuarantor.setSelectedStateIdx(40);
		primaryPatientGuarantor.setSelectedCountryIdx(1);
		primaryPatientGuarantor.setPatientRelationship("Self");
		primaryPatientGuarantor.setPhoneNumber("9999999999");		
		
		primaryCaseGuarantor.setPatientGuarantor(primaryPatientGuarantor);		

		PatientGuarantor secondaryPatientGuarantor = new PatientGuarantor();
		CaseGuarantor secondaryCaseGuarantor = new CaseGuarantor();
		secondaryCaseGuarantor.setPatientGuarantor(secondaryPatientGuarantor);
		secondaryCaseGuarantor.setSortOrder(2);
		secondaryCaseGuarantor.setIsActive(false);
		secondaryCaseGuarantor.setGuarantorId(null);
		secondaryCaseGuarantor.setIsSelf(false);
		secondaryPatientGuarantor.setSelectedStateIdx(0);
		secondaryPatientGuarantor.setSelectedCountryIdx(0);
		secondaryCaseGuarantor.setPatientGuarantor(secondaryPatientGuarantor);
		
		
		CaseInsurance primaryInsurance = new CaseInsurance(); 
		CaseInsurance secondaryInsurance = new CaseInsurance();
		CaseInsurance tertiaryInsurance = new CaseInsurance();
		
		PatientInsurance primaryPatientInsurance = new PatientInsurance();
		PatientInsurance secondaryPatientInsurance = new PatientInsurance();
		PatientInsurance tertiaryPatientInsurance = new PatientInsurance();
		
		primaryInsurance.setSortOrder(0);
		secondaryInsurance.setSortOrder(1);
		tertiaryInsurance.setSortOrder(2);
		
		primaryInsurance.setPatientInsurance(primaryPatientInsurance);
		secondaryInsurance.setPatientInsurance(secondaryPatientInsurance);
		tertiaryInsurance.setPatientInsurance(tertiaryPatientInsurance);
		
		List<CaseGuarantor> caseGuarantors = new ArrayList<CaseGuarantor>(); 
		caseGuarantors.add(primaryCaseGuarantor);
		caseGuarantors.add(secondaryCaseGuarantor);
		
		List<CaseInsurance> caseInsurances = new ArrayList<CaseInsurance>(); 
		caseInsurances.add(primaryInsurance);
		caseInsurances.add(secondaryInsurance);
		caseInsurances.add(tertiaryInsurance);
		
		caseSummary.setCaseGuarantor(caseGuarantors);
		caseSummary.setCaseInsurances(caseInsurances);
		caseSummary.setAdditionalClaimInfo(additionalClaimInfo);
		
		caseSummary.setReferringPhysicianName("sis Gem_user10, Dr");
		caseSummary.setAppointmentTypeId(appointmentType3.getAppointmentTypeId());
		caseSummary.setReferringPhysicianId(10);
		
		caseSummary.setProcedureStartDt("2020-07-30T05:30:00.000Z");
		caseSummary.setProcedureStopDt("2020-07-30T05:30:00.000Z");
		caseSummary.setProcedureStartTime("2020-07-30T04:30:00.000Z");
		caseSummary.setProcedureStopTime("2020-07-30T05:30:00.000Z");
		caseSummary.setProcedureDt("2020-07-30T04:30:00.000Z");
		
		caseSummary.getPatient().setMedsLastLoaded(null); 
		caseSummary.getPatient().setEmail(null);
	//	caseSummary.getPatient().getAddress().setCounty(null);  
	//	caseSummary.getPatient().getEmergencyContact().setPhoneHomeExtension(null); 
		caseSummary.getPatient().setPrimaryProcedure(null);    
		caseSummary.getPatient().setNoHomeMedicationTf(null);     
		caseSummary.getPatient().setReligion(null); 
		
	//	caseSummary.getPatient().getAddress().setLine1(null);     
	//	caseSummary.getPatient().getAddress().setLine2(null);
		
		caseSummary.getCaseGuarantor().get(0).getPatientGuarantor().setAddress2(null);
		caseSummary.getCaseGuarantor().get(0).getPatientGuarantor().setAddress1(null);
		
		caseSummary.getCaseProcedures().get(0).setPreOpDiagnosisCodeId(null);   
		*/
		
        /*
         * caseSummaryObject = new JSONObject(mapper.writeValueAsString(caseSummary));
			LOG.info(caseSummaryObject.toString(4));
			
			
			
			LOG.info("|<*>|<*>|<*>|<*>|<*>|<*>|<*>|<*>|<*>|<*>|<*>|<*>|");
			caseSummaryObject = new JSONObject(mapper.writeValueAsString(caseSummary));
			LOG.info(caseSummaryObject.toString(4));
			
         */
		
        /*
		 super.executeGet("/api/CaseRequest/GetCaseRequestPendingRecordCount");   
		 LOG.info(super.testContext().getResponse().asString());
		 
		 super.executeGet("/api/Insurance/Gemini/GetPatientInsurancesByPatientId/" + caseSummary.getPatientId());		 
		 LOG.info(super.testContext().getResponse().asString());
		 
		 super.executeGet("/api/PatientGuarantor/GetPatientGuarantors/" + caseSummary.getPatientId());		 
		 LOG.info(super.testContext().getResponse().asString());
		 
		 super.testContext().setPayload(mapper.writeValueAsString(p));
		 super.executePost("/api/PatientData/Gemini/CreatePatient/2030");		 
		 LOG.info(super.testContext().getResponse().asString());
		// caseSummary.setPatient(mapper.readValue(super.testContext().getResponse().asString(), PPEPatient.class));
		 
        JSONObject caseSummaryObject = new JSONObject(mapper.writeValueAsString(caseSummary));
        LOG.info(caseSummaryObject.toString(4));

        super.testContext().setPayload(mapper.writeValueAsString(caseSummaryObject.toString()));   
        super.executePost("/api/CaseSummaryComplex/Gemini/UpsertCaseSummary");        
        
        
        LOG.info(super.testContext().getResponse().asString());
        JSONObject caseSummaryResponse = new JSONObject(super.testContext().getResponse().asString());
        LOG.info(caseSummaryResponse.toString());
        */
       

        // https://sisenterpriseapi160759qc.azurewebsites.net/api/Security/Permissions

        // https://sisenterpriseapi160759qc.azurewebsites.net/api/BusinessEntitySettings/GetBusinessEntitySettings

        // https://sisenterpriseapi160759qc.azurewebsites.net/api/PatientData/Gemini/GetPatient/48648
        // https://sisenterpriseapi160759qc.azurewebsites.net/api/Dictionary/v2/152

        // https://sisenterpriseapi160759qc.azurewebsites.net/api/Dictionary/v2/158/All

        // https://sisenterpriseapi160759qc.azurewebsites.net/api/CaseScheduleConflictCheck/GetCaseConflictsMinimal
        
        /*
         * {
  "physicianList": [
    10
  ],
  "roomId": 129,
  "procedureStartDt": "2020-07-30T04:30:00.000Z",
  "procedureStopDt": "2020-07-30T05:30:00.000Z"
}
         */
        
 // https://sisenterpriseapi160759qc.azurewebsites.net/api/Insurance/Gemini/GetPatientInsurancesByPatientId/48648
        
        // https://sisenterpriseapi160759qc.azurewebsites.net/api/Security/GetAllFeatureStates
        
// https://sisenterpriseapi160759qc.azurewebsites.net/
        // Race
   // https://sisenterpriseapi160759qc.azurewebsites.net
        // AppointmentType
        


// https://sisenterpriseapi160759qc.azurewebsites.net/api/Insurance/Gemini/GetPatientInsurancesByPatientId/48648
// https://sisenterpriseapi160759qc.azurewebsites.net
// AnesthesiaType 
        
        // https://sisenterpriseapi160759qc.azurewebsites.net/
        /*
         * {
    "staffId": 347,
    "personId": 10,
    "roleId": 1,
    "roleName": "Physician",
    "firstName": "sis",
    "middleInitial": "",
    "lastName": "Gem_user10",
    "title": "Dr",
    "fullName": "sis Gem_user10, Dr",
    "primaryPhone": null,
    "emailAddress": null,
    "sourceIdentifier": "00000000-0000-0000-0000-000000000000"
  }
         */











        
        /*
         * /
         
         {
  "firstName": "TestA1",
  "lastName": "TestA1",
  "dateOfBirth": "11/11/1991"
}
         https://sisenterpriseapi171395qc.azurewebsites.net/api/Room/GetActiveORRoomsForOrganization
         https://sisenterpriseapi171395qc.azurewebsites.net/api/ZipCode/55555
         
         https://sisenterpriseapi171395qc.azurewebsites.net/api/SchedulingData/Gemini/GetSchedulingData
         
         https://sisenterpriseapi171395qc.azurewebsites.net/api/ApptypeCasepackMap/GetApptypeCasepackMapData
         
         
         * 
         */


    }

    public static void main(String[] args) throws JSONException, JsonProcessingException {
        Practice practice = new Practice();

        practice.stepOne();

    }
}










