package com.bhavani.bdd.practice3;

import com.bhavani.bdd.CucumberTestContext;
import com.bhavani.utils.PropertiesReader;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.io.Charsets;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class AbstractStepsForPPE {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractStepsForPPE.class);

    private CucumberTestContext CONTEXT = CucumberTestContext.CONTEXT;

    protected String baseUrl() {
      return String.valueOf(new PropertiesReader().loadProperties("application.properties").get("baseURL"));
      // return "https://sisenterpriseapi164381-g.azurewebsites.net/";
    }

    protected CucumberTestContext testContext() {
        return CONTEXT;
    }

    protected String executeRequest(String url, String method) {
      HttpClient httpClient = new DefaultHttpClient();
      HttpResponse httpResponse = null;
      try {
          if(method.equalsIgnoreCase("get")) {
            HttpGet getRequest = new HttpGet(url);
            getRequest.addHeader("content-type", "application/json");
            httpResponse = httpClient.execute(getRequest);
          }
          if(method.equalsIgnoreCase("post")) {
            HttpPost postRequest = new HttpPost();
            postRequest.addHeader("content-type", "application/json");
          }
          if(method.equalsIgnoreCase("put")) {
            HttpPut putRequest = new HttpPut();
            putRequest.addHeader("content-type", "application/json");
          }
          if(method.equalsIgnoreCase("delete")) {
            HttpDelete deleteRequest = new HttpDelete();
            deleteRequest.addHeader("content-type", "application/json");
          }

          int statusCode = httpResponse.getStatusLine().getStatusCode();
          String statusLine = httpResponse.getStatusLine().getReasonPhrase();

        HttpEntity entity = httpResponse.getEntity();
        org.apache.http.Header encodingHeader = entity.getContentEncoding();
        Charset encoding = encodingHeader == null ? StandardCharsets.UTF_8 :
        Charsets.toCharset(encodingHeader.getValue());
        String jsonResponse = EntityUtils.toString(entity, StandardCharsets.UTF_8);
        return jsonResponse;
      } catch (IOException e) {
        e.printStackTrace();
      }
      return null;
    }

    protected void executePost(String apiPath) {
        executePost(apiPath, null, null);
      }

    protected void executePost(String apiPath, Map<String, String> pathParams) {
        executePost(apiPath, pathParams, null);
      }

    protected void executePost(String apiPath, Map<String, String> pathParams, Map<String, String> queryParamas) {
        final RequestSpecification request = CONTEXT.getRequest();
        // final Object payload = CONTEXT.getPayload();
        final Object payload = CONTEXT.getPayloadFromJSONObject();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParamas, request);

        try {
            Map<String, String> headers = new HashMap<String, String>();
          if(testContext().get("token").toString().length() > 1) {
            headers.put("token", testContext().get("token").toString());

          }
       //   headers.put("application_identifier", "Gateway");
          setHeaders(headers, request);
        } catch (Exception e) {

        }
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<< " + apiPath);

        Response response = null;
        request.header(new Header("application_identifier", "Gateway"));
        if(avoidLogMessages(apiPath)) {

          response = request.accept(ContentType.JSON)
                  .post(url);

        } else {
          /*
          response = request.accept(ContentType.JSON)
                  .log()
                  .all()
                  .post(url);
            */
            response = request
                  //  .given()
                //    .header("application_identifier", "Gateway")
                    .log()
                    .all()
                    .post(url);
          logResponse(response);

        }

        /*
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .post(url);
        */
      // logResponse(response);
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<< "  + apiPath);

        CONTEXT.setResponse(response);
      }

    protected void executeMultiPartPost(String apiPath) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");
        Response response = request.multiPart("fuelTransfer", payload, "application/json")
          .log()
          .all()
          .post(url);

        logResponse(response);
        CONTEXT.setResponse(response);
      }

    protected void executeDelete(String apiPath) {
        executeDelete(apiPath, null, null);
      }

    protected void executeDelete(String apiPath, Map<String, String> pathParams) {
        executeDelete(apiPath, pathParams, null);
      }

    protected void executeDelete(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<< "  + apiPath);
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .delete(url);

        logResponse(response);
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<< "  + apiPath);
        CONTEXT.setResponse(response);
      }

    protected void executePut(String apiPath) {
        executePut(apiPath, null, null);
      }

    protected void executePut(String apiPath, Map<String, String> pathParams) {
        executePut(apiPath, pathParams, null);
      }

    protected void executePut(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<< "  + apiPath);
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .put(url);

        logResponse(response);
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<< "  + apiPath);
        CONTEXT.setResponse(response);
      }

    protected void executePatch(String apiPath) {
        executePatch(apiPath, null, null);
      }

    protected void executePatch(String apiPath, Map<String, String> pathParams) {
        executePatch(apiPath, pathParams, null);
      }

    protected void executePatch(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<< "  + apiPath);
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .patch(url);

        logResponse(response);
        CONTEXT.setResponse(response);
      }

    protected void executeGet(String apiPath) {
        executeGet(apiPath, null, null);
      }

    protected void executeGet(String apiPath, Map<String, String> pathParams) {
        executeGet(apiPath, pathParams, null);
      }

    protected void executeGet(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final String url = baseUrl() + apiPath;

        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);

        Response response = null;
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<< "  + apiPath);
        if(avoidLogMessages(apiPath)) {
          response = request.accept(ContentType.JSON)
                  .get(url);
        } else {
          response = request.accept(ContentType.JSON)
                  .log()
                  .all()
                  .get(url);
          logResponse(response);
        }


        /*
        response = request.accept(ContentType.JSON)
                .log()
                .all()
                .get(url);
        logResponse(response);
        */
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<< "  + apiPath);
        CONTEXT.setResponse(response);
      }

    private void logResponse(Response response) {
        response.then()
          .log()
          .all();
      }

    private void setPathParams(Map<String, String> queryParamas, RequestSpecification request) {
        if (null != queryParamas) {
          request.queryParams(queryParamas);
        }
      }

    private void setQueryParams(Map<String, String> pathParams, RequestSpecification request) {
        if (null != pathParams) {
          request.pathParams(pathParams);
        }
      }

    private void setHeaders(Map<String, String> headers, RequestSpecification request) {
        if (null != headers) {
          request.headers(headers);
        }
      }

    private void setPayload(RequestSpecification request, Object payload) {
        if (null != payload) {
          request.contentType(ContentType.JSON)
            .body(payload);
        }
      }

    private Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("token", testContext().get("token").toString());
        headers.put("application_identifier", "Gateway");
        return headers;
      }

    private boolean avoidLogMessages(String requestPath) {
        switch (requestPath) {
          case "api/User/UserOrgMap":
            return true;
          case "api/FeeSchedule/GetFeeSchedules":
            return true;
          case "api/PeriodBatch/GetPeriodBatch/false":
            return true;
          case "api/Room/GetActiveORRoomsForOrganization":
            return true;
          case "api/PatientData/GetDuplicatePatients":
            return true;
          case "api/Room/GetRoomsForOrganization":
            return true;
          case "api/FacilityConfiguration/GetCurrentFacilityAddresses":
            return true;
          case "api/ICDCodeClassification/GetICDCodeClassifications":
            return true;
          case "api/Dictionary/v2/151/All":
            return true;
          case "api/Dictionary/v2/158/All":
            return true;
          case "api/ApptypeCasepackMap/GetApptypeCasepackMapData":
            return true;
          case "api/StaffList/GetStaffForFacility":
            return true;
          case "api/Gateway/User/UserOrgMap":
            return true;
          default:
            if(requestPath.contains("api/PatientData/GetDuplicatePatients")) {
              return true;
            }
            if(requestPath.contains("api/PatientData/Patients/")) {
              return true;
            }
            if(requestPath.contains("api/StaffList/GetStaffForFacility")) {
              return true;
            }
            if(requestPath.contains("api/CaseSummary/PPEPatient/")) {
              return true;
            }
            if(requestPath.contains("api/CaseSummary/GetCaseSummaryInfo/")) {
              return true;
            }
            if(requestPath.contains("api/CaseSummary/GetCaseInformation/")) {
              return true;
            }
            if(requestPath.contains("api/PatientFacesheet/GetCaseDetailInformation/")) {
              return true;
            }
            if(requestPath.contains("api/ScheduledCaseProcedure/GetScheduledProcedures/")) {
              return true;
            }

            return false;
        }
    }


}