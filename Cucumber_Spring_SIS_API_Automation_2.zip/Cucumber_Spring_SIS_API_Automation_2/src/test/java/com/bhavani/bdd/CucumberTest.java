package com.bhavani.bdd;

import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
@RunWith(CucumberReportRunner.class)
@CucumberOptions(features = "classpath:features/sample", plugin = {
        "pretty",
        "json:target/cucumber-report.json",
        "html:target/cucumber-html",
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})
public class CucumberTest {
}