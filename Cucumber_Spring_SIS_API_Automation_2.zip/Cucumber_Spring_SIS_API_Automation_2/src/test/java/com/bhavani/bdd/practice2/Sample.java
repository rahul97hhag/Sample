package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.icdCodes.IcdCodes;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.staff.Staff;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.minidev.json.JSONArray;
import org.junit.Test;

/**
 * Created by BhavaniPrasadReddy on 8/15/2020.
 */
public class Sample extends AbstractSteps{




    @Test
    public void sampleOne() {
        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";
        CommonRequests commonRequests = new CommonRequests();
        commonRequests.createSession(username, password, facility);
        /*
        IcdCodes icdCodes = commonRequests.getICDCodes("H44.001");
        System.out.println(icdCodes.toString());
        */

       // super.executeGet("/PatientCoverPage/AreaOfCare/PreOperative/admit_source.json");
       // super.executeGet("/PatientCoverPage/AreaOfCare/PreOperative/admit_type.json");

        Response response = null;
        RequestSpecification request = RestAssured.given();
        request.baseUri("https://sisenterpriseweb171051-gem-pr.azurewebsites.net");
        request.basePath("/PatientCoverPage/AreaOfCare/PreOperative/admit_source.json");
        response = request.get();
        org.json.JSONArray admitSource = new org.json.JSONArray(response.asString());
        System.out.println(admitSource.toString(4));

        request.basePath("/PatientCoverPage/AreaOfCare/PreOperative/admit_type.json");
        response = request.get();
        org.json.JSONArray admitType = new org.json.JSONArray(response.asString());
        System.out.println(admitType.toString(4));




        /*



        GET api/PatientData/GetPatientData
No documentation available.

GET api/PatientData/Patients
No documentation available.

GET api/PatientData/Patients/{id}
No documentation available.

GET api/PatientData/Gemini/GetPatient/{id}
No documentation available.

GET api/PatientData/{id}/Auditing
No documentation available.

POST api/PatientData/Search
No documentation available.

POST api/PatientData/SearchToken
No documentation available.

POST api/PatientData/Gemini/SearchToken
No documentation available.

POST api/PatientData/InsertPatient
No documentation available.

PUT api/PatientData/InsertMpiPatientData?id={id}
No documentation available.

DELETE api/PatientData/DeletePatientData?id={id}
No documentation available.

GET api/PatientData/{patientId}/allergyHistory
No documentation available.

GET api/PatientData/{patientId}/medicationHistory
No documentation available.

GET api/PatientData/{patientId}/surgicalHistory
No documentation available.

GET api/PatientData/{patientId}/phone
No documentation available.

POST api/PatientData/CreatePatient/{sourceModuleId}
No documentation available.

POST api/PatientData/Gemini/CreatePatient/{sourceModuleId}
No documentation available.

GET api/PatientData/Image/{id}
No documentation available.

GET api/PatientData/GetSurescriptLastLoadedMedsDate/{patientId}
No documentation available.

POST api/PatientData/GetDuplicatePatients
No documentation available.

GET api/PatientData/GetFaceSheetPatientInfo/{patientId}/{caseSummaryId}
No documentation available.

GET api/PatientData/GetPatientResponsibleParties/{patientId}
No documentation available.

PUT api/PatientData/Transfer/{patientId}
No documentation available.

PUT api/PatientData/Transfer/Language/{patientId}
No d

PUT api/EmergencyContact/Transfer/{patientId}
No documentation available.

POST api/EmergencyContact/Upsert/Case
No documentation available.

GET api/EmergencyContact/Case/{caseSummaryId}
No documentation available.

GET api/EmergencyContact/FaceSheet/{patientId}
No documentation available.

GET api/EmergencyContact/PatientEmergencyContact/{patientId}
No documentation available.

DELETE api/EmergencyContact/DeleteEmergencyContact/{emergencyContactId}
No d






         */
    }
}
