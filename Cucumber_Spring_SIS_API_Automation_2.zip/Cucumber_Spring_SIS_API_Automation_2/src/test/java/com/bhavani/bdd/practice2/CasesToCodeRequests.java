package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.patientCases.casesToCode.PerformedProcedures;
import com.bhavani.models.patientCases.casesToCodeResponse.CasesToCodeResponse;
import com.bhavani.models.scheduledProcedures.ScheduledProcedures;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/29/2020.
 */
public class CasesToCodeRequests extends AbstractSteps {

    private static Logger LOG = LoggerFactory.getLogger(CasesToCodeRequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public List<ScheduledProcedures> getScheduledProcedures(int caseSummaryId) {
        super.executeGet("api/ScheduledCaseProcedure/GetScheduledProcedures/"+caseSummaryId+"/false");
        //  /api/ScheduledCaseProcedure/GetScheduledProcedures/46704/false
        Response scheduledProceduresResponse = testContext().getResponse();
        List<ScheduledProcedures> scheduledProcedures = null;
        try {
            scheduledProcedures = Arrays.asList(mapper.readValue(scheduledProceduresResponse.asString(), ScheduledProcedures[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return scheduledProcedures;
    }

    public CasesToCodeResponse performCasesToCode(PerformedProcedures performedProcedures) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(performedProcedures));
            super.executePost("api/CaseToCode/SavePerformedItems/");
            Response casesToCodeResponse = testContext().getResponse();
            // LOG.info(casesToCodeResponse.asString());
            CasesToCodeResponse casesToCodeResponseObject = mapper.readValue(casesToCodeResponse.asString(), CasesToCodeResponse.class);
            return casesToCodeResponseObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

}
