package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.patient.Employer;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.patientCases.caseSummary.*;
import com.bhavani.models.patientCases.newCaseSummary.CaseSummary;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/29/2020.
 */
public class PatientRequests extends AbstractSteps {
    private static Logger LOG = LoggerFactory.getLogger(PatientRequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public Patient createPatient(Patient patient) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(patient));
            super.executePost("api/PatientData/Gemini/CreatePatient/2030");
            Response createPatientResponse = testContext().getResponse();
            LOG.info(createPatientResponse.asString());
            patient = mapper.readValue(createPatientResponse.asString(), Patient.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patient;
    }

    public void savePatientEmployer(Employer employer) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(employer));
            super.executePost("api/PatientEmployer/SavePatientEmployer");
            Response employeeResponse = testContext().getResponse();
            LOG.info(employeeResponse.asString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public Patient getDuplicatePatient(String firstName, String lastName) {
        JSONObject patientSearchObject = new JSONObject();
        try {
            patientSearchObject.put("firstName", firstName);
            patientSearchObject.put("lastName", lastName);
            super.testContext().setPayload(patientSearchObject.toString());
            super.executePost("api/PatientData/GetDuplicatePatients");
            Response duplicatePatientsResponse = testContext().getResponse();
            List<Patient> availablePatients = null;
            availablePatients = Arrays.asList(mapper.readValue(duplicatePatientsResponse.asString(), Patient[].class));
            return availablePatients.get(0);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Patient getPatientByPatientId(int patientId) {
        super.executeGet("api/PatientData/Patients/" + patientId);
        Response patientsResponse = testContext().getResponse();
        Patient patient = null;
        try {
            patient = mapper.readValue(patientsResponse.asString(), Patient.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patient;
    }

    public Patient getPatientFromFirstNameAndLastName(String firstName, String lastName) {
        Patient patient = getDuplicatePatient(firstName, lastName);
        patient = getPatientByPatientId(patient.getPatientId());
        return patient;
    }

    public CaseSummaryFromPatientId getCaseSummaryByPatientId(int patientId) {
        // super.executeGet("api/CaseSummary/PPEPatient/" + patientId);
        super.executeGet("api/CaseSummary/Patient/" + patientId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseSummaryFromPatientId caseSummaryFromPatientId = null;
        try {
            List<CaseSummaryFromPatientId> caseSummaries = Arrays.asList(mapper.readValue(caseSummaryResponse.asString(), CaseSummaryFromPatientId[].class));
            caseSummaryFromPatientId = caseSummaries.get(0);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryFromPatientId;
    }

    public void getCurrentBEByPatientId(int patientId) {
        super.executeGet("api/CaseSummary/CurrentBE/Patient/" + patientId);
        Response businessEntitySettings = testContext().getResponse();
    }

    public CaseSummaryFromCaseSummaryId getCaseSummaryByCaseSummaryId(int caseSummaryId) {
        super.executeGet("api/CaseSummary/" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseSummaryFromCaseSummaryId caseSummaryFromCaseSummaryId = null;
        try {
            caseSummaryFromCaseSummaryId = mapper.readValue(caseSummaryResponse.asString(), CaseSummaryFromCaseSummaryId.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryFromCaseSummaryId;
    }

    public CaseSummaryInfo getCaseSummaryInfo(int caseSummaryId) {
        super.executeGet("api/CaseSummary/GetCaseSummaryInfo/" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseSummaryInfo caseSummaryInfo = null;
        try {
            caseSummaryInfo = mapper.readValue(caseSummaryResponse.asString(), CaseSummaryInfo.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryInfo;
    }

    public CaseInformation getCaseInformation(int caseSummaryId) {
        super.executeGet("api/CaseSummary/GetCaseInformation/" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
        CaseInformation caseInformation = null;
        try {
            caseInformation = mapper.readValue(caseSummaryResponse.asString(), CaseInformation.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseInformation;
    }

    public void getCaseDetails(int caseSummaryId, int moduleId) {
        super.executeGet("api/WorklistCaseDetails/GetCaseDetails/"+caseSummaryId+"/"+moduleId);
        Response caseSummaryResponse = testContext().getResponse();
    }


    public CaseDetailInformation getCaseDetailInformation(int patientId, int caseSummaryId) {
        super.executeGet("api/PatientFacesheet/GetCaseDetailInformation/" + patientId+ "/" + caseSummaryId);
        Response caseDetailInformationResponse = testContext().getResponse();
        CaseDetailInformation caseDetailInformation = null;
        try {
            caseDetailInformation = mapper.readValue(caseDetailInformationResponse.asString(), CaseDetailInformation.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseDetailInformation;
    }



    public void updateCaseStatus(int caseSummaryId, String caseStatus) {
        super.testContext().setPayload(caseStatus);
        super.executePost("api/CaseSummary/UpdateCaseSatus/" + caseSummaryId);
        Response caseStatusResponse = testContext().getResponse();
    }

    public void requestLock(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/Security/RecordLock/RequestLock");
        Response requestLockResponse = testContext().getResponse();
    }

    public void releaseLock(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/Security/RecordLock/ReleaseLock");
        Response requestLockResponse = testContext().getResponse();
    }



    public void upsertCaseSummaryInfo(CaseSummaryInfo caseSummaryInfo) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(caseSummaryInfo));
            super.executePut("api/CaseSummary/UpsertCaseSummaryInfo");
            Response upsertCaseSummaryInfoResponse = testContext().getResponse();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public void getBasicModuleInfoByCaseSummaryId(int caseSummaryId) {
        super.executeGet("api/BasicModuleInfo/GetBasicModuleInfoByCaseSummaryId/" + caseSummaryId );
        Response upsertCaseSummaryInfoResponse = testContext().getResponse();
    }

    public JSONObject upsertCaseSummary(CaseSummary caseSummary) {
        JSONObject caseSummaryObject = null;
        try {
            super.testContext().setPayload(mapper.writeValueAsString(caseSummary));
            super.executePost("api/CaseSummaryComplex/Gemini/UpsertCaseSummary");
            Response caseSummaryResponse = testContext().getResponse();
            caseSummaryObject = new JSONObject(caseSummaryResponse.asString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return caseSummaryObject;
    }
}
