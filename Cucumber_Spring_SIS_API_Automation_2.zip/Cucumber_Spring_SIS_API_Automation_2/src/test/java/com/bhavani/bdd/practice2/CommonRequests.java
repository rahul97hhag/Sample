package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.anesthesiaType.AnesthesiaType;
import com.bhavani.models.appointmentType.AppointmentType;
import com.bhavani.models.others.States;
import com.bhavani.models.patientCases.chargeEntry.Period;
import com.bhavani.models.commons.ChildOrganizations;
import com.bhavani.models.commons.MappedOrganizations;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.icdCodes.IcdCodes;
import com.bhavani.models.others.ZipCode;
import com.bhavani.models.room.ActiveRoom;
import com.bhavani.models.staff.Staff;
import com.bhavani.models.staff.StaffByRole;
import com.bhavani.templates.WebServiceRequestKeys;
import com.bhavani.utils.PropertiesReader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by BhavaniPrasadReddy on 8/15/2020.
 */
public class CommonRequests extends AbstractSteps {

    private static Logger LOG = LoggerFactory.getLogger(CommonRequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public void createSession(String username, String password, String facility) {
        super.getWebServiceRequests();
        testContext().reset();
        JSONObject loginObject = new JSONObject();
        try {
            loginObject.put("Password", password);
            loginObject.put("UserName", username);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        super.testContext().setPayload(loginObject);
        super.executePost(super.webserviceRequests.getJSONObject("UserAuthentication").getJSONObject("loginUser").get(WebServiceRequestKeys.relUrl).toString());
        Response loginResponse = testContext().getResponse();
        String token = loginResponse.asString();
        token = token.replaceAll("\"", "");
        LOG.info(token);
        super.testContext().set("token", token);
        super.testContext().clearPayload();

        super.executeGet(super.webserviceRequests.getJSONObject("User").getJSONObject("getUserOrgMap").get(WebServiceRequestKeys.relUrl).toString());
        Response getUserOrgMapResponse = testContext().getResponse();

        try {
            JSONObject mappedOrgs = new JSONArray(getUserOrgMapResponse.asString()).getJSONObject(0);
            MappedOrganizations mappedOrganizations = mapper.readValue(mappedOrgs.toString(), MappedOrganizations.class);
            List<ChildOrganizations> childOrganizations = new ArrayList<ChildOrganizations>();
            childOrganizations = mappedOrganizations.getChildOrgs();
            ListIterator<ChildOrganizations> childOrganizationsListIterator = childOrganizations.listIterator();
            boolean skip = false;
            while(childOrganizationsListIterator.hasNext() && !(skip)) {
                ChildOrganizations childOrganization = childOrganizationsListIterator.next();
                String organizationName = childOrganization.getName().trim();
                if(organizationName.equalsIgnoreCase(facility)) {
                    super.testContext().set("organizationId", childOrganization.getOrganizationId());
                    skip = true;
                }
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String userOrgMapURL = super.webserviceRequests.getJSONObject("UserSession").getJSONObject("UserSessionOrg").get(WebServiceRequestKeys.relUrl).toString();
        super.params.put("orgID", super.testContext().get("organizationId").toString());
        super.executePost(userOrgMapURL, params);
        Response mapUserResponse = super.testContext().getResponse();
        LOG.info(mapUserResponse.asString());
    }

    public void logout() {
        super.executeGet(super.webserviceRequests.getJSONObject("UserSession").getJSONObject("logout").get(WebServiceRequestKeys.relUrl).toString());
        Response logoutResponse = testContext().getResponse();
        String token = logoutResponse.asString().replaceAll("\"", "");
        LOG.info(token);
    }

    public ActiveRoom getRoomByName(String roomName) {
        super.executeGet(super.webserviceRequests.getJSONObject("Room").getJSONObject("getActiveRoomsForOrganization").get(WebServiceRequestKeys.relUrl).toString());
        Response roomsResponse = testContext().getResponse();
        try {
            List<ActiveRoom> activeRooms = Arrays.asList(mapper.readValue(roomsResponse.asString(), ActiveRoom[].class));
            ActiveRoom room = activeRooms.stream().filter(obj ->
                    roomName.equalsIgnoreCase(obj.getName())).findAny().orElse(null);
            return room;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActiveRoom getRoomByNameInNursingDesktop(String roomName) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("isAlphabeticalOrder", true);
        jsonObject.put("showInClinicalTf", true);
        super.testContext().setPayload(jsonObject.toString());
        super.executePost(super.webserviceRequests.getJSONObject("Room").getJSONObject("getRooms").get(WebServiceRequestKeys.relUrl).toString());
        Response roomsResponse = testContext().getResponse();
        try {
            List<ActiveRoom> activeRooms = Arrays.asList(mapper.readValue(roomsResponse.asString(), ActiveRoom[].class));
            ActiveRoom room = activeRooms.stream().filter(obj ->
                    roomName.equalsIgnoreCase(obj.getItemName().toString())).findAny().orElse(null);
            return room;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public StaffByRole getStaffByRole(String staffName) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pageNumber", 1);
        jsonObject.put("isAlphabeticalOrder", true);
        super.testContext().setPayload(jsonObject.toString());
        super.executePost(super.webserviceRequests.getJSONObject("Staff").getJSONObject("getStaffByRole").get(WebServiceRequestKeys.relUrl).toString());
        Response staffResponse = testContext().getResponse();
        try {
            List<StaffByRole> staffs = Arrays.asList(mapper.readValue(staffResponse.asString(), StaffByRole[].class));
            StaffByRole staff = staffs.stream().filter(obj ->
                    staffName.equalsIgnoreCase(obj.getLastName().toString())).findAny().orElse(null);
            return staff;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void getPatientRecord(int patientId, int caseSummaryId) {
        super.params.put("patientId", String.valueOf(patientId));
        super.params.put("caseSummaryId", String.valueOf(caseSummaryId));
        super.executeGet(super.webserviceRequests.getJSONObject("RecordHeader").getJSONObject("getPatientRecord").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response roomsResponse = testContext().getResponse();
    }

    public void getPatientRecordByCaseSummaryId(int caseSummaryId) {
        super.params.put("caseSummaryId", String.valueOf(caseSummaryId));
        super.executeGet(super.webserviceRequests.getJSONObject("RecordHeader").getJSONObject("getPatientRecordByCaseSummaryId").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response roomsResponse = testContext().getResponse();
    }

    public void getPatientMonitorConfiguration() {
        super.executeGet(super.webserviceRequests.getJSONObject("PatientMonitorConfiguration").getJSONObject("getPatientMonitorConfiguration").get(WebServiceRequestKeys.relUrl).toString());
        Response roomsResponse = testContext().getResponse();
    }

    public void getCoverPageInformation(int patientId, int caseSummaryId) {
        super.params.put("patientId", String.valueOf(patientId));
        super.params.put("caseSummaryId", String.valueOf(caseSummaryId));
        super.executeGet(super.webserviceRequests.getJSONObject("PatientFacesheetConsolidation").getJSONObject("getCoverPageInformation").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response roomsResponse = testContext().getResponse();
    }

    public AnesthesiaType getAnesthesiaType(String anesthesiaType) {
        super.executeGet("api/Dictionary/v2/152");
        Response anesthesiaTypesResponse = testContext().getResponse();
        try {
            List<AnesthesiaType> anesthesiaTypes = Arrays.asList(mapper.readValue(anesthesiaTypesResponse.asString(), AnesthesiaType[].class));
            AnesthesiaType anesthesiaTypeObject = anesthesiaTypes.stream().filter(obj ->
                    anesthesiaType.equalsIgnoreCase(obj.getValue())).findAny().orElse(null);
            return anesthesiaTypeObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ZipCode getAddressFromZipCode(String zipCode) {
        super.params.put("zipCode", zipCode);
        super.executeGet(super.webserviceRequests.getJSONObject("ZipCode").getJSONObject("getZipCode").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response zipCodeResponse = testContext().getResponse();
        ZipCode zipCodeObject = null;
        try {
            zipCodeObject = mapper.readValue(zipCodeResponse.asString(), ZipCode.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return zipCodeObject;
    }

    public AppointmentType getAppointmentType(String appointmentTypeName) {
        super.executeGet(super.webserviceRequests.getJSONObject("ApptypeCasepackMap").getJSONObject("getApptypeCasepackMapData").get(WebServiceRequestKeys.relUrl).toString());
        Response appointmentTypeResponse = testContext().getResponse();
        AppointmentType appointmentType = null;
        try {
            List<AppointmentType> appointmentTypes = Arrays.asList(mapper.readValue(appointmentTypeResponse.asString(), AppointmentType[].class));
            appointmentType = appointmentTypes.stream().filter(obj ->
                    appointmentTypeName.equalsIgnoreCase(obj.getAppointmentTypeDesc())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return appointmentType;
    }

    public Staff getPhysicianDetails(String physicianName) {
        super.testContext().setPayload("");
        super.executePost(super.webserviceRequests.getJSONObject("StaffList").getJSONObject("getStaffForFacility").get(WebServiceRequestKeys.relUrl).toString());
        Response staffForFacilityResponse = testContext().getResponse();
        Staff staff = null;
        try {
            List<Staff> staffDetails = Arrays.asList(mapper.readValue(staffForFacilityResponse.asString(), Staff[].class));
            staff = staffDetails.stream().filter(obj ->
                    physicianName.equalsIgnoreCase(obj.getLastName())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return staff;
    }

    public FeeSchedule getFeeScheduleByCptCode(String cptCode) {
        String encodedCptCode = Base64.getEncoder().encodeToString(cptCode.getBytes());
        super.testContext().setPayload("\""+encodedCptCode+"\"");
        super.executePost(super.webserviceRequests.getJSONObject("FeeSchedule").getJSONObject("searchFeeSchedule").get(WebServiceRequestKeys.relUrl).toString());
        Response feeScheduleResponse = testContext().getResponse();
        FeeSchedule feeSchedule = null;
        try {
            List<FeeSchedule> feeSchedules = Arrays.asList(mapper.readValue(feeScheduleResponse.asString(), FeeSchedule[].class));
            feeSchedule = feeSchedules.stream().filter(obj ->
                    cptCode.contentEquals(obj.getCptProcedure().getCptCode())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return feeSchedule;
    }

    public void getBusinssEntitySettings() {
        super.executeGet(super.webserviceRequests.getJSONObject("BusinessEntitySettings").getJSONObject("getBusinessEntitySettings").get(WebServiceRequestKeys.relUrl).toString());
        Response businessEntitySettings = testContext().getResponse();
    }

    public IcdCodes getICDCodes(String ICDCode) {
        super.testContext().setPayload("\""+ICDCode.substring(0, 3)+"\"");
        super.executePost(super.webserviceRequests.getJSONObject("ICDCodeClassification").getJSONObject("getICDCodeClassifications").get(WebServiceRequestKeys.relUrl).toString());
        Response icdCodesResponse = testContext().getResponse();
        List<IcdCodes> icdCodes = null;
        IcdCodes icdCode = null;
        try {
            icdCodes = Arrays.asList(mapper.readValue(icdCodesResponse.asString(), IcdCodes[].class));
            icdCode = icdCodes.stream().filter(obj ->
                    ICDCode.contentEquals(obj.getIcdCode())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return icdCode;
    }

    public Period getPeriodByPeriodName(String periodName) {
        super.params.put("isReturnAll", "false");
        super.executeGet(super.webserviceRequests.getJSONObject("Period").getJSONObject("getPeriodBatch").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response periodResponse = testContext().getResponse();
        List<Period> periods = null;
        Period period = null;
        try {
            periods = Arrays.asList(mapper.readValue(periodResponse.asString(), Period[].class));
            period = periods.stream().filter(obj ->
                    periodName.contentEquals(obj.getPeriodName())).findAny().orElse(null);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return period;
    }

    public JSONArray getResponseFromURL(String url) {
         String baseURL = String.valueOf(new PropertiesReader().loadProperties("application.properties").get("applicationURL"));

         String completeURL = baseURL + url;
        JSONArray jsonArray = new JSONArray(super.executeRequest(completeURL, "GET"));
        return jsonArray;
    }
}
