package com.bhavani.bdd.practice2;

import org.apache.commons.io.Charsets;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * Created by BhavaniPrasadReddy on 8/23/2020.
 */
public class Sample2 {

    public JSONArray getResponseFromURL(String url) {
        String baseURL = "https://sisenterpriseweb171051-gem-pr.azurewebsites.net/";

        String completeURL = baseURL + url;
        JSONArray jsonArray = new JSONArray(executeRequest(completeURL, "GET"));
        return jsonArray;
    }

    protected String executeRequest(String url, String method) {
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse = null;
        try {
            if(method.equalsIgnoreCase("get")) {
                // HttpGet getRequest = new HttpGet(baseUrl() + url);
                HttpGet getRequest = new HttpGet(url);
                getRequest.addHeader("content-type", "application/json");
                httpResponse = httpClient.execute(getRequest);
            }
            if(method.equalsIgnoreCase("post")) {
                HttpPost postRequest = new HttpPost();
                postRequest.addHeader("content-type", "application/json");
            }
            if(method.equalsIgnoreCase("put")) {
                HttpPut putRequest = new HttpPut();
                putRequest.addHeader("content-type", "application/json");
            }
            if(method.equalsIgnoreCase("delete")) {
                HttpDelete deleteRequest = new HttpDelete();
                deleteRequest.addHeader("content-type", "application/json");
            }

            int statusCode = httpResponse.getStatusLine().getStatusCode();
            String statusLine = httpResponse.getStatusLine().getReasonPhrase();

            HttpEntity entity = httpResponse.getEntity();
            org.apache.http.Header encodingHeader = entity.getContentEncoding();
            Charset encoding = encodingHeader == null ? StandardCharsets.UTF_8 :
                    Charsets.toCharset(encodingHeader.getValue());
            String jsonResponse = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            return jsonResponse;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        Sample2 sample2 = new Sample2();
        JSONArray admitSources = sample2.getResponseFromURL("PatientCoverPage/AreaOfCare/PreOperative/admit_source.json");
        // https://sisenterpriseweb171051-gem-pr.azurewebsites.net/PatientCoverPage/AreaOfCare/PreOperative/admit_source.json
        JSONArray admitTypes = sample2.getResponseFromURL("PatientCoverPage/AreaOfCare/PreOperative/admit_type.json");


    }
}
