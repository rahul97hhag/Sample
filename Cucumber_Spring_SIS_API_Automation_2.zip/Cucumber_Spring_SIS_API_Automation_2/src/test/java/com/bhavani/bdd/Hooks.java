package com.bhavani.bdd;

import cucumber.api.PickleStepTestStep;
import cucumber.api.Scenario;
import cucumber.api.TestCase;
import cucumber.api.java.Before;
import cucumber.api.java.After;
import cucumber.api.java.BeforeStep;
import cucumber.api.java.AfterStep;
import org.springframework.test.context.TestContext;

import java.lang.reflect.Field;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by BhavaniPrasadReddy on 8/21/2020.
 */
public class Hooks {

  //  TestContext testContext;
    private int currentStepDefIndex = 0;

    /*
    public Hooks(TestContext context) {
        this.testContext = context;
    }
    */
    /*
    @Before
    public void beforeScenario(Scenario scenario) {
      //  scenario.write("Started executing "+ scenario.getName());
    }

    @After
    public void afterScenario(Scenario scenario) {
    //    scenario.write("Completed executing "+ scenario.getName());
    }

    @BeforeStep
    public void beforeStep(Scenario scenario) {
   //     scenario.write("33");
        byte arr[] = new byte[] {1, 6, 3};
     //   scenario.embed(arr, "Sample Step " );
        Field field = null;
        try {
            field = scenario.getClass().getDeclaredField("testCase");
            field.setAccessible(true);
            TestCase testCase = (TestCase) field.get(scenario);
            List<PickleStepTestStep> stepDefs = testCase.getTestSteps()
                        .stream().filter(testStep -> testStep instanceof PickleStepTestStep)
                        .map(testStep -> (PickleStepTestStep) testStep)
                        .collect(Collectors.toList());
            PickleStepTestStep currentStep = stepDefs.get(currentStepDefIndex);

        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }


    }

    @AfterStep
    public void afterStep(Scenario scenario) {
      //  scenario.write("38");
        byte arr[] = new byte[] {9, 7, 5};
      //  scenario.embed(arr, "Sample Step " );
        currentStepDefIndex += 1;
    }
    */



}
