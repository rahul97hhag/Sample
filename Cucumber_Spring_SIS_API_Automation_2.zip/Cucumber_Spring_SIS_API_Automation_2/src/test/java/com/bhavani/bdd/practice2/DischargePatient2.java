package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.patientCases.caseSummary.*;
import com.bhavani.models.patientCases.dischargePatient.*;
import com.bhavani.models.patientCases.dischargePatient.FormByName;
import com.bhavani.models.patientCases.dischargePatient.FormUsageByFormOwner;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.staff.Staff;
import com.bhavani.utils.DateUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/15/2020.
 */
public class DischargePatient2 extends AbstractSteps {

    private static Logger LOG = LoggerFactory.getLogger(DischargePatient2.class);
    @Test
    public void dischargePatient() {

        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";

        String roomName = "Gemuser2_Room1";
        String appointmentTypeName = "Gem_General2";
        String cptCode = "22899";
        String physicianName = "Gem_user10";
        String preOpDiagnosisCode = "H44.001";

        String insuranceName = "Carrier1906_3";
        String patientFirstName = "AAAAAAAnDBilW";
        String patientLastName = "AAAAAAAnDBilW";
        String patientMiddleInitial = "M";
        String patientDateOfBirth = "11/11/1991";
        String patientGender = "Male";

        String date = DateUtilities.getInstance().addDate("today", "yyyy-MM-dd");
        String today = date + "T01:00:39.422Z";
        String country = "United States";
        String addressKind = "RESIDENTIAL";
        String startTime = "11:00";
        String endTime = "12:00";
        int duration = 60;
        String dateOfService = DateUtilities.getInstance().addDate("today", "MM/dd/yyyy");
        String procedureStartTime = date + "T"+startTime+":00.000Z";
        String procedureStopTime = date + "T"+endTime+":00.000Z";
        String procedureStartDt = date + "T"+startTime+":00.000Z";
        String procedureStopDt = date+ "T"+endTime+":00.000Z";
        String procedureDate = null;
        String formName = "Patient Panel";
        String formLastUpdatedDate = date + "T02:00:00.000Z";

        String inTime = date + "T11:20:00.000Z";
        String outTime = date + "T11:30:00.000Z";

        String transferTime = date + "T07:00:00+05:30";
        String transferTimeOfTime = DateUtilities.getInstance().addDate("today", "MM-dd-yyyy") + " 07:20";
        String transferTimeWfTime = DateUtilities.getInstance().addDate("today", "MM-dd-yyyy") + " 03:30";

        String admissionTime = date+ "T06:30:00+05:30";

       // String moduleName = "Pre-Operative";
        String moduleName = "Recovery";
        String transferModuleName = "Recovery";
        Module module = null;
        Module transferModule = null;
        // 2020-08-20T11:

        CommonRequests commonRequests = new CommonRequests();
        PatientRequests patientRequests = new PatientRequests();
        DischargePatientRequests dischargePatientRequests = new DischargePatientRequests();

        commonRequests.createSession(username, password, facility);
        Patient patient = patientRequests.getPatientFromFirstNameAndLastName(patientFirstName, patientLastName);
        Staff staff = commonRequests.getPhysicianDetails(username);

        ObjectMapper mapper = new ObjectMapper();

        CaseSummaryFromPatientId caseSummaryFromPatientId = patientRequests.getCaseSummaryByPatientId(patient.getPatientId());
        CaseSummaryFromCaseSummaryId caseSummaryFromCaseSummaryId = patientRequests.getCaseSummaryByCaseSummaryId(caseSummaryFromPatientId.getCaseSummaryId());
        CaseSummaryInfo caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        CaseInformation caseInformation = patientRequests.getCaseInformation(caseSummaryFromCaseSummaryId.getCaseSummaryId());

        dischargePatientRequests.getModulesAndFormsByCaseId(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        dischargePatientRequests.getModules();
        patientRequests.getBasicModuleInfoByCaseSummaryId(caseSummaryFromCaseSummaryId.getCaseSummaryId());


        AreaOfCareStaffDetails saveAreaOfCareStaffDetails = null;
        AreaCareInformationResponse areaCareInformationResponse = null;
        AreaOfCareStaffDetails areaOfCareStaffDetailsResponse = null;

        JSONArray admitSources = null;
        JSONArray admitTypes = null;
        admitSources = commonRequests.getResponseFromURL("PatientCoverPage/AreaOfCare/PreOperative/admit_source.json");
        admitTypes = commonRequests.getResponseFromURL("PatientCoverPage/AreaOfCare/PreOperative/admit_type.json");

        CaseDetailInformation caseDetailInformation = patientRequests.getCaseDetailInformation(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());
        List<Module> modules = caseDetailInformation.getModules();
        module = modules.stream().filter(obj ->
                moduleName.contentEquals(obj.getModuleName())).findAny().orElse(null);
        transferModule = modules.stream().filter(obj ->
                transferModuleName.contentEquals(obj.getModuleName())).findAny().orElse(null);

        patientRequests.getCaseDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), module.getModuleId());

        dischargePatientRequests.getPrimaryPhysicianFromCase(caseSummaryInfo.getCaseSummaryId());
        commonRequests.getBusinssEntitySettings();
        patientRequests.getCurrentBEByPatientId(patient.getPatientId());
        commonRequests.getPatientRecord(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());
        commonRequests.getPatientRecordByCaseSummaryId(caseSummaryInfo.getCaseSummaryId());
        commonRequests.getCoverPageInformation(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());
        commonRequests.getPatientMonitorConfiguration();
        procedureDate = caseSummaryFromCaseSummaryId.getProcedureDt();
        // 1
        FormByName formByName = dischargePatientRequests.getFormByName(formName);
        int moduleId = module.getModuleId();
        FormUsageByFormOwner formUsageByFormOwner = dischargePatientRequests.getFormUsageByFormOwner(caseSummaryInfo.getCaseSummaryId(), moduleId, formByName.getFormId());

        formUsageByFormOwner.setLastUpdated(formLastUpdatedDate);
        formUsageByFormOwner.setStaffId(staff.getStaffId());
        formUsageByFormOwner.setStaffName(staff.getFullName());
        formUsageByFormOwner = dischargePatientRequests.updateFormUsageByFormOwner(formUsageByFormOwner);
        formUsageByFormOwner = dischargePatientRequests.getFormUsageByFormOwner(caseSummaryInfo.getCaseSummaryId(), moduleId, formByName.getFormId());

        caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryInfo.getCaseSummaryId());
        dischargePatientRequests.isModuleExistsForCase(caseSummaryInfo.getCaseSummaryId());
        areaOfCareStaffDetailsResponse = dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");
        dischargePatientRequests.getModulesByCaseId(caseSummaryFromCaseSummaryId.getCaseSummaryId(), Integer.valueOf(super.testContext().get("organizationId").toString()));

        caseSummaryFromCaseSummaryId = patientRequests.getCaseSummaryByCaseSummaryId(caseSummaryInfo.getCaseSummaryId());


        JSONObject requestLockObject = new JSONObject();
        requestLockObject.put("CaseSummaryId", String.valueOf(caseSummaryFromCaseSummaryId.getCaseSummaryId()));
        requestLockObject.put("RecordLockTypeId", 16);
        requestLockObject.put("ModuleId", moduleId);
        patientRequests.requestLock(requestLockObject);

        dischargePatientRequests.getSpecialtyByCase(caseSummaryFromCaseSummaryId.getCaseSummaryId());

        dischargePatientRequests.getAreaCareInformationByCase(patient.getPatientId(), caseSummaryFromCaseSummaryId.getCaseSummaryId(), 0);
        dischargePatientRequests.getAreaCareInformationByCase(patient.getPatientId(), caseSummaryFromCaseSummaryId.getCaseSummaryId(), module.getModuleId());
        dischargePatientRequests.getRoomsFromDictionary("Gemuser2_Room1");
        caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryInfo.getCaseSummaryId());


        dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "undefined");

        AreaOfCareStaffDetails saveAreaOfCareStaffDetailsResponse = new AreaOfCareStaffDetails();

        List<AreaofCareStaffEntryDetail> areaofCareStaffEntryDetailsList = new ArrayList<>();
        AreaofCareStaffEntryDetail areaofCareStaffEntryDetail = new AreaofCareStaffEntryDetail();
        areaofCareStaffEntryDetail.setStaffId(staff.getStaffId());
        areaofCareStaffEntryDetail.setStaffRoleId(staff.getRoleId());
        areaofCareStaffEntryDetail.setInTimeDt(formLastUpdatedDate);
        areaofCareStaffEntryDetailsList.add(areaofCareStaffEntryDetail);
        saveAreaOfCareStaffDetailsResponse.setAreaofCareStaffEntryDetails(areaofCareStaffEntryDetailsList);
        saveAreaOfCareStaffDetailsResponse.setIsUpdateAllTransferDt(true);
        saveAreaOfCareStaffDetailsResponse.setIsUpdateAllAdmissionDt(true);
        saveAreaOfCareStaffDetailsResponse.setCaseSummaryId(caseSummaryInfo.getCaseSummaryId());
        saveAreaOfCareStaffDetailsResponse.setModuleId(module.getModuleId());
        saveAreaOfCareStaffDetailsResponse.setIsCopyPreviousStaff(true);

        AreaCareInformationRequest areaCareInformationRequest = new AreaCareInformationRequest();
        areaCareInformationRequest.setCaseSummaryId(String.valueOf(caseSummaryInfo.getCaseSummaryId()));
        areaCareInformationRequest.setAdmittedById(staff.getStaffId());
        areaCareInformationRequest.setModuleId(moduleId);
        areaCareInformationRequest.setAdmissionTime(admissionTime);
        areaCareInformationRequest.setPatientId(String.valueOf(patient.getPatientId()));
        LOG.info("155 ------------------ " + admitTypes.getJSONObject(3).getString("value"));
        LOG.info("156 ------------------ " + admitSources.getJSONObject(4).getString("value"));

        JSONObject requestObject = null;
        try {
            requestObject = new JSONObject(mapper.writeValueAsString(areaCareInformationRequest));
            saveAreaOfCareStaffDetailsResponse = dischargePatientRequests.saveAreaOfCareStaffDetails(saveAreaOfCareStaffDetailsResponse);
            dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "undefined");
            areaCareInformationResponse = dischargePatientRequests.insertAreaCareInformation(requestObject);
            dischargePatientRequests.getSpecialtyByCase(caseSummaryFromCaseSummaryId.getCaseSummaryId());
            patientRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), String.valueOf(4));
            dischargePatientRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");
            PatientHandsOffData patientHandsOffData = dischargePatientRequests.getPatientHandsOffData(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId);
            patientHandsOffData = dischargePatientRequests.getPatientHandsOffData(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId);

            patientHandsOffData.setTransferTime(transferTime);
            patientHandsOffData.setTransferredById(null); // if recovery set this to null
            patientHandsOffData.setDischargeNormalTf(true);
            patientHandsOffData.setAbnormalDischargeCircumstance("");
            patientHandsOffData.setDischargedOnDt(transferTime);
            patientHandsOffData.setTransferTimeOFTime(transferTimeOfTime);
            patientHandsOffData.setTransferModuleId(null); // if recovery set this to null
            patientHandsOffData.setIsUpdated(false);
            patientHandsOffData.setTransferredByValue(staff.getFullName());
            patientHandsOffData.setTransferTimeWFTime(null); // if recovery set this to null
            patientHandsOffData.setCaseStatus(10); // if recovery set this to 10
            patientHandsOffData.setDefaultCaseStatusId(10); // if recovery set this to 10
            patientHandsOffData.setDischargeNormalTf(true);

            patientHandsOffData = dischargePatientRequests.insertPatientHandsOffData(patientHandsOffData);
            AreaOfCareStaffDetails sd = dischargePatientRequests.getAreaOfCareStaffEntry(caseSummaryFromCaseSummaryId.getCaseSummaryId(), module.getModuleId());
            LOG.info("");
            sd.getAreaofCareStaffEntryDetails().get(0).setInTimeDt(date + "T20:56:00+00:00");
            sd.getAreaofCareStaffEntryDetails().get(0).setOutTimeDt(date + "T21:56:00+00:00");
            sd.setPatientId(patient.getPatientId());
            sd.setIsCopyPreviousStaff(true);
            sd.setIsUpdateAllAdmissionDt(true);
            sd.setIsUpdateAllTransferDt(true);
            dischargePatientRequests.saveAreaOfCareStaffDetails(sd);
            dischargePatientRequests.insertPatientHandsOffData(patientHandsOffData);
            // https://sisenterpriseapi171051-gem-pr.azurewebsites.net/api/AreaOfCareStaffEntry/GetStaffFromPrevCaseAndRoom/46815?moduleId=1060












        /*
            caseSummaryInfo = commonRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());

            commonRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");
            caseSummaryInfo = commonRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
            areaOfCareStaffDetailsResponse = commonRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");
            saveAreaOfCareStaffDetails.setAreaofCareStaffId(areaOfCareStaffDetailsResponse.getAreaofCareStaffId());
            areaofCareStaffEntryDetail.setAreaOfCareStaffId(areaOfCareStaffDetailsResponse.getAreaofCareStaffId());

            areaofCareStaffEntryDetail.setAreaOfCareStaffEntryId(areaOfCareStaffDetailsResponse.getAreaofCareStaffEntryDetails().get(0).getAreaOfCareStaffEntryId());
            areaofCareStaffEntryDetail.setStaffId(staff.getStaffId());
            areaofCareStaffEntryDetail.setStaffRoleId(staff.getRoleId());
            areaofCareStaffEntryDetail.setInTimeDt(inTime);
            areaofCareStaffEntryDetail.setOutTimeDt(null);
            areaofCareStaffEntryDetail.setManuallyChanged(null);
            areaofCareStaffEntryDetail.setManuallyChangedInTime(false);
            areaofCareStaffEntryDetail.setManuallyChangedOutTime(false);
            areaofCareStaffEntryDetail.setStaffRoleName(staff.getRoleName());
            areaofCareStaffEntryDetail.setStaffName(staff.getFullName());
            areaofCareStaffEntryDetail.setPersonID(null);
            areaofCareStaffEntryDetail.setStaffFirstName(null);
            areaofCareStaffEntryDetail.setStaffLastName(null);
            areaofCareStaffEntryDetail.setStaffMiddleInitial(null);
            areaofCareStaffEntryDetail.setStaffTitle(null);
            areaOfCareStaffDetails.add(areaofCareStaffEntryDetail);
            saveAreaOfCareStaffDetailsResponse.setAreaofCareStaffEntryDetails(areaOfCareStaffDetails);

            commonRequests.saveAreaOfCareStaffDetails(saveAreaOfCareStaffDetailsResponse);

            commonRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), String.valueOf(4));
            commonRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "undefined");


            areaCareInformationRequest.setAreaOfCareInformationId(areaCareInformationResponse.getAreaOfCareInformationId());
            areaCareInformationRequest.setAdmitTypeValue(admitTypes.getJSONObject(5).getString("value"));
            areaCareInformationResponse = commonRequests.updateAreaCareInformation(new JSONObject(mapper.writeValueAsString(areaCareInformationRequest)));

            areaCareInformationRequest.setAdmitTypeValue(admitTypes.getJSONObject(5).getString("value"));
            areaCareInformationResponse = commonRequests.updateAreaCareInformation(new JSONObject(mapper.writeValueAsString(areaCareInformationRequest)));
            commonRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), String.valueOf(4));
            areaCareInformationRequest.setAdmitTypeValue(admitSources.getJSONObject(4).getString("value"));
            areaCareInformationResponse = commonRequests.updateAreaCareInformation(new JSONObject(mapper.writeValueAsString(areaCareInformationRequest)));

            commonRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "undefined");
            caseSummaryInfo = commonRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());

            commonRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), String.valueOf(4));
            caseSummaryInfo = commonRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        */


        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

       //  JSONObject insertAreaCareInformation = new JSONObject();




        // patientHandsOffData.setPatientHandoffId(0);


        /*
        patientHandsOffData = commonRequests.insertPatientHandsOffData(patientHandsOffData);

        commonRequests.getAreaOfCareStaffDetails(caseSummaryFromCaseSummaryId.getCaseSummaryId(), moduleId, "null");


     //   commonRequests.releaseLock(requestLockObject);
        commonRequests.requestLock(requestLockObject);

        patientHandsOffData.setCaseStatus(10);
        patientHandsOffData.setDefaultCaseStatusId(10);
        patientHandsOffData = commonRequests.insertPatientHandsOffData(patientHandsOffData);
     //   commonRequests.saveAreaOfCareStaffDetails(saveAreaOfCareStaffDetailsResponse);
        commonRequests.releaseLock(requestLockObject);


        caseSummaryInfo.setStatus(10);
        caseSummaryInfo.setStatusAtDischarge(10);
        caseSummaryInfo.setPreviousStatus(4);
        commonRequests.upsertCaseSummaryInfo(caseSummaryInfo);
        */

       // commonRequests.signDepartment(caseSummaryInfo.getCaseSummaryId(), moduleId);

    }
}
