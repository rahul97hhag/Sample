package com.bhavani.bdd.stepdefs.sample;

import com.aventstack.extentreports.reporter.configuration.ExtentHtmlReporterConfiguration;
import com.bhavani.bdd.practice2.ChargeEntryRequests;
import com.bhavani.bdd.practice2.CommonRequests;
import com.bhavani.bdd.practice2.PatientRequests;
import com.bhavani.bdd.practice4.InsuranceRequests;
import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.builder.RoomObjects;
import com.bhavani.models.anesthesiaType.AnesthesiaType;
import com.bhavani.models.appointmentType.AppointmentType;
import com.bhavani.models.configuration.business.insurance.InsuranceCarrierList;
import com.bhavani.models.patient.*;
import com.bhavani.models.patientCases.chargeEntry.ChargeEntry;
import com.bhavani.models.patientCases.newCaseSummary.CaseGuarantor;
import com.bhavani.models.patientCases.newCaseSummary.CaseProcedure;
import com.bhavani.models.patientCases.newCaseSummary.FeeScheduleItem;
import com.bhavani.models.room.ActiveRoom;
import com.bhavani.models.room.Room;
import com.bhavani.models.room.RoomType;
import com.bhavani.models.staff.Staff;
import cucumber.api.Scenario;
import cucumber.api.java.an.E;
import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 8/18/2020.
 */
public class SampleSteps extends AbstractSteps implements En {
    private static Logger LOG = LoggerFactory.getLogger(SampleSteps.class);
    private static CommonRequests commonRequests = new CommonRequests();
    private static PatientRequests patientRequests = new PatientRequests();
    private static ChargeEntryRequests chargeEntryRequests = new ChargeEntryRequests();
    private static InsuranceRequests insuranceRequests = new InsuranceRequests();

    // public SampleSteps(Scenario scenario) {  // Causing error
    public SampleSteps() {
        Given("I login to the application", (DataTable loginData) -> {
            // List<Map<String, String>> userCredentialsMap = loginData.transpose().asMaps();
            List<Map<String, String>> userCredentialsMap = loginData.asMaps();
            String username = userCredentialsMap.get(0).get("username");
            String password = userCredentialsMap.get(0).get("password");
            String businessEntity = userCredentialsMap.get(0).get("business_entity");
            LOG.info(userCredentialsMap.toString());
            LOG.info(username+ " "  + password + " " + businessEntity);

          //  Map<String, String> userCredentials = userCredentialsMap.get("0");
            // LOG.info();

            List<E> loginInformation = loginData.asList(String.class);
        //    Map<E, E> loginMap = loginData.asMap(String.class, String.class);
            LOG.info(loginData.toString());
          //  LOG.info(loginMap.toString());
           // LOG.info(loginInformation.toString());


        });


        Then("I should login to the application", (String successMessage) -> {
            LOG.info(" " + successMessage);
        });

        When("I create a room", (DataTable roomData) -> {
            List<Map<String, String>> roomCredentialsMap = roomData.asMaps();
            LOG.info(roomCredentialsMap.toString());
            String roomName = roomCredentialsMap.get(0).get("room_name");
            LOG.info(roomName);
            // scenario.write("52 ");
            ActiveRoom room = commonRequests.getRoomByName(roomName);
            if(!(room.getName().equalsIgnoreCase(roomName))) {
                // RoomType roomType = RoomObjects.getRoomType();
                // Room newRoom = RoomObjects.getRoom(roomName);

            }

        });

        Then("I should see new room created", (String successMessage) -> {
            LOG.info(successMessage);
        });

        When("I add a transaction code", (DataTable transactionCodeData) -> {
            List<Map<String, String>> transactionCodeDetailsMap = transactionCodeData.asMaps();
            LOG.info(transactionCodeDetailsMap.toString());
            String transactionCode = transactionCodeDetailsMap.get(0).get("transaction_code");
            String transactionType = transactionCodeDetailsMap.get(0).get("transaction_type");
            LOG.info(transactionCode + " " + transactionType);

        });

        Then("I should see new transaction code created", (String successMessage) -> {
            LOG.info(successMessage);
        });

        When("I create discounts", (DataTable discountData) -> {
            List<Map<String, String>> discountDataMap = discountData.asMaps();
            LOG.info(discountDataMap.toString());
            String discountName = discountDataMap.get(0).get("discount_name");
            String writeOffGroupCode = discountDataMap.get(0).get("write_off_group_code");
            String writeOffReasonCode = discountDataMap.get(0).get("write_off_reason_code");
            String transactionCodeName = discountDataMap.get(0).get("transaction_code_name");
            String discountPercent = discountDataMap.get(0).get("discount_percent");
            LOG.info(discountName + " "  + writeOffGroupCode + " " + writeOffReasonCode + " " + transactionCodeName + " " + discountPercent);

        });

        Then("I should see new discount created", (String successMessage) -> {
            LOG.info(successMessage);
        });

        When("I create a patient", (DataTable patientDetails) -> {
            List<Map<String, String>> patientDetailsMap = patientDetails.asMaps();
            LOG.info(patientDetailsMap.toString());
            String firstName = patientDetailsMap.get(0).get("first_name");
            String lastName = patientDetailsMap.get(0).get("last_name");
            String dateOfBirth = patientDetailsMap.get(0).get("date_of_birth");
            LOG.info(firstName + " " +lastName+ " " + dateOfBirth);
            List<String> patientInformation = patientDetails.asList(String.class);
//            Map<String, String> patientMap = patientDetails.asMap(String.class, String.class);
            LOG.info(patientDetails.toString());
        //    LOG.info(patientMap.toString());
            LOG.info(patientInformation.toString());

        });


        And("I add patient additional details", (DataTable patientAdditionalDetails) -> {
            List<Map<String, String>> patientAdditionalDetailsMap = patientAdditionalDetails.asMaps();
            LOG.info(patientAdditionalDetailsMap.toString());
            String title = patientAdditionalDetailsMap.get(0).get("title");
            String middleInitial = patientAdditionalDetailsMap.get(0).get("middle_initial");
            String nickName = patientAdditionalDetailsMap.get(0).get("nick_name");
            Long ssn = Long.valueOf(patientAdditionalDetailsMap.get(0).get("ssn").toString());
            String gender = patientAdditionalDetailsMap.get(0).get("gender");
            String occupation = patientAdditionalDetailsMap.get(0).get("occupation");
            String dateOfBirth = patientAdditionalDetailsMap.get(0).get("date_of_birth");
            String maritalStatus = patientAdditionalDetailsMap.get(0).get("marital_status");
            String religion = patientAdditionalDetailsMap.get(0).get("religion");
            String language = patientAdditionalDetailsMap.get(0).get("language");
            String race = patientAdditionalDetailsMap.get(0).get("race");
            String ethnicity = patientAdditionalDetailsMap.get(0).get("ethnicity");

            LOG.info(title + " " + middleInitial + " " + nickName + " " + ssn + " " + gender + " " + occupation + " " + dateOfBirth  );
            LOG.info(maritalStatus + " " + religion + " " +  language + " " + race + " " + ethnicity );

            Patient patient = new Patient();

        });

        And("I add patient address details", (DataTable patientAddressDetails) -> {
            List<Map<String, String>> patientAddressDetailsMap = patientAddressDetails.asMaps();
            String addressLine1 = patientAddressDetailsMap.get(0).get("address_line_1");
            String addressLine2 = patientAddressDetailsMap.get(0).get("address_line_2");
            String zip = patientAddressDetailsMap.get(0).get("zip");
            String extendedZip = patientAddressDetailsMap.get(0).get("extended_zip");
            String state = patientAddressDetailsMap.get(0).get("state");
            String city = patientAddressDetailsMap.get(0).get("city");
            String county = patientAddressDetailsMap.get(0).get("county");
            String country = patientAddressDetailsMap.get(0).get("country");
            LOG.info(addressLine1 + " " + addressLine2 + " " + zip + " " + extendedZip + " " + state + " " + city + " " + county +" " + country );
            Address address = new Address();


        });

        And("I add patient phone details", (DataTable patientPhoneDetails) -> {
            List<Map<String, String>> patientPhoneDetailsMap = patientPhoneDetails.asMaps();
            String phoneType = patientPhoneDetailsMap.get(0).get("phone_type");
            String primaryContact = patientPhoneDetailsMap.get(0).get("primary_contact");
            String phoneNumber = patientPhoneDetailsMap.get(0).get("phone_number");
            String phoneExtension = patientPhoneDetailsMap.get(0).get("phone_extension");
            String isCellPhone = patientPhoneDetailsMap.get(0).get("is_cell_phone");
            LOG.info( phoneType + " " + primaryContact + " " + phoneNumber + " " + phoneExtension +" " + isCellPhone );
            MpiPatientPhone patientPhone = new MpiPatientPhone();
        });

        And("I add patient emergency contact details", (DataTable patientEmergencyContactDetails) -> {
            List<Map<String, String>> patientEmergencyContactDetailsMap = patientEmergencyContactDetails.asMaps();
            String firstName = patientEmergencyContactDetailsMap.get(0).get("first_name");
            String lastName = patientEmergencyContactDetailsMap.get(0).get("last_name");
            LOG.info( firstName + " " + lastName );
            EmergencyContact emergencyContact = new EmergencyContact();
        });

        And("I add patient employer details", (DataTable patientEmployerDetails) -> {
            List<Map<String, String>> patientEmployerDetailsMap = patientEmployerDetails.asMaps();
            String phoneNumber = patientEmployerDetailsMap.get(0).get("phone_number");
            Employer employer = new Employer();
        });

        And("I add patient emmployer address details", (DataTable patientEmployerAddressDetails) -> {
            List<Map<String, String>> patientEmployerAddressDetailsMap = patientEmployerAddressDetails.asMaps();
            String country = patientEmployerAddressDetailsMap.get(0).get("country");

        });

        Then("I should see patient created successfully", (String successMessage) -> {
            LOG.info(" " + successMessage);
        });

        And("I create case details for the patient", (DataTable caseDetails) -> {
            List<Map<String, String>> caseDetailsMap = caseDetails.asMaps();
            LOG.info(caseDetailsMap.toString());
            String physician = caseDetailsMap.get(0).get("physician");
            String appointmentType = caseDetailsMap.get(0).get("appointment_type");
            String anesthesiaType = caseDetailsMap.get(0).get("anesthesia_type");
            Staff staff = new Staff();
            AppointmentType appointmentTypeObject = new AppointmentType();
            AnesthesiaType anesthesiaTypeObject = new AnesthesiaType();
            LOG.info(physician );
            LOG.info(appointmentType + " " + anesthesiaType + " " );
        });

        And("I add time details for the patient", (DataTable timeDetails) -> {
            List<Map<String, String>> timeDetailsMap = timeDetails.asMaps();
            String roomName = timeDetailsMap.get(0).get("room_name");
            String date = timeDetailsMap.get(0).get("date");
            String startTime = timeDetailsMap.get(0).get("start_time");
            String endTime = timeDetailsMap.get(0).get("end_time");
            LOG.info(roomName + " " + date + " " + startTime + " " + endTime);

        });

        And("I add billing details for the patient", () -> {

        });



        And("I add a guarantor for the patient", (DataTable guarantorDetails) -> {
            List<Map<String, String>> guarantorDetailsMap = guarantorDetails.asMaps();
            for(int i = 0; i < guarantorDetailsMap.size(); i++) {
                String guarantorFirstName = guarantorDetailsMap.get(i).get("guarantor_first_name");
                String guarantorLastName = guarantorDetailsMap.get(i).get("guarantor_last_name");
             //    LOG.info(guarantorDetailsMap.toString());
                LOG.info(guarantorFirstName + " " + guarantorLastName);
                CaseGuarantor caseGuarantor = new CaseGuarantor();
            }
        });

        And("I add guarantor address details", (DataTable guarantorAddressDetails) -> {
            List<Map<String, String>> guarantorAddressDetailsMap = guarantorAddressDetails.asMaps();
            // LOG.info(guarantorAddressDetailsMap.toString());
            for(int i = 0; i < guarantorAddressDetailsMap.size(); i++) {
                String addressLine1 = guarantorAddressDetailsMap.get(i).get("address_line_1");
                String addressLine2 = guarantorAddressDetailsMap.get(i).get("address_line_2");
                String city = guarantorAddressDetailsMap.get(i).get("city");
                LOG.info(addressLine1 + " " + addressLine2 + " " + city);
            }


        });

        And("I add guarantor additional details", (DataTable guarantorAdditionalDetails) -> {
            List<Map<String, String>> guarantorAdditionalDetailsMap = guarantorAdditionalDetails.asMaps();
            LOG.info(guarantorAdditionalDetailsMap.toString());
            for(int i = 0; i < guarantorAdditionalDetailsMap.size(); i++) {
                String gender = guarantorAdditionalDetailsMap.get(i).get("gender");
                LOG.info(gender );
            }

        });

        And("I add insurances to the patient", (DataTable insuranceDetails) -> {
            List<Map<String, String>> insuranceDetailsMap = insuranceDetails.asMaps();
            // LOG.info(insuranceDetailsMap.toString());
            for(int i = 0; i < insuranceDetailsMap.size(); i++) {
                String insuranceName = insuranceDetailsMap.get(i).get("insurance_name");
                String planName = insuranceDetailsMap.get(i).get("plan_name");
                LOG.info(insuranceName + " " + planName );
                InsuranceCarrierList insuranceCarrierList = new InsuranceCarrierList();
            }

        });

        And("I add insurance contact details for the patient", (DataTable insuranceContactDetails) -> {
            List<Map<String, String>> insuranceContactDetailsMap = insuranceContactDetails.asMaps();
            // LOG.info(insuranceContactDetailsMap.toString());
            for(int i = 0; i < insuranceContactDetailsMap.size(); i++) {
                String insuranceFirstName = insuranceContactDetailsMap.get(i).get("insurance_first_name");
                String insuranceLastName = insuranceContactDetailsMap.get(i).get("insurance_last_name");
                String relationShip = insuranceContactDetailsMap.get(i).get("relation_ship");
                String gender = insuranceContactDetailsMap.get(i).get("gender");
                LOG.info(insuranceFirstName + " " + insuranceLastName + " " + relationShip + " " + gender);
            }

        });

        And("I add insurance address details", (DataTable insuranceAddressDetails) -> {
            List<Map<String, String>> insuranceAddressDetailsMap = insuranceAddressDetails.asMaps();
            // LOG.info(insuranceAddressDetailsMap.toString());
            for(int i = 0; i < insuranceAddressDetailsMap.size(); i++) {
                String addressLine1 = insuranceAddressDetailsMap.get(i).get("address_line_1");
                String addressLine2 = insuranceAddressDetailsMap.get(i).get("address_line_2");
                String city = insuranceAddressDetailsMap.get(i).get("city");
                String state = insuranceAddressDetailsMap.get(i).get("state");
                String zip = insuranceAddressDetailsMap.get(i).get("zip");
                String extendedZip = insuranceAddressDetailsMap.get(i).get("extended_zip");
                LOG.info(addressLine1 + " " + addressLine2 + " " + city + " " + state + " " + zip + " " + extendedZip);
            }
        });

        And("I add insurance additional details", (DataTable insuranceAdditionalDetails) -> {
            List<Map<String, String>> insuranceAdditionalDetailsMap = insuranceAdditionalDetails.asMaps();
            // LOG.info(insuranceAdditionalDetailsMap.toString());
            for(int i = 0; i < insuranceAdditionalDetailsMap.size(); i++) {
                String displayName = insuranceAdditionalDetailsMap.get(i).get("display_name");
                String groupName = insuranceAdditionalDetailsMap.get(i).get("group_name");
                String groupType = insuranceAdditionalDetailsMap.get(i).get("group_type");
                String subscriber = insuranceAdditionalDetailsMap.get(i).get("subscriber");
                LOG.info(displayName + " " + groupName + " " + groupType + " " + subscriber);
            }
        });

        And("I add procedure", (DataTable procedureDetails) -> {
            List<Map<String, String>> procedureDetailsMap = procedureDetails.asMaps();
            for(int i = 0; i < procedureDetailsMap.size(); i++) {
                String cptCode = procedureDetailsMap.get(i).get("cpt_code");
                String physician = procedureDetailsMap.get(i).get("physician");
                String laterality = procedureDetailsMap.get(i).get("laterality");
                String diagnosisCode = procedureDetailsMap.get(i).get("diagnosis_code");
                LOG.info(cptCode + " " + physician + " " + laterality + " " + diagnosisCode);
                CaseProcedure caseProcedure = new CaseProcedure();
                FeeScheduleItem feeScheduleItem = new FeeScheduleItem();
            }
        });

        And("I add worklist to patient", (DataTable worklistDetails) -> {
            List<Map<String, String>> worklistDetailsMap = worklistDetails.asMaps();
            for(int i = 0; i < worklistDetailsMap.size(); i++) {

            }
        });

        And("I add implants to patient worklist", (DataTable implantDetails) -> {

        });

        And("I add op notes to patient", (DataTable opNotesDetails) -> {

        });

        And("I add preference card to patient", () -> {

        });

        And("I discharge the patient", (DataTable dischargeDetails) -> {
            List<Map<String, String>> dischargeDetailsMap = dischargeDetails.asMaps();
            for(int i = 0; i < dischargeDetailsMap.size(); i++) {
                String admissionTime = dischargeDetailsMap.get(i).get("admission_time");
                String transferTime = dischargeDetailsMap.get(i).get("transfer_time");
                String moduleName = dischargeDetailsMap.get(i).get("module_name");
                String transferModuleName = dischargeDetailsMap.get(i).get("transfer_module_name");
                String admitType = dischargeDetailsMap.get(i).get("admit_type");
                String admitSource = dischargeDetailsMap.get(i).get("admit_source");

                LOG.info(admissionTime+ " " + transferTime + " " + moduleName + " " + transferModuleName + " " + admitType + " " + admitSource);

            }

        });

        And("I transfer the patient", (DataTable transferDetails) -> {
            List<Map<String, String>> transferDetailsMap = transferDetails.asMaps();
            for(int i = 0; i < transferDetailsMap.size(); i++) {

            }
        });
        And("I should see patient discharged successfully", (String successMessage) -> {
            LOG.info(" " + successMessage);
        });

        And("I signed the departments", () -> {

        });



        When("I perform cases to code", (DataTable casesToCodeDetails) -> {
            List<Map<String, String>> casesToCodeDetailsMap = casesToCodeDetails.asMaps();
            for(int i = 0; i < casesToCodeDetailsMap.size(); i++) {
                String diagnosisCode = casesToCodeDetailsMap.get(i).get("diagnosis_code");
                String units = casesToCodeDetailsMap.get(i).get("units");
                LOG.info(diagnosisCode + " " + units);
            }
        });

        Then("I should see cases to code performed successfully", (String successMessage) -> {
            LOG.info(" " + successMessage);
        });

        When("I perform charge entry", (DataTable chargeEntryDetails) -> {
            List<Map<String, String>> chargeEntryDetailsMap = chargeEntryDetails.asMaps();
            for(int i = 0; i < chargeEntryDetailsMap.size(); i++) {
                String periodName = chargeEntryDetailsMap.get(i).get("period_name");
                String batchName = chargeEntryDetailsMap.get(i).get("batch_name");
                String amount = chargeEntryDetailsMap.get(i).get("amount");
                LOG.info(periodName + " " + batchName + " " + amount);
                ChargeEntry chargeEntry = new ChargeEntry();
            }
        });

        Then("I should see charge entry performed successfully", (String successMessage) -> {
            LOG.info(" " + successMessage);
        });

        When("I verify Insurance Billing Tracker", () -> {

        });

        Then("I should see insurances present in billing tracker", () -> {

        });

        When("I verify transactions", () -> {

        });

        Then("I should see transactions", () -> {

        });


    }
}

