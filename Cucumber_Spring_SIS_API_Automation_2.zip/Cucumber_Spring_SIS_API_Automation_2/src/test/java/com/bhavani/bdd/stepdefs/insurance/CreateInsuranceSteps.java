package com.bhavani.bdd.stepdefs.insurance;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class CreateInsuranceSteps {

    /*
    api/InsuranceCarrierObject/GetInsuranceCarriers
    api/InsuranceCarrierObject/SaveInsuranceCarrier
    api/Insurance/InsertInsuranceClaimOffice
    api/InsurancePlan/SaveInsurancePlan
    api/Insurance/UpdateInsuranceClaimOffice
     */
}