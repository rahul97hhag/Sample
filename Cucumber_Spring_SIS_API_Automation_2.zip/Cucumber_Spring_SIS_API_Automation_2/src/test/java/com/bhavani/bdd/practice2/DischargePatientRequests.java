package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.anesthesiaType.AnesthesiaType;
import com.bhavani.models.patientCases.dischargePatient.FormByName;
import com.bhavani.models.patientCases.dischargePatient.FormUsageByFormOwner;
import com.bhavani.models.patientCases.dischargePatient.AreaCareInformationResponse;
import com.bhavani.models.patientCases.dischargePatient.AreaOfCareStaffDetails;
import com.bhavani.models.patientCases.dischargePatient.PatientHandsOffData;
import com.bhavani.models.room.DictionaryRoom;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/29/2020.
 */
public class DischargePatientRequests extends AbstractSteps {
    private static Logger LOG = LoggerFactory.getLogger(DischargePatientRequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public DictionaryRoom getDictionaryRooms(List<String> departments, String roomName) {
        JSONArray jsonArray = new JSONArray();
        departments.forEach(department -> jsonArray.put(department));
        super.testContext().setPayload(jsonArray.toString());
        super.executePost("api/RoomDictionary/GetDictionaryRooms");
        Response roomsResponse = testContext().getResponse();
        try {
            List<DictionaryRoom> activeRooms = Arrays.asList(mapper.readValue(roomsResponse.asString(), DictionaryRoom[].class));
            DictionaryRoom room = activeRooms.stream().filter(obj ->
                    roomName.equalsIgnoreCase(obj.getItemName().toString())).findAny().orElse(null);
            return room;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void isModuleExistsForCase(int caseSummaryId) {
        super.executeGet("api/ModuleComplex/IsModuleExistsForCase/"+caseSummaryId+"/2050");
        Response roomsResponse = testContext().getResponse();
    }

    public AnesthesiaType getRoomsFromDictionary(String anesthesiaType) {
        super.executeGet("api/Dictionary/v2/8/All");
        Response anesthesiaTypesResponse = testContext().getResponse();
        try {
            List<AnesthesiaType> anesthesiaTypes = Arrays.asList(mapper.readValue(anesthesiaTypesResponse.asString(), AnesthesiaType[].class));
            AnesthesiaType anesthesiaTypeObject = anesthesiaTypes.stream().filter(obj ->
                    anesthesiaType.equalsIgnoreCase(obj.getValue())).findAny().orElse(null);
            return anesthesiaTypeObject;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void getPrimaryPhysicianFromCase(int caseSummaryId) {
        super.executeGet("api/Staff/GetPrimaryPhysicianFromCase?caseSummaryId=" + caseSummaryId);
        Response caseSummaryResponse = testContext().getResponse();
    }

    public FormByName getFormByName(String formName) {
        super.executeGet("api/RecordHeader/"+formName+"/GetFormbyName");
        Response formByNameResponse = testContext().getResponse();
        FormByName formByName = null;
        try {
            formByName = mapper.readValue(formByNameResponse.asString(), FormByName.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return formByName;
    }

    public FormUsageByFormOwner getFormUsageByFormOwner(int caseSummaryId, int moduleId, int formId) {
        JSONObject requestObject = new JSONObject();
        requestObject.put("caseSummaryId", String.valueOf(caseSummaryId));
        requestObject.put("moduleId", moduleId);
        requestObject.put("formId", formId);
        super.testContext().setPayload(requestObject.toString(4));
        super.executePost("api/FormUsage/GetFormUsagebyByFormOwner/");
        Response formUsageByFormOwnerResponse = testContext().getResponse();
        FormUsageByFormOwner formUsageByFormOwner = null;
        try {
            formUsageByFormOwner = mapper.readValue(formUsageByFormOwnerResponse.asString(), FormUsageByFormOwner.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return formUsageByFormOwner;
    }

    public FormUsageByFormOwner updateFormUsageByFormOwner(FormUsageByFormOwner formUsageByFormOwner) {
        Response formUsageByFormOwnerResponse = null;
        try {
            super.testContext().setPayload(mapper.writeValueAsString(formUsageByFormOwner));
            super.executePost("api/FormUsage/UpdateFormUsageByFormOwner");
            formUsageByFormOwnerResponse = testContext().getResponse();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        formUsageByFormOwner = null;
        boolean isResultValid = true;
        try {
            Boolean.valueOf(formUsageByFormOwnerResponse.asString().trim());
            isResultValid = false;
        } catch (Exception e) {
        }

        try {
            if(isResultValid) {
                formUsageByFormOwner = mapper.readValue(formUsageByFormOwnerResponse.asString(), FormUsageByFormOwner.class);
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return formUsageByFormOwner;
    }

    public void getAreaCareInformationByCase(int patientId, int caseSummaryId, int moduleId) {
        JSONObject requestObject = new JSONObject();
        requestObject.put("caseSummaryId", String.valueOf(caseSummaryId));
        requestObject.put("patientId", String.valueOf(patientId));
        if(moduleId != 0) {
            requestObject.put("moduleId", moduleId);
        }
        super.testContext().setPayload(requestObject.toString());
        super.executePost("api/AreaCareInformation/GetAreaCareInformationsbyCase");
        Response areaCareInformation = testContext().getResponse();
    }

    public void getModulesByCaseId(int caseSummaryId, int organizationId) {
        super.executeGet("api/Module/GetModulesBycaseId/"+ caseSummaryId+ "/undefined?organisationId=" + organizationId);
        Response modulesByCaseResponse = testContext().getResponse();
    }

    public void getModules() {
        super.executeGet("api/Module/GetModules/undefined");
        Response modulesByCaseResponse = testContext().getResponse();
    }

    public void getModulesAndFormsByCaseId(int caseSummaryId) {
        super.executeGet("api/ModuleComplex/GetModulesAndFormsByCaseId/"+caseSummaryId+"/undefined");
        Response modulesByCaseResponse = testContext().getResponse();
    }

    public AreaCareInformationResponse insertAreaCareInformation(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/AreaCareInformation/InsertAreaCareInformation");
        Response areaCareInformation = testContext().getResponse();
        AreaCareInformationResponse areaCareInformationResponse = null;
        try {
            areaCareInformationResponse = mapper.readValue(areaCareInformation.asString(), AreaCareInformationResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return areaCareInformationResponse;
    }

    public void getSpecialtyByCase(int caseSummaryId) {
        super.executeGet("api/CaseSummary/GetSpecialityByCase/" + caseSummaryId);
        Response specialtyByCase = testContext().getResponse();
    }

    public AreaOfCareStaffDetails saveAreaOfCareStaffDetails(AreaOfCareStaffDetails jsonObject) {
        AreaOfCareStaffDetails saveAreaOfCareStaffDetailsResponseObject = null;
        try {
            super.testContext().setPayload(mapper.writeValueAsString(jsonObject));
            super.executePost("api/AreaOfCareStaffEntry/SaveAreaOfCareStaffDetails");
            Response saveAreaOfCareStaffDetailsResponse = testContext().getResponse();
            try {
                saveAreaOfCareStaffDetailsResponseObject = mapper.readValue(saveAreaOfCareStaffDetailsResponse.asString(), AreaOfCareStaffDetails.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return saveAreaOfCareStaffDetailsResponseObject;
    }

    public AreaOfCareStaffDetails getAreaOfCareStaffDetails(int caseSummaryId, int moduleId, String staffId) {
        super.executeGet("api/AreaOfCareStaffEntry/GetAreaofCareStaffDetails/"+caseSummaryId+"?moduleId="+moduleId+"&staffId=" + staffId);
        Response caseStatusResponse = testContext().getResponse();
        AreaOfCareStaffDetails areaOfCareStaffDetailsResponse = null;
        try {
            areaOfCareStaffDetailsResponse = mapper.readValue(caseStatusResponse.asString(), AreaOfCareStaffDetails.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return areaOfCareStaffDetailsResponse;
    }

    public AreaCareInformationResponse updateAreaCareInformation(JSONObject jsonObject) {
        super.testContext().setPayload(jsonObject.toString());
        super.executePost("api/AreaCareInformation/UpdateAreaCareInformation");
        Response areaCareInformation = testContext().getResponse();
        AreaCareInformationResponse areaCareInformationResponse = null;
        try {
            areaCareInformationResponse = mapper.readValue(areaCareInformation.asString(), AreaCareInformationResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return areaCareInformationResponse;
    }

    public PatientHandsOffData getPatientHandsOffData(int caseSummaryId, int moduleId) {
        super.executeGet("api/patientHandOff/GetPatientHandsOffData?casesummaryId="+caseSummaryId+"&moduleId=" + moduleId);
        Response patientHandOffResponse = testContext().getResponse();
        PatientHandsOffData patientHandsOffData = null;
        try {
            patientHandsOffData = mapper.readValue(patientHandOffResponse.asString(), PatientHandsOffData.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patientHandsOffData;
    }

    public AreaOfCareStaffDetails getAreaOfCareStaffEntry(int caseSummaryId, int moduleId) {
        super.executeGet("api/AreaOfCareStaffEntry/GetStaffFromPrevCaseAndRoom/"+caseSummaryId+"?moduleId=" + moduleId);
        Response patientHandOffResponse = testContext().getResponse();
        AreaOfCareStaffDetails patientHandsOffData = null;
        try {
            patientHandsOffData = mapper.readValue(patientHandOffResponse.asString(), AreaOfCareStaffDetails.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patientHandsOffData;
    }

    public PatientHandsOffData insertPatientHandsOffData(PatientHandsOffData patientHandsOffData) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(patientHandsOffData));
            super.executePost("api/patientHandOff/InsertPatientHandOffData");
            Response patientHandsOffDataResponse = testContext().getResponse();
            patientHandsOffData = mapper.readValue(patientHandsOffDataResponse.asString(), PatientHandsOffData.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return patientHandsOffData;
    }

    public void signDepartment(int caseSummaryId, int moduleId) {
        super.testContext().setPayload("");
        super.executePut("api/BasicModuleInfoSignature/SignByCurrentUser/"+caseSummaryId+"/" + moduleId);
        Response upsertCaseSummaryInfoResponse = testContext().getResponse();
    }
}
