package com.bhavani.bdd.practice;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.commons.ChildOrganizations;
import com.bhavani.models.commons.MappedOrganizations;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;

public class LoginAndLogout extends AbstractSteps {

	 private static Logger LOG = LoggerFactory.getLogger(LoginAndLogout.class);
	 
	 public void createSession(String username, String password, String facility) throws JSONException, JsonProcessingException {
		 ObjectMapper mapper = new ObjectMapper();
	        testContext().reset();
	        // String organizationId = null;
	        JSONObject loginObject = new JSONObject();        
	        loginObject.put("UserName", username);
	        loginObject.put("Password", password);

	        super.testContext().setPayload(loginObject);
	        super.executePost("api/Login/LoginUser");
	        Response loginResponse = testContext().getResponse();
	        String token = loginResponse.asString();
	        token = token.replaceAll("\"", "");
	        LOG.info(token);
	        super.testContext().set("token", token);
	        
	        super.executeGet("api/User/UserOrgMap");
	        Response getUserOrgMapResponse = testContext().getResponse();


	        try {
	            MappedOrganizations mappedOrganizations = mapper.readValue(new JSONArray(getUserOrgMapResponse.asString()).getJSONObject(0).toString(), MappedOrganizations.class);
	            List<ChildOrganizations> childOrganizations = new ArrayList<ChildOrganizations>();
	            childOrganizations = mappedOrganizations.getChildOrgs();
	            for(int i = 0; i < childOrganizations.size(); i++) {
	                String organizationName = childOrganizations.get(i).getName().trim();
	                if(organizationName.equalsIgnoreCase(facility)) {
	                    int organizationId = childOrganizations.get(i).getOrganizationId();
	                    super.testContext().set("organizationId", organizationId);
	                    LOG.info(""+organizationId);
	                }
	            }

	        } catch (JsonProcessingException e) {
	            e.printStackTrace();
	        }

	        super.executePost("api/UserSession/UserSessionOrg/" + super.testContext().get("organizationId").toString());
	        Response mapUserResponse = super.testContext().getResponse();
	      //  LOG.info(mapUserResponse.asString());		 
	 }
	 
	 public void logout() {
		 super.executeGet("api/UserSession/logout");		 
	        Response logoutResponse = testContext().getResponse();
	        String token = logoutResponse.asString();
	        token = token.replaceAll("\"", "");
	        LOG.info(token);
	 }
	 
	 public static void main(String[] args) {
		 LoginAndLogout loginAndLogout = new LoginAndLogout();
		 try {
			loginAndLogout.createSession("Gem_user2", "Test#123", "Gem_Org002");
			loginAndLogout.logout();
			
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		 
	 }
}
