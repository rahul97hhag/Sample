package com.bhavani.bdd.practice3;

import com.bhavani.models.patientCases.ppePatient.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/22/2020.
 */
public class CreatePatientInPPE extends AbstractStepsForPPE {
    private static Logger LOG = LoggerFactory.getLogger(CreatePatientInPPE.class);
    @Test
    public void testOne() {
        String username = "Gem_user1";
        String password = "Test#123";
        String facility = "Gem_OrgInboundADTEnabled";
        PPERequests commonRequests = new PPERequests();
        ObjectMapper mapper = new ObjectMapper();

        String accountNumber = RandomStringUtils.randomNumeric(15);
        String randomString = RandomStringUtils.randomAlphabetic(5);
        String ssn = RandomStringUtils.randomNumeric(3)+"-"+RandomStringUtils.randomNumeric(2)+"-"+RandomStringUtils.randomNumeric(4);
        String mrn = RandomStringUtils.randomNumeric(9);
        String today = new SimpleDateFormat("MM/dd/yyyy").format(new Date());

        String primaryPhoneNumber = RandomStringUtils.randomNumeric(10);
        String secondaryPhoneNumber = RandomStringUtils.randomNumeric(10);

        String patientFirstName = "Test"+randomString+"Test";
        String patientLastName = "Test"+randomString+"Test";

        String roomName = "Org1Room_1";
        String appointmentNote = "Gem_General1";
        String primaryPhysicianNPI = "123456";

        commonRequests.createSession(username, password, facility);
        LOG.info(super.testContext().get("token").toString());

        PPEPatient ppePatient = new PPEPatient();
        Patient patient = new Patient();
        Address address = new Address();
        MpiPatientPhone primaryPhone = new MpiPatientPhone();
        MpiPatientPhone secondaryPhone = new MpiPatientPhone();
        List<CaseGuarantor> guarantors = new ArrayList<CaseGuarantor>();
        List<CaseInsurance> insurances = new ArrayList<CaseInsurance>();
        List<CaseProcedure> procedures = new ArrayList<CaseProcedure>();
        List<DiagnosisList> diagnosisLists = new ArrayList<DiagnosisList>();

        Case caseDetails = new Case();
        CaseGuarantor primaryGuarantor = new CaseGuarantor();
        CaseInsurance primaryInsurance = new CaseInsurance();
        CaseProcedure primaryProcedure = new CaseProcedure();
        DiagnosisList diagnosisItem = new DiagnosisList();

        patient.setExternalPatientId("22222222");
        patient.setAccountNumber(accountNumber);
        patient.setFirstName(patientFirstName);
        patient.setLastName(patientLastName);
        patient.setMiddleInitial("M");
        patient.setDateOfBirth("01/09/1987");
        patient.setGender("Female");
        patient.setEmail("sample@sample.com");
        patient.setMaritalStatus("Single");

        address.setLine1("string");
        address.setLine2("string");
        address.setState("string");
        address.setCity("string");
        address.setZip("string");

        patient.setSsn(ssn);

        primaryPhone.setPhoneNumber(primaryPhoneNumber);
        primaryPhone.setIsCellPhoneTf(true);

        secondaryPhone.setPhoneNumber(secondaryPhoneNumber);
        secondaryPhone.setIsCellPhoneTf(true);

        caseDetails.setDateOfService(today);
        caseDetails.setStartTime("01:00");
        caseDetails.setEndTime("02:00");
      //  caseDetails.setRoomName("string");
       // caseDetails.setAnesthesiaTypeName("string");
        caseDetails.setPrimaryPhysicianNPI(primaryPhysicianNPI);
        caseDetails.setReferringPhysicianNPI(primaryPhysicianNPI);

        primaryGuarantor.setIsSelf(true);
        primaryGuarantor.setFirstName(patientFirstName);
        primaryGuarantor.setLastName(patientLastName);
        primaryGuarantor.setDateOfBirth("08/01/1987");
        primaryGuarantor.setAddress1("string");
        primaryGuarantor.setAddress2("string");
        primaryGuarantor.setCity("string");
        primaryGuarantor.setState("string");
        primaryGuarantor.setZip("string");
        primaryGuarantor.setPatientRelationship("string");
        primaryGuarantor.setCountry("string");
        primaryGuarantor.setPhoneNumber(RandomStringUtils.randomNumeric(10));

        primaryInsurance.setDisplayName("Carrier1442_2");
        primaryInsurance.setRelationshipToInsured("Self");
        primaryInsurance.setGroupNumber("string");
        primaryInsurance.setGroupName("string");
        primaryInsurance.setCarrier("Carrier1442_2");
        primaryInsurance.setFirstName("string");
        primaryInsurance.setLastName("string");
        primaryInsurance.setPrimaryPhone(RandomStringUtils.randomNumeric(10));


        primaryProcedure.setCptCode("28192");
        primaryProcedure.setSelfPayTf(true);
        primaryProcedure.setPhysicianNPI(primaryPhysicianNPI);
        primaryProcedure.setLateralityText("Right");
        primaryProcedure.setModifiedProcedureDescription("string");

        diagnosisItem.setIcdCode("string");
        diagnosisItem.setIcdCodeDescription("Malignant melanoma");

        guarantors.add(primaryGuarantor);
        insurances.add(primaryInsurance);
        caseDetails.setCaseGuarantor(guarantors);
        caseDetails.setCaseInsurances(insurances);

        diagnosisLists.add(diagnosisItem);
        primaryProcedure.setDiagnosisList(diagnosisLists);
        procedures.add(primaryProcedure);
        patient.setMpiPatientPhone(primaryPhone);
        patient.setMpiPatientPhoneSecondary(secondaryPhone);
        patient.setAddress(address);
        caseDetails.setCaseProcedures(procedures);
        ppePatient.setExternalCaseRequestId("34567");
        ppePatient.setPatient(patient);
        ppePatient.setCase(caseDetails);


        try {
            Response response = null;
            super.testContext().setPayload(mapper.writeValueAsString(ppePatient));
            LOG.info(mapper.writeValueAsString(ppePatient));
            super.executePost("api/Gateway/CaseRequest/Encode");
             response = super.testContext().getResponse();
            org.json.JSONObject encodedPatient = new org.json.JSONObject(response.asString());
            encodedPatient.put("sourceIdentifier", "OTI5MkNCOEItMTBBRS00OTNFLTg2OEItM0JGRUFERTY3MDFC");
            org.json.JSONObject caseObject = encodedPatient.getJSONObject("case");
            org.json.JSONArray caseInsurancesList = caseObject.getJSONArray("caseInsurances");
            org.json.JSONArray caseGuarantorsList = caseObject.getJSONArray("caseGuarantor");
            caseGuarantorsList.getJSONObject(0).put("sortOrder", 0);
            caseInsurancesList.getJSONObject(0).put("sortOrder", 0);
            caseObject.put("caseInsurances", caseInsurancesList);
            caseObject.put("caseGuarantor", caseGuarantorsList);
            encodedPatient.put("case", caseObject);
            super.testContext().setPayload(encodedPatient.toString());
            super.executePost("api/Gateway/CaseRequest/New/Encoded");
            response = super.testContext().getResponse();
            LOG.info(response.asString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
      //  super.executePost("api/FormUsage/GetFormUsagebyByFormOwner/");

    }

}
