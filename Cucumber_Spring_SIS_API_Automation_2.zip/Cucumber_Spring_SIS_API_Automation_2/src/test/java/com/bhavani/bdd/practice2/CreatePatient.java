package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.builder.*;
import com.bhavani.models.appointmentType.AppointmentType;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.patientCases.newCaseSummary.CaseProcedure;
import com.bhavani.models.patientCases.newCaseSummary.CaseSummary;

import com.bhavani.models.patient.Address;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.room.ActiveRoom;
import com.bhavani.models.staff.Staff;
import com.bhavani.utils.DateUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/14/2020.
 */
public class CreatePatient extends AbstractSteps {

    private static Logger LOG = LoggerFactory.getLogger(CreatePatient.class);
    private static ObjectMapper mapper = new ObjectMapper();




    // @Test
    public void testOne() {

        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";

        String roomName = "Gemuser2_Room1";
        String appointmentTypeName = "Gem_General2";
        String cptCode = "22899";
        String physicianName = "Gem_user10";
        String preOpDiagnosisCode = "H44.001";

        String insuranceName = "Carrier1906_3";
        String randomString = RandomStringUtils.randomAlphabetic(6);
      //  String patientFirstName = "AAAAAAA" + randomString;
      //  String patientLastName = "AAAAAAA" + randomString;
        String patientFirstName = "AAAAAAAnDBilW";
        String patientLastName = "AAAAAAAnDBilW";

        String patientMiddleInitial = "M";
        String patientDateOfBirth = "11/11/1991";
        String patientGender = "Male";

        String date = DateUtilities.getInstance().addDate("today", "yyyy-MM-dd");
        String today = date + "T01:00:39.422Z";
        String country = "United States";
        String addressKind = "RESIDENTIAL";
        String startTime = "11:00";
        String endTime = "12:00";
        int duration = 60;
        String dateOfService = DateUtilities.getInstance().addDate("today", "MM/dd/yyyy");
        String procedureStartTime = date + "T"+startTime+":00.000Z";
        String procedureStopTime = date + "T"+endTime+":00.000Z";
        String procedureStartDt = date + "T"+startTime+":00.000Z";
        String procedureStopDt = date+ "T"+endTime+":00.000Z";

        CommonRequests commonRequests = new CommonRequests();
        PatientRequests patientRequests = new PatientRequests();

        commonRequests.createSession(username, password, facility);

        Patient patient = PatientObjects.buildPatientObject(patientFirstName, patientLastName, patientMiddleInitial, patientGender, patientDateOfBirth);
        try {
            super.testContext().setPayload(mapper.writeValueAsString(patient));
            super.executePost("api/PatientData/Gemini/CreatePatient/2030");
            Response createPatientResponse = testContext().getResponse();
            LOG.info(createPatientResponse.asString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        patient = patientRequests.getPatientFromFirstNameAndLastName(patientFirstName, patientLastName);

        AppointmentType appointmentType = commonRequests.getAppointmentType(appointmentTypeName);
        LOG.info(appointmentType.toString());
        Staff staff = commonRequests.getPhysicianDetails(physicianName);
        LOG.info(staff.toString());
        FeeSchedule feeSchedule = commonRequests.getFeeScheduleByCptCode(cptCode);
        LOG.info(feeSchedule.toString());

        ActiveRoom room = commonRequests.getRoomByName(roomName);
        LOG.info(room.toString());
        LOG.info(room.getName()+" "+ room.getRoomId() + " " + room.getOrganizationId());



        CaseSummary caseSummary = new CaseSummary();
        caseSummary.setCaseEquipments(new JSONArray());
        caseSummary.setToday(today);
        caseSummary.setCaseSummaryId(0);
        patient.setAddress(new Address());
        caseSummary.setPatient(patient);
        caseSummary.setPatientId(patient.getPatientId());
        caseSummary.getPatient().getAddress().setCountry(country);
        caseSummary.getPatient().getAddress().setPatientId(patient.getPatientId());
        caseSummary.getPatient().getAddress().setAddressKindName(addressKind);
        caseSummary.setCaseGuarantor(GuarantorObjects.getEmptyPatientGuarantors(patient));
        caseSummary.getPatient().setDateOfBirth("11/11/1991");
        caseSummary.setCaseInsurances(InsuranceObjects.getEmptyPatientInsurances());
        caseSummary.setCaseMSPInsuranceTypeMap(null);

        List<CaseProcedure> caseProcedures = new ArrayList<>();
        CaseProcedure caseProcedure = ProcedureObjects.buildCaseProcedure(cptCode, physicianName, staff, feeSchedule);
        caseProcedures.add(caseProcedure);
        caseSummary.setCaseProcedures(caseProcedures);

        caseSummary.setCasePreferenceCards(new JSONArray());
        caseSummary.setRoomId(room.getRoomId());
        caseSummary.setRoomName(room.getName());

        caseSummary.setProcedureStopDt(procedureStopDt);
        caseSummary.setProcedureStartDt(procedureStartDt);
        caseSummary.setProcedureStartTime(procedureStartTime);
        caseSummary.setProcedureStopTime(procedureStopTime);

        caseSummary.setStartTime(startTime);
        caseSummary.setEndTime(endTime);
        caseSummary.setDuration(duration);
        caseSummary.setAppointmentTypeId(appointmentType.getAppointmentTypeId());
        caseSummary.setAppointmentTypeName(appointmentType.getAppointmentTypeDesc());
        caseSummary.setCaseType(appointmentType.getCaseTypeAfterStartDate());
        caseSummary.setProcedureDt(procedureStartTime);
        caseSummary.setDateOfService(dateOfService);
        caseSummary.setAdditionalClaimInfo(CaseSummaryObjects.getAdditionalClaimInfo());
        caseSummary.setPrimaryPhysicianId(staff.getPersonId());

        ObjectMapper mapper = new ObjectMapper();
        String json = null;
        try {
            json = mapper.writeValueAsString(caseSummary);
            System.out.println(json);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        super.testContext().setPayload(json);
        super.executePost("api/CaseSummaryComplex/Gemini/UpsertCaseSummary");
        Response caseSummaryResponse = testContext().getResponse();
        LOG.info(caseSummaryResponse.asString());

          //   */




            // /

            // /api/PatientData/Gemini/GetPatient/ + patientId

            // api/Insurance/Gemini/GetPatientInsurancesByPatientId/+ patientId

            /*
            api/Security/RecordLock/RequestLock

            {
              "PatientId": 43370,
              "RecordLockTypeId": 13,
              "ObjectId": 43370,
              "ModuleId": 2030
            }
             */

            /*
            // UnreleasedFeatures/GetUnreleasedFeatures

            // api/Dictionary/v2/150/All  - language -- English
            // /api/Dictionary/v2/151/All -- Race
            // /api/Dictionary/v2/160/All -- Language

            // /api/Security/GetAllFeatureStates
            // api/FeeSchedule/GetFeeSchedules
                // api/FeeSchedule/GetFeeSchedules
         // api/StaffList/GetStaffForFacility
        // https://sisenterpriseapi164381-g.azurewebsites.net/

            https://sisenterpriseapi164381-g.azurewebsites.net/api/PatientGuarantor/GetPatientGuarantors/ + patientId
            sisenterpriseapi164381-g.azurewebsites.net/api/Insurance/Gemini/GetPatientInsurancesByPatientId/ + patientId


POST https://sisenterpriseapi164381-g.azurewebsites.net/api/PatientData/Gemini/CreatePatient/2030 HTTP/1.1

 */

        commonRequests.logout();

    }


    public static void main(String[] args) {
        CreatePatient createPatient = new CreatePatient();
        createPatient.testOne();
    }
}
