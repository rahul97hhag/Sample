package com.bhavani.bdd.practice4;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.models.configuration.business.insurance.*;
import com.bhavani.models.configuration.business.insurance.insuranceResponse.InsuranceClaimOfficeResponse;
import com.bhavani.models.configuration.business.insurance.insuranceResponse.SaveInsuranceCarrierResponse;
import com.bhavani.models.configuration.business.insurance.insuranceResponse.SaveInsurancePlanResponse;
import com.bhavani.models.patientCases.newCaseSummary.InsertInsuranceToPatientResponse;
import com.bhavani.models.patientCases.newCaseSummary.PatientInsurance;
import com.bhavani.templates.WebServiceRequestKeys;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/30/2020.
 */
public class InsuranceRequests extends AbstractSteps {
    private static Logger LOG = LoggerFactory.getLogger(InsuranceRequests.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public List<InsuranceContractList> getInsuranceContracts() {
        super.executeGet(super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("getInsuranceContractList").get(WebServiceRequestKeys.relUrl).toString());
        Response logoutResponse = testContext().getResponse();
        List<InsuranceContractList> insuranceContractListList = null;
        try {
            insuranceContractListList = Arrays.asList(mapper.readValue(logoutResponse.asString(), InsuranceContractList[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceContractListList;
    }

    public List<TransactionCodeListByType> getTranscationCodeListByType(int typeId) {
        List<TransactionCodeListByType> transactionCodeListByType = null;
        super.params.put("typeId", String.valueOf(typeId));
        super.executeGet(super.webserviceRequests.getJSONObject("TransactionCode").getJSONObject("getTransactionCodeListByType").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response logoutResponse = testContext().getResponse();
        try {
            transactionCodeListByType = Arrays.asList(mapper.readValue(logoutResponse.asString(), TransactionCodeListByType[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return transactionCodeListByType;
    }

    public List<TransactionCodeListByType> getTranscationCodeList() {
        List<TransactionCodeListByType> transactionCodeListByType = null;
        super.executeGet(super.webserviceRequests.getJSONObject("TransactionCode").getJSONObject("getTransactionCodeList").get(WebServiceRequestKeys.relUrl).toString());
        Response logoutResponse = testContext().getResponse();
        try {
            transactionCodeListByType = Arrays.asList(mapper.readValue(logoutResponse.asString(), TransactionCodeListByType[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return transactionCodeListByType;
    }

    public List<WriteOffGroup> getWriteOffGroupList() {
        List<WriteOffGroup> transactionCodeListByType = null;
        super.executeGet(super.webserviceRequests.getJSONObject("StaticList").getJSONObject("getWriteOffGroupList").get(WebServiceRequestKeys.relUrl).toString());
        Response logoutResponse = testContext().getResponse();
        try {
            transactionCodeListByType = Arrays.asList(mapper.readValue(logoutResponse.asString(), WriteOffGroup[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return transactionCodeListByType;
    }

    public List<WriteOffReason> getWriteOffReasonList() {
        List<WriteOffReason> transactionCodeListByType = null;
        super.executeGet(super.webserviceRequests.getJSONObject("StaticList").getJSONObject("getWriteOffReasonList").get(WebServiceRequestKeys.relUrl).toString());
        Response logoutResponse = testContext().getResponse();
        try {
            transactionCodeListByType = Arrays.asList(mapper.readValue(logoutResponse.asString(), WriteOffReason[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return transactionCodeListByType;
    }

    public InsuranceContractList saveInsuranceContract(InsuranceContractList insuranceContract) {
        super.getWebServiceRequests();
        try {
            super.testContext().setPayload(mapper.writeValueAsString(insuranceContract));
         //   LOG.info(super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("saveInsuranceContract").get(WebServiceRequestKeys.relUrl).toString());
            super.executePut(super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("saveInsuranceContract").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            try {
                insuranceContract = mapper.readValue(logoutResponse.asString(), InsuranceContractList.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceContract;
    }

    public InsuranceContractPostingOption saveInsuranceContractPosting(InsuranceContractPostingOption insuranceContract) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(insuranceContract));
            super.executePut(super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("saveInsuranceContractPostingOption").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            try {
                insuranceContract = mapper.readValue(logoutResponse.asString(), InsuranceContractPostingOption.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceContract;
    }

    public List<SourceOfRevenue> getSourceOfRevenue() {
        List<SourceOfRevenue> sourceOfRevenueList = null;
        try {
            super.executeGet(super.webserviceRequests.getJSONObject("SourceOfRevenue").getJSONObject("getSourceOfRevenueList").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            sourceOfRevenueList = Arrays.asList(mapper.readValue(logoutResponse.asString(), SourceOfRevenue[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return sourceOfRevenueList;
    }

    public List<InsuranceCarrierList> getInsuranceCarriers() {
        super.getWebServiceRequests();
        List<InsuranceCarrierList> insuranceCarrierList = null;
        try {
            super.executeGet(super.webserviceRequests.getJSONObject("InsuranceCarrierObject").getJSONObject("getInsuranceCarriers").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            insuranceCarrierList = Arrays.asList(mapper.readValue(logoutResponse.asString(), InsuranceCarrierList[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceCarrierList;
    }

    /*
    public InsuranceCarrierList getInsuranceCarriers(int insuranceCarrierId) {
        super.getWebServiceRequests();
        InsuranceCarrierList insuranceCarrierList = null;
        try {
            super.executeGet(super.webserviceRequests.getJSONObject("InsuranceCarrierObject").getJSONObject("getInsuranceCarriers").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            insuranceCarrierList = Arrays.asList(mapper.readValue(logoutResponse.asString(), InsuranceCarrierList[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceCarrierList;
    }
    */

    public SaveInsurancePlanResponse getInsurancePlans(JSONObject jsonObject) {
        List<SaveInsurancePlanResponse> insuranceCarrierList = null;
        super.testContext().setPayload(jsonObject.toString());
        try {
            super.executePost(super.webserviceRequests.getJSONObject("InsurancePlan").getJSONObject("getInsurancePlans").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            insuranceCarrierList = Arrays.asList(mapper.readValue(logoutResponse.asString(), SaveInsurancePlanResponse[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceCarrierList.get(0);
    }


    public SaveInsuranceCarrierResponse saveInsuranceCarrier(SaveInsuranceCarrier saveInsuranceCarrier) {
        SaveInsuranceCarrierResponse saveInsuranceCarrierResponse = null;
        try {
            super.testContext().setPayload(mapper.writeValueAsString(saveInsuranceCarrier));
            super.executePut(super.webserviceRequests.getJSONObject("InsuranceCarrierObject").getJSONObject("saveInsuranceCarrier").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            saveInsuranceCarrierResponse = mapper.readValue(logoutResponse.asString(), SaveInsuranceCarrierResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return saveInsuranceCarrierResponse;
    }

    public InsuranceClaimOfficeResponse insertInsuranceClaimOffice(InsuranceClaimOfficeResponse insuranceClaimOffice) {
        try {
            super.testContext().setPayload(mapper.writeValueAsString(insuranceClaimOffice));
            super.executePost(super.webserviceRequests.getJSONObject("Insurance").getJSONObject("insertInsuranceClaimOffice").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            insuranceClaimOffice = mapper.readValue(logoutResponse.asString(), InsuranceClaimOfficeResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceClaimOffice;
    }

    public InsuranceClaimOfficeResponse getInsuranceClaimOffice(int insuranceCarrierObjectId) {
        super.params.put("insuranceCarrierObjectId", String.valueOf(insuranceCarrierObjectId));
        InsuranceClaimOfficeResponse insuranceClaimOfficeResponse = null;
        try {
            super.executeGet(super.webserviceRequests.getJSONObject("Insurance").getJSONObject("getInsuranceClaimOfficeByInsuranceCarrierObjectId").get(WebServiceRequestKeys.relUrl).toString(), params);
            Response logoutResponse = testContext().getResponse();
            List<InsuranceClaimOfficeResponse> insuranceClaimOffice = Arrays.asList(mapper.readValue(logoutResponse.asString(), InsuranceClaimOfficeResponse[].class));
            insuranceClaimOfficeResponse = insuranceClaimOffice.get(0);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceClaimOfficeResponse;
    }

    public SaveInsurancePlanResponse saveInsurancePlan(SaveInsurancePlan saveInsurancePlan) {
        SaveInsurancePlanResponse insuranceClaimOfficeResponse = null;
        try {
            super.testContext().setPayload(mapper.writeValueAsString(saveInsurancePlan));
            super.executePut(super.webserviceRequests.getJSONObject("InsurancePlan").getJSONObject("saveInsurancePlan").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            insuranceClaimOfficeResponse = mapper.readValue(logoutResponse.asString(), SaveInsurancePlanResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insuranceClaimOfficeResponse;
    }

    public InsertInsuranceToPatientResponse insertInsuranceToPatient(PatientInsurance patientInsurance) {
        InsertInsuranceToPatientResponse insertInsuranceToPatientResponse = null;
        try {
            super.testContext().setPayload(mapper.writeValueAsString(patientInsurance));
            super.executePost(super.webserviceRequests.getJSONObject("Insurance").getJSONObject("insertInsuranceGemini").get(WebServiceRequestKeys.relUrl).toString());
            Response logoutResponse = testContext().getResponse();
            insertInsuranceToPatientResponse = mapper.readValue(logoutResponse.asString(), InsertInsuranceToPatientResponse.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insertInsuranceToPatientResponse;
    }

    public List<InsertInsuranceToPatientResponse> getPatientInsuranceByPatientId(int patientId) {
        super.params.put("patientId", String.valueOf(patientId));
        List<InsertInsuranceToPatientResponse> insertInsuranceToPatientResponse = null;
        try {
            super.executeGet(super.webserviceRequests.getJSONObject("Insurance").getJSONObject("getPatientInsurancesByPatientId").get(WebServiceRequestKeys.relUrl).toString(), params);
            Response logoutResponse = testContext().getResponse();
            insertInsuranceToPatientResponse = Arrays.asList(mapper.readValue(logoutResponse.asString(), InsertInsuranceToPatientResponse[].class));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return insertInsuranceToPatientResponse;
    }

    public JSONObject sendPayerEligibility(int patientId, int caseSummaryId) {
        super.testContext().setPayload("");
        super.params.put("caseSummaryId", String.valueOf(caseSummaryId));
        super.params.put("patientId", String.valueOf(patientId));
        super.params.put("eligibilityRequestLocation", String.valueOf(1));
        JSONObject payerEligibility = null;

        super.executePost(super.webserviceRequests.getJSONObject("Eligibility").getJSONObject("sendPayerEligibility").get(WebServiceRequestKeys.relUrl).toString(), params);
        Response logoutResponse = testContext().getResponse();
        payerEligibility = new JSONObject(logoutResponse.asString());
        return payerEligibility;
    }



    /*
    getInsuranceClaimOfficeByInsuranceCarrierObjectId
    super.webserviceRequests.getJSONObject("TransactionCode").getJSONObject("getDefaultPaymentTransactionCodeByResponsiblePartyId")
    super.webserviceRequests.getJSONObject("StaticList").getJSONObject("getTransactionTypes")



        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("copyInsuranceContract")
        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("getInsuranceContractPostingOption")
        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("saveInsuranceContract")

        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("deleteAllInsuranceContractOptions")
        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("getInsuranceContractReviews")
        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("getInsuranceContractReviewsFromFeeSchedule")
        super.webserviceRequests.getJSONObject("InsuranceContract").getJSONObject("saveInsuranceContractPostingOption")


        super.webserviceRequests.getJSONObject("SourceOfRevenue").getJSONObject("saveSourceOfRevenue")
        super.webserviceRequests.getJSONObject("SourceOfRevenue").getJSONObject("deleteSourceOfRevenue")
    */






}
