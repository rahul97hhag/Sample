package com.bhavani.bdd.practice;

import com.bhavani.utils.DateUtilities;

/**
 * Created by BhavaniPrasadReddy on 8/26/2020.
 */
public class Sample {

    public static void main(String[] args) {
        String x = null;
        x = "Today";
        System.out.println(DateUtilities.getInstance().addDate(x, "blank"));
        x = "Today+1";
        System.out.println(DateUtilities.getInstance().addDate(x, "blank"));
        x = "Today-1";
        System.out.println(DateUtilities.getInstance().addDate(x, "blank"));

    }
}
