package com.bhavani.bdd.practice2;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.builder.*;
import com.bhavani.models.appointmentType.AppointmentType;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.others.ZipCode;
import com.bhavani.models.patient.*;
import com.bhavani.models.patient.Address;
import com.bhavani.models.patient.EmergencyContact;
import com.bhavani.models.patientCases.newCaseSummary.CaseProcedure;
import com.bhavani.models.patientCases.newCaseSummary.CaseSummary;
import com.bhavani.models.room.ActiveRoom;
import com.bhavani.models.staff.Staff;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import org.apache.commons.lang3.RandomStringUtils;

import org.json.JSONObject;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/17/2020.
 */
public class CreatePatientAllDetails extends AbstractSteps {

    private static Logger LOG = LoggerFactory.getLogger(CreatePatientAllDetails.class);
    private static ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testOne() {

        String roomName = "Gemuser2_Room1";
        String appointmentTypeName = "Gem_General2";
        String cptCode = "22899";
        String physicianName = "Gem_user10";
        String preOpDiagnosisCode = "H44.001";

        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";

        String insuranceName = "Carrier1906_3";
        String randomString = RandomStringUtils.randomAlphabetic(6);
        String patientFirstName = "AAAAAAA" + randomString;
        String patientLastName = "AAAAAAA" + randomString;
        String patientMiddleInitial = "M";
        String patientDateOfBirth = "11/11/1991";
        String patientGender = "Male";

        String date = "2020-08-15";
        String today = date + "T21:10:39.422Z";
        String country = "United States";
        String addressKind = "RESIDENTIAL";
        String startTime = "11:00";
        String endTime = "12:00";
        int duration = 60;
        String dateOfService = "08/17/2020";
        String procedureStartTime = date + "T"+startTime+":00.000Z";
        String procedureStopTime = date + "T"+endTime+":00.000Z";
        String procedureStartDt = date + "T"+startTime+":00.000Z";
        String procedureStopDt = date+ "T"+endTime+":00.000Z";

        String zipCodeString = "12345";

        CommonRequests commonRequests = new CommonRequests();
        PatientRequests patientRequests = new PatientRequests();
        DischargePatientRequests dischargePatientRequests = new DischargePatientRequests();

        commonRequests.createSession(username, password, facility);

        Patient patient = null;

        patient = PatientObjects.buildPatientObject(patientFirstName, patientLastName, patientMiddleInitial, patientGender, patientDateOfBirth);
        patient = patientRequests.createPatient(patient);

        patient = patientRequests.getPatientFromFirstNameAndLastName(patientFirstName, patientLastName);

        JSONObject patientRecordLockObject = new JSONObject();
        patientRecordLockObject.put("PatientId", patient.getPatientId());
        patientRecordLockObject.put("RecordLockTypeId", 13);
        patientRecordLockObject.put("ObjectId", patient.getPatientId());
        patientRecordLockObject.put("ModuleId", 2030);

        patientRequests.requestLock(patientRecordLockObject);
        MpiPatientPhone primaryPhone = new MpiPatientPhone();
        MpiPatientPhone secondaryPhone = new MpiPatientPhone();
        Address address = new Address();
        EmergencyContact emergencyContact = new EmergencyContact();
        Employer employer = new Employer();

        primaryPhone.setPhoneId(0);
        primaryPhone.setPatientId(patient.getPatientId());
        primaryPhone.setPhoneType("Home");
        primaryPhone.setPrimaryContactTf(true);
        primaryPhone.setPhoneNumber("9999999999");
        primaryPhone.setPhoneExtension(null);
        primaryPhone.setIsCellPhoneTf(true);
        primaryPhone.setAdtMaintainedFieldArray(new ArrayList<>());

        secondaryPhone.setPhoneId(0);
        secondaryPhone.setPatientId(patient.getPatientId());
        secondaryPhone.setPhoneType("Secondary");
        secondaryPhone.setPrimaryContactTf(false);
        secondaryPhone.setPhoneNumber("8888888888");
        secondaryPhone.setPhoneExtension(null);
        secondaryPhone.setIsCellPhoneTf(false);
        secondaryPhone.setAdtMaintainedFieldArray(new ArrayList<>());

        patient.setMpiPatientPhone(primaryPhone);
        patient.setMpiPatientPhoneSecondary(secondaryPhone);

        ZipCode zipCode = commonRequests.getAddressFromZipCode(zipCodeString);

        address.setCountry(zipCode.getCountry());
        address.setLine1("Address Line One");
        address.setLine2("Address Line Two");
        address.setZip(zipCodeString + "1111");
        address.setState(zipCode.getState());
        address.setCity(zipCode.getCity());
        address.setCounty(zipCode.getCounty());

        patient.setAddress(address);

        emergencyContact.setFirstName("Emer FN");
        emergencyContact.setMiddleInitial("M");
        emergencyContact.setLastName("Emer LN");
        emergencyContact.setPhoneHome("2222222222");
        emergencyContact.setPhoneHomeExtension("");
        emergencyContact.setRelationship("Friend");

        patient.setEmergencyContact(emergencyContact);

        patient.setIsPatientExists(true);

        employer.setPatientId(patient.getPatientId());
        employer.setCountry("United States");
        employer.setEmployerName("Sample Employer Name");
        employer.setAddress("Address Employer");
        employer.setZip("12354-1111");
        employer.setState("AE");
        employer.setCity("City Employer");
        employer.setPhoneNumber(5555555555l);

        patientRequests.savePatientEmployer(employer);

        patient.setEmployer(employer);
        patient = patientRequests.createPatient(patient);

        patientRequests.releaseLock(patientRecordLockObject);

     //   /*
        AppointmentType appointmentType = commonRequests.getAppointmentType(appointmentTypeName);
        LOG.info(appointmentType.toString());
        Staff staff = commonRequests.getPhysicianDetails(physicianName);
        LOG.info(staff.toString());
        FeeSchedule feeSchedule = commonRequests.getFeeScheduleByCptCode(cptCode);
        LOG.info(feeSchedule.toString());

        ActiveRoom room = commonRequests.getRoomByName(roomName);
        LOG.info(room.toString());
        LOG.info(room.getName()+" "+ room.getRoomId() + " " + room.getOrganizationId());

        CaseSummary caseSummary = new CaseSummary();
        caseSummary.setCaseEquipments(new ArrayList<>());
        caseSummary.setToday(today);
        caseSummary.setCaseSummaryId(0);
        patient.setAddress(new Address());
        caseSummary.setPatient(patient);
        caseSummary.setPatientId(patient.getPatientId());
        caseSummary.getPatient().getAddress().setCountry(country);
        caseSummary.getPatient().getAddress().setPatientId(patient.getPatientId());
        caseSummary.getPatient().getAddress().setAddressKindName(addressKind);
        caseSummary.setCaseGuarantor(GuarantorObjects.getEmptyPatientGuarantors(patient));
        caseSummary.getPatient().setDateOfBirth("11/11/1991");
        caseSummary.setCaseInsurances(InsuranceObjects.getEmptyPatientInsurances());
        caseSummary.setCaseMSPInsuranceTypeMap(null);

        List<CaseProcedure> caseProcedures = new ArrayList<>();
        CaseProcedure caseProcedure = ProcedureObjects.buildCaseProcedure(cptCode, physicianName, staff, feeSchedule);
        caseProcedures.add(caseProcedure);
        caseSummary.setCaseProcedures(caseProcedures);

        caseSummary.setCasePreferenceCards(new JSONArray());
        caseSummary.setRoomId(room.getRoomId());
        caseSummary.setRoomName(room.getName());

        caseSummary.setProcedureStopDt(procedureStopDt);
        caseSummary.setProcedureStartDt(procedureStartDt);
        caseSummary.setProcedureStartTime(procedureStartTime);
        caseSummary.setProcedureStopTime(procedureStopTime);

        caseSummary.setStartTime(startTime);
        caseSummary.setEndTime(endTime);
        caseSummary.setDuration(duration);
        caseSummary.setAppointmentTypeId(appointmentType.getAppointmentTypeId());
        caseSummary.setAppointmentTypeName(appointmentType.getAppointmentTypeDesc());
        caseSummary.setCaseType(appointmentType.getCaseTypeAfterStartDate());
        caseSummary.setProcedureDt(procedureStartTime);
        caseSummary.setDateOfService(dateOfService);
        caseSummary.setAdditionalClaimInfo(CaseSummaryObjects.getAdditionalClaimInfo());
        caseSummary.setPrimaryPhysicianId(staff.getPersonId());

        ObjectMapper mapper = new ObjectMapper();
        String json = null;
        try {
            json = mapper.writeValueAsString(caseSummary);
            System.out.println(json);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        super.testContext().setPayload(json);
        super.executePost("api/CaseSummaryComplex/Gemini/UpsertCaseSummary");
        Response caseSummaryResponse = testContext().getResponse();
        LOG.info(caseSummaryResponse.asString());
     //   */
        commonRequests.logout();
    }
}
