package com.bhavani.bdd.practice4;

import com.bhavani.bdd.practice2.CommonRequests;
import com.bhavani.models.configuration.business.insurance.*;
import com.bhavani.models.configuration.business.insurance.insuranceResponse.InsuranceClaimOfficeResponse;
import com.bhavani.models.configuration.business.insurance.insuranceResponse.SaveInsuranceCarrierResponse;
import com.bhavani.models.configuration.business.insurance.insuranceResponse.SaveInsurancePlanResponse;
import com.bhavani.utils.DateUtilities;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/30/2020.
 */
public class CreateInsurance {
    private static Logger LOG = LoggerFactory.getLogger(CreateInsurance.class);
    private static ObjectMapper mapper = new ObjectMapper();

    public void createInsurance() {
        CommonRequests commonRequests = new CommonRequests();
        InsuranceRequests insuranceRequests = new InsuranceRequests();

        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";



        String insuranceContractName = "AAA123";
        String effectiveDate = DateUtilities.getInstance().getDate("Today-360", "yyyy-MM-dd")+"T18:30:00.000Z";
        String expirationDate = DateUtilities.getInstance().getDate("Today+360", "yyyy-MM-dd")+"T18:30:00.000Z";
        int percentageOfBillCharged = 30;
        String transactionCodeName = "TestwriteOff2244_2";
        String writeOffGroupCodeOption = "OA";
        String writeOffReasonOption = "Coinsurance Amount";

        int electronicClaim = 1;
        int paperForm = 1;
        String insuranceCarrierName = "AAAInsSe55";
        String planName = "BInsurance";
        String classification = "Champus";
        String primaryEmcPayerid = "1234";

        String line1 = RandomStringUtils.randomAlphabetic(6);
        String city = RandomStringUtils.randomAlphabetic(6);
        String state = "AS";
        String zip = "12345";
        String extendedZip = "1111";
        String name = "VBIT";
        String phone = RandomStringUtils.randomNumeric(10);
        String contactName = RandomStringUtils.randomAlphabetic(6);

        List<WriteOffGroup> writeOffGroupList = null;
        List<WriteOffReason> writeOffReasonList = null;
        WriteOffGroup writeOffGroup = null;
        WriteOffReason writeOffReason = null;

        commonRequests.createSession(username, password, facility);
       // /*
        InsuranceContractList insuranceContractList = new InsuranceContractList();
        insuranceContractList.setInsuranceContractName(insuranceContractName);
        insuranceContractList.setInsuranceContractId(0);

        insuranceContractList = insuranceRequests.saveInsuranceContract(insuranceContractList);
        insuranceContractList.setEffectiveDate(effectiveDate);
        insuranceContractList.setExpirationDate(expirationDate);
        insuranceContractList.setContractType(3);

        insuranceRequests.saveInsuranceContract(insuranceContractList);

        InsuranceContractPostingOption insuranceContractPostingOption = new InsuranceContractPostingOption();
        insuranceContractPostingOption.setPostingOption(1);
        insuranceContractPostingOption.setInsuranceContractId(insuranceContractList.getInsuranceContractId());
        insuranceContractPostingOption.setPercentOfBilledCharge(percentageOfBillCharged);
        insuranceContractPostingOption = insuranceRequests.saveInsuranceContractPosting(insuranceContractPostingOption);

        List<TransactionCodeListByType> transactionCodeListByTypeList = insuranceRequests.getTranscationCodeListByType(4);

        TransactionCodeListByType transactionCodeListByType = transactionCodeListByTypeList.stream().filter(obj ->
                transactionCodeName.contentEquals(obj.getTransactionCodeName())).findAny().orElse(null);

        writeOffGroupList = insuranceRequests.getWriteOffGroupList();
        writeOffReasonList = insuranceRequests.getWriteOffReasonList();

        writeOffGroup = writeOffGroupList.stream().filter(obj ->
                writeOffGroupCodeOption.contentEquals(obj.getWriteOffGroupCode())).findAny().orElse(null);

        writeOffReason = writeOffReasonList.stream().filter(obj ->
                writeOffReasonOption.contentEquals(obj.getDescription())).findAny().orElse(null);

        insuranceContractPostingOption.setTransactionCodeId(transactionCodeListByType.getTransactionCodeId());
        insuranceContractPostingOption.setWriteOffGroupId(writeOffGroup.getWriteOffGroupId());
        insuranceContractPostingOption.setWriteOffReasonId(writeOffReason.getWriteOffReasonId());

        insuranceContractPostingOption = insuranceRequests.saveInsuranceContractPosting(insuranceContractPostingOption);

        List<SourceOfRevenue> sourceOfRevenueList = insuranceRequests.getSourceOfRevenue();
      //  */

        List<InsuranceCarrierList> insuranceCarrierLists = insuranceRequests.getInsuranceCarriers();

        org.json.JSONArray states = null;
        states = commonRequests.getResponseFromURL("assets/static_data/states.json");
        LOG.info(states.toString(4));

        writeOffGroupList = insuranceRequests.getWriteOffGroupList();
        writeOffReasonList = insuranceRequests.getWriteOffReasonList();

        writeOffGroup = writeOffGroupList.stream().filter(obj ->
                writeOffGroupCodeOption.contentEquals(obj.getWriteOffGroupCode())).findAny().orElse(null);

        writeOffReason = writeOffReasonList.stream().filter(obj ->
                writeOffReasonOption.contentEquals(obj.getDescription())).findAny().orElse(null);

        List<InsuranceContractList> insuranceContractLists = insuranceRequests.getInsuranceContracts();

        SaveInsuranceCarrier saveInsuranceCarrier = new SaveInsuranceCarrier();
        InsurancePlanSaveDetails insurancePlanSaveDetails = new InsurancePlanSaveDetails();
        saveInsuranceCarrier.setElectronicClaim(electronicClaim);
        saveInsuranceCarrier.setPaperForm(paperForm);
        saveInsuranceCarrier.setInsuranceCarrierId(0);
        saveInsuranceCarrier.setInsuranceCarrierName(insuranceCarrierName);
        insurancePlanSaveDetails.setDefaultPlanTf(true);
        insurancePlanSaveDetails.setIsInsurancePlanValid(false);
        insurancePlanSaveDetails.setClaimOfficeId(null);
        insurancePlanSaveDetails.setPreviousPhoneValue("");
        insurancePlanSaveDetails.setPlanName(planName);
        insurancePlanSaveDetails.setPrimaryEmcPayerid(primaryEmcPayerid);
        insurancePlanSaveDetails.setClassification(classification);
        saveInsuranceCarrier.setInsurancePlanSaveDetails(insurancePlanSaveDetails);

        SaveInsuranceCarrierResponse saveInsuranceCarrierResponse = insuranceRequests.saveInsuranceCarrier(saveInsuranceCarrier);

        InsuranceClaimOfficeResponse insuranceClaimOffice = new InsuranceClaimOfficeResponse();
        insuranceClaimOffice.setLine1(line1);
        insuranceClaimOffice.setLine2(line1);
        insuranceClaimOffice.setCity(city);
        insuranceClaimOffice.setState(state);
        insuranceClaimOffice.setZip(zip);
        insuranceClaimOffice.setExtendedZip(extendedZip);
        insuranceClaimOffice.setName(name);
        insuranceClaimOffice.setPhone(phone);
        insuranceClaimOffice.setContactName(contactName);
        insuranceClaimOffice.setCountry("United States");
        insuranceClaimOffice.setCounty("Schendency");
        insuranceClaimOffice.setInsuranceCarrierObjectId(saveInsuranceCarrierResponse.getInsuranceCarrierId());

        insuranceClaimOffice = insuranceRequests.insertInsuranceClaimOffice(insuranceClaimOffice);
        insuranceClaimOffice = insuranceRequests.insertInsuranceClaimOffice(insuranceClaimOffice);

        SaveInsurancePlan saveInsurancePlan = new SaveInsurancePlan();
        saveInsurancePlan.setDefaultPlanTf(true);
        saveInsurancePlan.setIsInsurancePlanValid(true);
        saveInsurancePlan.setClaimOfficeId(insuranceClaimOffice.getClaimOfficeId());
        saveInsurancePlan.setPreviousPhoneValue("");
        saveInsurancePlan.setPlanName(planName);
        saveInsurancePlan.setPrimaryEmcPayerid(RandomStringUtils.randomNumeric(4));
        saveInsurancePlan.setClassification(classification);
        saveInsurancePlan.setInsuranceCarrierId(saveInsuranceCarrierResponse.getInsuranceCarrierId());
        saveInsurancePlan.setInsurancePlanId(saveInsuranceCarrierResponse.getInsurancePlanSaveDetails().getInsurancePlanId());
        saveInsurancePlan.setGenerateClaimTf(true);
        saveInsurancePlan.setPrimaryEmcPayerid(primaryEmcPayerid);
        saveInsurancePlan.setSelectedState(3);
        saveInsurancePlan.setClaimOfficeName(name);
        saveInsurancePlan.setAddress1(line1);
        saveInsurancePlan.setCity(city);
        saveInsurancePlan.setState(state);
        saveInsurancePlan.setZipCode(zip);
        saveInsurancePlan.setExtendedZipCode(extendedZip);
        saveInsurancePlan.setContactName(contactName);
        saveInsurancePlan.setPhoneNumber(phone);
        saveInsurancePlan.setInsurancePlanContractList(new ArrayList<>());

        SaveInsurancePlanResponse saveInsurancePlanResponse = insuranceRequests.saveInsurancePlan(saveInsurancePlan);
        saveInsurancePlanResponse = insuranceRequests.getInsurancePlans(new JSONObject().put("insuranceCarrierId", saveInsuranceCarrierResponse.getInsuranceCarrierId()));

        SaveInsurancePlan newSaveInsurancePlan = new SaveInsurancePlan();
        newSaveInsurancePlan.setDefaultPlanTf(true);
        newSaveInsurancePlan.setIsInsurancePlanValid(true);
        newSaveInsurancePlan.setClaimOfficeId(insuranceClaimOffice.getClaimOfficeId());
        newSaveInsurancePlan.setPreviousPhoneValue("");
        newSaveInsurancePlan.setPlanName(planName);
        newSaveInsurancePlan.setPrimaryEmcPayerid(primaryEmcPayerid);
        newSaveInsurancePlan.setClassification(classification);
        newSaveInsurancePlan.setInsuranceCarrierId(saveInsuranceCarrierResponse.getInsuranceCarrierId());
        newSaveInsurancePlan.setInsurancePlanId(saveInsurancePlanResponse.getInsurancePlanId());
        newSaveInsurancePlan.setGenerateClaimTf(true);
        newSaveInsurancePlan.setSelectedState(3);
        newSaveInsurancePlan.setClaimOfficeName(name);
        newSaveInsurancePlan.setAddress1(line1);
        newSaveInsurancePlan.setCity(city);
        newSaveInsurancePlan.setState(state);
        newSaveInsurancePlan.setZipCode(zip);
        newSaveInsurancePlan.setExtendedZipCode(extendedZip);
        newSaveInsurancePlan.setContactName(contactName);
        newSaveInsurancePlan.setPhoneNumber(phone);
        newSaveInsurancePlan.setIsPlanExist(false);
        newSaveInsurancePlan.setSelectedContracts(new ArrayList<>());
        newSaveInsurancePlan.setInsurancePlanContractList(new ArrayList<>());

        insuranceRequests.saveInsurancePlan(newSaveInsurancePlan);

    }

    public static void main(String[] args) {
        CreateInsurance createInsurance = new CreateInsurance();
        createInsurance.createInsurance();
    }
}
