package com.bhavani.bdd.practice;

import com.github.dzieciou.testing.curl.Options;
import com.github.dzieciou.testing.curl.Platform;
import io.restassured.config.RestAssuredConfig;
import com.github.dzieciou.testing.curl.CurlLoggingRestAssuredConfigFactory;



import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.options;

/**
 * Created by BhavaniPrasadReddy on 8/8/2020.
 */
public class GenerateLogs {

    public static void main(String[] args) {



        // /*
        try {
            Options options = Options.builder().printMultiliner().targetPlatform(Platform.WINDOWS).build();
            RestAssuredConfig config = CurlLoggingRestAssuredConfigFactory.createConfig(options);
            given()
                    .config(config)
                    .redirects().follow(false)
                    .when()
                    .log()
                    .all()
                    // .outputCurl()
                    .get("http://google.com")
                    .then()
                    .statusCode(301);

        } catch (Exception e) {
            e.printStackTrace();
        }
        // */
    }
}
