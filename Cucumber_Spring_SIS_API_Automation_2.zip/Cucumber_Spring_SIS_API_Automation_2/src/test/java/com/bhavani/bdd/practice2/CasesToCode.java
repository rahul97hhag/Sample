package com.bhavani.bdd.practice2;

import com.bhavani.models.patientCases.caseSummary.*;
import com.bhavani.models.patientCases.casesToCode.*;
import com.bhavani.models.patientCases.casesToCode.DictionaryItem;
import com.bhavani.models.patientCases.casesToCodeResponse.CasesToCodeResponse;
import com.bhavani.models.patientCases.chargeEntry.*;
import com.bhavani.models.patientCases.chargeEntryResponse.ChargeEntryResponse;
import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.icdCodes.IcdCodes;
import com.bhavani.models.patient.Patient;
import com.bhavani.models.scheduledProcedures.ScheduledProcedures;
import com.bhavani.models.staff.Staff;
import com.bhavani.utils.DateUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/16/2020.
 */
public class CasesToCode {

    private static Logger LOG = LoggerFactory.getLogger(CasesToCode.class);
    private static ObjectMapper mapper = new ObjectMapper();

    @Test
    public void performCasesToCode() {

        String username = "Gem_user2";
        String password = "Test#123";
        String facility = "Gem_Org002";

        String roomName = "Gemuser2_Room1";
        String appointmentTypeName = "Gem_General2";
        String cptCode = "22899";
        String physicianName = "Gem_user10";
        String preOpDiagnosisCode = "H44.001";

        String insuranceName = "Carrier1906_3";
        String patientFirstName = "AAAAAAAjXvvkp";
        String patientLastName = "AAAAAAAjXvvkp";
        String patientMiddleInitial = "M";
        String patientDateOfBirth = "11/11/1991";
        String patientGender = "Male";

        String date = DateUtilities.getInstance().addDate("today", "yyyy-MM-dd");
        String today = date + "T01:00:39.422Z";
        String country = "United States";
        String addressKind = "RESIDENTIAL";
        String startTime = "11:00";
        String endTime = "12:00";
        int duration = 60;
        String dateOfService = DateUtilities.getInstance().addDate("today", "MM/dd/yyyy");
        String procedureStartTime = date + "T"+startTime+":00.000Z";
        String procedureStopTime = date + "T"+endTime+":00.000Z";
        String procedureStartDt = date + "T"+startTime+":00.000Z";
        String procedureStopDt = date+ "T"+endTime+":00.000Z";

        String procedureDate = null;
        String formName = "Patient Panel";
        String formLastUpdatedDate = date + "T02:00:00.000Z";

        String inTime = date + "T11:20:00.000Z";
        String outTime = date + "T11:30:00.000Z";

        String transferTime = date + "T07:00:00+05:30";
        String transferTimeOfTime = DateUtilities.getInstance().addDate("today", "MM-dd-yyyy") + " 07:20";
        String transferTimeWfTime = DateUtilities.getInstance().addDate("today", "MM-dd-yyyy") + " 03:30";

        String admissionTime = date+ "T06:30:00+05:30";

        String moduleName = "Recovery";
        String transferModuleName = "Recovery";
        Module module = null;
        Module transferModule = null;

        String zipCodeString = "12345";

        String icdCode = "H44.001";
        String periodName = "A_2018";
        String batchName = "batch_10";
        int amount = 2000;
        int units = 1;

        CommonRequests commonRequests = new CommonRequests();
        PatientRequests patientRequests = new PatientRequests();
        CasesToCodeRequests casesToCodeRequests = new CasesToCodeRequests();
        ChargeEntryRequests chargeEntryRequests = new ChargeEntryRequests();

        commonRequests.createSession(username, password, facility);
        Patient patient = patientRequests.getPatientFromFirstNameAndLastName(patientFirstName, patientLastName);
        Staff staff = commonRequests.getPhysicianDetails(username);

        CaseSummaryFromPatientId caseSummaryFromPatientId = patientRequests.getCaseSummaryByPatientId(patient.getPatientId());
        CaseSummaryFromCaseSummaryId caseSummaryFromCaseSummaryId = patientRequests.getCaseSummaryByCaseSummaryId(caseSummaryFromPatientId.getCaseSummaryId());
        CaseSummaryInfo caseSummaryInfo = patientRequests.getCaseSummaryInfo(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        CaseInformation caseInformation = patientRequests.getCaseInformation(caseSummaryFromCaseSummaryId.getCaseSummaryId());

        CaseDetailInformation caseDetailInformation = patientRequests.getCaseDetailInformation(patient.getPatientId(), caseSummaryInfo.getCaseSummaryId());

        List<ScheduledProcedures> scheduledProcedures = casesToCodeRequests.getScheduledProcedures(caseSummaryInfo.getCaseSummaryId());
        IcdCodes icdCodes = commonRequests.getICDCodes(icdCode);

        PerformedProcedures performedProcedures = new PerformedProcedures();

        DiagnosisList diagnosisList = new DiagnosisList();
        DictionaryItem dictionaryItem = new DictionaryItem();
        dictionaryItem.setOnlyClinical(true);
        dictionaryItem.setId(icdCodes.getIcdCodeId());
        dictionaryItem.setQuickCode(icdCodes.getIcdCode());
        dictionaryItem.setValue(icdCodes.getIcdCodeDescription());
        diagnosisList.setDictionaryItem(dictionaryItem);
        diagnosisList.setDiagnosisId(icdCodes.getIcdCodeId());
        diagnosisList.setSortOrder(0);
        List<DiagnosisList> diagnosisListObject = new ArrayList<>();
        diagnosisListObject.add(diagnosisList);

        performedProcedures.setDeletedPerformedItems(new ArrayList<Object>());
        PerformedItem performedItem = new PerformedItem();
        FeeSchedule feeSchedule = commonRequests.getFeeScheduleByCptCode(cptCode);
        feeSchedule.setCptProcedure(null);
        performedItem.setFeeScheduleItem(feeSchedule);
        performedItem.setUnableToCode(false);
        performedItem.setPanelCollapsed(false);
        performedItem.setPrimaryInsurancesList(new ArrayList<Object>());
        performedItem.setSecondaryInsurancesList(new ArrayList<Object>());
        performedItem.setTertiaryInsurancesList(new ArrayList<Object>());
        performedItem.setControlsModifiedInEditChargeMode(true);
        performedItem.setFullChargeCorrectionRequired(false);
        performedItem.setGenerateBillStateModified(false);
        PerformedCaseSupply performedCaseSupply = new PerformedCaseSupply();
        performedItem.setPerformedCaseSupply(performedCaseSupply);
        performedItem.setSelectedSupplyToInventory(null);
        performedItem.setIsReadOnlyPeriodBatch(false);
        performedItem.setResetClosedPeriodBatch(false);
        performedItem.setIsNewProcedureAdded(false);
        performedItem.setIsAmountChanged(false);
        performedItem.setInsuranceModification(0);
        performedItem.setGuarantorModification(0);
        performedItem.setIsGCode(false);
        performedItem.setIsCombinedCodingChargeEntry(false);
        performedItem.setIsCorrected(false);
        performedItem.setUnits(1);
        performedItem.setPerformedCaseItemTypeId(0);
        performedItem.setSortorder(0);
        performedItem.setHovered(false);
        performedItem.setDiagnosisList(diagnosisListObject);

        performedItem.setCaseSummaryId(caseSummaryFromCaseSummaryId.getCaseSummaryId());
        performedItem.setCaseProcedureId(scheduledProcedures.get(0).getCaseProcedureId());
        performedItem.setCptProcedureId(scheduledProcedures.get(0).getCptProcedureId());
        performedItem.setCptCode(scheduledProcedures.get(0).getCptCode());
        performedItem.setCptProcedureDescription(scheduledProcedures.get(0).getCptDescription());
        performedItem.setProviderId(scheduledProcedures.get(0).getPhysicianId());
        performedItem.setPhysicianName(scheduledProcedures.get(0).getPhysicianName());
        performedItem.setFeeScheduleId(scheduledProcedures.get(0).getFeeScheduleId());
        performedItem.setGenerateBill(scheduledProcedures.get(0).getGenerateBill());

        List<PerformedItem> performedItemList = new ArrayList<>();
        performedItemList.add(performedItem);
        performedProcedures.setPerformedItems(performedItemList);

        CasesToCodeResponse casesToCodeResponse = casesToCodeRequests.performCasesToCode(performedProcedures);

        patientRequests.updateCaseStatus(caseSummaryFromCaseSummaryId.getCaseSummaryId(), "11");
        caseSummaryInfo.setStatus(11);
        caseSummaryInfo.setPreviousStatus(10);
        caseSummaryInfo.setStatusAtDischarge(10);
        patientRequests.upsertCaseSummaryInfo(caseSummaryInfo);

        JSONArray chargeEntryRequestBody = new JSONArray();
        Period period = commonRequests.getPeriodByPeriodName(periodName);
        List<Batch> batches = period.getBatches();
        List<Batch> newBatches = new ArrayList<>();

       // LOG.info(period.toString());
       // LOG.info(batch.toString());
        List<com.bhavani.models.patientCases.casesToCodeResponse.PerformedItem> performedItemsList = casesToCodeResponse.getPerformedItems();
        List<ChargeEntry> chargeEntryList = new ArrayList<>();

        for(int i = 0; i < batches.size(); i++) {
            Batch batchObject = batches.get(i);
            batchObject.setValue(batchObject.getBatchId());
            batchObject.setLabel(batchObject.getBatchDescription());
            newBatches.add(batchObject);
        }

        Batch newBatch = newBatches.stream().filter(obj ->
                batchName.contentEquals(obj.getBatchDescription())).findAny().orElse(null);
     //   /*
        for(int i = 0; i < performedItemsList.size(); i++) {
          com.bhavani.models.patientCases.casesToCodeResponse.PerformedItem performedItemObject = performedItemsList.get(i);
          ChargeEntry chargeEntryObject = new ChargeEntry();
          TransactionList transactionList = new TransactionList();
          List<TransactionList> transactionLists = new ArrayList<TransactionList>();
          ChargeDetails chargeDetails = new ChargeDetails();
          ChargeTransaction chargeTransaction = new ChargeTransaction();

          chargeEntryObject.setCptProcedureId(performedItemObject.getCptProcedureId());
          chargeEntryObject.setPatientId(performedItemObject.getPatientId());
          chargeEntryObject.setCaseProcedureId(performedItemObject.getCaseProcedureId());
          chargeEntryObject.setCptCode(performedItemObject.getCptCode());
          chargeEntryObject.setPhysicianName(performedItemObject.getPhysicianName());
          chargeEntryObject.setPerformedCaseProcedureId(performedItemObject.getPerformedCaseProcedureId());
          LOG.info("198 ---------------- " + performedItemObject.getPerformedCaseProcedureId());
          chargeEntryObject.setIsReadOnlyPeriodBatch(false);
          chargeEntryObject.setPanelCollapsed(false);
          chargeEntryObject.setAppointmentId(0);
         // chargeEntryObject.setPerformedCaseProcedureId(0);
          chargeEntryObject.setIsGCode(false);
          chargeEntryObject.setIsCorrected(false);
          chargeEntryObject.setEventSource("DoneBtn");
          chargeEntryObject.setUnableToCode(false);

          DebitTransaction debitTransaction = new DebitTransaction();
          debitTransaction.setIsHidden(false);
          debitTransaction.setIsDeleted(false);
          debitTransaction.setAmount(0);
          debitTransaction.setLastModifiedAmount(0);
          debitTransaction.setTransactionTypeId(6);


          chargeEntryObject.setDebitTransaction(debitTransaction);
          chargeEntryObject.setIsCorrected(false);
          chargeEntryObject.setChargeTransactionIndex(0);
          chargeEntryObject.setIsCaseProcedureSelfPay(true);
          chargeEntryObject.setIsCombinedCodingChargeEntry(false);



          chargeDetails.setPeformedCaseProcedureId(performedItemObject.getPerformedCaseProcedureId());
          chargeDetails.setBalance(amount);
          chargeDetails.setActualBalance(null);
          chargeDetails.setSourceOfRevenueId(null);
          chargeDetails.setTransactionId(0);
          chargeDetails.setSelfPay(true);
          chargeDetails.setRevenueCodeId(248);
          chargeDetails.setRevenueCode(null);
          chargeDetails.setDeductibleAmount(null);
          chargeDetails.setCoInsuranceAmount(null);
          chargeDetails.setCoPaymentAmount(null);
          chargeDetails.setBillId(null);
          chargeDetails.setGenerateBill(false);

          chargeDetails.setPatientResponsibilityCoPayments(null);
          chargeDetails.setWorkersCompensation(false);
          chargeDetails.setTypeOfBill("0831");
          chargeDetails.setChargeEntryLevelTransactionsAmount(0);
          chargeDetails.setGenerateBillStateModified(false);
          chargeDetails.setCorrected(false);



          chargeEntryObject.setUnits(units);
          chargeEntryObject.setSortorder(i);
          chargeEntryObject.setIsNewProcedureAdded(false);
          chargeEntryObject.setFeeScheduleItem(performedItemObject.getFeeScheduleItem());
          chargeEntryObject.setCptProcedureDescription(performedItemObject.getCptProcedureDescription());
          chargeEntryObject.setCaseSummaryId(performedItemObject.getCaseSummaryId());
          chargeEntryObject.setProviderId(performedItemObject.getProviderId());
          chargeEntryObject.setFeeScheduleId(performedItemObject.getFeeScheduleId());

          for(int j = 0; j < performedItemObject.getDiagnosisList().size(); j++) {
              performedItemObject.getDiagnosisList().get(j).getDictionaryItem().setOnlyClinical(false);
          }

          chargeEntryObject.setDiagnosisList(performedItemObject.getDiagnosisList());
          chargeEntryObject.setChargeAutoCorrected(false);
          chargeEntryObject.setGenerateBill(true);
          chargeEntryObject.setResetClosedPeriodBatch(false);
          chargeEntryObject.setWorkersCompensation(false);
          chargeEntryObject.setGuarantorModification(0);
          chargeEntryObject.setDiagnosisCodesRemoved(false);
          chargeEntryObject.setSelfPay(true);
          chargeEntryObject.setIsAmountChanged(false);
          chargeEntryObject.setGenerateBillStateModified(false);
          chargeEntryObject.setInsuranceModification(0);
          chargeEntryObject.setPrimaryInsuranceId(null);
          chargeEntryObject.setSecondaryInsuranceId(null);
          chargeEntryObject.setTertiaryInsuranceId(null);
          chargeEntryObject.setPerformedCaseItemTypeId(0);
          chargeEntryObject.setControlsModifiedInEditChargeMode(true);


          PeriodBatch periodBatch = new PeriodBatch();
          periodBatch.setIsActive(true);
          periodBatch.setPeriodId(0);
        //  periodBatch.setPeriodName(period.getPeriodName());
          periodBatch.setPeriodName(null);
          chargeEntryObject.setPeriodBatch(periodBatch);


          chargeTransaction.setPeriod(period);
          chargeTransaction.setBatch(newBatch);
          chargeTransaction.setBatchId(newBatch.getBatchId());
          chargeTransaction.setTransactionId(0);
          chargeTransaction.setTransactionResponsiblePartyId(null);
          chargeTransaction.setBatchDescription(newBatch.getBatchDescription());
          chargeTransaction.setIsHidden(false);
          chargeTransaction.setCreatorId(0);
          chargeTransaction.setIsEditable(null);
          chargeTransaction.setCreatedUserId(0);
          chargeTransaction.setTransactionParentId(0);
          chargeTransaction.setIsDeleted(false);
          chargeTransaction.setAmount(amount);
          chargeTransaction.setTransactionRootId(0);
          chargeTransaction.setPeriodId(period.getPeriodId());
          chargeTransaction.setTransactionTypeId(1);
          // chargeTransaction.setBatchIsActive(newBatch.getIsActive());
            chargeTransaction.setBatchIsActive(false);
          chargeTransaction.setIsPaymentTransfer(false);
          chargeTransaction.setCreatedDate("0001-01-01T00:00:00+00:00");


          chargeEntryObject.setBatch(newBatch);

          transactionList.setBatch(newBatch);
          transactionList.setPeriod(period);
          transactionList.getPeriod().setBatches(newBatches);
          transactionList.setPeriodId(period.getPeriodId());
          transactionList.setBatchId(newBatch.getBatchId());
          transactionList.setTransactionId(0);
          transactionList.setTransactionRootId(0);
          transactionList.setAmount(amount);
          transactionList.setBatchDescription(newBatch.getBatchDescription());
          transactionList.setTransactionParentId(0);
          transactionList.setCreatedUserId(0);
          transactionList.setIsDeleted(false);
          transactionList.setCreatorId(0);
          transactionList.setIsPaymentTransfer(false);
          transactionList.setTransactionTypeId(1);
          // transactionList.setBatchIsActive(newBatch.getIsActive());
            transactionList.setBatchIsActive(false);
          transactionList.setWriteOffDetails(null);
          transactionList.setPaymentDetails(null);
          transactionList.setCreatedDate("0001-01-01T00:00:00+00:00");
          transactionList.setPostedDate(null);
          transactionList.setTransactionDate(null);
          transactionList.setTransactionCodeId(null);
          transactionList.setTransactionResponsiblePartyId(null);
          transactionList.setCurrentResponsiblePartyId(null);
          transactionList.setCurrentResponsiblePartyType(null);
          transactionList.setTransactionResponsiblePartyName(null);
          transactionList.setIsHidden(false);
          transactionList.setTransactionCodeName(null);
          transactionList.setReceivedFrom(null);
          transactionList.setIsEditable(null);
          transactionList.setLastModifiedAmount(null);
          transactionList.setContractProcedureId(null);
          transactionList.setCreatorId(0);
          transactionList.setCheckInPaymentId(null);
          transactionList.setBatchCloserUserId(null);
          transactionList.setPeriodCloserUserId(null);
          transactionList.setPeriodName(null);
          transactionList.setTransferTo(null);
          transactionList.setImpactedTransactions(null);
          transactionList.setChargeDetails(chargeDetails);


          transactionLists.add(transactionList);
          chargeEntryObject.setTransactionList(transactionLists);
          chargeTransaction.setChargeDetails(chargeDetails);
          chargeEntryObject.setChargeTransaction(chargeTransaction);

          chargeEntryList.add(chargeEntryObject);
        }
      //  */
        /*
        try {
            String chargeEntryJson = mapper.writeValueAsString(chargeEntryList);
            LOG.info(chargeEntryJson);

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        */


        List<ChargeEntryResponse> chargeEntryResponse = chargeEntryRequests.performChargeEntry(chargeEntryList);
        String chargeEntryResponseJson = null;
        try {
            chargeEntryResponseJson = mapper.writeValueAsString(chargeEntryResponse);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        LOG.info(chargeEntryResponseJson);







        /*
        /api/ScheduledCaseProcedure/GetScheduledProcedures/46699/false

/api/CasesToCodeTracker/GetNextCase/46699/dateOfSurgery/
/api/ScheduledCaseProcedure/GetScheduledProcedures/46699/false

 /api/ScheduledCaseProcedure/GetImplantsSupplyByCaseId/46699/false

/api/CaseToCodeComplex/GetPerformProcedures/46699
 /api/User/PersonsByRoles
[
  "Surgeon",
  "Physician",
  "Physician Assistant"
]


/api/CaseToCode/SavePerformedItems

UpdatedCaseStatus - 11


api/PerformedCaseProcedure/GetTotalBalanceDueByCaseSummaryId/46699
api/TransactionCode/GetTransactionCodeListByType/6
api/TransactionCode/GetTransactionCodeListByType/4
/api/SourceOfRevenue/GetSourceOfRevenueList

api/Modifiers/GetModifiers

/api/RevenueCode/GetRevenueCodeList/0/0

/api/StaticList/GetWriteOffGroupList
/api/StaticList/GetWriteOffReasonList


/api/Insurance/PatientInsurances/46699
/api/PeriodBatch/GetPeriodBatch/false


/api/CaseToChargeComplex/GetPerformProcedures/46699/true

api/Insurance/Gemini/GetPatientInsurancesByPatientId/48604
/api/InsuranceContractEvaluation/EvaluateDiscount

/api/CaseToCharge/SavePerformedProcedure/










         */


















    }
}
