package com.bhavani.utils;

import com.google.common.base.CharMatcher;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by BhavaniPrasadReddy on 8/23/2020.
 */
public class DateUtilities {
    private static final DateUtilities dateUtilities = new DateUtilities();

    private DateUtilities(){}

    public static DateUtilities getInstance(){
        return dateUtilities;
    }

    public String getTodaysDate() {
        return null;
    }

    public String currentYear() {
        return null;
    }

    public String getCurrentMonthAsString() {
        return null;
    }

    public String getCurrentMonthAsNumber() {
        return null;
    }

    public String addDaysToCurrentDate() {
        return null;
    }

    public String getCurrentTimeInHHMM() {
        return null;
    }

    public String getDate(String format) {
        try {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
            String date = simpleDateFormat.format(calendar.getTime());
            return date;
        } catch (Exception e) {
            return null;
        }
    }

    public String getDate(String value, String format) {
        try {
            String date = addDate(value, format);
            return date;
        } catch (Exception e) {
            return null;
        }
    }

    public String addDate(String value, String format) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = null;
        if(format.equalsIgnoreCase("blank")) {
            simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        } else {
            simpleDateFormat = new SimpleDateFormat(format);
        }

        String date = null;
        int days = 0;

        if(value.trim().equalsIgnoreCase("today")) {
            date = simpleDateFormat.format(calendar.getTime());
            return date;
        }
        if(value.trim().contains("+")) {
            days = Integer.valueOf(CharMatcher.digit().retainFrom(value));
            date = simpleDateFormat.format(calendar.getTime());
            calendar.add(Calendar.DATE, days);
            date = simpleDateFormat.format(calendar.getTime());
            return date;
        }
        if(value.trim().contains("-")) {
            days = Integer.valueOf(CharMatcher.digit().retainFrom(value));
            date = simpleDateFormat.format(calendar.getTime());
            calendar.add(Calendar.DATE, -days);
            date = simpleDateFormat.format(calendar.getTime());
            return date;
        }
        return date;
    }






}
