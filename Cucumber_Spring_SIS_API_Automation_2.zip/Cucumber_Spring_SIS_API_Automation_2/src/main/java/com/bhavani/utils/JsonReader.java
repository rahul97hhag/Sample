package com.bhavani.utils;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import java.io.*;

/**
 * Created by BhavaniPrasadReddy on 8/30/2020.
 */
public class JsonReader {

    private static final JsonReader jsonReader = new JsonReader();

    private JsonReader(){}

    public static JsonReader getInstance(){
        return jsonReader;
    }

    public JSONObject loadJSONObjectFromFile(String path) {
        JSONObject jsonObject = null;
        File file = new File(path);
        if(file.exists()) {
            try {
                InputStream inputStream = new FileInputStream(file);
                String jsonText = IOUtils.toString(inputStream, "UTF-8");
                jsonObject = new JSONObject(jsonText);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonObject;
    }
}
