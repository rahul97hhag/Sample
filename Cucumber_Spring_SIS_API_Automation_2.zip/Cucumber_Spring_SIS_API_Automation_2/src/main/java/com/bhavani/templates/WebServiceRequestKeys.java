package com.bhavani.templates;

/**
 * Created by BhavaniPrasadReddy on 8/30/2020.
 */
public interface WebServiceRequestKeys {
    public static final String comments = "comments";
    public static final String method = "method";
    public static final String requestBody = "requestBody";
    public static final String inputs = "inputs";
    public static final String response = "response";
    public static final String methodName = "methodName";
    public static final String description = "description";
    public static final String section = "section";
    public static final String model = "model";
    public static final String relUrl = "relUrl";
    public static final String successStatus = "successStatus";
}
