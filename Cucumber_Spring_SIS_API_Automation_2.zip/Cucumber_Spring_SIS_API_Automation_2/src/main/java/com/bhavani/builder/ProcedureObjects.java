package com.bhavani.builder;

import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.bhavani.models.patientCases.newCaseSummary.CaseProcedure;
import com.bhavani.models.patientCases.newCaseSummary.FeeScheduleItem;
import com.bhavani.models.staff.Staff;

import java.util.ArrayList;

/**
 * Created by BhavaniPrasadReddy on 8/15/2020.
 */
public class ProcedureObjects {

    public static CaseProcedure buildCaseProcedure(String cptCode, String physicianName, Staff staff, FeeSchedule feeSchedule) {


        CaseProcedure caseProcedure = new CaseProcedure();
        FeeScheduleItem feeScheduleItem = new FeeScheduleItem();

        feeScheduleItem.setCptProcedure(feeSchedule.getCptProcedure());
        feeScheduleItem.setActiveTf(feeSchedule.getActiveTf());
        // feeScheduleItem.setAmount(Integer.valueOf(String.valueOf(Math.floor(feeSchedule.getAmount()))));
        feeScheduleItem.setAmount(2000); // ----------
        feeScheduleItem.setCptProcedureId(feeSchedule.getCptProcedureId());
        feeScheduleItem.setEffectiveDate(feeSchedule.getEffectiveDate());
        feeScheduleItem.setFeeScheduleHistoryId(feeSchedule.getFeeScheduleHistoryId());
        feeScheduleItem.setFeeScheduleId(feeSchedule.getFeeScheduleHistoryId());
        feeScheduleItem.setFeeScheduleRootId(feeSchedule.getFeeScheduleRootId());
        feeScheduleItem.setIsIncludeStateReportTf(feeSchedule.getIsIncludeStateReportTf());
        feeScheduleItem.setModifiedProcedureDescription(feeSchedule.getModifiedProcedureDescription().toString());
        feeScheduleItem.setOrganizationId(feeSchedule.getOrganizationId());
        feeScheduleItem.setProcedure(feeSchedule.getProcedure());
        feeScheduleItem.setProcedureDisplayName(feeSchedule.getModifiedProcedureDescription().toString());
        feeScheduleItem.setSourceIdentifier(feeSchedule.getSourceIdentifier());
        feeScheduleItem.setStatus(feeSchedule.getStatus());

        caseProcedure.setPhysicianId(staff.getPersonId());
        caseProcedure.setPhysician(staff.getFullName());
        caseProcedure.setPreOpDiagnosisCodeId(null);
        caseProcedure.setPreOpDiagnosisCode(null);
        caseProcedure.setProcedureId(null);
        caseProcedure.setProcedureDescription(feeSchedule.getCptProcedure().getCptDescription());
        caseProcedure.setPrimaryProcedureTf(false);
        caseProcedure.setAppointmentId(null);
        caseProcedure.setProcedureSequence(null);
        caseProcedure.setPreferenceCardId(null);
        caseProcedure.setFeeScheduleId(feeSchedule.getFeeScheduleId());
        caseProcedure.setProcedureDisplayName(feeSchedule.getModifiedProcedureDescription().toString());
        caseProcedure.setIsEditable(true);
        caseProcedure.setSelfPayTf(true);
        caseProcedure.setWorkersCompensation(null);
        caseProcedure.setAnesTypeName(null);
        caseProcedure.setCasePackName(null);
        caseProcedure.setDummyCPTId(-10);
        caseProcedure.setModifiedProcedureDescription(feeSchedule.getModifiedProcedureDescription().toString());
        caseProcedure.setIsDisplayTrashIcon(true);
        caseProcedure.setDiagnosisList(new ArrayList<>());
        caseProcedure.setCptCode(cptCode);
        caseProcedure.setFeeScheduleList(new ArrayList<>());
        caseProcedure.setFeeScheduleItem(feeScheduleItem);

        return caseProcedure;
    }
}
