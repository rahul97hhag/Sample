package com.bhavani.builder;

import com.bhavani.models.patientCases.newCaseSummary.CaseInsurance;
import com.bhavani.models.patientCases.newCaseSummary.InsertInsuranceToPatientResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 7/26/2020.
 */
public class InsuranceObjects {

    public static List<CaseInsurance> getEmptyPatientInsurances() {
        List<CaseInsurance> caseInsurances = new ArrayList<>();
        InsertInsuranceToPatientResponse patientInsurance = new InsertInsuranceToPatientResponse();

        CaseInsurance primaryCaseInsurance = new CaseInsurance();
        primaryCaseInsurance.setSortOrder(0);
        primaryCaseInsurance.setPatientInsurance(patientInsurance);

        CaseInsurance secondaryCaseInsurance = new CaseInsurance();
        secondaryCaseInsurance.setSortOrder(1);
        secondaryCaseInsurance.setPatientInsurance(patientInsurance);

        CaseInsurance tertiaryCaseInsurance = new CaseInsurance();
        tertiaryCaseInsurance.setSortOrder(2);
        tertiaryCaseInsurance.setPatientInsurance(patientInsurance);

        caseInsurances.add(primaryCaseInsurance);
        caseInsurances.add(secondaryCaseInsurance);
        caseInsurances.add(tertiaryCaseInsurance);
        return caseInsurances;
    }

}