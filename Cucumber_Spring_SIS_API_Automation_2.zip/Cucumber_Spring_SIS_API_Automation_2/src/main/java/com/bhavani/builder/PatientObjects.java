package com.bhavani.builder;

import com.bhavani.models.others.ZipCode;
import com.bhavani.models.patient.Address;
import com.bhavani.models.patient.MpiPatientAge;
import com.bhavani.models.patient.MpiPatientPhone;
import com.bhavani.models.patient.Patient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;

/**
 * Created by BhavaniPrasadReddy on 7/26/2020.
 */
public class PatientObjects {

    public static Patient buildPatientObject(String firstName, String lastName, String middleInitial, String gender, String dateOfBirth) {
        Patient patient = new Patient();
        patient.setPatientId(0);
        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setMiddleInitial(middleInitial);
        patient.setTitle(null);
        patient.setDateOfBirth(dateOfBirth);
        patient.setGender(gender);
        patient.setAdtLockedFieldList(null);
        patient.setAdtMaintainedFieldArray(null);
        patient.setIsLockExists(false);
        patient.setMpiPatientPhone(null);
        patient.setMpiPatientPhoneSecondary(null);
        patient.setPatientImage(null);
        patient.setAddress(null);
        patient.setEmergencyContact(null);
        patient.setIsPatientExists(false);
        patient.setFullName(firstName+" " + lastName );
        patient.setFullNameWithTitle(firstName+" " + lastName);
        patient.setProcedureDt("0001-01-01T00:00:00+00:00");
        patient.setPrimaryProcedure(null);
        patient.setMpiPatientAge(new MpiPatientAge());
        patient.getMpiPatientAge().setDays(3);
        patient.getMpiPatientAge().setMonths(3);
        patient.getMpiPatientAge().setYears(28);
        return patient;
    }

    public static MpiPatientPhone getPatientPhone(int patientId, String phoneType, String phoneNumber, boolean isCell, boolean isPrimaryPhone) {
        MpiPatientPhone patientPhone = new MpiPatientPhone();
        patientPhone.setPhoneId(0);
        patientPhone.setPatientId(patientId);
        patientPhone.setPhoneType(phoneType);
        patientPhone.setPrimaryContactTf(isPrimaryPhone);
        patientPhone.setPhoneNumber(phoneNumber);
        patientPhone.setPhoneExtension(null);
        patientPhone.setIsCellPhoneTf(isCell);
        patientPhone.setAdtMaintainedFieldArray(new ArrayList<>());
        return patientPhone;
    }

    public static Address getAddress(String line1, String line2, String county, String city, String state, String country, String zip, String extendedZip) {
        Address address = new Address();
        address.setCountry(country);
        address.setLine1(line1);
        address.setLine2(line2);
        address.setZip(zip + extendedZip);
        address.setState(state);
        address.setCity(city);
        address.setCounty(county);
        return address;
    }

    public static Address getAddress(String line1, String line2, String extendedZip, ZipCode zipCode) {
        Address address = new Address();
        address.setCountry(zipCode.getCountry());
        address.setLine1(line1);
        address.setLine2(line2);
        address.setZip(zipCode.getZipCode() + "1111");
        address.setState(zipCode.getState());
        address.setCity(zipCode.getCity());
        address.setCounty(zipCode.getCounty());
        return address;
    }

}