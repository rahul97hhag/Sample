package com.bhavani.builder;

import com.bhavani.models.patientCases.newCaseSummary.CaseGuarantor;
import com.bhavani.models.patientCases.newCaseSummary.PatientGuarantor;
import com.bhavani.models.patient.Patient;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BhavaniPrasadReddy on 8/15/2020.
 */
public class GuarantorObjects {

    public static List<CaseGuarantor> getEmptyPatientGuarantors(Patient patient) {
        List<CaseGuarantor> caseGuarantors = new ArrayList<>();
        PatientGuarantor primaryGuarantor = new PatientGuarantor();
        PatientGuarantor secondaryGuarantor = new PatientGuarantor();

        primaryGuarantor.setPatientGuarantorId(-1);
        primaryGuarantor.setPatientId(patient.getPatientId());
        primaryGuarantor.setFirstName(patient.getFirstName());
        primaryGuarantor.setLastName(patient.getLastName());
        primaryGuarantor.setGender(patient.getGender());
        primaryGuarantor.setDateOfBirth("11/11/1991");
        primaryGuarantor.setPatientRelationship("Self");
        primaryGuarantor.setCountry("United States");

        secondaryGuarantor.setSelectedStateIdx(0);
        secondaryGuarantor.setSelectedCountryIdx(0);

        CaseGuarantor primaryCaseGuarantor = new CaseGuarantor();
        primaryCaseGuarantor.setSortOrder(1);
        primaryCaseGuarantor.setIsActive(true);
        primaryCaseGuarantor.setPatientGuarantor(primaryGuarantor);
        primaryCaseGuarantor.setIsSelf(true);
        primaryCaseGuarantor.setGuarantorId(-1);

        CaseGuarantor secondaryCaseGuarantor = new CaseGuarantor();
        secondaryCaseGuarantor.setSortOrder(2);
        secondaryCaseGuarantor.setIsActive(false);
        secondaryCaseGuarantor.setPatientGuarantor(secondaryGuarantor);
        secondaryCaseGuarantor.setGuarantorId(null);
        secondaryCaseGuarantor.setIsSelf(false);

        caseGuarantors.add(primaryCaseGuarantor);
        caseGuarantors.add(secondaryCaseGuarantor);

        return caseGuarantors;
    }
}
