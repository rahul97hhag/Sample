package com.bhavani.builder;

import com.bhavani.models.room.Room;
import com.bhavani.models.room.RoomType;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class RoomObjects {

    public static com.bhavani.models.room.Room getRoom(int roomId, String organizationId, String roomName, RoomType roomType) {
        com.bhavani.models.room.Room room = new com.bhavani.models.room.Room();
        room.setRoomId(roomId);
        room.setQuickCode(roomType.getQuickCode());
        room.setRoomTypeId(roomType.getRoomTypeId());
        room.setActiveTf(true);
        room.setOrganizationId(Integer.valueOf(organizationId));
        room.setName(roomName);
        room.setFacilityId(null);
        room.setAoDictionaryTf(true);
        room.setShowInClinicalTf(true);
        return room;
    }

    public static RoomType getRoomType(int roomTypeId, String roomTypeName) {
        RoomType roomType = new RoomType();
        roomType.setRoomTypeId(roomTypeId);
        roomType.setRoomTypeDesc("Rtyp"+roomTypeName);
        roomType.setBusinessGroupId(1);
        roomType.setQuickCode("Rtyp"+roomTypeName);
        roomType.setActiveTf(true);
        roomType.setClassification("Procedure");
        return roomType;
    }
}