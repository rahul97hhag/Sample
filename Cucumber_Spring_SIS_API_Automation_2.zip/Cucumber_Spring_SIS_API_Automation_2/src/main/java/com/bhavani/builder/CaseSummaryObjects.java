package com.bhavani.builder;


import com.bhavani.models.patientCases.newCaseSummary.AdditionalClaimInfo;
import com.bhavani.models.patientCases.newCaseSummary.CaseSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;

/**
 * Created by BhavaniPrasadReddy on 7/26/2020.
 */
public class CaseSummaryObjects {

    private static Logger LOG = LoggerFactory.getLogger(CaseSummaryObjects.class);

    public static CaseSummary buildCaseSummaryObject() {
        return null;
    }

    public static AdditionalClaimInfo getAdditionalClaimInfo() {
        AdditionalClaimInfo additionalClaimInfo = new AdditionalClaimInfo();
        additionalClaimInfo.setValueCodes(new ArrayList<>());
        additionalClaimInfo.setConditionCodes(new ArrayList<>());
        additionalClaimInfo.setOccurenceCodes(new ArrayList<>());
        additionalClaimInfo.setEciCodes(new ArrayList<>());
        additionalClaimInfo.setReasonCodes(new ArrayList<>());
        additionalClaimInfo.setUbClaimNoteInfo(new ArrayList<>());
        additionalClaimInfo.setUbClaimSuppInfo(new ArrayList<>());
        additionalClaimInfo.setHcfaClaimNoteInfo(new ArrayList<>());
        additionalClaimInfo.setHcfaClaimSuppInfo(new ArrayList<>());
        additionalClaimInfo.setHcfaConditionCodes(new ArrayList<>());
        return additionalClaimInfo;
    }
}