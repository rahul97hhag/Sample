
package com.bhavani.models.ppe.caseRequests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caseEquipments",
    "appointmentNote",
    "caseSummaryId",
    "patientId",
    "caseGuarantor",
    "caseInsurances",
    "caseMSPInsuranceTypeMap",
    "roomId",
    "duration",
    "procedureStartDt",
    "procedureStopDt",
    "procedureStartTime",
    "procedureStopTime",
    "startTime",
    "endTime",
    "caseProcedures",
    "appointmentTypeId",
    "appointmentTypeName",
    "anesthesiaType",
    "procedureDt",
    "dateOfService",
    "additionalClaimInfo",
    "primaryPhysicianId",
    "referringPhysicianId",
    "referringPhysicianName",
    "anesthesiaTypeName",
    "anesthesiaTypeId",
    "today"
})
public class Case {

    @JsonProperty("caseEquipments")
    private List<Object> caseEquipments = new ArrayList<Object>();
    @JsonProperty("appointmentNote")
    private Object appointmentNote;
    @JsonProperty("caseSummaryId")
    private Object caseSummaryId;
    @JsonProperty("patientId")
    private Object patientId;
    @JsonProperty("caseGuarantor")
    private List<CaseGuarantor> caseGuarantor = new ArrayList<CaseGuarantor>();
    @JsonProperty("caseInsurances")
    private List<CaseInsurance> caseInsurances = new ArrayList<CaseInsurance>();
    @JsonProperty("caseMSPInsuranceTypeMap")
    private Object caseMSPInsuranceTypeMap;
    @JsonProperty("roomId")
    private Integer roomId;
    @JsonProperty("duration")
    private Integer duration;
    @JsonProperty("procedureStartDt")
    private String procedureStartDt;
    @JsonProperty("procedureStopDt")
    private String procedureStopDt;
    @JsonProperty("procedureStartTime")
    private String procedureStartTime;
    @JsonProperty("procedureStopTime")
    private String procedureStopTime;
    @JsonProperty("startTime")
    private String startTime;
    @JsonProperty("endTime")
    private String endTime;
    @JsonProperty("caseProcedures")
    private List<CaseProcedure> caseProcedures = new ArrayList<CaseProcedure>();
    @JsonProperty("appointmentTypeId")
    private Integer appointmentTypeId;
    @JsonProperty("appointmentTypeName")
    private Object appointmentTypeName;
    @JsonProperty("anesthesiaType")
    private Object anesthesiaType;
    @JsonProperty("procedureDt")
    private String procedureDt;
    @JsonProperty("dateOfService")
    private Object dateOfService;
    @JsonProperty("additionalClaimInfo")
    private AdditionalClaimInfo additionalClaimInfo;
    @JsonProperty("primaryPhysicianId")
    private Integer primaryPhysicianId;
    @JsonProperty("referringPhysicianId")
    private Object referringPhysicianId;
    @JsonProperty("referringPhysicianName")
    private Object referringPhysicianName;
    @JsonProperty("anesthesiaTypeName")
    private Object anesthesiaTypeName;
    @JsonProperty("anesthesiaTypeId")
    private Object anesthesiaTypeId;
    @JsonProperty("today")
    private Object today;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("caseEquipments")
    public List<Object> getCaseEquipments() {
        return caseEquipments;
    }

    @JsonProperty("caseEquipments")
    public void setCaseEquipments(List<Object> caseEquipments) {
        this.caseEquipments = caseEquipments;
    }

    public Case withCaseEquipments(List<Object> caseEquipments) {
        this.caseEquipments = caseEquipments;
        return this;
    }

    @JsonProperty("appointmentNote")
    public Object getAppointmentNote() {
        return appointmentNote;
    }

    @JsonProperty("appointmentNote")
    public void setAppointmentNote(Object appointmentNote) {
        this.appointmentNote = appointmentNote;
    }

    public Case withAppointmentNote(Object appointmentNote) {
        this.appointmentNote = appointmentNote;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Object getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Object caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public Case withCaseSummaryId(Object caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("patientId")
    public Object getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Object patientId) {
        this.patientId = patientId;
    }

    public Case withPatientId(Object patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("caseGuarantor")
    public List<CaseGuarantor> getCaseGuarantor() {
        return caseGuarantor;
    }

    @JsonProperty("caseGuarantor")
    public void setCaseGuarantor(List<CaseGuarantor> caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
    }

    public Case withCaseGuarantor(List<CaseGuarantor> caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
        return this;
    }

    @JsonProperty("caseInsurances")
    public List<CaseInsurance> getCaseInsurances() {
        return caseInsurances;
    }

    @JsonProperty("caseInsurances")
    public void setCaseInsurances(List<CaseInsurance> caseInsurances) {
        this.caseInsurances = caseInsurances;
    }

    public Case withCaseInsurances(List<CaseInsurance> caseInsurances) {
        this.caseInsurances = caseInsurances;
        return this;
    }

    @JsonProperty("caseMSPInsuranceTypeMap")
    public Object getCaseMSPInsuranceTypeMap() {
        return caseMSPInsuranceTypeMap;
    }

    @JsonProperty("caseMSPInsuranceTypeMap")
    public void setCaseMSPInsuranceTypeMap(Object caseMSPInsuranceTypeMap) {
        this.caseMSPInsuranceTypeMap = caseMSPInsuranceTypeMap;
    }

    public Case withCaseMSPInsuranceTypeMap(Object caseMSPInsuranceTypeMap) {
        this.caseMSPInsuranceTypeMap = caseMSPInsuranceTypeMap;
        return this;
    }

    @JsonProperty("roomId")
    public Integer getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Case withRoomId(Integer roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Case withDuration(Integer duration) {
        this.duration = duration;
        return this;
    }

    @JsonProperty("procedureStartDt")
    public String getProcedureStartDt() {
        return procedureStartDt;
    }

    @JsonProperty("procedureStartDt")
    public void setProcedureStartDt(String procedureStartDt) {
        this.procedureStartDt = procedureStartDt;
    }

    public Case withProcedureStartDt(String procedureStartDt) {
        this.procedureStartDt = procedureStartDt;
        return this;
    }

    @JsonProperty("procedureStopDt")
    public String getProcedureStopDt() {
        return procedureStopDt;
    }

    @JsonProperty("procedureStopDt")
    public void setProcedureStopDt(String procedureStopDt) {
        this.procedureStopDt = procedureStopDt;
    }

    public Case withProcedureStopDt(String procedureStopDt) {
        this.procedureStopDt = procedureStopDt;
        return this;
    }

    @JsonProperty("procedureStartTime")
    public String getProcedureStartTime() {
        return procedureStartTime;
    }

    @JsonProperty("procedureStartTime")
    public void setProcedureStartTime(String procedureStartTime) {
        this.procedureStartTime = procedureStartTime;
    }

    public Case withProcedureStartTime(String procedureStartTime) {
        this.procedureStartTime = procedureStartTime;
        return this;
    }

    @JsonProperty("procedureStopTime")
    public String getProcedureStopTime() {
        return procedureStopTime;
    }

    @JsonProperty("procedureStopTime")
    public void setProcedureStopTime(String procedureStopTime) {
        this.procedureStopTime = procedureStopTime;
    }

    public Case withProcedureStopTime(String procedureStopTime) {
        this.procedureStopTime = procedureStopTime;
        return this;
    }

    @JsonProperty("startTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("startTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Case withStartTime(String startTime) {
        this.startTime = startTime;
        return this;
    }

    @JsonProperty("endTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("endTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Case withEndTime(String endTime) {
        this.endTime = endTime;
        return this;
    }

    @JsonProperty("caseProcedures")
    public List<CaseProcedure> getCaseProcedures() {
        return caseProcedures;
    }

    @JsonProperty("caseProcedures")
    public void setCaseProcedures(List<CaseProcedure> caseProcedures) {
        this.caseProcedures = caseProcedures;
    }

    public Case withCaseProcedures(List<CaseProcedure> caseProcedures) {
        this.caseProcedures = caseProcedures;
        return this;
    }

    @JsonProperty("appointmentTypeId")
    public Integer getAppointmentTypeId() {
        return appointmentTypeId;
    }

    @JsonProperty("appointmentTypeId")
    public void setAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
    }

    public Case withAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
        return this;
    }

    @JsonProperty("appointmentTypeName")
    public Object getAppointmentTypeName() {
        return appointmentTypeName;
    }

    @JsonProperty("appointmentTypeName")
    public void setAppointmentTypeName(Object appointmentTypeName) {
        this.appointmentTypeName = appointmentTypeName;
    }

    public Case withAppointmentTypeName(Object appointmentTypeName) {
        this.appointmentTypeName = appointmentTypeName;
        return this;
    }

    @JsonProperty("anesthesiaType")
    public Object getAnesthesiaType() {
        return anesthesiaType;
    }

    @JsonProperty("anesthesiaType")
    public void setAnesthesiaType(Object anesthesiaType) {
        this.anesthesiaType = anesthesiaType;
    }

    public Case withAnesthesiaType(Object anesthesiaType) {
        this.anesthesiaType = anesthesiaType;
        return this;
    }

    @JsonProperty("procedureDt")
    public String getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
    }

    public Case withProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("dateOfService")
    public Object getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(Object dateOfService) {
        this.dateOfService = dateOfService;
    }

    public Case withDateOfService(Object dateOfService) {
        this.dateOfService = dateOfService;
        return this;
    }

    @JsonProperty("additionalClaimInfo")
    public AdditionalClaimInfo getAdditionalClaimInfo() {
        return additionalClaimInfo;
    }

    @JsonProperty("additionalClaimInfo")
    public void setAdditionalClaimInfo(AdditionalClaimInfo additionalClaimInfo) {
        this.additionalClaimInfo = additionalClaimInfo;
    }

    public Case withAdditionalClaimInfo(AdditionalClaimInfo additionalClaimInfo) {
        this.additionalClaimInfo = additionalClaimInfo;
        return this;
    }

    @JsonProperty("primaryPhysicianId")
    public Integer getPrimaryPhysicianId() {
        return primaryPhysicianId;
    }

    @JsonProperty("primaryPhysicianId")
    public void setPrimaryPhysicianId(Integer primaryPhysicianId) {
        this.primaryPhysicianId = primaryPhysicianId;
    }

    public Case withPrimaryPhysicianId(Integer primaryPhysicianId) {
        this.primaryPhysicianId = primaryPhysicianId;
        return this;
    }

    @JsonProperty("referringPhysicianId")
    public Object getReferringPhysicianId() {
        return referringPhysicianId;
    }

    @JsonProperty("referringPhysicianId")
    public void setReferringPhysicianId(Object referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
    }

    public Case withReferringPhysicianId(Object referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
        return this;
    }

    @JsonProperty("referringPhysicianName")
    public Object getReferringPhysicianName() {
        return referringPhysicianName;
    }

    @JsonProperty("referringPhysicianName")
    public void setReferringPhysicianName(Object referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
    }

    public Case withReferringPhysicianName(Object referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
        return this;
    }

    @JsonProperty("anesthesiaTypeName")
    public Object getAnesthesiaTypeName() {
        return anesthesiaTypeName;
    }

    @JsonProperty("anesthesiaTypeName")
    public void setAnesthesiaTypeName(Object anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
    }

    public Case withAnesthesiaTypeName(Object anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
        return this;
    }

    @JsonProperty("anesthesiaTypeId")
    public Object getAnesthesiaTypeId() {
        return anesthesiaTypeId;
    }

    @JsonProperty("anesthesiaTypeId")
    public void setAnesthesiaTypeId(Object anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
    }

    public Case withAnesthesiaTypeId(Object anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
        return this;
    }

    @JsonProperty("today")
    public Object getToday() {
        return today;
    }

    @JsonProperty("today")
    public void setToday(Object today) {
        this.today = today;
    }

    public Case withToday(Object today) {
        this.today = today;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Case withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(caseEquipments).append(appointmentNote).append(caseSummaryId).append(patientId).append(caseGuarantor).append(caseInsurances).append(caseMSPInsuranceTypeMap).append(roomId).append(duration).append(procedureStartDt).append(procedureStopDt).append(procedureStartTime).append(procedureStopTime).append(startTime).append(endTime).append(caseProcedures).append(appointmentTypeId).append(appointmentTypeName).append(anesthesiaType).append(procedureDt).append(dateOfService).append(additionalClaimInfo).append(primaryPhysicianId).append(referringPhysicianId).append(referringPhysicianName).append(anesthesiaTypeName).append(anesthesiaTypeId).append(today).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Case) == false) {
            return false;
        }
        Case rhs = ((Case) other);
        return new EqualsBuilder().append(caseEquipments, rhs.caseEquipments).append(appointmentNote, rhs.appointmentNote).append(caseSummaryId, rhs.caseSummaryId).append(patientId, rhs.patientId).append(caseGuarantor, rhs.caseGuarantor).append(caseInsurances, rhs.caseInsurances).append(caseMSPInsuranceTypeMap, rhs.caseMSPInsuranceTypeMap).append(roomId, rhs.roomId).append(duration, rhs.duration).append(procedureStartDt, rhs.procedureStartDt).append(procedureStopDt, rhs.procedureStopDt).append(procedureStartTime, rhs.procedureStartTime).append(procedureStopTime, rhs.procedureStopTime).append(startTime, rhs.startTime).append(endTime, rhs.endTime).append(caseProcedures, rhs.caseProcedures).append(appointmentTypeId, rhs.appointmentTypeId).append(appointmentTypeName, rhs.appointmentTypeName).append(anesthesiaType, rhs.anesthesiaType).append(procedureDt, rhs.procedureDt).append(dateOfService, rhs.dateOfService).append(additionalClaimInfo, rhs.additionalClaimInfo).append(primaryPhysicianId, rhs.primaryPhysicianId).append(referringPhysicianId, rhs.referringPhysicianId).append(referringPhysicianName, rhs.referringPhysicianName).append(anesthesiaTypeName, rhs.anesthesiaTypeName).append(anesthesiaTypeId, rhs.anesthesiaTypeId).append(today, rhs.today).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
