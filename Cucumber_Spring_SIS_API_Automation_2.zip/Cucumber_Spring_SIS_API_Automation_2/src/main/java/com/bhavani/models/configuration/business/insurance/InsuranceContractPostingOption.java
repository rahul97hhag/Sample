
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insuranceContractPostingOptionsId",
    "insuranceContractId",
    "postingOption",
    "percentOfBilledCharge",
    "transactionCodeId",
    "writeOffGroupId",
    "writeOffReasonId",
    "sourceIdentifier"
})
public class InsuranceContractPostingOption {

    @JsonProperty("insuranceContractPostingOptionsId")
    private Integer insuranceContractPostingOptionsId;
    @JsonProperty("insuranceContractId")
    private Integer insuranceContractId;
    @JsonProperty("postingOption")
    private Integer postingOption;
    @JsonProperty("percentOfBilledCharge")
    private Object percentOfBilledCharge;
    @JsonProperty("transactionCodeId")
    private Integer transactionCodeId;
    @JsonProperty("writeOffGroupId")
    private Object writeOffGroupId;
    @JsonProperty("writeOffReasonId")
    private Object writeOffReasonId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insuranceContractPostingOptionsId")
    public Integer getInsuranceContractPostingOptionsId() {
        return insuranceContractPostingOptionsId;
    }

    @JsonProperty("insuranceContractPostingOptionsId")
    public void setInsuranceContractPostingOptionsId(Integer insuranceContractPostingOptionsId) {
        this.insuranceContractPostingOptionsId = insuranceContractPostingOptionsId;
    }

    public InsuranceContractPostingOption withInsuranceContractPostingOptionsId(Integer insuranceContractPostingOptionsId) {
        this.insuranceContractPostingOptionsId = insuranceContractPostingOptionsId;
        return this;
    }

    @JsonProperty("insuranceContractId")
    public Integer getInsuranceContractId() {
        return insuranceContractId;
    }

    @JsonProperty("insuranceContractId")
    public void setInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
    }

    public InsuranceContractPostingOption withInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
        return this;
    }

    @JsonProperty("postingOption")
    public Integer getPostingOption() {
        return postingOption;
    }

    @JsonProperty("postingOption")
    public void setPostingOption(Integer postingOption) {
        this.postingOption = postingOption;
    }

    public InsuranceContractPostingOption withPostingOption(Integer postingOption) {
        this.postingOption = postingOption;
        return this;
    }

    @JsonProperty("percentOfBilledCharge")
    public Object getPercentOfBilledCharge() {
        return percentOfBilledCharge;
    }

    @JsonProperty("percentOfBilledCharge")
    public void setPercentOfBilledCharge(Object percentOfBilledCharge) {
        this.percentOfBilledCharge = percentOfBilledCharge;
    }

    public InsuranceContractPostingOption withPercentOfBilledCharge(Object percentOfBilledCharge) {
        this.percentOfBilledCharge = percentOfBilledCharge;
        return this;
    }

    @JsonProperty("transactionCodeId")
    public Integer getTransactionCodeId() {
        return transactionCodeId;
    }

    @JsonProperty("transactionCodeId")
    public void setTransactionCodeId(Integer transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
    }

    public InsuranceContractPostingOption withTransactionCodeId(Integer transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
        return this;
    }

    @JsonProperty("writeOffGroupId")
    public Object getWriteOffGroupId() {
        return writeOffGroupId;
    }

    @JsonProperty("writeOffGroupId")
    public void setWriteOffGroupId(Object writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
    }

    public InsuranceContractPostingOption withWriteOffGroupId(Object writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
        return this;
    }

    @JsonProperty("writeOffReasonId")
    public Object getWriteOffReasonId() {
        return writeOffReasonId;
    }

    @JsonProperty("writeOffReasonId")
    public void setWriteOffReasonId(Object writeOffReasonId) {
        this.writeOffReasonId = writeOffReasonId;
    }

    public InsuranceContractPostingOption withWriteOffReasonId(Object writeOffReasonId) {
        this.writeOffReasonId = writeOffReasonId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public InsuranceContractPostingOption withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsuranceContractPostingOption withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insuranceContractPostingOptionsId).append(insuranceContractId).append(postingOption).append(percentOfBilledCharge).append(transactionCodeId).append(writeOffGroupId).append(writeOffReasonId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsuranceContractPostingOption) == false) {
            return false;
        }
        InsuranceContractPostingOption rhs = ((InsuranceContractPostingOption) other);
        return new EqualsBuilder().append(insuranceContractPostingOptionsId, rhs.insuranceContractPostingOptionsId).append(insuranceContractId, rhs.insuranceContractId).append(postingOption, rhs.postingOption).append(percentOfBilledCharge, rhs.percentOfBilledCharge).append(transactionCodeId, rhs.transactionCodeId).append(writeOffGroupId, rhs.writeOffGroupId).append(writeOffReasonId, rhs.writeOffReasonId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
