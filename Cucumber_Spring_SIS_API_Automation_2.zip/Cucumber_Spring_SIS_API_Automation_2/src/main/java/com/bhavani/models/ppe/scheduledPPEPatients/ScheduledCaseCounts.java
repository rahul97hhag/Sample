
package com.bhavani.models.ppe.scheduledPPEPatients;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caseSummaryID",
    "unsignedAttachmentCount",
    "isAttachmentSigned",
    "unsignedConsentCount",
    "isConsentSigned",
    "isMedRecSigned",
    "unsignedOpNoteCount",
    "totalOpNoteCount",
    "isOpNoteSigned",
    "isDischargedFromPreOp",
    "orderCount",
    "signedOrderCount",
    "isOrderSigned",
    "isHistoryPhysicalSigned",
    "hasHistoryAndPhysical",
    "unsignedSpecimenPhysicianReviewCount",
    "isPreopExamSigned",
    "hasPreopExam",
    "unsignedBlockNoteCount",
    "isBlockNoteSigned",
    "isPostopExamSigned",
    "hasPostopExam"
})
public class ScheduledCaseCounts {

    @JsonProperty("caseSummaryID")
    private Integer caseSummaryID;
    @JsonProperty("unsignedAttachmentCount")
    private Integer unsignedAttachmentCount;
    @JsonProperty("isAttachmentSigned")
    private Boolean isAttachmentSigned;
    @JsonProperty("unsignedConsentCount")
    private Integer unsignedConsentCount;
    @JsonProperty("isConsentSigned")
    private Boolean isConsentSigned;
    @JsonProperty("isMedRecSigned")
    private Boolean isMedRecSigned;
    @JsonProperty("unsignedOpNoteCount")
    private Integer unsignedOpNoteCount;
    @JsonProperty("totalOpNoteCount")
    private Integer totalOpNoteCount;
    @JsonProperty("isOpNoteSigned")
    private Boolean isOpNoteSigned;
    @JsonProperty("isDischargedFromPreOp")
    private Boolean isDischargedFromPreOp;
    @JsonProperty("orderCount")
    private Integer orderCount;
    @JsonProperty("signedOrderCount")
    private Integer signedOrderCount;
    @JsonProperty("isOrderSigned")
    private Boolean isOrderSigned;
    @JsonProperty("isHistoryPhysicalSigned")
    private Boolean isHistoryPhysicalSigned;
    @JsonProperty("hasHistoryAndPhysical")
    private Boolean hasHistoryAndPhysical;
    @JsonProperty("unsignedSpecimenPhysicianReviewCount")
    private Integer unsignedSpecimenPhysicianReviewCount;
    @JsonProperty("isPreopExamSigned")
    private Boolean isPreopExamSigned;
    @JsonProperty("hasPreopExam")
    private Boolean hasPreopExam;
    @JsonProperty("unsignedBlockNoteCount")
    private Integer unsignedBlockNoteCount;
    @JsonProperty("isBlockNoteSigned")
    private Boolean isBlockNoteSigned;
    @JsonProperty("isPostopExamSigned")
    private Boolean isPostopExamSigned;
    @JsonProperty("hasPostopExam")
    private Boolean hasPostopExam;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("caseSummaryID")
    public Integer getCaseSummaryID() {
        return caseSummaryID;
    }

    @JsonProperty("caseSummaryID")
    public void setCaseSummaryID(Integer caseSummaryID) {
        this.caseSummaryID = caseSummaryID;
    }

    public ScheduledCaseCounts withCaseSummaryID(Integer caseSummaryID) {
        this.caseSummaryID = caseSummaryID;
        return this;
    }

    @JsonProperty("unsignedAttachmentCount")
    public Integer getUnsignedAttachmentCount() {
        return unsignedAttachmentCount;
    }

    @JsonProperty("unsignedAttachmentCount")
    public void setUnsignedAttachmentCount(Integer unsignedAttachmentCount) {
        this.unsignedAttachmentCount = unsignedAttachmentCount;
    }

    public ScheduledCaseCounts withUnsignedAttachmentCount(Integer unsignedAttachmentCount) {
        this.unsignedAttachmentCount = unsignedAttachmentCount;
        return this;
    }

    @JsonProperty("isAttachmentSigned")
    public Boolean getIsAttachmentSigned() {
        return isAttachmentSigned;
    }

    @JsonProperty("isAttachmentSigned")
    public void setIsAttachmentSigned(Boolean isAttachmentSigned) {
        this.isAttachmentSigned = isAttachmentSigned;
    }

    public ScheduledCaseCounts withIsAttachmentSigned(Boolean isAttachmentSigned) {
        this.isAttachmentSigned = isAttachmentSigned;
        return this;
    }

    @JsonProperty("unsignedConsentCount")
    public Integer getUnsignedConsentCount() {
        return unsignedConsentCount;
    }

    @JsonProperty("unsignedConsentCount")
    public void setUnsignedConsentCount(Integer unsignedConsentCount) {
        this.unsignedConsentCount = unsignedConsentCount;
    }

    public ScheduledCaseCounts withUnsignedConsentCount(Integer unsignedConsentCount) {
        this.unsignedConsentCount = unsignedConsentCount;
        return this;
    }

    @JsonProperty("isConsentSigned")
    public Boolean getIsConsentSigned() {
        return isConsentSigned;
    }

    @JsonProperty("isConsentSigned")
    public void setIsConsentSigned(Boolean isConsentSigned) {
        this.isConsentSigned = isConsentSigned;
    }

    public ScheduledCaseCounts withIsConsentSigned(Boolean isConsentSigned) {
        this.isConsentSigned = isConsentSigned;
        return this;
    }

    @JsonProperty("isMedRecSigned")
    public Boolean getIsMedRecSigned() {
        return isMedRecSigned;
    }

    @JsonProperty("isMedRecSigned")
    public void setIsMedRecSigned(Boolean isMedRecSigned) {
        this.isMedRecSigned = isMedRecSigned;
    }

    public ScheduledCaseCounts withIsMedRecSigned(Boolean isMedRecSigned) {
        this.isMedRecSigned = isMedRecSigned;
        return this;
    }

    @JsonProperty("unsignedOpNoteCount")
    public Integer getUnsignedOpNoteCount() {
        return unsignedOpNoteCount;
    }

    @JsonProperty("unsignedOpNoteCount")
    public void setUnsignedOpNoteCount(Integer unsignedOpNoteCount) {
        this.unsignedOpNoteCount = unsignedOpNoteCount;
    }

    public ScheduledCaseCounts withUnsignedOpNoteCount(Integer unsignedOpNoteCount) {
        this.unsignedOpNoteCount = unsignedOpNoteCount;
        return this;
    }

    @JsonProperty("totalOpNoteCount")
    public Integer getTotalOpNoteCount() {
        return totalOpNoteCount;
    }

    @JsonProperty("totalOpNoteCount")
    public void setTotalOpNoteCount(Integer totalOpNoteCount) {
        this.totalOpNoteCount = totalOpNoteCount;
    }

    public ScheduledCaseCounts withTotalOpNoteCount(Integer totalOpNoteCount) {
        this.totalOpNoteCount = totalOpNoteCount;
        return this;
    }

    @JsonProperty("isOpNoteSigned")
    public Boolean getIsOpNoteSigned() {
        return isOpNoteSigned;
    }

    @JsonProperty("isOpNoteSigned")
    public void setIsOpNoteSigned(Boolean isOpNoteSigned) {
        this.isOpNoteSigned = isOpNoteSigned;
    }

    public ScheduledCaseCounts withIsOpNoteSigned(Boolean isOpNoteSigned) {
        this.isOpNoteSigned = isOpNoteSigned;
        return this;
    }

    @JsonProperty("isDischargedFromPreOp")
    public Boolean getIsDischargedFromPreOp() {
        return isDischargedFromPreOp;
    }

    @JsonProperty("isDischargedFromPreOp")
    public void setIsDischargedFromPreOp(Boolean isDischargedFromPreOp) {
        this.isDischargedFromPreOp = isDischargedFromPreOp;
    }

    public ScheduledCaseCounts withIsDischargedFromPreOp(Boolean isDischargedFromPreOp) {
        this.isDischargedFromPreOp = isDischargedFromPreOp;
        return this;
    }

    @JsonProperty("orderCount")
    public Integer getOrderCount() {
        return orderCount;
    }

    @JsonProperty("orderCount")
    public void setOrderCount(Integer orderCount) {
        this.orderCount = orderCount;
    }

    public ScheduledCaseCounts withOrderCount(Integer orderCount) {
        this.orderCount = orderCount;
        return this;
    }

    @JsonProperty("signedOrderCount")
    public Integer getSignedOrderCount() {
        return signedOrderCount;
    }

    @JsonProperty("signedOrderCount")
    public void setSignedOrderCount(Integer signedOrderCount) {
        this.signedOrderCount = signedOrderCount;
    }

    public ScheduledCaseCounts withSignedOrderCount(Integer signedOrderCount) {
        this.signedOrderCount = signedOrderCount;
        return this;
    }

    @JsonProperty("isOrderSigned")
    public Boolean getIsOrderSigned() {
        return isOrderSigned;
    }

    @JsonProperty("isOrderSigned")
    public void setIsOrderSigned(Boolean isOrderSigned) {
        this.isOrderSigned = isOrderSigned;
    }

    public ScheduledCaseCounts withIsOrderSigned(Boolean isOrderSigned) {
        this.isOrderSigned = isOrderSigned;
        return this;
    }

    @JsonProperty("isHistoryPhysicalSigned")
    public Boolean getIsHistoryPhysicalSigned() {
        return isHistoryPhysicalSigned;
    }

    @JsonProperty("isHistoryPhysicalSigned")
    public void setIsHistoryPhysicalSigned(Boolean isHistoryPhysicalSigned) {
        this.isHistoryPhysicalSigned = isHistoryPhysicalSigned;
    }

    public ScheduledCaseCounts withIsHistoryPhysicalSigned(Boolean isHistoryPhysicalSigned) {
        this.isHistoryPhysicalSigned = isHistoryPhysicalSigned;
        return this;
    }

    @JsonProperty("hasHistoryAndPhysical")
    public Boolean getHasHistoryAndPhysical() {
        return hasHistoryAndPhysical;
    }

    @JsonProperty("hasHistoryAndPhysical")
    public void setHasHistoryAndPhysical(Boolean hasHistoryAndPhysical) {
        this.hasHistoryAndPhysical = hasHistoryAndPhysical;
    }

    public ScheduledCaseCounts withHasHistoryAndPhysical(Boolean hasHistoryAndPhysical) {
        this.hasHistoryAndPhysical = hasHistoryAndPhysical;
        return this;
    }

    @JsonProperty("unsignedSpecimenPhysicianReviewCount")
    public Integer getUnsignedSpecimenPhysicianReviewCount() {
        return unsignedSpecimenPhysicianReviewCount;
    }

    @JsonProperty("unsignedSpecimenPhysicianReviewCount")
    public void setUnsignedSpecimenPhysicianReviewCount(Integer unsignedSpecimenPhysicianReviewCount) {
        this.unsignedSpecimenPhysicianReviewCount = unsignedSpecimenPhysicianReviewCount;
    }

    public ScheduledCaseCounts withUnsignedSpecimenPhysicianReviewCount(Integer unsignedSpecimenPhysicianReviewCount) {
        this.unsignedSpecimenPhysicianReviewCount = unsignedSpecimenPhysicianReviewCount;
        return this;
    }

    @JsonProperty("isPreopExamSigned")
    public Boolean getIsPreopExamSigned() {
        return isPreopExamSigned;
    }

    @JsonProperty("isPreopExamSigned")
    public void setIsPreopExamSigned(Boolean isPreopExamSigned) {
        this.isPreopExamSigned = isPreopExamSigned;
    }

    public ScheduledCaseCounts withIsPreopExamSigned(Boolean isPreopExamSigned) {
        this.isPreopExamSigned = isPreopExamSigned;
        return this;
    }

    @JsonProperty("hasPreopExam")
    public Boolean getHasPreopExam() {
        return hasPreopExam;
    }

    @JsonProperty("hasPreopExam")
    public void setHasPreopExam(Boolean hasPreopExam) {
        this.hasPreopExam = hasPreopExam;
    }

    public ScheduledCaseCounts withHasPreopExam(Boolean hasPreopExam) {
        this.hasPreopExam = hasPreopExam;
        return this;
    }

    @JsonProperty("unsignedBlockNoteCount")
    public Integer getUnsignedBlockNoteCount() {
        return unsignedBlockNoteCount;
    }

    @JsonProperty("unsignedBlockNoteCount")
    public void setUnsignedBlockNoteCount(Integer unsignedBlockNoteCount) {
        this.unsignedBlockNoteCount = unsignedBlockNoteCount;
    }

    public ScheduledCaseCounts withUnsignedBlockNoteCount(Integer unsignedBlockNoteCount) {
        this.unsignedBlockNoteCount = unsignedBlockNoteCount;
        return this;
    }

    @JsonProperty("isBlockNoteSigned")
    public Boolean getIsBlockNoteSigned() {
        return isBlockNoteSigned;
    }

    @JsonProperty("isBlockNoteSigned")
    public void setIsBlockNoteSigned(Boolean isBlockNoteSigned) {
        this.isBlockNoteSigned = isBlockNoteSigned;
    }

    public ScheduledCaseCounts withIsBlockNoteSigned(Boolean isBlockNoteSigned) {
        this.isBlockNoteSigned = isBlockNoteSigned;
        return this;
    }

    @JsonProperty("isPostopExamSigned")
    public Boolean getIsPostopExamSigned() {
        return isPostopExamSigned;
    }

    @JsonProperty("isPostopExamSigned")
    public void setIsPostopExamSigned(Boolean isPostopExamSigned) {
        this.isPostopExamSigned = isPostopExamSigned;
    }

    public ScheduledCaseCounts withIsPostopExamSigned(Boolean isPostopExamSigned) {
        this.isPostopExamSigned = isPostopExamSigned;
        return this;
    }

    @JsonProperty("hasPostopExam")
    public Boolean getHasPostopExam() {
        return hasPostopExam;
    }

    @JsonProperty("hasPostopExam")
    public void setHasPostopExam(Boolean hasPostopExam) {
        this.hasPostopExam = hasPostopExam;
    }

    public ScheduledCaseCounts withHasPostopExam(Boolean hasPostopExam) {
        this.hasPostopExam = hasPostopExam;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ScheduledCaseCounts withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(caseSummaryID).append(unsignedAttachmentCount).append(isAttachmentSigned).append(unsignedConsentCount).append(isConsentSigned).append(isMedRecSigned).append(unsignedOpNoteCount).append(totalOpNoteCount).append(isOpNoteSigned).append(isDischargedFromPreOp).append(orderCount).append(signedOrderCount).append(isOrderSigned).append(isHistoryPhysicalSigned).append(hasHistoryAndPhysical).append(unsignedSpecimenPhysicianReviewCount).append(isPreopExamSigned).append(hasPreopExam).append(unsignedBlockNoteCount).append(isBlockNoteSigned).append(isPostopExamSigned).append(hasPostopExam).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ScheduledCaseCounts) == false) {
            return false;
        }
        ScheduledCaseCounts rhs = ((ScheduledCaseCounts) other);
        return new EqualsBuilder().append(caseSummaryID, rhs.caseSummaryID).append(unsignedAttachmentCount, rhs.unsignedAttachmentCount).append(isAttachmentSigned, rhs.isAttachmentSigned).append(unsignedConsentCount, rhs.unsignedConsentCount).append(isConsentSigned, rhs.isConsentSigned).append(isMedRecSigned, rhs.isMedRecSigned).append(unsignedOpNoteCount, rhs.unsignedOpNoteCount).append(totalOpNoteCount, rhs.totalOpNoteCount).append(isOpNoteSigned, rhs.isOpNoteSigned).append(isDischargedFromPreOp, rhs.isDischargedFromPreOp).append(orderCount, rhs.orderCount).append(signedOrderCount, rhs.signedOrderCount).append(isOrderSigned, rhs.isOrderSigned).append(isHistoryPhysicalSigned, rhs.isHistoryPhysicalSigned).append(hasHistoryAndPhysical, rhs.hasHistoryAndPhysical).append(unsignedSpecimenPhysicianReviewCount, rhs.unsignedSpecimenPhysicianReviewCount).append(isPreopExamSigned, rhs.isPreopExamSigned).append(hasPreopExam, rhs.hasPreopExam).append(unsignedBlockNoteCount, rhs.unsignedBlockNoteCount).append(isBlockNoteSigned, rhs.isBlockNoteSigned).append(isPostopExamSigned, rhs.isPostopExamSigned).append(hasPostopExam, rhs.hasPostopExam).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
