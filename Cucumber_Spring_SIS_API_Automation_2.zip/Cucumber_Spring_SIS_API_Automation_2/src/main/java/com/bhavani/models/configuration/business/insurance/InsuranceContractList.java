
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insuranceContractId",
    "insuranceContractName",
    "organizationId",
    "effectiveDate",
    "expirationDate",
    "contractType",
    "notes",
    "isMappedWithCharge",
    "sourceIdentifier"
})
public class InsuranceContractList {

    @JsonProperty("insuranceContractId")
    private Integer insuranceContractId;
    @JsonProperty("insuranceContractName")
    private String insuranceContractName;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("effectiveDate")
    private Object effectiveDate;
    @JsonProperty("expirationDate")
    private Object expirationDate;
    @JsonProperty("contractType")
    private Object contractType;
    @JsonProperty("notes")
    private Object notes;
    @JsonProperty("isMappedWithCharge")
    private Boolean isMappedWithCharge;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insuranceContractId")
    public Integer getInsuranceContractId() {
        return insuranceContractId;
    }

    @JsonProperty("insuranceContractId")
    public void setInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
    }

    public InsuranceContractList withInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
        return this;
    }

    @JsonProperty("insuranceContractName")
    public String getInsuranceContractName() {
        return insuranceContractName;
    }

    @JsonProperty("insuranceContractName")
    public void setInsuranceContractName(String insuranceContractName) {
        this.insuranceContractName = insuranceContractName;
    }

    public InsuranceContractList withInsuranceContractName(String insuranceContractName) {
        this.insuranceContractName = insuranceContractName;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public InsuranceContractList withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("effectiveDate")
    public Object getEffectiveDate() {
        return effectiveDate;
    }

    @JsonProperty("effectiveDate")
    public void setEffectiveDate(Object effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public InsuranceContractList withEffectiveDate(Object effectiveDate) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    @JsonProperty("expirationDate")
    public Object getExpirationDate() {
        return expirationDate;
    }

    @JsonProperty("expirationDate")
    public void setExpirationDate(Object expirationDate) {
        this.expirationDate = expirationDate;
    }

    public InsuranceContractList withExpirationDate(Object expirationDate) {
        this.expirationDate = expirationDate;
        return this;
    }

    @JsonProperty("contractType")
    public Object getContractType() {
        return contractType;
    }

    @JsonProperty("contractType")
    public void setContractType(Object contractType) {
        this.contractType = contractType;
    }

    public InsuranceContractList withContractType(Object contractType) {
        this.contractType = contractType;
        return this;
    }

    @JsonProperty("notes")
    public Object getNotes() {
        return notes;
    }

    @JsonProperty("notes")
    public void setNotes(Object notes) {
        this.notes = notes;
    }

    public InsuranceContractList withNotes(Object notes) {
        this.notes = notes;
        return this;
    }

    @JsonProperty("isMappedWithCharge")
    public Boolean getIsMappedWithCharge() {
        return isMappedWithCharge;
    }

    @JsonProperty("isMappedWithCharge")
    public void setIsMappedWithCharge(Boolean isMappedWithCharge) {
        this.isMappedWithCharge = isMappedWithCharge;
    }

    public InsuranceContractList withIsMappedWithCharge(Boolean isMappedWithCharge) {
        this.isMappedWithCharge = isMappedWithCharge;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public InsuranceContractList withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsuranceContractList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insuranceContractId).append(insuranceContractName).append(organizationId).append(effectiveDate).append(expirationDate).append(contractType).append(notes).append(isMappedWithCharge).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsuranceContractList) == false) {
            return false;
        }
        InsuranceContractList rhs = ((InsuranceContractList) other);
        return new EqualsBuilder().append(insuranceContractId, rhs.insuranceContractId).append(insuranceContractName, rhs.insuranceContractName).append(organizationId, rhs.organizationId).append(effectiveDate, rhs.effectiveDate).append(expirationDate, rhs.expirationDate).append(contractType, rhs.contractType).append(notes, rhs.notes).append(isMappedWithCharge, rhs.isMappedWithCharge).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
