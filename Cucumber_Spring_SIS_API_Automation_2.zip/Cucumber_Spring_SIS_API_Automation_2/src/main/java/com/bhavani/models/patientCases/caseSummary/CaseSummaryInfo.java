
package com.bhavani.models.patientCases.caseSummary;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caseSummaryId",
    "acuteChronicTf",
    "note",
    "created",
    "status",
    "statusAtDischarge",
    "cancelCaseReason",
    "cancelCaseReasonId",
    "cancelDate",
    "previousStatus",
    "appointmentId",
    "isDepleted",
    "isDocumented",
    "unableToCode",
    "unableToCodeReason",
    "caseType",
    "sourceIdentifier"
})
public class CaseSummaryInfo {

    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("acuteChronicTf")
    private Boolean acuteChronicTf;
    @JsonProperty("note")
    private Object note;
    @JsonProperty("created")
    private String created;
    @JsonProperty("status")
    private Integer status;
    @JsonProperty("statusAtDischarge")
    private Object statusAtDischarge;
    @JsonProperty("cancelCaseReason")
    private Object cancelCaseReason;
    @JsonProperty("cancelCaseReasonId")
    private Object cancelCaseReasonId;
    @JsonProperty("cancelDate")
    private Object cancelDate;
    @JsonProperty("previousStatus")
    private Object previousStatus;
    @JsonProperty("appointmentId")
    private Integer appointmentId;
    @JsonProperty("isDepleted")
    private Boolean isDepleted;
    @JsonProperty("isDocumented")
    private Boolean isDocumented;
    @JsonProperty("unableToCode")
    private Boolean unableToCode;
    @JsonProperty("unableToCodeReason")
    private Object unableToCodeReason;
    @JsonProperty("caseType")
    private Integer caseType;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public CaseSummaryInfo withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("acuteChronicTf")
    public Boolean getAcuteChronicTf() {
        return acuteChronicTf;
    }

    @JsonProperty("acuteChronicTf")
    public void setAcuteChronicTf(Boolean acuteChronicTf) {
        this.acuteChronicTf = acuteChronicTf;
    }

    public CaseSummaryInfo withAcuteChronicTf(Boolean acuteChronicTf) {
        this.acuteChronicTf = acuteChronicTf;
        return this;
    }

    @JsonProperty("note")
    public Object getNote() {
        return note;
    }

    @JsonProperty("note")
    public void setNote(Object note) {
        this.note = note;
    }

    public CaseSummaryInfo withNote(Object note) {
        this.note = note;
        return this;
    }

    @JsonProperty("created")
    public String getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(String created) {
        this.created = created;
    }

    public CaseSummaryInfo withCreated(String created) {
        this.created = created;
        return this;
    }

    @JsonProperty("status")
    public Integer getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Integer status) {
        this.status = status;
    }

    public CaseSummaryInfo withStatus(Integer status) {
        this.status = status;
        return this;
    }

    @JsonProperty("statusAtDischarge")
    public Object getStatusAtDischarge() {
        return statusAtDischarge;
    }

    @JsonProperty("statusAtDischarge")
    public void setStatusAtDischarge(Object statusAtDischarge) {
        this.statusAtDischarge = statusAtDischarge;
    }

    public CaseSummaryInfo withStatusAtDischarge(Object statusAtDischarge) {
        this.statusAtDischarge = statusAtDischarge;
        return this;
    }

    @JsonProperty("cancelCaseReason")
    public Object getCancelCaseReason() {
        return cancelCaseReason;
    }

    @JsonProperty("cancelCaseReason")
    public void setCancelCaseReason(Object cancelCaseReason) {
        this.cancelCaseReason = cancelCaseReason;
    }

    public CaseSummaryInfo withCancelCaseReason(Object cancelCaseReason) {
        this.cancelCaseReason = cancelCaseReason;
        return this;
    }

    @JsonProperty("cancelCaseReasonId")
    public Object getCancelCaseReasonId() {
        return cancelCaseReasonId;
    }

    @JsonProperty("cancelCaseReasonId")
    public void setCancelCaseReasonId(Object cancelCaseReasonId) {
        this.cancelCaseReasonId = cancelCaseReasonId;
    }

    public CaseSummaryInfo withCancelCaseReasonId(Object cancelCaseReasonId) {
        this.cancelCaseReasonId = cancelCaseReasonId;
        return this;
    }

    @JsonProperty("cancelDate")
    public Object getCancelDate() {
        return cancelDate;
    }

    @JsonProperty("cancelDate")
    public void setCancelDate(Object cancelDate) {
        this.cancelDate = cancelDate;
    }

    public CaseSummaryInfo withCancelDate(Object cancelDate) {
        this.cancelDate = cancelDate;
        return this;
    }

    @JsonProperty("previousStatus")
    public Object getPreviousStatus() {
        return previousStatus;
    }

    @JsonProperty("previousStatus")
    public void setPreviousStatus(Object previousStatus) {
        this.previousStatus = previousStatus;
    }

    public CaseSummaryInfo withPreviousStatus(Object previousStatus) {
        this.previousStatus = previousStatus;
        return this;
    }

    @JsonProperty("appointmentId")
    public Integer getAppointmentId() {
        return appointmentId;
    }

    @JsonProperty("appointmentId")
    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public CaseSummaryInfo withAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
        return this;
    }

    @JsonProperty("isDepleted")
    public Boolean getIsDepleted() {
        return isDepleted;
    }

    @JsonProperty("isDepleted")
    public void setIsDepleted(Boolean isDepleted) {
        this.isDepleted = isDepleted;
    }

    public CaseSummaryInfo withIsDepleted(Boolean isDepleted) {
        this.isDepleted = isDepleted;
        return this;
    }

    @JsonProperty("isDocumented")
    public Boolean getIsDocumented() {
        return isDocumented;
    }

    @JsonProperty("isDocumented")
    public void setIsDocumented(Boolean isDocumented) {
        this.isDocumented = isDocumented;
    }

    public CaseSummaryInfo withIsDocumented(Boolean isDocumented) {
        this.isDocumented = isDocumented;
        return this;
    }

    @JsonProperty("unableToCode")
    public Boolean getUnableToCode() {
        return unableToCode;
    }

    @JsonProperty("unableToCode")
    public void setUnableToCode(Boolean unableToCode) {
        this.unableToCode = unableToCode;
    }

    public CaseSummaryInfo withUnableToCode(Boolean unableToCode) {
        this.unableToCode = unableToCode;
        return this;
    }

    @JsonProperty("unableToCodeReason")
    public Object getUnableToCodeReason() {
        return unableToCodeReason;
    }

    @JsonProperty("unableToCodeReason")
    public void setUnableToCodeReason(Object unableToCodeReason) {
        this.unableToCodeReason = unableToCodeReason;
    }

    public CaseSummaryInfo withUnableToCodeReason(Object unableToCodeReason) {
        this.unableToCodeReason = unableToCodeReason;
        return this;
    }

    @JsonProperty("caseType")
    public Integer getCaseType() {
        return caseType;
    }

    @JsonProperty("caseType")
    public void setCaseType(Integer caseType) {
        this.caseType = caseType;
    }

    public CaseSummaryInfo withCaseType(Integer caseType) {
        this.caseType = caseType;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public CaseSummaryInfo withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseSummaryInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(caseSummaryId).append(acuteChronicTf).append(note).append(created).append(status).append(statusAtDischarge).append(cancelCaseReason).append(cancelCaseReasonId).append(cancelDate).append(previousStatus).append(appointmentId).append(isDepleted).append(isDocumented).append(unableToCode).append(unableToCodeReason).append(caseType).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseSummaryInfo) == false) {
            return false;
        }
        CaseSummaryInfo rhs = ((CaseSummaryInfo) other);
        return new EqualsBuilder().append(caseSummaryId, rhs.caseSummaryId).append(acuteChronicTf, rhs.acuteChronicTf).append(note, rhs.note).append(created, rhs.created).append(status, rhs.status).append(statusAtDischarge, rhs.statusAtDischarge).append(cancelCaseReason, rhs.cancelCaseReason).append(cancelCaseReasonId, rhs.cancelCaseReasonId).append(cancelDate, rhs.cancelDate).append(previousStatus, rhs.previousStatus).append(appointmentId, rhs.appointmentId).append(isDepleted, rhs.isDepleted).append(isDocumented, rhs.isDocumented).append(unableToCode, rhs.unableToCode).append(unableToCodeReason, rhs.unableToCodeReason).append(caseType, rhs.caseType).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
