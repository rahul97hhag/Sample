
package com.bhavani.models.appointmentType;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "organizationId",
    "casePackId",
    "appointmentTypeId",
    "createCaseTf",
    "startDt",
    "casepack_Name",
    "appointment_Type_Desc",
    "isAppointmentTypeActive",
    "anesthesiaDt",
    "prevAnesthesiaDt",
    "caseTypeStartDate",
    "caseTypeBeforeStartDate",
    "caseTypeAfterStartDate",
    "sourceIdentifier"
})
public class AppointmentType {

    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("casePackId")
    private Integer casePackId;
    @JsonProperty("appointmentTypeId")
    private Integer appointmentTypeId;
    @JsonProperty("createCaseTf")
    private Boolean createCaseTf;
    @JsonProperty("startDt")
    private Object startDt;
    @JsonProperty("casepack_Name")
    private Object casepackName;
    @JsonProperty("appointment_Type_Desc")
    private String appointmentTypeDesc;
    @JsonProperty("isAppointmentTypeActive")
    private Boolean isAppointmentTypeActive;
    @JsonProperty("anesthesiaDt")
    private Object anesthesiaDt;
    @JsonProperty("prevAnesthesiaDt")
    private Object prevAnesthesiaDt;
    @JsonProperty("caseTypeStartDate")
    private Object caseTypeStartDate;
    @JsonProperty("caseTypeBeforeStartDate")
    private Integer caseTypeBeforeStartDate;
    @JsonProperty("caseTypeAfterStartDate")
    private Integer caseTypeAfterStartDate;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public AppointmentType withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("casePackId")
    public Integer getCasePackId() {
        return casePackId;
    }

    @JsonProperty("casePackId")
    public void setCasePackId(Integer casePackId) {
        this.casePackId = casePackId;
    }

    public AppointmentType withCasePackId(Integer casePackId) {
        this.casePackId = casePackId;
        return this;
    }

    @JsonProperty("appointmentTypeId")
    public Integer getAppointmentTypeId() {
        return appointmentTypeId;
    }

    @JsonProperty("appointmentTypeId")
    public void setAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
    }

    public AppointmentType withAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
        return this;
    }

    @JsonProperty("createCaseTf")
    public Boolean getCreateCaseTf() {
        return createCaseTf;
    }

    @JsonProperty("createCaseTf")
    public void setCreateCaseTf(Boolean createCaseTf) {
        this.createCaseTf = createCaseTf;
    }

    public AppointmentType withCreateCaseTf(Boolean createCaseTf) {
        this.createCaseTf = createCaseTf;
        return this;
    }

    @JsonProperty("startDt")
    public Object getStartDt() {
        return startDt;
    }

    @JsonProperty("startDt")
    public void setStartDt(Object startDt) {
        this.startDt = startDt;
    }

    public AppointmentType withStartDt(Object startDt) {
        this.startDt = startDt;
        return this;
    }

    @JsonProperty("casepack_Name")
    public Object getCasepackName() {
        return casepackName;
    }

    @JsonProperty("casepack_Name")
    public void setCasepackName(Object casepackName) {
        this.casepackName = casepackName;
    }

    public AppointmentType withCasepackName(Object casepackName) {
        this.casepackName = casepackName;
        return this;
    }

    @JsonProperty("appointment_Type_Desc")
    public String getAppointmentTypeDesc() {
        return appointmentTypeDesc;
    }

    @JsonProperty("appointment_Type_Desc")
    public void setAppointmentTypeDesc(String appointmentTypeDesc) {
        this.appointmentTypeDesc = appointmentTypeDesc;
    }

    public AppointmentType withAppointmentTypeDesc(String appointmentTypeDesc) {
        this.appointmentTypeDesc = appointmentTypeDesc;
        return this;
    }

    @JsonProperty("isAppointmentTypeActive")
    public Boolean getIsAppointmentTypeActive() {
        return isAppointmentTypeActive;
    }

    @JsonProperty("isAppointmentTypeActive")
    public void setIsAppointmentTypeActive(Boolean isAppointmentTypeActive) {
        this.isAppointmentTypeActive = isAppointmentTypeActive;
    }

    public AppointmentType withIsAppointmentTypeActive(Boolean isAppointmentTypeActive) {
        this.isAppointmentTypeActive = isAppointmentTypeActive;
        return this;
    }

    @JsonProperty("anesthesiaDt")
    public Object getAnesthesiaDt() {
        return anesthesiaDt;
    }

    @JsonProperty("anesthesiaDt")
    public void setAnesthesiaDt(Object anesthesiaDt) {
        this.anesthesiaDt = anesthesiaDt;
    }

    public AppointmentType withAnesthesiaDt(Object anesthesiaDt) {
        this.anesthesiaDt = anesthesiaDt;
        return this;
    }

    @JsonProperty("prevAnesthesiaDt")
    public Object getPrevAnesthesiaDt() {
        return prevAnesthesiaDt;
    }

    @JsonProperty("prevAnesthesiaDt")
    public void setPrevAnesthesiaDt(Object prevAnesthesiaDt) {
        this.prevAnesthesiaDt = prevAnesthesiaDt;
    }

    public AppointmentType withPrevAnesthesiaDt(Object prevAnesthesiaDt) {
        this.prevAnesthesiaDt = prevAnesthesiaDt;
        return this;
    }

    @JsonProperty("caseTypeStartDate")
    public Object getCaseTypeStartDate() {
        return caseTypeStartDate;
    }

    @JsonProperty("caseTypeStartDate")
    public void setCaseTypeStartDate(Object caseTypeStartDate) {
        this.caseTypeStartDate = caseTypeStartDate;
    }

    public AppointmentType withCaseTypeStartDate(Object caseTypeStartDate) {
        this.caseTypeStartDate = caseTypeStartDate;
        return this;
    }

    @JsonProperty("caseTypeBeforeStartDate")
    public Integer getCaseTypeBeforeStartDate() {
        return caseTypeBeforeStartDate;
    }

    @JsonProperty("caseTypeBeforeStartDate")
    public void setCaseTypeBeforeStartDate(Integer caseTypeBeforeStartDate) {
        this.caseTypeBeforeStartDate = caseTypeBeforeStartDate;
    }

    public AppointmentType withCaseTypeBeforeStartDate(Integer caseTypeBeforeStartDate) {
        this.caseTypeBeforeStartDate = caseTypeBeforeStartDate;
        return this;
    }

    @JsonProperty("caseTypeAfterStartDate")
    public Integer getCaseTypeAfterStartDate() {
        return caseTypeAfterStartDate;
    }

    @JsonProperty("caseTypeAfterStartDate")
    public void setCaseTypeAfterStartDate(Integer caseTypeAfterStartDate) {
        this.caseTypeAfterStartDate = caseTypeAfterStartDate;
    }

    public AppointmentType withCaseTypeAfterStartDate(Integer caseTypeAfterStartDate) {
        this.caseTypeAfterStartDate = caseTypeAfterStartDate;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public AppointmentType withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AppointmentType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(organizationId).append(casePackId).append(appointmentTypeId).append(createCaseTf).append(startDt).append(casepackName).append(appointmentTypeDesc).append(isAppointmentTypeActive).append(anesthesiaDt).append(prevAnesthesiaDt).append(caseTypeStartDate).append(caseTypeBeforeStartDate).append(caseTypeAfterStartDate).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AppointmentType) == false) {
            return false;
        }
        AppointmentType rhs = ((AppointmentType) other);
        return new EqualsBuilder().append(organizationId, rhs.organizationId).append(casePackId, rhs.casePackId).append(appointmentTypeId, rhs.appointmentTypeId).append(createCaseTf, rhs.createCaseTf).append(startDt, rhs.startDt).append(casepackName, rhs.casepackName).append(appointmentTypeDesc, rhs.appointmentTypeDesc).append(isAppointmentTypeActive, rhs.isAppointmentTypeActive).append(anesthesiaDt, rhs.anesthesiaDt).append(prevAnesthesiaDt, rhs.prevAnesthesiaDt).append(caseTypeStartDate, rhs.caseTypeStartDate).append(caseTypeBeforeStartDate, rhs.caseTypeBeforeStartDate).append(caseTypeAfterStartDate, rhs.caseTypeAfterStartDate).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
