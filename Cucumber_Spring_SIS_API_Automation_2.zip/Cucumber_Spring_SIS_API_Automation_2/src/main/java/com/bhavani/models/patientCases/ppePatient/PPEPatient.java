
package com.bhavani.models.patientCases.ppePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "externalCaseRequestId",
    "patient",
    "case"
})
public class PPEPatient {

    @JsonProperty("externalCaseRequestId")
    private String externalCaseRequestId;
    @JsonProperty("patient")
    private Patient patient;
    @JsonProperty("case")
    private Case _case;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("externalCaseRequestId")
    public String getExternalCaseRequestId() {
        return externalCaseRequestId;
    }

    @JsonProperty("externalCaseRequestId")
    public void setExternalCaseRequestId(String externalCaseRequestId) {
        this.externalCaseRequestId = externalCaseRequestId;
    }

    public PPEPatient withExternalCaseRequestId(String externalCaseRequestId) {
        this.externalCaseRequestId = externalCaseRequestId;
        return this;
    }

    @JsonProperty("patient")
    public Patient getPatient() {
        return patient;
    }

    @JsonProperty("patient")
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public PPEPatient withPatient(Patient patient) {
        this.patient = patient;
        return this;
    }

    @JsonProperty("case")
    public Case getCase() {
        return _case;
    }

    @JsonProperty("case")
    public void setCase(Case _case) {
        this._case = _case;
    }

    public PPEPatient withCase(Case _case) {
        this._case = _case;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PPEPatient withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(externalCaseRequestId).append(patient).append(_case).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PPEPatient) == false) {
            return false;
        }
        PPEPatient rhs = ((PPEPatient) other);
        return new EqualsBuilder().append(externalCaseRequestId, rhs.externalCaseRequestId).append(patient, rhs.patient).append(_case, rhs._case).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
