
package com.bhavani.models.patientCases.dischargePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "admittedById",
    "isBTOBtnEnabled",
    "admitTypeValue",
    "admitSourceValue",
    "caseSummaryId",
    "moduleId",
    "admissionTime",
    "patientId",
    "areaOfCareInformationId"
})
public class AreaCareInformationRequest {

    @JsonProperty("admittedById")
    private Integer admittedById;
    @JsonProperty("isBTOBtnEnabled")
    private Boolean isBTOBtnEnabled;
    @JsonProperty("admitTypeValue")
    private String admitTypeValue;
    @JsonProperty("admitSourceValue")
    private String admitSourceValue;
    @JsonProperty("caseSummaryId")
    private String caseSummaryId;
    @JsonProperty("moduleId")
    private Integer moduleId;
    @JsonProperty("admissionTime")
    private String admissionTime;
    @JsonProperty("patientId")
    private String patientId;
    @JsonProperty("areaOfCareInformationId")
    private Integer areaOfCareInformationId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("isBTOBtnEnabled")
    public Boolean getIsBTOBtnEnabled() {
        return isBTOBtnEnabled;
    }

    @JsonProperty("isBTOBtnEnabled")
    public void setIsBTOBtnEnabled(Boolean isBTOBtnEnabled) {
        this.isBTOBtnEnabled = isBTOBtnEnabled;
    }

    public AreaCareInformationRequest withIsBTOBtnEnabled(Boolean isBTOBtnEnabled) {
        this.isBTOBtnEnabled = isBTOBtnEnabled;
        return this;
    }

    @JsonProperty("admitTypeValue")
    public String getAdmitTypeValue() {
        return admitTypeValue;
    }

    @JsonProperty("admitTypeValue")
    public void setAdmitTypeValue(String admitTypeValue) {
        this.admitTypeValue = admitTypeValue;
    }

    public AreaCareInformationRequest withAdmitTypeValue(String admitTypeValue) {
        this.admitTypeValue = admitTypeValue;
        return this;
    }

    @JsonProperty("admitSourceValue")
    public String getAdmitSourceValue() {
        return admitSourceValue;
    }

    @JsonProperty("admitSourceValue")
    public void setAdmitSourceValue(String admitSourceValue) {
        this.admitSourceValue = admitSourceValue;
    }

    public AreaCareInformationRequest withAdmitSourceValue(String admitSourceValue) {
        this.admitSourceValue = admitSourceValue;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public String getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(String caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public AreaCareInformationRequest withCaseSummaryId(String caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("moduleId")
    public Integer getModuleId() {
        return moduleId;
    }

    @JsonProperty("moduleId")
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public AreaCareInformationRequest withModuleId(Integer moduleId) {
        this.moduleId = moduleId;
        return this;
    }

    @JsonProperty("admissionTime")
    public String getAdmissionTime() {
        return admissionTime;
    }

    @JsonProperty("admissionTime")
    public void setAdmissionTime(String admissionTime) {
        this.admissionTime = admissionTime;
    }

    public AreaCareInformationRequest withAdmissionTime(String admissionTime) {
        this.admissionTime = admissionTime;
        return this;
    }

    @JsonProperty("patientId")
    public String getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public AreaCareInformationRequest withPatientId(String patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("admittedById")
    public Integer getAdmittedById() {
        return admittedById;
    }

    @JsonProperty("admittedById")
    public void setAdmittedById(Integer admittedById) {
        this.admittedById = admittedById;
    }

    public AreaCareInformationRequest withAdmittedById(Integer admittedById) {
        this.admittedById = admittedById;
        return this;
    }

    @JsonProperty("areaOfCareInformationId")
    public Integer getAreaOfCareInformationId() {
        return areaOfCareInformationId;
    }

    @JsonProperty("areaOfCareInformationId")
    public void setAreaOfCareInformationId(Integer areaOfCareInformationId) {
        this.areaOfCareInformationId = areaOfCareInformationId;
    }

    public AreaCareInformationRequest withAreaOfCareInformationId(Integer areaOfCareInformationId) {
        this.areaOfCareInformationId = areaOfCareInformationId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AreaCareInformationRequest withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(isBTOBtnEnabled).append(admitTypeValue).append(admitSourceValue).append(caseSummaryId).append(moduleId).append(admissionTime).append(patientId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AreaCareInformationRequest) == false) {
            return false;
        }
        AreaCareInformationRequest rhs = ((AreaCareInformationRequest) other);
        return new EqualsBuilder().append(isBTOBtnEnabled, rhs.isBTOBtnEnabled).append(admitTypeValue, rhs.admitTypeValue).append(admitSourceValue, rhs.admitSourceValue).append(caseSummaryId, rhs.caseSummaryId).append(moduleId, rhs.moduleId).append(admissionTime, rhs.admissionTime).append(patientId, rhs.patientId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
