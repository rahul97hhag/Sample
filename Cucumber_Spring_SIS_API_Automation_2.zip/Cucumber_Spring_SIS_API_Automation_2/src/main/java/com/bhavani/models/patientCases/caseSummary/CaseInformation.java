
package com.bhavani.models.patientCases.caseSummary;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "admitTime",
    "caseSummaryId",
    "patientId",
    "caseStatus",
    "dischargeTime",
    "dateOfService",
    "procedureText",
    "patientMRN"
})
public class CaseInformation {

    @JsonProperty("admitTime")
    private Object admitTime;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("caseStatus")
    private String caseStatus;
    @JsonProperty("dischargeTime")
    private Object dischargeTime;
    @JsonProperty("dateOfService")
    private String dateOfService;
    @JsonProperty("procedureText")
    private String procedureText;
    @JsonProperty("patientMRN")
    private String patientMRN;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("admitTime")
    public Object getAdmitTime() {
        return admitTime;
    }

    @JsonProperty("admitTime")
    public void setAdmitTime(Object admitTime) {
        this.admitTime = admitTime;
    }

    public CaseInformation withAdmitTime(Object admitTime) {
        this.admitTime = admitTime;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public CaseInformation withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public CaseInformation withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("caseStatus")
    public String getCaseStatus() {
        return caseStatus;
    }

    @JsonProperty("caseStatus")
    public void setCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
    }

    public CaseInformation withCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
        return this;
    }

    @JsonProperty("dischargeTime")
    public Object getDischargeTime() {
        return dischargeTime;
    }

    @JsonProperty("dischargeTime")
    public void setDischargeTime(Object dischargeTime) {
        this.dischargeTime = dischargeTime;
    }

    public CaseInformation withDischargeTime(Object dischargeTime) {
        this.dischargeTime = dischargeTime;
        return this;
    }

    @JsonProperty("dateOfService")
    public String getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public CaseInformation withDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
        return this;
    }

    @JsonProperty("procedureText")
    public String getProcedureText() {
        return procedureText;
    }

    @JsonProperty("procedureText")
    public void setProcedureText(String procedureText) {
        this.procedureText = procedureText;
    }

    public CaseInformation withProcedureText(String procedureText) {
        this.procedureText = procedureText;
        return this;
    }

    @JsonProperty("patientMRN")
    public String getPatientMRN() {
        return patientMRN;
    }

    @JsonProperty("patientMRN")
    public void setPatientMRN(String patientMRN) {
        this.patientMRN = patientMRN;
    }

    public CaseInformation withPatientMRN(String patientMRN) {
        this.patientMRN = patientMRN;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseInformation withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(admitTime).append(caseSummaryId).append(patientId).append(caseStatus).append(dischargeTime).append(dateOfService).append(procedureText).append(patientMRN).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseInformation) == false) {
            return false;
        }
        CaseInformation rhs = ((CaseInformation) other);
        return new EqualsBuilder().append(admitTime, rhs.admitTime).append(caseSummaryId, rhs.caseSummaryId).append(patientId, rhs.patientId).append(caseStatus, rhs.caseStatus).append(dischargeTime, rhs.dischargeTime).append(dateOfService, rhs.dateOfService).append(procedureText, rhs.procedureText).append(patientMRN, rhs.patientMRN).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
