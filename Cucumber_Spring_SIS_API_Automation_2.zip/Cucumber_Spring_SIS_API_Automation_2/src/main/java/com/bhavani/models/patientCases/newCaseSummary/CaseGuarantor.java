
package com.bhavani.models.patientCases.newCaseSummary;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sortOrder",
    "isActive",
    "patientGuarantor",
    "guarantorId",
    "isSelf"
})
public class CaseGuarantor {

    @JsonProperty("sortOrder")
    private Integer sortOrder;
    @JsonProperty("isActive")
    private Boolean isActive;
    @JsonProperty("patientGuarantor")
    private PatientGuarantor patientGuarantor;
    @JsonProperty("guarantorId")
    private Object guarantorId;
    @JsonProperty("isSelf")
    private Boolean isSelf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("sortOrder")
    public Integer getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public CaseGuarantor withSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("isActive")
    public Boolean getIsActive() {
        return isActive;
    }

    @JsonProperty("isActive")
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public CaseGuarantor withIsActive(Boolean isActive) {
        this.isActive = isActive;
        return this;
    }

    @JsonProperty("patientGuarantor")
    public PatientGuarantor getPatientGuarantor() {
        return patientGuarantor;
    }

    @JsonProperty("patientGuarantor")
    public void setPatientGuarantor(PatientGuarantor patientGuarantor) {
        this.patientGuarantor = patientGuarantor;
    }

    public CaseGuarantor withPatientGuarantor(PatientGuarantor patientGuarantor) {
        this.patientGuarantor = patientGuarantor;
        return this;
    }

    @JsonProperty("guarantorId")
    public Object getGuarantorId() {
        return guarantorId;
    }

    @JsonProperty("guarantorId")
    public void setGuarantorId(Object guarantorId) {
        this.guarantorId = guarantorId;
    }

    public CaseGuarantor withGuarantorId(Object guarantorId) {
        this.guarantorId = guarantorId;
        return this;
    }

    @JsonProperty("isSelf")
    public Boolean getIsSelf() {
        return isSelf;
    }

    @JsonProperty("isSelf")
    public void setIsSelf(Boolean isSelf) {
        this.isSelf = isSelf;
    }

    public CaseGuarantor withIsSelf(Boolean isSelf) {
        this.isSelf = isSelf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseGuarantor withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sortOrder).append(isActive).append(patientGuarantor).append(guarantorId).append(isSelf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseGuarantor) == false) {
            return false;
        }
        CaseGuarantor rhs = ((CaseGuarantor) other);
        return new EqualsBuilder().append(sortOrder, rhs.sortOrder).append(isActive, rhs.isActive).append(patientGuarantor, rhs.patientGuarantor).append(guarantorId, rhs.guarantorId).append(isSelf, rhs.isSelf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
