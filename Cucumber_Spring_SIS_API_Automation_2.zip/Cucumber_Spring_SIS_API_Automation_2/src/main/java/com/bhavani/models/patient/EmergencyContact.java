
package com.bhavani.models.patient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "firstName",
    "middleInitial",
    "lastName",
    "phoneHome",
    "phoneHomeExtension",
    "relationship"
})
public class EmergencyContact {

    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("phoneHome")
    private String phoneHome;
    @JsonProperty("phoneHomeExtension")
    private String phoneHomeExtension;
    @JsonProperty("relationship")
    private String relationship;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public EmergencyContact withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public EmergencyContact withMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public EmergencyContact withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("phoneHome")
    public String getPhoneHome() {
        return phoneHome;
    }

    @JsonProperty("phoneHome")
    public void setPhoneHome(String phoneHome) {
        this.phoneHome = phoneHome;
    }

    public EmergencyContact withPhoneHome(String phoneHome) {
        this.phoneHome = phoneHome;
        return this;
    }

    @JsonProperty("phoneHomeExtension")
    public String getPhoneHomeExtension() {
        return phoneHomeExtension;
    }

    @JsonProperty("phoneHomeExtension")
    public void setPhoneHomeExtension(String phoneHomeExtension) {
        this.phoneHomeExtension = phoneHomeExtension;
    }

    public EmergencyContact withPhoneHomeExtension(String phoneHomeExtension) {
        this.phoneHomeExtension = phoneHomeExtension;
        return this;
    }

    @JsonProperty("relationship")
    public String getRelationship() {
        return relationship;
    }

    @JsonProperty("relationship")
    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public EmergencyContact withRelationship(String relationship) {
        this.relationship = relationship;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EmergencyContact withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(firstName).append(middleInitial).append(lastName).append(phoneHome).append(phoneHomeExtension).append(relationship).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EmergencyContact) == false) {
            return false;
        }
        EmergencyContact rhs = ((EmergencyContact) other);
        return new EqualsBuilder().append(firstName, rhs.firstName).append(middleInitial, rhs.middleInitial).append(lastName, rhs.lastName).append(phoneHome, rhs.phoneHome).append(phoneHomeExtension, rhs.phoneHomeExtension).append(relationship, rhs.relationship).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
