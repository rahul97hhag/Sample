
package com.bhavani.models.patientCases.caseSummary;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "errors",
    "isDocumentedTf",
    "caseSummaryId",
    "patientId",
    "organizationId",
    "procedureDt",
    "primaryPhysicianId",
    "referringPhysicianId",
    "referringPhysicianName",
    "signatureId",
    "signatureDt",
    "externalId",
    "activeTf",
    "procedureStartDt",
    "procedureStopDt",
    "primaryProcedure",
    "roomId",
    "roomName",
    "arrivalTime",
    "primarySurgeon",
    "caseStatus",
    "appointmentId",
    "appointmentTypeId",
    "appointmentTypeName",
    "caseType",
    "primaryProcedureId",
    "appointmentNote",
    "cleanupTime",
    "preOpDiagnosis",
    "diagnosisId",
    "anesthesiaTypeId",
    "dateOfService",
    "caseProcedures",
    "caseGuarantor",
    "caseInsurances",
    "casePreferenceCards",
    "caseEquipments",
    "caseProcedurePhysName",
    "additionalClaimInfo",
    "anesthesiaTypeName",
    "caseMSPInsuranceTypeMap",
    "sourceIdentifier"
})
public class CaseSummaryFromCaseSummaryId {

    @JsonProperty("errors")
    private Object errors;
    @JsonProperty("isDocumentedTf")
    private Boolean isDocumentedTf;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("procedureDt")
    private String procedureDt;
    @JsonProperty("primaryPhysicianId")
    private Integer primaryPhysicianId;
    @JsonProperty("referringPhysicianId")
    private Object referringPhysicianId;
    @JsonProperty("referringPhysicianName")
    private Object referringPhysicianName;
    @JsonProperty("signatureId")
    private Object signatureId;
    @JsonProperty("signatureDt")
    private Object signatureDt;
    @JsonProperty("externalId")
    private Integer externalId;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("procedureStartDt")
    private String procedureStartDt;
    @JsonProperty("procedureStopDt")
    private String procedureStopDt;
    @JsonProperty("primaryProcedure")
    private Object primaryProcedure;
    @JsonProperty("roomId")
    private Integer roomId;
    @JsonProperty("roomName")
    private Object roomName;
    @JsonProperty("arrivalTime")
    private Object arrivalTime;
    @JsonProperty("primarySurgeon")
    private Object primarySurgeon;
    @JsonProperty("caseStatus")
    private Object caseStatus;
    @JsonProperty("appointmentId")
    private Integer appointmentId;
    @JsonProperty("appointmentTypeId")
    private Integer appointmentTypeId;
    @JsonProperty("appointmentTypeName")
    private Object appointmentTypeName;
    @JsonProperty("caseType")
    private Integer caseType;
    @JsonProperty("primaryProcedureId")
    private Integer primaryProcedureId;
    @JsonProperty("appointmentNote")
    private Object appointmentNote;
    @JsonProperty("cleanupTime")
    private Object cleanupTime;
    @JsonProperty("preOpDiagnosis")
    private Object preOpDiagnosis;
    @JsonProperty("diagnosisId")
    private Object diagnosisId;
    @JsonProperty("anesthesiaTypeId")
    private Object anesthesiaTypeId;
    @JsonProperty("dateOfService")
    private Object dateOfService;
    @JsonProperty("caseProcedures")
    private Object caseProcedures;
    @JsonProperty("caseGuarantor")
    private Object caseGuarantor;
    @JsonProperty("caseInsurances")
    private Object caseInsurances;
    @JsonProperty("casePreferenceCards")
    private Object casePreferenceCards;
    @JsonProperty("caseEquipments")
    private Object caseEquipments;
    @JsonProperty("caseProcedurePhysName")
    private Object caseProcedurePhysName;
    @JsonProperty("additionalClaimInfo")
    private Object additionalClaimInfo;
    @JsonProperty("anesthesiaTypeName")
    private Object anesthesiaTypeName;
    @JsonProperty("caseMSPInsuranceTypeMap")
    private Object caseMSPInsuranceTypeMap;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("errors")
    public Object getErrors() {
        return errors;
    }

    @JsonProperty("errors")
    public void setErrors(Object errors) {
        this.errors = errors;
    }

    public CaseSummaryFromCaseSummaryId withErrors(Object errors) {
        this.errors = errors;
        return this;
    }

    @JsonProperty("isDocumentedTf")
    public Boolean getIsDocumentedTf() {
        return isDocumentedTf;
    }

    @JsonProperty("isDocumentedTf")
    public void setIsDocumentedTf(Boolean isDocumentedTf) {
        this.isDocumentedTf = isDocumentedTf;
    }

    public CaseSummaryFromCaseSummaryId withIsDocumentedTf(Boolean isDocumentedTf) {
        this.isDocumentedTf = isDocumentedTf;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public CaseSummaryFromCaseSummaryId withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public CaseSummaryFromCaseSummaryId withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public CaseSummaryFromCaseSummaryId withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("procedureDt")
    public String getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
    }

    public CaseSummaryFromCaseSummaryId withProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("primaryPhysicianId")
    public Integer getPrimaryPhysicianId() {
        return primaryPhysicianId;
    }

    @JsonProperty("primaryPhysicianId")
    public void setPrimaryPhysicianId(Integer primaryPhysicianId) {
        this.primaryPhysicianId = primaryPhysicianId;
    }

    public CaseSummaryFromCaseSummaryId withPrimaryPhysicianId(Integer primaryPhysicianId) {
        this.primaryPhysicianId = primaryPhysicianId;
        return this;
    }

    @JsonProperty("referringPhysicianId")
    public Object getReferringPhysicianId() {
        return referringPhysicianId;
    }

    @JsonProperty("referringPhysicianId")
    public void setReferringPhysicianId(Object referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
    }

    public CaseSummaryFromCaseSummaryId withReferringPhysicianId(Object referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
        return this;
    }

    @JsonProperty("referringPhysicianName")
    public Object getReferringPhysicianName() {
        return referringPhysicianName;
    }

    @JsonProperty("referringPhysicianName")
    public void setReferringPhysicianName(Object referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
    }

    public CaseSummaryFromCaseSummaryId withReferringPhysicianName(Object referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
        return this;
    }

    @JsonProperty("signatureId")
    public Object getSignatureId() {
        return signatureId;
    }

    @JsonProperty("signatureId")
    public void setSignatureId(Object signatureId) {
        this.signatureId = signatureId;
    }

    public CaseSummaryFromCaseSummaryId withSignatureId(Object signatureId) {
        this.signatureId = signatureId;
        return this;
    }

    @JsonProperty("signatureDt")
    public Object getSignatureDt() {
        return signatureDt;
    }

    @JsonProperty("signatureDt")
    public void setSignatureDt(Object signatureDt) {
        this.signatureDt = signatureDt;
    }

    public CaseSummaryFromCaseSummaryId withSignatureDt(Object signatureDt) {
        this.signatureDt = signatureDt;
        return this;
    }

    @JsonProperty("externalId")
    public Integer getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Integer externalId) {
        this.externalId = externalId;
    }

    public CaseSummaryFromCaseSummaryId withExternalId(Integer externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public CaseSummaryFromCaseSummaryId withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("procedureStartDt")
    public String getProcedureStartDt() {
        return procedureStartDt;
    }

    @JsonProperty("procedureStartDt")
    public void setProcedureStartDt(String procedureStartDt) {
        this.procedureStartDt = procedureStartDt;
    }

    public CaseSummaryFromCaseSummaryId withProcedureStartDt(String procedureStartDt) {
        this.procedureStartDt = procedureStartDt;
        return this;
    }

    @JsonProperty("procedureStopDt")
    public String getProcedureStopDt() {
        return procedureStopDt;
    }

    @JsonProperty("procedureStopDt")
    public void setProcedureStopDt(String procedureStopDt) {
        this.procedureStopDt = procedureStopDt;
    }

    public CaseSummaryFromCaseSummaryId withProcedureStopDt(String procedureStopDt) {
        this.procedureStopDt = procedureStopDt;
        return this;
    }

    @JsonProperty("primaryProcedure")
    public Object getPrimaryProcedure() {
        return primaryProcedure;
    }

    @JsonProperty("primaryProcedure")
    public void setPrimaryProcedure(Object primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
    }

    public CaseSummaryFromCaseSummaryId withPrimaryProcedure(Object primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
        return this;
    }

    @JsonProperty("roomId")
    public Integer getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public CaseSummaryFromCaseSummaryId withRoomId(Integer roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("roomName")
    public Object getRoomName() {
        return roomName;
    }

    @JsonProperty("roomName")
    public void setRoomName(Object roomName) {
        this.roomName = roomName;
    }

    public CaseSummaryFromCaseSummaryId withRoomName(Object roomName) {
        this.roomName = roomName;
        return this;
    }

    @JsonProperty("arrivalTime")
    public Object getArrivalTime() {
        return arrivalTime;
    }

    @JsonProperty("arrivalTime")
    public void setArrivalTime(Object arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public CaseSummaryFromCaseSummaryId withArrivalTime(Object arrivalTime) {
        this.arrivalTime = arrivalTime;
        return this;
    }

    @JsonProperty("primarySurgeon")
    public Object getPrimarySurgeon() {
        return primarySurgeon;
    }

    @JsonProperty("primarySurgeon")
    public void setPrimarySurgeon(Object primarySurgeon) {
        this.primarySurgeon = primarySurgeon;
    }

    public CaseSummaryFromCaseSummaryId withPrimarySurgeon(Object primarySurgeon) {
        this.primarySurgeon = primarySurgeon;
        return this;
    }

    @JsonProperty("caseStatus")
    public Object getCaseStatus() {
        return caseStatus;
    }

    @JsonProperty("caseStatus")
    public void setCaseStatus(Object caseStatus) {
        this.caseStatus = caseStatus;
    }

    public CaseSummaryFromCaseSummaryId withCaseStatus(Object caseStatus) {
        this.caseStatus = caseStatus;
        return this;
    }

    @JsonProperty("appointmentId")
    public Integer getAppointmentId() {
        return appointmentId;
    }

    @JsonProperty("appointmentId")
    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public CaseSummaryFromCaseSummaryId withAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
        return this;
    }

    @JsonProperty("appointmentTypeId")
    public Integer getAppointmentTypeId() {
        return appointmentTypeId;
    }

    @JsonProperty("appointmentTypeId")
    public void setAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
    }

    public CaseSummaryFromCaseSummaryId withAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
        return this;
    }

    @JsonProperty("appointmentTypeName")
    public Object getAppointmentTypeName() {
        return appointmentTypeName;
    }

    @JsonProperty("appointmentTypeName")
    public void setAppointmentTypeName(Object appointmentTypeName) {
        this.appointmentTypeName = appointmentTypeName;
    }

    public CaseSummaryFromCaseSummaryId withAppointmentTypeName(Object appointmentTypeName) {
        this.appointmentTypeName = appointmentTypeName;
        return this;
    }

    @JsonProperty("caseType")
    public Integer getCaseType() {
        return caseType;
    }

    @JsonProperty("caseType")
    public void setCaseType(Integer caseType) {
        this.caseType = caseType;
    }

    public CaseSummaryFromCaseSummaryId withCaseType(Integer caseType) {
        this.caseType = caseType;
        return this;
    }

    @JsonProperty("primaryProcedureId")
    public Integer getPrimaryProcedureId() {
        return primaryProcedureId;
    }

    @JsonProperty("primaryProcedureId")
    public void setPrimaryProcedureId(Integer primaryProcedureId) {
        this.primaryProcedureId = primaryProcedureId;
    }

    public CaseSummaryFromCaseSummaryId withPrimaryProcedureId(Integer primaryProcedureId) {
        this.primaryProcedureId = primaryProcedureId;
        return this;
    }

    @JsonProperty("appointmentNote")
    public Object getAppointmentNote() {
        return appointmentNote;
    }

    @JsonProperty("appointmentNote")
    public void setAppointmentNote(Object appointmentNote) {
        this.appointmentNote = appointmentNote;
    }

    public CaseSummaryFromCaseSummaryId withAppointmentNote(Object appointmentNote) {
        this.appointmentNote = appointmentNote;
        return this;
    }

    @JsonProperty("cleanupTime")
    public Object getCleanupTime() {
        return cleanupTime;
    }

    @JsonProperty("cleanupTime")
    public void setCleanupTime(Object cleanupTime) {
        this.cleanupTime = cleanupTime;
    }

    public CaseSummaryFromCaseSummaryId withCleanupTime(Object cleanupTime) {
        this.cleanupTime = cleanupTime;
        return this;
    }

    @JsonProperty("preOpDiagnosis")
    public Object getPreOpDiagnosis() {
        return preOpDiagnosis;
    }

    @JsonProperty("preOpDiagnosis")
    public void setPreOpDiagnosis(Object preOpDiagnosis) {
        this.preOpDiagnosis = preOpDiagnosis;
    }

    public CaseSummaryFromCaseSummaryId withPreOpDiagnosis(Object preOpDiagnosis) {
        this.preOpDiagnosis = preOpDiagnosis;
        return this;
    }

    @JsonProperty("diagnosisId")
    public Object getDiagnosisId() {
        return diagnosisId;
    }

    @JsonProperty("diagnosisId")
    public void setDiagnosisId(Object diagnosisId) {
        this.diagnosisId = diagnosisId;
    }

    public CaseSummaryFromCaseSummaryId withDiagnosisId(Object diagnosisId) {
        this.diagnosisId = diagnosisId;
        return this;
    }

    @JsonProperty("anesthesiaTypeId")
    public Object getAnesthesiaTypeId() {
        return anesthesiaTypeId;
    }

    @JsonProperty("anesthesiaTypeId")
    public void setAnesthesiaTypeId(Object anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
    }

    public CaseSummaryFromCaseSummaryId withAnesthesiaTypeId(Object anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
        return this;
    }

    @JsonProperty("dateOfService")
    public Object getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(Object dateOfService) {
        this.dateOfService = dateOfService;
    }

    public CaseSummaryFromCaseSummaryId withDateOfService(Object dateOfService) {
        this.dateOfService = dateOfService;
        return this;
    }

    @JsonProperty("caseProcedures")
    public Object getCaseProcedures() {
        return caseProcedures;
    }

    @JsonProperty("caseProcedures")
    public void setCaseProcedures(Object caseProcedures) {
        this.caseProcedures = caseProcedures;
    }

    public CaseSummaryFromCaseSummaryId withCaseProcedures(Object caseProcedures) {
        this.caseProcedures = caseProcedures;
        return this;
    }

    @JsonProperty("caseGuarantor")
    public Object getCaseGuarantor() {
        return caseGuarantor;
    }

    @JsonProperty("caseGuarantor")
    public void setCaseGuarantor(Object caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
    }

    public CaseSummaryFromCaseSummaryId withCaseGuarantor(Object caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
        return this;
    }

    @JsonProperty("caseInsurances")
    public Object getCaseInsurances() {
        return caseInsurances;
    }

    @JsonProperty("caseInsurances")
    public void setCaseInsurances(Object caseInsurances) {
        this.caseInsurances = caseInsurances;
    }

    public CaseSummaryFromCaseSummaryId withCaseInsurances(Object caseInsurances) {
        this.caseInsurances = caseInsurances;
        return this;
    }

    @JsonProperty("casePreferenceCards")
    public Object getCasePreferenceCards() {
        return casePreferenceCards;
    }

    @JsonProperty("casePreferenceCards")
    public void setCasePreferenceCards(Object casePreferenceCards) {
        this.casePreferenceCards = casePreferenceCards;
    }

    public CaseSummaryFromCaseSummaryId withCasePreferenceCards(Object casePreferenceCards) {
        this.casePreferenceCards = casePreferenceCards;
        return this;
    }

    @JsonProperty("caseEquipments")
    public Object getCaseEquipments() {
        return caseEquipments;
    }

    @JsonProperty("caseEquipments")
    public void setCaseEquipments(Object caseEquipments) {
        this.caseEquipments = caseEquipments;
    }

    public CaseSummaryFromCaseSummaryId withCaseEquipments(Object caseEquipments) {
        this.caseEquipments = caseEquipments;
        return this;
    }

    @JsonProperty("caseProcedurePhysName")
    public Object getCaseProcedurePhysName() {
        return caseProcedurePhysName;
    }

    @JsonProperty("caseProcedurePhysName")
    public void setCaseProcedurePhysName(Object caseProcedurePhysName) {
        this.caseProcedurePhysName = caseProcedurePhysName;
    }

    public CaseSummaryFromCaseSummaryId withCaseProcedurePhysName(Object caseProcedurePhysName) {
        this.caseProcedurePhysName = caseProcedurePhysName;
        return this;
    }

    @JsonProperty("additionalClaimInfo")
    public Object getAdditionalClaimInfo() {
        return additionalClaimInfo;
    }

    @JsonProperty("additionalClaimInfo")
    public void setAdditionalClaimInfo(Object additionalClaimInfo) {
        this.additionalClaimInfo = additionalClaimInfo;
    }

    public CaseSummaryFromCaseSummaryId withAdditionalClaimInfo(Object additionalClaimInfo) {
        this.additionalClaimInfo = additionalClaimInfo;
        return this;
    }

    @JsonProperty("anesthesiaTypeName")
    public Object getAnesthesiaTypeName() {
        return anesthesiaTypeName;
    }

    @JsonProperty("anesthesiaTypeName")
    public void setAnesthesiaTypeName(Object anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
    }

    public CaseSummaryFromCaseSummaryId withAnesthesiaTypeName(Object anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
        return this;
    }

    @JsonProperty("caseMSPInsuranceTypeMap")
    public Object getCaseMSPInsuranceTypeMap() {
        return caseMSPInsuranceTypeMap;
    }

    @JsonProperty("caseMSPInsuranceTypeMap")
    public void setCaseMSPInsuranceTypeMap(Object caseMSPInsuranceTypeMap) {
        this.caseMSPInsuranceTypeMap = caseMSPInsuranceTypeMap;
    }

    public CaseSummaryFromCaseSummaryId withCaseMSPInsuranceTypeMap(Object caseMSPInsuranceTypeMap) {
        this.caseMSPInsuranceTypeMap = caseMSPInsuranceTypeMap;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public CaseSummaryFromCaseSummaryId withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseSummaryFromCaseSummaryId withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(errors).append(isDocumentedTf).append(caseSummaryId).append(patientId).append(organizationId).append(procedureDt).append(primaryPhysicianId).append(referringPhysicianId).append(referringPhysicianName).append(signatureId).append(signatureDt).append(externalId).append(activeTf).append(procedureStartDt).append(procedureStopDt).append(primaryProcedure).append(roomId).append(roomName).append(arrivalTime).append(primarySurgeon).append(caseStatus).append(appointmentId).append(appointmentTypeId).append(appointmentTypeName).append(caseType).append(primaryProcedureId).append(appointmentNote).append(cleanupTime).append(preOpDiagnosis).append(diagnosisId).append(anesthesiaTypeId).append(dateOfService).append(caseProcedures).append(caseGuarantor).append(caseInsurances).append(casePreferenceCards).append(caseEquipments).append(caseProcedurePhysName).append(additionalClaimInfo).append(anesthesiaTypeName).append(caseMSPInsuranceTypeMap).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseSummaryFromCaseSummaryId) == false) {
            return false;
        }
        CaseSummaryFromCaseSummaryId rhs = ((CaseSummaryFromCaseSummaryId) other);
        return new EqualsBuilder().append(errors, rhs.errors).append(isDocumentedTf, rhs.isDocumentedTf).append(caseSummaryId, rhs.caseSummaryId).append(patientId, rhs.patientId).append(organizationId, rhs.organizationId).append(procedureDt, rhs.procedureDt).append(primaryPhysicianId, rhs.primaryPhysicianId).append(referringPhysicianId, rhs.referringPhysicianId).append(referringPhysicianName, rhs.referringPhysicianName).append(signatureId, rhs.signatureId).append(signatureDt, rhs.signatureDt).append(externalId, rhs.externalId).append(activeTf, rhs.activeTf).append(procedureStartDt, rhs.procedureStartDt).append(procedureStopDt, rhs.procedureStopDt).append(primaryProcedure, rhs.primaryProcedure).append(roomId, rhs.roomId).append(roomName, rhs.roomName).append(arrivalTime, rhs.arrivalTime).append(primarySurgeon, rhs.primarySurgeon).append(caseStatus, rhs.caseStatus).append(appointmentId, rhs.appointmentId).append(appointmentTypeId, rhs.appointmentTypeId).append(appointmentTypeName, rhs.appointmentTypeName).append(caseType, rhs.caseType).append(primaryProcedureId, rhs.primaryProcedureId).append(appointmentNote, rhs.appointmentNote).append(cleanupTime, rhs.cleanupTime).append(preOpDiagnosis, rhs.preOpDiagnosis).append(diagnosisId, rhs.diagnosisId).append(anesthesiaTypeId, rhs.anesthesiaTypeId).append(dateOfService, rhs.dateOfService).append(caseProcedures, rhs.caseProcedures).append(caseGuarantor, rhs.caseGuarantor).append(caseInsurances, rhs.caseInsurances).append(casePreferenceCards, rhs.casePreferenceCards).append(caseEquipments, rhs.caseEquipments).append(caseProcedurePhysName, rhs.caseProcedurePhysName).append(additionalClaimInfo, rhs.additionalClaimInfo).append(anesthesiaTypeName, rhs.anesthesiaTypeName).append(caseMSPInsuranceTypeMap, rhs.caseMSPInsuranceTypeMap).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
