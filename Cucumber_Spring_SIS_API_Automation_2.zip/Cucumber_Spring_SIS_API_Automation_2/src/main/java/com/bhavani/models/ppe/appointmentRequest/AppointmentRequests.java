
package com.bhavani.models.ppe.appointmentRequest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "applicationScope",
    "caseRequestId",
    "caseRequestStatus",
    "caseSummaryId",
    "organizationId",
    "modifiedByMiddleInitial",
    "isNewCase",
    "contentEncoded"
})
public class AppointmentRequests {

    @JsonProperty("applicationScope")
    private Integer applicationScope;
    @JsonProperty("caseRequestId")
    private Integer caseRequestId;
    @JsonProperty("caseRequestStatus")
    private Object caseRequestStatus;
    @JsonProperty("caseSummaryId")
    private Object caseSummaryId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("modifiedByMiddleInitial")
    private String modifiedByMiddleInitial;
    @JsonProperty("isNewCase")
    private Boolean isNewCase;
    @JsonProperty("contentEncoded")
    private String contentEncoded;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("applicationScope")
    public Integer getApplicationScope() {
        return applicationScope;
    }

    @JsonProperty("applicationScope")
    public void setApplicationScope(Integer applicationScope) {
        this.applicationScope = applicationScope;
    }

    public AppointmentRequests withApplicationScope(Integer applicationScope) {
        this.applicationScope = applicationScope;
        return this;
    }

    @JsonProperty("caseRequestId")
    public Integer getCaseRequestId() {
        return caseRequestId;
    }

    @JsonProperty("caseRequestId")
    public void setCaseRequestId(Integer caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public AppointmentRequests withCaseRequestId(Integer caseRequestId) {
        this.caseRequestId = caseRequestId;
        return this;
    }

    @JsonProperty("caseRequestStatus")
    public Object getCaseRequestStatus() {
        return caseRequestStatus;
    }

    @JsonProperty("caseRequestStatus")
    public void setCaseRequestStatus(Object caseRequestStatus) {
        this.caseRequestStatus = caseRequestStatus;
    }

    public AppointmentRequests withCaseRequestStatus(Object caseRequestStatus) {
        this.caseRequestStatus = caseRequestStatus;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Object getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Object caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public AppointmentRequests withCaseSummaryId(Object caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public AppointmentRequests withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("modifiedByMiddleInitial")
    public String getModifiedByMiddleInitial() {
        return modifiedByMiddleInitial;
    }

    @JsonProperty("modifiedByMiddleInitial")
    public void setModifiedByMiddleInitial(String modifiedByMiddleInitial) {
        this.modifiedByMiddleInitial = modifiedByMiddleInitial;
    }

    public AppointmentRequests withModifiedByMiddleInitial(String modifiedByMiddleInitial) {
        this.modifiedByMiddleInitial = modifiedByMiddleInitial;
        return this;
    }

    @JsonProperty("isNewCase")
    public Boolean getIsNewCase() {
        return isNewCase;
    }

    @JsonProperty("isNewCase")
    public void setIsNewCase(Boolean isNewCase) {
        this.isNewCase = isNewCase;
    }

    public AppointmentRequests withIsNewCase(Boolean isNewCase) {
        this.isNewCase = isNewCase;
        return this;
    }

    @JsonProperty("contentEncoded")
    public String getContentEncoded() {
        return contentEncoded;
    }

    @JsonProperty("contentEncoded")
    public void setContentEncoded(String contentEncoded) {
        this.contentEncoded = contentEncoded;
    }

    public AppointmentRequests withContentEncoded(String contentEncoded) {
        this.contentEncoded = contentEncoded;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AppointmentRequests withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(applicationScope).append(caseRequestId).append(caseRequestStatus).append(caseSummaryId).append(organizationId).append(modifiedByMiddleInitial).append(isNewCase).append(contentEncoded).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AppointmentRequests) == false) {
            return false;
        }
        AppointmentRequests rhs = ((AppointmentRequests) other);
        return new EqualsBuilder().append(applicationScope, rhs.applicationScope).append(caseRequestId, rhs.caseRequestId).append(caseRequestStatus, rhs.caseRequestStatus).append(caseSummaryId, rhs.caseSummaryId).append(organizationId, rhs.organizationId).append(modifiedByMiddleInitial, rhs.modifiedByMiddleInitial).append(isNewCase, rhs.isNewCase).append(contentEncoded, rhs.contentEncoded).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
