
package com.bhavani.models.patientCases.chargeEntry;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "chargeEntryDetailsId",
    "patientInsuranceId",
    "sortOrder",
    "canBillGenerated"
})
public class ChargeEntryPatientInsMap {

    @JsonProperty("chargeEntryDetailsId")
    private Integer chargeEntryDetailsId;
    @JsonProperty("patientInsuranceId")
    private Integer patientInsuranceId;
    @JsonProperty("sortOrder")
    private Integer sortOrder;
    @JsonProperty("canBillGenerated")
    private Boolean canBillGenerated;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("chargeEntryDetailsId")
    public Integer getChargeEntryDetailsId() {
        return chargeEntryDetailsId;
    }

    @JsonProperty("chargeEntryDetailsId")
    public void setChargeEntryDetailsId(Integer chargeEntryDetailsId) {
        this.chargeEntryDetailsId = chargeEntryDetailsId;
    }

    public ChargeEntryPatientInsMap withChargeEntryDetailsId(Integer chargeEntryDetailsId) {
        this.chargeEntryDetailsId = chargeEntryDetailsId;
        return this;
    }

    @JsonProperty("patientInsuranceId")
    public Integer getPatientInsuranceId() {
        return patientInsuranceId;
    }

    @JsonProperty("patientInsuranceId")
    public void setPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
    }

    public ChargeEntryPatientInsMap withPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
        return this;
    }

    @JsonProperty("sortOrder")
    public Integer getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public ChargeEntryPatientInsMap withSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("canBillGenerated")
    public Boolean getCanBillGenerated() {
        return canBillGenerated;
    }

    @JsonProperty("canBillGenerated")
    public void setCanBillGenerated(Boolean canBillGenerated) {
        this.canBillGenerated = canBillGenerated;
    }

    public ChargeEntryPatientInsMap withCanBillGenerated(Boolean canBillGenerated) {
        this.canBillGenerated = canBillGenerated;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChargeEntryPatientInsMap withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(chargeEntryDetailsId).append(patientInsuranceId).append(sortOrder).append(canBillGenerated).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChargeEntryPatientInsMap) == false) {
            return false;
        }
        ChargeEntryPatientInsMap rhs = ((ChargeEntryPatientInsMap) other);
        return new EqualsBuilder().append(chargeEntryDetailsId, rhs.chargeEntryDetailsId).append(patientInsuranceId, rhs.patientInsuranceId).append(sortOrder, rhs.sortOrder).append(canBillGenerated, rhs.canBillGenerated).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
