
package com.bhavani.models.room;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "roomId",
    "organizationId",
    "name",
    "category",
    "quickCode",
    "activeTf",
    "itemId",
    "itemName",
    "sourceIdentifier"
})
public class DictionaryRoom {

    @JsonProperty("roomId")
    private Integer roomId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("category")
    private String category;
    @JsonProperty("quickCode")
    private String quickCode;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("itemId")
    private Integer itemId;
    @JsonProperty("itemName")
    private String itemName;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("roomId")
    public Integer getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public DictionaryRoom withRoomId(Integer roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public DictionaryRoom withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public DictionaryRoom withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("category")
    public String getCategory() {
        return category;
    }

    @JsonProperty("category")
    public void setCategory(String category) {
        this.category = category;
    }

    public DictionaryRoom withCategory(String category) {
        this.category = category;
        return this;
    }

    @JsonProperty("quickCode")
    public String getQuickCode() {
        return quickCode;
    }

    @JsonProperty("quickCode")
    public void setQuickCode(String quickCode) {
        this.quickCode = quickCode;
    }

    public DictionaryRoom withQuickCode(String quickCode) {
        this.quickCode = quickCode;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public DictionaryRoom withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("itemId")
    public Integer getItemId() {
        return itemId;
    }

    @JsonProperty("itemId")
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public DictionaryRoom withItemId(Integer itemId) {
        this.itemId = itemId;
        return this;
    }

    @JsonProperty("itemName")
    public String getItemName() {
        return itemName;
    }

    @JsonProperty("itemName")
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public DictionaryRoom withItemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public DictionaryRoom withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DictionaryRoom withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(roomId).append(organizationId).append(name).append(category).append(quickCode).append(activeTf).append(itemId).append(itemName).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DictionaryRoom) == false) {
            return false;
        }
        DictionaryRoom rhs = ((DictionaryRoom) other);
        return new EqualsBuilder().append(roomId, rhs.roomId).append(organizationId, rhs.organizationId).append(name, rhs.name).append(category, rhs.category).append(quickCode, rhs.quickCode).append(activeTf, rhs.activeTf).append(itemId, rhs.itemId).append(itemName, rhs.itemName).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
