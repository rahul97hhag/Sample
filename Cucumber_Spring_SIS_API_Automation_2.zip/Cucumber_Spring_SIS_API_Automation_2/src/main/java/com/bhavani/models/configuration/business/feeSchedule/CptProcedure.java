
package com.bhavani.models.configuration.business.feeSchedule;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cptProcedureId",
    "cptCode",
    "cptDescription",
    "isHcpcsCode",
    "sourceIdentifier"
})
public class CptProcedure {

    @JsonProperty("cptProcedureId")
    private Integer cptProcedureId;
    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("cptDescription")
    private String cptDescription;
    @JsonProperty("isHcpcsCode")
    private Boolean isHcpcsCode;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cptProcedureId")
    public Integer getCptProcedureId() {
        return cptProcedureId;
    }

    @JsonProperty("cptProcedureId")
    public void setCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
    }

    public CptProcedure withCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
        return this;
    }

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public CptProcedure withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("cptDescription")
    public String getCptDescription() {
        return cptDescription;
    }

    @JsonProperty("cptDescription")
    public void setCptDescription(String cptDescription) {
        this.cptDescription = cptDescription;
    }

    public CptProcedure withCptDescription(String cptDescription) {
        this.cptDescription = cptDescription;
        return this;
    }

    @JsonProperty("isHcpcsCode")
    public Boolean getIsHcpcsCode() {
        return isHcpcsCode;
    }

    @JsonProperty("isHcpcsCode")
    public void setIsHcpcsCode(Boolean isHcpcsCode) {
        this.isHcpcsCode = isHcpcsCode;
    }

    public CptProcedure withIsHcpcsCode(Boolean isHcpcsCode) {
        this.isHcpcsCode = isHcpcsCode;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public CptProcedure withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CptProcedure withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cptProcedureId).append(cptCode).append(cptDescription).append(isHcpcsCode).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CptProcedure) == false) {
            return false;
        }
        CptProcedure rhs = ((CptProcedure) other);
        return new EqualsBuilder().append(cptProcedureId, rhs.cptProcedureId).append(cptCode, rhs.cptCode).append(cptDescription, rhs.cptDescription).append(isHcpcsCode, rhs.isHcpcsCode).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
