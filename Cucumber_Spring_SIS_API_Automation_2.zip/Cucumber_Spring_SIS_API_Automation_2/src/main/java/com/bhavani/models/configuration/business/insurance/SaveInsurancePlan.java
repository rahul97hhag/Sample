
package com.bhavani.models.configuration.business.insurance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insurancePlanId",
    "insuranceCarrierId",
    "planName",
    "savedPlanName",
    "classification",
    "planType",
    "groupInsuranceid",
    "primaryEmcPayerid",
    "secondaryEmcPayerid",
    "primaryHpId",
    "secondaryHpId",
    "defaultPlanTf",
    "acceptAssignmentTf",
    "generateClaimTf",
    "billPrimaryGuarantorTf",
    "contract",
    "address1",
    "city",
    "state",
    "zipCode",
    "extendedZipCode",
    "phoneNumber",
    "contactName",
    "isPlanExist",
    "claimOfficeId",
    "insuranceContractId",
    "insurancePlanIds",
    "paymentTransactionCodeId",
    "paymentTransactionCodeName",
    "writeOffTransactionCodeId",
    "writeOffTransactionCodeName",
    "writeOffGroupId",
    "writeOffGroupName",
    "writeOffReasonId",
    "writeOffReasonName",
    "insurancePlanContractList",
    "sourceIdentifier",
    "planHeaderText1",
    "planHeaderText2",
    "planHeaderText3",
    "isPlanExpanded",
    "isInsurancePlanValid",
    "selectedContracts",
    "previousPhoneValue",
    "selectedState",
    "claimOfficeName"
})
public class SaveInsurancePlan {

    @JsonProperty("insurancePlanId")
    private Integer insurancePlanId;
    @JsonProperty("insuranceCarrierId")
    private Integer insuranceCarrierId;
    @JsonProperty("planName")
    private String planName;
    @JsonProperty("savedPlanName")
    private String savedPlanName;
    @JsonProperty("classification")
    private String classification;
    @JsonProperty("planType")
    private Object planType;
    @JsonProperty("groupInsuranceid")
    private Object groupInsuranceid;
    @JsonProperty("primaryEmcPayerid")
    private String primaryEmcPayerid;
    @JsonProperty("secondaryEmcPayerid")
    private Object secondaryEmcPayerid;
    @JsonProperty("primaryHpId")
    private Object primaryHpId;
    @JsonProperty("secondaryHpId")
    private Object secondaryHpId;
    @JsonProperty("defaultPlanTf")
    private Boolean defaultPlanTf;
    @JsonProperty("acceptAssignmentTf")
    private Boolean acceptAssignmentTf;
    @JsonProperty("generateClaimTf")
    private Boolean generateClaimTf;
    @JsonProperty("billPrimaryGuarantorTf")
    private Boolean billPrimaryGuarantorTf;
    @JsonProperty("contract")
    private String contract;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("extendedZipCode")
    private String extendedZipCode;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("contactName")
    private String contactName;
    @JsonProperty("isPlanExist")
    private Boolean isPlanExist;
    @JsonProperty("claimOfficeId")
    private Integer claimOfficeId;
    @JsonProperty("insuranceContractId")
    private Integer insuranceContractId;
    @JsonProperty("insurancePlanIds")
    private Object insurancePlanIds;
    @JsonProperty("paymentTransactionCodeId")
    private Object paymentTransactionCodeId;
    @JsonProperty("paymentTransactionCodeName")
    private Object paymentTransactionCodeName;
    @JsonProperty("writeOffTransactionCodeId")
    private Object writeOffTransactionCodeId;
    @JsonProperty("writeOffTransactionCodeName")
    private Object writeOffTransactionCodeName;
    @JsonProperty("writeOffGroupId")
    private Object writeOffGroupId;
    @JsonProperty("writeOffGroupName")
    private Object writeOffGroupName;
    @JsonProperty("writeOffReasonId")
    private Object writeOffReasonId;
    @JsonProperty("writeOffReasonName")
    private Object writeOffReasonName;
    @JsonProperty("insurancePlanContractList")
    private List<InsurancePlanContractList> insurancePlanContractList = new ArrayList<InsurancePlanContractList>();
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonProperty("planHeaderText1")
    private String planHeaderText1;
    @JsonProperty("planHeaderText2")
    private String planHeaderText2;
    @JsonProperty("planHeaderText3")
    private String planHeaderText3;
    @JsonProperty("isPlanExpanded")
    private Boolean isPlanExpanded;
    @JsonProperty("isInsurancePlanValid")
    private Boolean isInsurancePlanValid;
    @JsonProperty("selectedContracts")
    private List<SelectedContract> selectedContracts = new ArrayList<SelectedContract>();
    @JsonProperty("previousPhoneValue")
    private String previousPhoneValue;
    @JsonProperty("selectedState")
    private Integer selectedState;
    @JsonProperty("claimOfficeName")
    private String claimOfficeName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insurancePlanId")
    public Integer getInsurancePlanId() {
        return insurancePlanId;
    }

    @JsonProperty("insurancePlanId")
    public void setInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
    }

    public SaveInsurancePlan withInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
        return this;
    }

    @JsonProperty("insuranceCarrierId")
    public Integer getInsuranceCarrierId() {
        return insuranceCarrierId;
    }

    @JsonProperty("insuranceCarrierId")
    public void setInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
    }

    public SaveInsurancePlan withInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
        return this;
    }

    @JsonProperty("planName")
    public String getPlanName() {
        return planName;
    }

    @JsonProperty("planName")
    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public SaveInsurancePlan withPlanName(String planName) {
        this.planName = planName;
        return this;
    }

    @JsonProperty("savedPlanName")
    public String getSavedPlanName() {
        return savedPlanName;
    }

    @JsonProperty("savedPlanName")
    public void setSavedPlanName(String savedPlanName) {
        this.savedPlanName = savedPlanName;
    }

    public SaveInsurancePlan withSavedPlanName(String savedPlanName) {
        this.savedPlanName = savedPlanName;
        return this;
    }

    @JsonProperty("classification")
    public String getClassification() {
        return classification;
    }

    @JsonProperty("classification")
    public void setClassification(String classification) {
        this.classification = classification;
    }

    public SaveInsurancePlan withClassification(String classification) {
        this.classification = classification;
        return this;
    }

    @JsonProperty("planType")
    public Object getPlanType() {
        return planType;
    }

    @JsonProperty("planType")
    public void setPlanType(Object planType) {
        this.planType = planType;
    }

    public SaveInsurancePlan withPlanType(Object planType) {
        this.planType = planType;
        return this;
    }

    @JsonProperty("groupInsuranceid")
    public Object getGroupInsuranceid() {
        return groupInsuranceid;
    }

    @JsonProperty("groupInsuranceid")
    public void setGroupInsuranceid(Object groupInsuranceid) {
        this.groupInsuranceid = groupInsuranceid;
    }

    public SaveInsurancePlan withGroupInsuranceid(Object groupInsuranceid) {
        this.groupInsuranceid = groupInsuranceid;
        return this;
    }

    @JsonProperty("primaryEmcPayerid")
    public String getPrimaryEmcPayerid() {
        return primaryEmcPayerid;
    }

    @JsonProperty("primaryEmcPayerid")
    public void setPrimaryEmcPayerid(String primaryEmcPayerid) {
        this.primaryEmcPayerid = primaryEmcPayerid;
    }

    public SaveInsurancePlan withPrimaryEmcPayerid(String primaryEmcPayerid) {
        this.primaryEmcPayerid = primaryEmcPayerid;
        return this;
    }

    @JsonProperty("secondaryEmcPayerid")
    public Object getSecondaryEmcPayerid() {
        return secondaryEmcPayerid;
    }

    @JsonProperty("secondaryEmcPayerid")
    public void setSecondaryEmcPayerid(Object secondaryEmcPayerid) {
        this.secondaryEmcPayerid = secondaryEmcPayerid;
    }

    public SaveInsurancePlan withSecondaryEmcPayerid(Object secondaryEmcPayerid) {
        this.secondaryEmcPayerid = secondaryEmcPayerid;
        return this;
    }

    @JsonProperty("primaryHpId")
    public Object getPrimaryHpId() {
        return primaryHpId;
    }

    @JsonProperty("primaryHpId")
    public void setPrimaryHpId(Object primaryHpId) {
        this.primaryHpId = primaryHpId;
    }

    public SaveInsurancePlan withPrimaryHpId(Object primaryHpId) {
        this.primaryHpId = primaryHpId;
        return this;
    }

    @JsonProperty("secondaryHpId")
    public Object getSecondaryHpId() {
        return secondaryHpId;
    }

    @JsonProperty("secondaryHpId")
    public void setSecondaryHpId(Object secondaryHpId) {
        this.secondaryHpId = secondaryHpId;
    }

    public SaveInsurancePlan withSecondaryHpId(Object secondaryHpId) {
        this.secondaryHpId = secondaryHpId;
        return this;
    }

    @JsonProperty("defaultPlanTf")
    public Boolean getDefaultPlanTf() {
        return defaultPlanTf;
    }

    @JsonProperty("defaultPlanTf")
    public void setDefaultPlanTf(Boolean defaultPlanTf) {
        this.defaultPlanTf = defaultPlanTf;
    }

    public SaveInsurancePlan withDefaultPlanTf(Boolean defaultPlanTf) {
        this.defaultPlanTf = defaultPlanTf;
        return this;
    }

    @JsonProperty("acceptAssignmentTf")
    public Boolean getAcceptAssignmentTf() {
        return acceptAssignmentTf;
    }

    @JsonProperty("acceptAssignmentTf")
    public void setAcceptAssignmentTf(Boolean acceptAssignmentTf) {
        this.acceptAssignmentTf = acceptAssignmentTf;
    }

    public SaveInsurancePlan withAcceptAssignmentTf(Boolean acceptAssignmentTf) {
        this.acceptAssignmentTf = acceptAssignmentTf;
        return this;
    }

    @JsonProperty("generateClaimTf")
    public Boolean getGenerateClaimTf() {
        return generateClaimTf;
    }

    @JsonProperty("generateClaimTf")
    public void setGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
    }

    public SaveInsurancePlan withGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
        return this;
    }

    @JsonProperty("billPrimaryGuarantorTf")
    public Boolean getBillPrimaryGuarantorTf() {
        return billPrimaryGuarantorTf;
    }

    @JsonProperty("billPrimaryGuarantorTf")
    public void setBillPrimaryGuarantorTf(Boolean billPrimaryGuarantorTf) {
        this.billPrimaryGuarantorTf = billPrimaryGuarantorTf;
    }

    public SaveInsurancePlan withBillPrimaryGuarantorTf(Boolean billPrimaryGuarantorTf) {
        this.billPrimaryGuarantorTf = billPrimaryGuarantorTf;
        return this;
    }

    @JsonProperty("contract")
    public String getContract() {
        return contract;
    }

    @JsonProperty("contract")
    public void setContract(String contract) {
        this.contract = contract;
    }

    public SaveInsurancePlan withContract(String contract) {
        this.contract = contract;
        return this;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public SaveInsurancePlan withAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public SaveInsurancePlan withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public SaveInsurancePlan withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public SaveInsurancePlan withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("extendedZipCode")
    public String getExtendedZipCode() {
        return extendedZipCode;
    }

    @JsonProperty("extendedZipCode")
    public void setExtendedZipCode(String extendedZipCode) {
        this.extendedZipCode = extendedZipCode;
    }

    public SaveInsurancePlan withExtendedZipCode(String extendedZipCode) {
        this.extendedZipCode = extendedZipCode;
        return this;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public SaveInsurancePlan withPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("contactName")
    public String getContactName() {
        return contactName;
    }

    @JsonProperty("contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public SaveInsurancePlan withContactName(String contactName) {
        this.contactName = contactName;
        return this;
    }

    @JsonProperty("isPlanExist")
    public Boolean getIsPlanExist() {
        return isPlanExist;
    }

    @JsonProperty("isPlanExist")
    public void setIsPlanExist(Boolean isPlanExist) {
        this.isPlanExist = isPlanExist;
    }

    public SaveInsurancePlan withIsPlanExist(Boolean isPlanExist) {
        this.isPlanExist = isPlanExist;
        return this;
    }

    @JsonProperty("claimOfficeId")
    public Integer getClaimOfficeId() {
        return claimOfficeId;
    }

    @JsonProperty("claimOfficeId")
    public void setClaimOfficeId(Integer claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
    }

    public SaveInsurancePlan withClaimOfficeId(Integer claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
        return this;
    }

    @JsonProperty("insuranceContractId")
    public Integer getInsuranceContractId() {
        return insuranceContractId;
    }

    @JsonProperty("insuranceContractId")
    public void setInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
    }

    public SaveInsurancePlan withInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
        return this;
    }

    @JsonProperty("insurancePlanIds")
    public Object getInsurancePlanIds() {
        return insurancePlanIds;
    }

    @JsonProperty("insurancePlanIds")
    public void setInsurancePlanIds(Object insurancePlanIds) {
        this.insurancePlanIds = insurancePlanIds;
    }

    public SaveInsurancePlan withInsurancePlanIds(Object insurancePlanIds) {
        this.insurancePlanIds = insurancePlanIds;
        return this;
    }

    @JsonProperty("paymentTransactionCodeId")
    public Object getPaymentTransactionCodeId() {
        return paymentTransactionCodeId;
    }

    @JsonProperty("paymentTransactionCodeId")
    public void setPaymentTransactionCodeId(Object paymentTransactionCodeId) {
        this.paymentTransactionCodeId = paymentTransactionCodeId;
    }

    public SaveInsurancePlan withPaymentTransactionCodeId(Object paymentTransactionCodeId) {
        this.paymentTransactionCodeId = paymentTransactionCodeId;
        return this;
    }

    @JsonProperty("paymentTransactionCodeName")
    public Object getPaymentTransactionCodeName() {
        return paymentTransactionCodeName;
    }

    @JsonProperty("paymentTransactionCodeName")
    public void setPaymentTransactionCodeName(Object paymentTransactionCodeName) {
        this.paymentTransactionCodeName = paymentTransactionCodeName;
    }

    public SaveInsurancePlan withPaymentTransactionCodeName(Object paymentTransactionCodeName) {
        this.paymentTransactionCodeName = paymentTransactionCodeName;
        return this;
    }

    @JsonProperty("writeOffTransactionCodeId")
    public Object getWriteOffTransactionCodeId() {
        return writeOffTransactionCodeId;
    }

    @JsonProperty("writeOffTransactionCodeId")
    public void setWriteOffTransactionCodeId(Object writeOffTransactionCodeId) {
        this.writeOffTransactionCodeId = writeOffTransactionCodeId;
    }

    public SaveInsurancePlan withWriteOffTransactionCodeId(Object writeOffTransactionCodeId) {
        this.writeOffTransactionCodeId = writeOffTransactionCodeId;
        return this;
    }

    @JsonProperty("writeOffTransactionCodeName")
    public Object getWriteOffTransactionCodeName() {
        return writeOffTransactionCodeName;
    }

    @JsonProperty("writeOffTransactionCodeName")
    public void setWriteOffTransactionCodeName(Object writeOffTransactionCodeName) {
        this.writeOffTransactionCodeName = writeOffTransactionCodeName;
    }

    public SaveInsurancePlan withWriteOffTransactionCodeName(Object writeOffTransactionCodeName) {
        this.writeOffTransactionCodeName = writeOffTransactionCodeName;
        return this;
    }

    @JsonProperty("writeOffGroupId")
    public Object getWriteOffGroupId() {
        return writeOffGroupId;
    }

    @JsonProperty("writeOffGroupId")
    public void setWriteOffGroupId(Object writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
    }

    public SaveInsurancePlan withWriteOffGroupId(Object writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
        return this;
    }

    @JsonProperty("writeOffGroupName")
    public Object getWriteOffGroupName() {
        return writeOffGroupName;
    }

    @JsonProperty("writeOffGroupName")
    public void setWriteOffGroupName(Object writeOffGroupName) {
        this.writeOffGroupName = writeOffGroupName;
    }

    public SaveInsurancePlan withWriteOffGroupName(Object writeOffGroupName) {
        this.writeOffGroupName = writeOffGroupName;
        return this;
    }

    @JsonProperty("writeOffReasonId")
    public Object getWriteOffReasonId() {
        return writeOffReasonId;
    }

    @JsonProperty("writeOffReasonId")
    public void setWriteOffReasonId(Object writeOffReasonId) {
        this.writeOffReasonId = writeOffReasonId;
    }

    public SaveInsurancePlan withWriteOffReasonId(Object writeOffReasonId) {
        this.writeOffReasonId = writeOffReasonId;
        return this;
    }

    @JsonProperty("writeOffReasonName")
    public Object getWriteOffReasonName() {
        return writeOffReasonName;
    }

    @JsonProperty("writeOffReasonName")
    public void setWriteOffReasonName(Object writeOffReasonName) {
        this.writeOffReasonName = writeOffReasonName;
    }

    public SaveInsurancePlan withWriteOffReasonName(Object writeOffReasonName) {
        this.writeOffReasonName = writeOffReasonName;
        return this;
    }

    @JsonProperty("insurancePlanContractList")
    public List<InsurancePlanContractList> getInsurancePlanContractList() {
        return insurancePlanContractList;
    }

    @JsonProperty("insurancePlanContractList")
    public void setInsurancePlanContractList(List<InsurancePlanContractList> insurancePlanContractList) {
        this.insurancePlanContractList = insurancePlanContractList;
    }

    public SaveInsurancePlan withInsurancePlanContractList(List<InsurancePlanContractList> insurancePlanContractList) {
        this.insurancePlanContractList = insurancePlanContractList;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public SaveInsurancePlan withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @JsonProperty("planHeaderText1")
    public String getPlanHeaderText1() {
        return planHeaderText1;
    }

    @JsonProperty("planHeaderText1")
    public void setPlanHeaderText1(String planHeaderText1) {
        this.planHeaderText1 = planHeaderText1;
    }

    public SaveInsurancePlan withPlanHeaderText1(String planHeaderText1) {
        this.planHeaderText1 = planHeaderText1;
        return this;
    }

    @JsonProperty("planHeaderText2")
    public String getPlanHeaderText2() {
        return planHeaderText2;
    }

    @JsonProperty("planHeaderText2")
    public void setPlanHeaderText2(String planHeaderText2) {
        this.planHeaderText2 = planHeaderText2;
    }

    public SaveInsurancePlan withPlanHeaderText2(String planHeaderText2) {
        this.planHeaderText2 = planHeaderText2;
        return this;
    }

    @JsonProperty("planHeaderText3")
    public String getPlanHeaderText3() {
        return planHeaderText3;
    }

    @JsonProperty("planHeaderText3")
    public void setPlanHeaderText3(String planHeaderText3) {
        this.planHeaderText3 = planHeaderText3;
    }

    public SaveInsurancePlan withPlanHeaderText3(String planHeaderText3) {
        this.planHeaderText3 = planHeaderText3;
        return this;
    }

    @JsonProperty("isPlanExpanded")
    public Boolean getIsPlanExpanded() {
        return isPlanExpanded;
    }

    @JsonProperty("isPlanExpanded")
    public void setIsPlanExpanded(Boolean isPlanExpanded) {
        this.isPlanExpanded = isPlanExpanded;
    }

    public SaveInsurancePlan withIsPlanExpanded(Boolean isPlanExpanded) {
        this.isPlanExpanded = isPlanExpanded;
        return this;
    }

    @JsonProperty("isInsurancePlanValid")
    public Boolean getIsInsurancePlanValid() {
        return isInsurancePlanValid;
    }

    @JsonProperty("isInsurancePlanValid")
    public void setIsInsurancePlanValid(Boolean isInsurancePlanValid) {
        this.isInsurancePlanValid = isInsurancePlanValid;
    }

    public SaveInsurancePlan withIsInsurancePlanValid(Boolean isInsurancePlanValid) {
        this.isInsurancePlanValid = isInsurancePlanValid;
        return this;
    }

    @JsonProperty("selectedContracts")
    public List<SelectedContract> getSelectedContracts() {
        return selectedContracts;
    }

    @JsonProperty("selectedContracts")
    public void setSelectedContracts(List<SelectedContract> selectedContracts) {
        this.selectedContracts = selectedContracts;
    }

    public SaveInsurancePlan withSelectedContracts(List<SelectedContract> selectedContracts) {
        this.selectedContracts = selectedContracts;
        return this;
    }

    @JsonProperty("previousPhoneValue")
    public String getPreviousPhoneValue() {
        return previousPhoneValue;
    }

    @JsonProperty("previousPhoneValue")
    public void setPreviousPhoneValue(String previousPhoneValue) {
        this.previousPhoneValue = previousPhoneValue;
    }

    public SaveInsurancePlan withPreviousPhoneValue(String previousPhoneValue) {
        this.previousPhoneValue = previousPhoneValue;
        return this;
    }

    @JsonProperty("selectedState")
    public Integer getSelectedState() {
        return selectedState;
    }

    @JsonProperty("selectedState")
    public void setSelectedState(Integer selectedState) {
        this.selectedState = selectedState;
    }

    public SaveInsurancePlan withSelectedState(Integer selectedState) {
        this.selectedState = selectedState;
        return this;
    }

    @JsonProperty("claimOfficeName")
    public String getClaimOfficeName() {
        return claimOfficeName;
    }

    @JsonProperty("claimOfficeName")
    public void setClaimOfficeName(String claimOfficeName) {
        this.claimOfficeName = claimOfficeName;
    }

    public SaveInsurancePlan withClaimOfficeName(String claimOfficeName) {
        this.claimOfficeName = claimOfficeName;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SaveInsurancePlan withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insurancePlanId).append(insuranceCarrierId).append(planName).append(savedPlanName).append(classification).append(planType).append(groupInsuranceid).append(primaryEmcPayerid).append(secondaryEmcPayerid).append(primaryHpId).append(secondaryHpId).append(defaultPlanTf).append(acceptAssignmentTf).append(generateClaimTf).append(billPrimaryGuarantorTf).append(contract).append(address1).append(city).append(state).append(zipCode).append(extendedZipCode).append(phoneNumber).append(contactName).append(isPlanExist).append(claimOfficeId).append(insuranceContractId).append(insurancePlanIds).append(paymentTransactionCodeId).append(paymentTransactionCodeName).append(writeOffTransactionCodeId).append(writeOffTransactionCodeName).append(writeOffGroupId).append(writeOffGroupName).append(writeOffReasonId).append(writeOffReasonName).append(insurancePlanContractList).append(sourceIdentifier).append(planHeaderText1).append(planHeaderText2).append(planHeaderText3).append(isPlanExpanded).append(isInsurancePlanValid).append(selectedContracts).append(previousPhoneValue).append(selectedState).append(claimOfficeName).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaveInsurancePlan) == false) {
            return false;
        }
        SaveInsurancePlan rhs = ((SaveInsurancePlan) other);
        return new EqualsBuilder().append(insurancePlanId, rhs.insurancePlanId).append(insuranceCarrierId, rhs.insuranceCarrierId).append(planName, rhs.planName).append(savedPlanName, rhs.savedPlanName).append(classification, rhs.classification).append(planType, rhs.planType).append(groupInsuranceid, rhs.groupInsuranceid).append(primaryEmcPayerid, rhs.primaryEmcPayerid).append(secondaryEmcPayerid, rhs.secondaryEmcPayerid).append(primaryHpId, rhs.primaryHpId).append(secondaryHpId, rhs.secondaryHpId).append(defaultPlanTf, rhs.defaultPlanTf).append(acceptAssignmentTf, rhs.acceptAssignmentTf).append(generateClaimTf, rhs.generateClaimTf).append(billPrimaryGuarantorTf, rhs.billPrimaryGuarantorTf).append(contract, rhs.contract).append(address1, rhs.address1).append(city, rhs.city).append(state, rhs.state).append(zipCode, rhs.zipCode).append(extendedZipCode, rhs.extendedZipCode).append(phoneNumber, rhs.phoneNumber).append(contactName, rhs.contactName).append(isPlanExist, rhs.isPlanExist).append(claimOfficeId, rhs.claimOfficeId).append(insuranceContractId, rhs.insuranceContractId).append(insurancePlanIds, rhs.insurancePlanIds).append(paymentTransactionCodeId, rhs.paymentTransactionCodeId).append(paymentTransactionCodeName, rhs.paymentTransactionCodeName).append(writeOffTransactionCodeId, rhs.writeOffTransactionCodeId).append(writeOffTransactionCodeName, rhs.writeOffTransactionCodeName).append(writeOffGroupId, rhs.writeOffGroupId).append(writeOffGroupName, rhs.writeOffGroupName).append(writeOffReasonId, rhs.writeOffReasonId).append(writeOffReasonName, rhs.writeOffReasonName).append(insurancePlanContractList, rhs.insurancePlanContractList).append(sourceIdentifier, rhs.sourceIdentifier).append(planHeaderText1, rhs.planHeaderText1).append(planHeaderText2, rhs.planHeaderText2).append(planHeaderText3, rhs.planHeaderText3).append(isPlanExpanded, rhs.isPlanExpanded).append(isInsurancePlanValid, rhs.isInsurancePlanValid).append(selectedContracts, rhs.selectedContracts).append(previousPhoneValue, rhs.previousPhoneValue).append(selectedState, rhs.selectedState).append(claimOfficeName, rhs.claimOfficeName).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
