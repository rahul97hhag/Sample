
package com.bhavani.models.patientCases.chargeEntry;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "chargeDetails",
    "writeOffDetails",
    "paymentDetails",
    "transactionId",
    "periodId",
    "batchId",
    "batchDescription",
    "createdDate",
    "createdUserId",
    "postedDate",
    "transactionDate",
    "amount",
    "transactionTypeId",
    "transactionCodeId",
    "transactionParentId",
    "transactionRootId",
    "transactionResponsiblePartyId",
    "currentResponsiblePartyId",
    "currentResponsiblePartyType",
    "transactionResponsiblePartyName",
    "batchIsActive",
    "notes",
    "unassignedPaymentDetail",
    "paymentAllocationDetail",
    "isDeleted",
    "isPaymentTransfer",
    "transactionCodeName",
    "receivedFrom",
    "isEditable",
    "lastModifiedAmount",
    "contractProcedureId",
    "creatorId",
    "checkInPaymentId",
    "batchCloserUserId",
    "periodCloserUserId",
    "periodName",
    "transferTo",
    "impactedTransactions",
    "sourceIdentifier",
    "isHidden",
    "period",
    "batch"
})
public class TransactionList {

    @JsonProperty("chargeDetails")
    private ChargeDetails chargeDetails;
    @JsonProperty("writeOffDetails")
    private Object writeOffDetails;
    @JsonProperty("paymentDetails")
    private Object paymentDetails;
    @JsonProperty("transactionId")
    private Integer transactionId;
    @JsonProperty("periodId")
    private Integer periodId;
    @JsonProperty("batchId")
    private Integer batchId;
    @JsonProperty("batchDescription")
    private String batchDescription;
    @JsonProperty("createdDate")
    private String createdDate;
    @JsonProperty("createdUserId")
    private Integer createdUserId;
    @JsonProperty("postedDate")
    private Object postedDate;
    @JsonProperty("transactionDate")
    private Object transactionDate;
    @JsonProperty("amount")
    private Integer amount;
    @JsonProperty("transactionTypeId")
    private Integer transactionTypeId;
    @JsonProperty("transactionCodeId")
    private Object transactionCodeId;
    @JsonProperty("transactionParentId")
    private Integer transactionParentId;
    @JsonProperty("transactionRootId")
    private Integer transactionRootId;
    @JsonProperty("transactionResponsiblePartyId")
    private Object transactionResponsiblePartyId;
    @JsonProperty("currentResponsiblePartyId")
    private Object currentResponsiblePartyId;
    @JsonProperty("currentResponsiblePartyType")
    private Object currentResponsiblePartyType;
    @JsonProperty("transactionResponsiblePartyName")
    private Object transactionResponsiblePartyName;
    @JsonProperty("batchIsActive")
    private Boolean batchIsActive;
    @JsonProperty("notes")
    private Object notes;
    @JsonProperty("unassignedPaymentDetail")
    private Object unassignedPaymentDetail;
    @JsonProperty("paymentAllocationDetail")
    private Object paymentAllocationDetail;
    @JsonProperty("isDeleted")
    private Boolean isDeleted;
    @JsonProperty("isPaymentTransfer")
    private Boolean isPaymentTransfer;
    @JsonProperty("transactionCodeName")
    private Object transactionCodeName;
    @JsonProperty("receivedFrom")
    private Object receivedFrom;
    @JsonProperty("isEditable")
    private Object isEditable;
    @JsonProperty("lastModifiedAmount")
    private Object lastModifiedAmount;
    @JsonProperty("contractProcedureId")
    private Object contractProcedureId;
    @JsonProperty("creatorId")
    private Integer creatorId;
    @JsonProperty("checkInPaymentId")
    private Object checkInPaymentId;
    @JsonProperty("batchCloserUserId")
    private Object batchCloserUserId;
    @JsonProperty("periodCloserUserId")
    private Object periodCloserUserId;
    @JsonProperty("periodName")
    private Object periodName;
    @JsonProperty("transferTo")
    private Object transferTo;
    @JsonProperty("impactedTransactions")
    private Object impactedTransactions;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonProperty("isHidden")
    private Boolean isHidden;
    @JsonProperty("period")
    private Period period;
    @JsonProperty("batch")
    private Batch batch;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("chargeDetails")
    public ChargeDetails getChargeDetails() {
        return chargeDetails;
    }

    @JsonProperty("chargeDetails")
    public void setChargeDetails(ChargeDetails chargeDetails) {
        this.chargeDetails = chargeDetails;
    }

    public TransactionList withChargeDetails(ChargeDetails chargeDetails) {
        this.chargeDetails = chargeDetails;
        return this;
    }

    @JsonProperty("writeOffDetails")
    public Object getWriteOffDetails() {
        return writeOffDetails;
    }

    @JsonProperty("writeOffDetails")
    public void setWriteOffDetails(Object writeOffDetails) {
        this.writeOffDetails = writeOffDetails;
    }

    public TransactionList withWriteOffDetails(Object writeOffDetails) {
        this.writeOffDetails = writeOffDetails;
        return this;
    }

    @JsonProperty("paymentDetails")
    public Object getPaymentDetails() {
        return paymentDetails;
    }

    @JsonProperty("paymentDetails")
    public void setPaymentDetails(Object paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

    public TransactionList withPaymentDetails(Object paymentDetails) {
        this.paymentDetails = paymentDetails;
        return this;
    }

    @JsonProperty("transactionId")
    public Integer getTransactionId() {
        return transactionId;
    }

    @JsonProperty("transactionId")
    public void setTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
    }

    public TransactionList withTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
        return this;
    }

    @JsonProperty("periodId")
    public Integer getPeriodId() {
        return periodId;
    }

    @JsonProperty("periodId")
    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public TransactionList withPeriodId(Integer periodId) {
        this.periodId = periodId;
        return this;
    }

    @JsonProperty("batchId")
    public Integer getBatchId() {
        return batchId;
    }

    @JsonProperty("batchId")
    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public TransactionList withBatchId(Integer batchId) {
        this.batchId = batchId;
        return this;
    }

    @JsonProperty("batchDescription")
    public String getBatchDescription() {
        return batchDescription;
    }

    @JsonProperty("batchDescription")
    public void setBatchDescription(String batchDescription) {
        this.batchDescription = batchDescription;
    }

    public TransactionList withBatchDescription(String batchDescription) {
        this.batchDescription = batchDescription;
        return this;
    }

    @JsonProperty("createdDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("createdDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public TransactionList withCreatedDate(String createdDate) {
        this.createdDate = createdDate;
        return this;
    }

    @JsonProperty("createdUserId")
    public Integer getCreatedUserId() {
        return createdUserId;
    }

    @JsonProperty("createdUserId")
    public void setCreatedUserId(Integer createdUserId) {
        this.createdUserId = createdUserId;
    }

    public TransactionList withCreatedUserId(Integer createdUserId) {
        this.createdUserId = createdUserId;
        return this;
    }

    @JsonProperty("postedDate")
    public Object getPostedDate() {
        return postedDate;
    }

    @JsonProperty("postedDate")
    public void setPostedDate(Object postedDate) {
        this.postedDate = postedDate;
    }

    public TransactionList withPostedDate(Object postedDate) {
        this.postedDate = postedDate;
        return this;
    }

    @JsonProperty("transactionDate")
    public Object getTransactionDate() {
        return transactionDate;
    }

    @JsonProperty("transactionDate")
    public void setTransactionDate(Object transactionDate) {
        this.transactionDate = transactionDate;
    }

    public TransactionList withTransactionDate(Object transactionDate) {
        this.transactionDate = transactionDate;
        return this;
    }

    @JsonProperty("amount")
    public Integer getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public TransactionList withAmount(Integer amount) {
        this.amount = amount;
        return this;
    }

    @JsonProperty("transactionTypeId")
    public Integer getTransactionTypeId() {
        return transactionTypeId;
    }

    @JsonProperty("transactionTypeId")
    public void setTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    public TransactionList withTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
        return this;
    }

    @JsonProperty("transactionCodeId")
    public Object getTransactionCodeId() {
        return transactionCodeId;
    }

    @JsonProperty("transactionCodeId")
    public void setTransactionCodeId(Object transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
    }

    public TransactionList withTransactionCodeId(Object transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
        return this;
    }

    @JsonProperty("transactionParentId")
    public Integer getTransactionParentId() {
        return transactionParentId;
    }

    @JsonProperty("transactionParentId")
    public void setTransactionParentId(Integer transactionParentId) {
        this.transactionParentId = transactionParentId;
    }

    public TransactionList withTransactionParentId(Integer transactionParentId) {
        this.transactionParentId = transactionParentId;
        return this;
    }

    @JsonProperty("transactionRootId")
    public Integer getTransactionRootId() {
        return transactionRootId;
    }

    @JsonProperty("transactionRootId")
    public void setTransactionRootId(Integer transactionRootId) {
        this.transactionRootId = transactionRootId;
    }

    public TransactionList withTransactionRootId(Integer transactionRootId) {
        this.transactionRootId = transactionRootId;
        return this;
    }

    @JsonProperty("transactionResponsiblePartyId")
    public Object getTransactionResponsiblePartyId() {
        return transactionResponsiblePartyId;
    }

    @JsonProperty("transactionResponsiblePartyId")
    public void setTransactionResponsiblePartyId(Object transactionResponsiblePartyId) {
        this.transactionResponsiblePartyId = transactionResponsiblePartyId;
    }

    public TransactionList withTransactionResponsiblePartyId(Object transactionResponsiblePartyId) {
        this.transactionResponsiblePartyId = transactionResponsiblePartyId;
        return this;
    }

    @JsonProperty("currentResponsiblePartyId")
    public Object getCurrentResponsiblePartyId() {
        return currentResponsiblePartyId;
    }

    @JsonProperty("currentResponsiblePartyId")
    public void setCurrentResponsiblePartyId(Object currentResponsiblePartyId) {
        this.currentResponsiblePartyId = currentResponsiblePartyId;
    }

    public TransactionList withCurrentResponsiblePartyId(Object currentResponsiblePartyId) {
        this.currentResponsiblePartyId = currentResponsiblePartyId;
        return this;
    }

    @JsonProperty("currentResponsiblePartyType")
    public Object getCurrentResponsiblePartyType() {
        return currentResponsiblePartyType;
    }

    @JsonProperty("currentResponsiblePartyType")
    public void setCurrentResponsiblePartyType(Object currentResponsiblePartyType) {
        this.currentResponsiblePartyType = currentResponsiblePartyType;
    }

    public TransactionList withCurrentResponsiblePartyType(Object currentResponsiblePartyType) {
        this.currentResponsiblePartyType = currentResponsiblePartyType;
        return this;
    }

    @JsonProperty("transactionResponsiblePartyName")
    public Object getTransactionResponsiblePartyName() {
        return transactionResponsiblePartyName;
    }

    @JsonProperty("transactionResponsiblePartyName")
    public void setTransactionResponsiblePartyName(Object transactionResponsiblePartyName) {
        this.transactionResponsiblePartyName = transactionResponsiblePartyName;
    }

    public TransactionList withTransactionResponsiblePartyName(Object transactionResponsiblePartyName) {
        this.transactionResponsiblePartyName = transactionResponsiblePartyName;
        return this;
    }

    @JsonProperty("batchIsActive")
    public Boolean getBatchIsActive() {
        return batchIsActive;
    }

    @JsonProperty("batchIsActive")
    public void setBatchIsActive(Boolean batchIsActive) {
        this.batchIsActive = batchIsActive;
    }

    public TransactionList withBatchIsActive(Boolean batchIsActive) {
        this.batchIsActive = batchIsActive;
        return this;
    }

    @JsonProperty("notes")
    public Object getNotes() {
        return notes;
    }

    @JsonProperty("notes")
    public void setNotes(Object notes) {
        this.notes = notes;
    }

    public TransactionList withNotes(Object notes) {
        this.notes = notes;
        return this;
    }

    @JsonProperty("unassignedPaymentDetail")
    public Object getUnassignedPaymentDetail() {
        return unassignedPaymentDetail;
    }

    @JsonProperty("unassignedPaymentDetail")
    public void setUnassignedPaymentDetail(Object unassignedPaymentDetail) {
        this.unassignedPaymentDetail = unassignedPaymentDetail;
    }

    public TransactionList withUnassignedPaymentDetail(Object unassignedPaymentDetail) {
        this.unassignedPaymentDetail = unassignedPaymentDetail;
        return this;
    }

    @JsonProperty("paymentAllocationDetail")
    public Object getPaymentAllocationDetail() {
        return paymentAllocationDetail;
    }

    @JsonProperty("paymentAllocationDetail")
    public void setPaymentAllocationDetail(Object paymentAllocationDetail) {
        this.paymentAllocationDetail = paymentAllocationDetail;
    }

    public TransactionList withPaymentAllocationDetail(Object paymentAllocationDetail) {
        this.paymentAllocationDetail = paymentAllocationDetail;
        return this;
    }

    @JsonProperty("isDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("isDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public TransactionList withIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
        return this;
    }

    @JsonProperty("isPaymentTransfer")
    public Boolean getIsPaymentTransfer() {
        return isPaymentTransfer;
    }

    @JsonProperty("isPaymentTransfer")
    public void setIsPaymentTransfer(Boolean isPaymentTransfer) {
        this.isPaymentTransfer = isPaymentTransfer;
    }

    public TransactionList withIsPaymentTransfer(Boolean isPaymentTransfer) {
        this.isPaymentTransfer = isPaymentTransfer;
        return this;
    }

    @JsonProperty("transactionCodeName")
    public Object getTransactionCodeName() {
        return transactionCodeName;
    }

    @JsonProperty("transactionCodeName")
    public void setTransactionCodeName(Object transactionCodeName) {
        this.transactionCodeName = transactionCodeName;
    }

    public TransactionList withTransactionCodeName(Object transactionCodeName) {
        this.transactionCodeName = transactionCodeName;
        return this;
    }

    @JsonProperty("receivedFrom")
    public Object getReceivedFrom() {
        return receivedFrom;
    }

    @JsonProperty("receivedFrom")
    public void setReceivedFrom(Object receivedFrom) {
        this.receivedFrom = receivedFrom;
    }

    public TransactionList withReceivedFrom(Object receivedFrom) {
        this.receivedFrom = receivedFrom;
        return this;
    }

    @JsonProperty("isEditable")
    public Object getIsEditable() {
        return isEditable;
    }

    @JsonProperty("isEditable")
    public void setIsEditable(Object isEditable) {
        this.isEditable = isEditable;
    }

    public TransactionList withIsEditable(Object isEditable) {
        this.isEditable = isEditable;
        return this;
    }

    @JsonProperty("lastModifiedAmount")
    public Object getLastModifiedAmount() {
        return lastModifiedAmount;
    }

    @JsonProperty("lastModifiedAmount")
    public void setLastModifiedAmount(Object lastModifiedAmount) {
        this.lastModifiedAmount = lastModifiedAmount;
    }

    public TransactionList withLastModifiedAmount(Object lastModifiedAmount) {
        this.lastModifiedAmount = lastModifiedAmount;
        return this;
    }

    @JsonProperty("contractProcedureId")
    public Object getContractProcedureId() {
        return contractProcedureId;
    }

    @JsonProperty("contractProcedureId")
    public void setContractProcedureId(Object contractProcedureId) {
        this.contractProcedureId = contractProcedureId;
    }

    public TransactionList withContractProcedureId(Object contractProcedureId) {
        this.contractProcedureId = contractProcedureId;
        return this;
    }

    @JsonProperty("creatorId")
    public Integer getCreatorId() {
        return creatorId;
    }

    @JsonProperty("creatorId")
    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public TransactionList withCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
        return this;
    }

    @JsonProperty("checkInPaymentId")
    public Object getCheckInPaymentId() {
        return checkInPaymentId;
    }

    @JsonProperty("checkInPaymentId")
    public void setCheckInPaymentId(Object checkInPaymentId) {
        this.checkInPaymentId = checkInPaymentId;
    }

    public TransactionList withCheckInPaymentId(Object checkInPaymentId) {
        this.checkInPaymentId = checkInPaymentId;
        return this;
    }

    @JsonProperty("batchCloserUserId")
    public Object getBatchCloserUserId() {
        return batchCloserUserId;
    }

    @JsonProperty("batchCloserUserId")
    public void setBatchCloserUserId(Object batchCloserUserId) {
        this.batchCloserUserId = batchCloserUserId;
    }

    public TransactionList withBatchCloserUserId(Object batchCloserUserId) {
        this.batchCloserUserId = batchCloserUserId;
        return this;
    }

    @JsonProperty("periodCloserUserId")
    public Object getPeriodCloserUserId() {
        return periodCloserUserId;
    }

    @JsonProperty("periodCloserUserId")
    public void setPeriodCloserUserId(Object periodCloserUserId) {
        this.periodCloserUserId = periodCloserUserId;
    }

    public TransactionList withPeriodCloserUserId(Object periodCloserUserId) {
        this.periodCloserUserId = periodCloserUserId;
        return this;
    }

    @JsonProperty("periodName")
    public Object getPeriodName() {
        return periodName;
    }

    @JsonProperty("periodName")
    public void setPeriodName(Object periodName) {
        this.periodName = periodName;
    }

    public TransactionList withPeriodName(Object periodName) {
        this.periodName = periodName;
        return this;
    }

    @JsonProperty("transferTo")
    public Object getTransferTo() {
        return transferTo;
    }

    @JsonProperty("transferTo")
    public void setTransferTo(Object transferTo) {
        this.transferTo = transferTo;
    }

    public TransactionList withTransferTo(Object transferTo) {
        this.transferTo = transferTo;
        return this;
    }

    @JsonProperty("impactedTransactions")
    public Object getImpactedTransactions() {
        return impactedTransactions;
    }

    @JsonProperty("impactedTransactions")
    public void setImpactedTransactions(Object impactedTransactions) {
        this.impactedTransactions = impactedTransactions;
    }

    public TransactionList withImpactedTransactions(Object impactedTransactions) {
        this.impactedTransactions = impactedTransactions;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public TransactionList withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @JsonProperty("isHidden")
    public Boolean getIsHidden() {
        return isHidden;
    }

    @JsonProperty("isHidden")
    public void setIsHidden(Boolean isHidden) {
        this.isHidden = isHidden;
    }

    public TransactionList withIsHidden(Boolean isHidden) {
        this.isHidden = isHidden;
        return this;
    }

    @JsonProperty("period")
    public Period getPeriod() {
        return period;
    }

    @JsonProperty("period")
    public void setPeriod(Period period) {
        this.period = period;
    }

    public TransactionList withPeriod(Period period) {
        this.period = period;
        return this;
    }

    @JsonProperty("batch")
    public Batch getBatch() {
        return batch;
    }

    @JsonProperty("batch")
    public void setBatch(Batch batch) {
        this.batch = batch;
    }

    public TransactionList withBatch(Batch batch) {
        this.batch = batch;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TransactionList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(chargeDetails).append(writeOffDetails).append(paymentDetails).append(transactionId).append(periodId).append(batchId).append(batchDescription).append(createdDate).append(createdUserId).append(postedDate).append(transactionDate).append(amount).append(transactionTypeId).append(transactionCodeId).append(transactionParentId).append(transactionRootId).append(transactionResponsiblePartyId).append(currentResponsiblePartyId).append(currentResponsiblePartyType).append(transactionResponsiblePartyName).append(batchIsActive).append(notes).append(unassignedPaymentDetail).append(paymentAllocationDetail).append(isDeleted).append(isPaymentTransfer).append(transactionCodeName).append(receivedFrom).append(isEditable).append(lastModifiedAmount).append(contractProcedureId).append(creatorId).append(checkInPaymentId).append(batchCloserUserId).append(periodCloserUserId).append(periodName).append(transferTo).append(impactedTransactions).append(sourceIdentifier).append(isHidden).append(period).append(batch).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TransactionList) == false) {
            return false;
        }
        TransactionList rhs = ((TransactionList) other);
        return new EqualsBuilder().append(chargeDetails, rhs.chargeDetails).append(writeOffDetails, rhs.writeOffDetails).append(paymentDetails, rhs.paymentDetails).append(transactionId, rhs.transactionId).append(periodId, rhs.periodId).append(batchId, rhs.batchId).append(batchDescription, rhs.batchDescription).append(createdDate, rhs.createdDate).append(createdUserId, rhs.createdUserId).append(postedDate, rhs.postedDate).append(transactionDate, rhs.transactionDate).append(amount, rhs.amount).append(transactionTypeId, rhs.transactionTypeId).append(transactionCodeId, rhs.transactionCodeId).append(transactionParentId, rhs.transactionParentId).append(transactionRootId, rhs.transactionRootId).append(transactionResponsiblePartyId, rhs.transactionResponsiblePartyId).append(currentResponsiblePartyId, rhs.currentResponsiblePartyId).append(currentResponsiblePartyType, rhs.currentResponsiblePartyType).append(transactionResponsiblePartyName, rhs.transactionResponsiblePartyName).append(batchIsActive, rhs.batchIsActive).append(notes, rhs.notes).append(unassignedPaymentDetail, rhs.unassignedPaymentDetail).append(paymentAllocationDetail, rhs.paymentAllocationDetail).append(isDeleted, rhs.isDeleted).append(isPaymentTransfer, rhs.isPaymentTransfer).append(transactionCodeName, rhs.transactionCodeName).append(receivedFrom, rhs.receivedFrom).append(isEditable, rhs.isEditable).append(lastModifiedAmount, rhs.lastModifiedAmount).append(contractProcedureId, rhs.contractProcedureId).append(creatorId, rhs.creatorId).append(checkInPaymentId, rhs.checkInPaymentId).append(batchCloserUserId, rhs.batchCloserUserId).append(periodCloserUserId, rhs.periodCloserUserId).append(periodName, rhs.periodName).append(transferTo, rhs.transferTo).append(impactedTransactions, rhs.impactedTransactions).append(sourceIdentifier, rhs.sourceIdentifier).append(isHidden, rhs.isHidden).append(period, rhs.period).append(batch, rhs.batch).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
