
package com.bhavani.models.patientCases.chargeEntryResponse;

import java.util.HashMap;
import java.util.Map;


import com.bhavani.models.patientCases.casesToCodeResponse.DictionaryItem;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "diagnosisPerformedCaseProcedureMapId",
    "diagnosisId",
    "sortOrder",
    "dictionaryItem",
    "sourceIdentifier"
})
public class DiagnosisList {

    @JsonProperty("diagnosisPerformedCaseProcedureMapId")
    private Integer diagnosisPerformedCaseProcedureMapId;
    @JsonProperty("diagnosisId")
    private Integer diagnosisId;
    @JsonProperty("sortOrder")
    private Integer sortOrder;
    @JsonProperty("dictionaryItem")
    private DictionaryItem dictionaryItem;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("diagnosisPerformedCaseProcedureMapId")
    public Integer getDiagnosisPerformedCaseProcedureMapId() {
        return diagnosisPerformedCaseProcedureMapId;
    }

    @JsonProperty("diagnosisPerformedCaseProcedureMapId")
    public void setDiagnosisPerformedCaseProcedureMapId(Integer diagnosisPerformedCaseProcedureMapId) {
        this.diagnosisPerformedCaseProcedureMapId = diagnosisPerformedCaseProcedureMapId;
    }

    public DiagnosisList withDiagnosisPerformedCaseProcedureMapId(Integer diagnosisPerformedCaseProcedureMapId) {
        this.diagnosisPerformedCaseProcedureMapId = diagnosisPerformedCaseProcedureMapId;
        return this;
    }

    @JsonProperty("diagnosisId")
    public Integer getDiagnosisId() {
        return diagnosisId;
    }

    @JsonProperty("diagnosisId")
    public void setDiagnosisId(Integer diagnosisId) {
        this.diagnosisId = diagnosisId;
    }

    public DiagnosisList withDiagnosisId(Integer diagnosisId) {
        this.diagnosisId = diagnosisId;
        return this;
    }

    @JsonProperty("sortOrder")
    public Integer getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public DiagnosisList withSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("dictionaryItem")
    public DictionaryItem getDictionaryItem() {
        return dictionaryItem;
    }

    @JsonProperty("dictionaryItem")
    public void setDictionaryItem(DictionaryItem dictionaryItem) {
        this.dictionaryItem = dictionaryItem;
    }

    public DiagnosisList withDictionaryItem(DictionaryItem dictionaryItem) {
        this.dictionaryItem = dictionaryItem;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public DiagnosisList withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DiagnosisList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(diagnosisPerformedCaseProcedureMapId).append(diagnosisId).append(sortOrder).append(dictionaryItem).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DiagnosisList) == false) {
            return false;
        }
        DiagnosisList rhs = ((DiagnosisList) other);
        return new EqualsBuilder().append(diagnosisPerformedCaseProcedureMapId, rhs.diagnosisPerformedCaseProcedureMapId).append(diagnosisId, rhs.diagnosisId).append(sortOrder, rhs.sortOrder).append(dictionaryItem, rhs.dictionaryItem).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
