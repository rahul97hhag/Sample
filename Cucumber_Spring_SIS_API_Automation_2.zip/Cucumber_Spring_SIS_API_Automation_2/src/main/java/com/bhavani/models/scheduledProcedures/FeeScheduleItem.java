
package com.bhavani.models.scheduledProcedures;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "feeScheduleId",
    "procedure",
    "organizationId",
    "cptProcedureId",
    "cptProcedure",
    "modifiedProcedureDescription",
    "status",
    "amount",
    "effectiveDate",
    "feeScheduleHistoryId",
    "feeScheduleRootId",
    "activeTf",
    "isIncludeStateReportTf",
    "sourceIdentifier"
})
public class FeeScheduleItem {

    @JsonProperty("feeScheduleId")
    private Integer feeScheduleId;
    @JsonProperty("procedure")
    private String procedure;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("cptProcedureId")
    private Integer cptProcedureId;
    @JsonProperty("cptProcedure")
    private Object cptProcedure;
    @JsonProperty("modifiedProcedureDescription")
    private String modifiedProcedureDescription;
    @JsonProperty("status")
    private Object status;
    @JsonProperty("amount")
    private Double amount;
    @JsonProperty("effectiveDate")
    private String effectiveDate;
    @JsonProperty("feeScheduleHistoryId")
    private Integer feeScheduleHistoryId;
    @JsonProperty("feeScheduleRootId")
    private Integer feeScheduleRootId;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("isIncludeStateReportTf")
    private Boolean isIncludeStateReportTf;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("feeScheduleId")
    public Integer getFeeScheduleId() {
        return feeScheduleId;
    }

    @JsonProperty("feeScheduleId")
    public void setFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
    }

    public FeeScheduleItem withFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
        return this;
    }

    @JsonProperty("procedure")
    public String getProcedure() {
        return procedure;
    }

    @JsonProperty("procedure")
    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public FeeScheduleItem withProcedure(String procedure) {
        this.procedure = procedure;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public FeeScheduleItem withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("cptProcedureId")
    public Integer getCptProcedureId() {
        return cptProcedureId;
    }

    @JsonProperty("cptProcedureId")
    public void setCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
    }

    public FeeScheduleItem withCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
        return this;
    }

    @JsonProperty("cptProcedure")
    public Object getCptProcedure() {
        return cptProcedure;
    }

    @JsonProperty("cptProcedure")
    public void setCptProcedure(Object cptProcedure) {
        this.cptProcedure = cptProcedure;
    }

    public FeeScheduleItem withCptProcedure(Object cptProcedure) {
        this.cptProcedure = cptProcedure;
        return this;
    }

    @JsonProperty("modifiedProcedureDescription")
    public String getModifiedProcedureDescription() {
        return modifiedProcedureDescription;
    }

    @JsonProperty("modifiedProcedureDescription")
    public void setModifiedProcedureDescription(String modifiedProcedureDescription) {
        this.modifiedProcedureDescription = modifiedProcedureDescription;
    }

    public FeeScheduleItem withModifiedProcedureDescription(String modifiedProcedureDescription) {
        this.modifiedProcedureDescription = modifiedProcedureDescription;
        return this;
    }

    @JsonProperty("status")
    public Object getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Object status) {
        this.status = status;
    }

    public FeeScheduleItem withStatus(Object status) {
        this.status = status;
        return this;
    }

    @JsonProperty("amount")
    public Double getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public FeeScheduleItem withAmount(Double amount) {
        this.amount = amount;
        return this;
    }

    @JsonProperty("effectiveDate")
    public String getEffectiveDate() {
        return effectiveDate;
    }

    @JsonProperty("effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public FeeScheduleItem withEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    @JsonProperty("feeScheduleHistoryId")
    public Integer getFeeScheduleHistoryId() {
        return feeScheduleHistoryId;
    }

    @JsonProperty("feeScheduleHistoryId")
    public void setFeeScheduleHistoryId(Integer feeScheduleHistoryId) {
        this.feeScheduleHistoryId = feeScheduleHistoryId;
    }

    public FeeScheduleItem withFeeScheduleHistoryId(Integer feeScheduleHistoryId) {
        this.feeScheduleHistoryId = feeScheduleHistoryId;
        return this;
    }

    @JsonProperty("feeScheduleRootId")
    public Integer getFeeScheduleRootId() {
        return feeScheduleRootId;
    }

    @JsonProperty("feeScheduleRootId")
    public void setFeeScheduleRootId(Integer feeScheduleRootId) {
        this.feeScheduleRootId = feeScheduleRootId;
    }

    public FeeScheduleItem withFeeScheduleRootId(Integer feeScheduleRootId) {
        this.feeScheduleRootId = feeScheduleRootId;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public FeeScheduleItem withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("isIncludeStateReportTf")
    public Boolean getIsIncludeStateReportTf() {
        return isIncludeStateReportTf;
    }

    @JsonProperty("isIncludeStateReportTf")
    public void setIsIncludeStateReportTf(Boolean isIncludeStateReportTf) {
        this.isIncludeStateReportTf = isIncludeStateReportTf;
    }

    public FeeScheduleItem withIsIncludeStateReportTf(Boolean isIncludeStateReportTf) {
        this.isIncludeStateReportTf = isIncludeStateReportTf;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public FeeScheduleItem withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FeeScheduleItem withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(feeScheduleId).append(procedure).append(organizationId).append(cptProcedureId).append(cptProcedure).append(modifiedProcedureDescription).append(status).append(amount).append(effectiveDate).append(feeScheduleHistoryId).append(feeScheduleRootId).append(activeTf).append(isIncludeStateReportTf).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FeeScheduleItem) == false) {
            return false;
        }
        FeeScheduleItem rhs = ((FeeScheduleItem) other);
        return new EqualsBuilder().append(feeScheduleId, rhs.feeScheduleId).append(procedure, rhs.procedure).append(organizationId, rhs.organizationId).append(cptProcedureId, rhs.cptProcedureId).append(cptProcedure, rhs.cptProcedure).append(modifiedProcedureDescription, rhs.modifiedProcedureDescription).append(status, rhs.status).append(amount, rhs.amount).append(effectiveDate, rhs.effectiveDate).append(feeScheduleHistoryId, rhs.feeScheduleHistoryId).append(feeScheduleRootId, rhs.feeScheduleRootId).append(activeTf, rhs.activeTf).append(isIncludeStateReportTf, rhs.isIncludeStateReportTf).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
