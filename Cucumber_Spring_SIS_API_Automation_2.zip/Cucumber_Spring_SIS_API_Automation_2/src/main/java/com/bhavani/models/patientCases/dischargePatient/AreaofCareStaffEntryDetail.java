
package com.bhavani.models.patientCases.dischargePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "areaOfCareStaffId",
    "areaOfCareStaffEntryId",
    "staffId",
    "staffRoleId",
    "inTimeDt",
    "outTimeDt",
    "manuallyChanged",
    "manuallyChangedInTime",
    "manuallyChangedOutTime",
    "staffRoleName",
    "staffName",
    "personID",
    "staffFirstName",
    "staffLastName",
    "staffMiddleInitial",
    "staffTitle",
    "sourceIdentifier"
})
public class AreaofCareStaffEntryDetail {

    @JsonProperty("areaOfCareStaffId")
    private Integer areaOfCareStaffId;
    @JsonProperty("areaOfCareStaffEntryId")
    private Integer areaOfCareStaffEntryId;
    @JsonProperty("staffId")
    private Integer staffId;
    @JsonProperty("staffRoleId")
    private Integer staffRoleId;
    @JsonProperty("inTimeDt")
    private String inTimeDt;
    @JsonProperty("outTimeDt")
    private Object outTimeDt;
    @JsonProperty("manuallyChanged")
    private Object manuallyChanged;
    @JsonProperty("manuallyChangedInTime")
    private Boolean manuallyChangedInTime;
    @JsonProperty("manuallyChangedOutTime")
    private Boolean manuallyChangedOutTime;
    @JsonProperty("staffRoleName")
    private Object staffRoleName;
    @JsonProperty("staffName")
    private Object staffName;
    @JsonProperty("personID")
    private Object personID;
    @JsonProperty("staffFirstName")
    private Object staffFirstName;
    @JsonProperty("staffLastName")
    private Object staffLastName;
    @JsonProperty("staffMiddleInitial")
    private Object staffMiddleInitial;
    @JsonProperty("staffTitle")
    private Object staffTitle;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("areaOfCareStaffId")
    public Integer getAreaOfCareStaffId() {
        return areaOfCareStaffId;
    }

    @JsonProperty("areaOfCareStaffId")
    public void setAreaOfCareStaffId(Integer areaOfCareStaffId) {
        this.areaOfCareStaffId = areaOfCareStaffId;
    }

    public AreaofCareStaffEntryDetail withAreaOfCareStaffId(Integer areaOfCareStaffId) {
        this.areaOfCareStaffId = areaOfCareStaffId;
        return this;
    }

    @JsonProperty("areaOfCareStaffEntryId")
    public Integer getAreaOfCareStaffEntryId() {
        return areaOfCareStaffEntryId;
    }

    @JsonProperty("areaOfCareStaffEntryId")
    public void setAreaOfCareStaffEntryId(Integer areaOfCareStaffEntryId) {
        this.areaOfCareStaffEntryId = areaOfCareStaffEntryId;
    }

    public AreaofCareStaffEntryDetail withAreaOfCareStaffEntryId(Integer areaOfCareStaffEntryId) {
        this.areaOfCareStaffEntryId = areaOfCareStaffEntryId;
        return this;
    }

    @JsonProperty("staffId")
    public Integer getStaffId() {
        return staffId;
    }

    @JsonProperty("staffId")
    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public AreaofCareStaffEntryDetail withStaffId(Integer staffId) {
        this.staffId = staffId;
        return this;
    }

    @JsonProperty("staffRoleId")
    public Integer getStaffRoleId() {
        return staffRoleId;
    }

    @JsonProperty("staffRoleId")
    public void setStaffRoleId(Integer staffRoleId) {
        this.staffRoleId = staffRoleId;
    }

    public AreaofCareStaffEntryDetail withStaffRoleId(Integer staffRoleId) {
        this.staffRoleId = staffRoleId;
        return this;
    }

    @JsonProperty("inTimeDt")
    public String getInTimeDt() {
        return inTimeDt;
    }

    @JsonProperty("inTimeDt")
    public void setInTimeDt(String inTimeDt) {
        this.inTimeDt = inTimeDt;
    }

    public AreaofCareStaffEntryDetail withInTimeDt(String inTimeDt) {
        this.inTimeDt = inTimeDt;
        return this;
    }

    @JsonProperty("outTimeDt")
    public Object getOutTimeDt() {
        return outTimeDt;
    }

    @JsonProperty("outTimeDt")
    public void setOutTimeDt(Object outTimeDt) {
        this.outTimeDt = outTimeDt;
    }

    public AreaofCareStaffEntryDetail withOutTimeDt(Object outTimeDt) {
        this.outTimeDt = outTimeDt;
        return this;
    }

    @JsonProperty("manuallyChanged")
    public Object getManuallyChanged() {
        return manuallyChanged;
    }

    @JsonProperty("manuallyChanged")
    public void setManuallyChanged(Object manuallyChanged) {
        this.manuallyChanged = manuallyChanged;
    }

    public AreaofCareStaffEntryDetail withManuallyChanged(Object manuallyChanged) {
        this.manuallyChanged = manuallyChanged;
        return this;
    }

    @JsonProperty("manuallyChangedInTime")
    public Boolean getManuallyChangedInTime() {
        return manuallyChangedInTime;
    }

    @JsonProperty("manuallyChangedInTime")
    public void setManuallyChangedInTime(Boolean manuallyChangedInTime) {
        this.manuallyChangedInTime = manuallyChangedInTime;
    }

    public AreaofCareStaffEntryDetail withManuallyChangedInTime(Boolean manuallyChangedInTime) {
        this.manuallyChangedInTime = manuallyChangedInTime;
        return this;
    }

    @JsonProperty("manuallyChangedOutTime")
    public Boolean getManuallyChangedOutTime() {
        return manuallyChangedOutTime;
    }

    @JsonProperty("manuallyChangedOutTime")
    public void setManuallyChangedOutTime(Boolean manuallyChangedOutTime) {
        this.manuallyChangedOutTime = manuallyChangedOutTime;
    }

    public AreaofCareStaffEntryDetail withManuallyChangedOutTime(Boolean manuallyChangedOutTime) {
        this.manuallyChangedOutTime = manuallyChangedOutTime;
        return this;
    }

    @JsonProperty("staffRoleName")
    public Object getStaffRoleName() {
        return staffRoleName;
    }

    @JsonProperty("staffRoleName")
    public void setStaffRoleName(Object staffRoleName) {
        this.staffRoleName = staffRoleName;
    }

    public AreaofCareStaffEntryDetail withStaffRoleName(Object staffRoleName) {
        this.staffRoleName = staffRoleName;
        return this;
    }

    @JsonProperty("staffName")
    public Object getStaffName() {
        return staffName;
    }

    @JsonProperty("staffName")
    public void setStaffName(Object staffName) {
        this.staffName = staffName;
    }

    public AreaofCareStaffEntryDetail withStaffName(Object staffName) {
        this.staffName = staffName;
        return this;
    }

    @JsonProperty("personID")
    public Object getPersonID() {
        return personID;
    }

    @JsonProperty("personID")
    public void setPersonID(Object personID) {
        this.personID = personID;
    }

    public AreaofCareStaffEntryDetail withPersonID(Object personID) {
        this.personID = personID;
        return this;
    }

    @JsonProperty("staffFirstName")
    public Object getStaffFirstName() {
        return staffFirstName;
    }

    @JsonProperty("staffFirstName")
    public void setStaffFirstName(Object staffFirstName) {
        this.staffFirstName = staffFirstName;
    }

    public AreaofCareStaffEntryDetail withStaffFirstName(Object staffFirstName) {
        this.staffFirstName = staffFirstName;
        return this;
    }

    @JsonProperty("staffLastName")
    public Object getStaffLastName() {
        return staffLastName;
    }

    @JsonProperty("staffLastName")
    public void setStaffLastName(Object staffLastName) {
        this.staffLastName = staffLastName;
    }

    public AreaofCareStaffEntryDetail withStaffLastName(Object staffLastName) {
        this.staffLastName = staffLastName;
        return this;
    }

    @JsonProperty("staffMiddleInitial")
    public Object getStaffMiddleInitial() {
        return staffMiddleInitial;
    }

    @JsonProperty("staffMiddleInitial")
    public void setStaffMiddleInitial(Object staffMiddleInitial) {
        this.staffMiddleInitial = staffMiddleInitial;
    }

    public AreaofCareStaffEntryDetail withStaffMiddleInitial(Object staffMiddleInitial) {
        this.staffMiddleInitial = staffMiddleInitial;
        return this;
    }

    @JsonProperty("staffTitle")
    public Object getStaffTitle() {
        return staffTitle;
    }

    @JsonProperty("staffTitle")
    public void setStaffTitle(Object staffTitle) {
        this.staffTitle = staffTitle;
    }

    public AreaofCareStaffEntryDetail withStaffTitle(Object staffTitle) {
        this.staffTitle = staffTitle;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public AreaofCareStaffEntryDetail withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AreaofCareStaffEntryDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(areaOfCareStaffId).append(areaOfCareStaffEntryId).append(staffId).append(staffRoleId).append(inTimeDt).append(outTimeDt).append(manuallyChanged).append(manuallyChangedInTime).append(manuallyChangedOutTime).append(staffRoleName).append(staffName).append(personID).append(staffFirstName).append(staffLastName).append(staffMiddleInitial).append(staffTitle).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AreaofCareStaffEntryDetail) == false) {
            return false;
        }
        AreaofCareStaffEntryDetail rhs = ((AreaofCareStaffEntryDetail) other);
        return new EqualsBuilder().append(areaOfCareStaffId, rhs.areaOfCareStaffId).append(areaOfCareStaffEntryId, rhs.areaOfCareStaffEntryId).append(staffId, rhs.staffId).append(staffRoleId, rhs.staffRoleId).append(inTimeDt, rhs.inTimeDt).append(outTimeDt, rhs.outTimeDt).append(manuallyChanged, rhs.manuallyChanged).append(manuallyChangedInTime, rhs.manuallyChangedInTime).append(manuallyChangedOutTime, rhs.manuallyChangedOutTime).append(staffRoleName, rhs.staffRoleName).append(staffName, rhs.staffName).append(personID, rhs.personID).append(staffFirstName, rhs.staffFirstName).append(staffLastName, rhs.staffLastName).append(staffMiddleInitial, rhs.staffMiddleInitial).append(staffTitle, rhs.staffTitle).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
