
package com.bhavani.models.patientCases.newCaseSummary;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientRelationship",
    "patientGuarantorId",
    "patientId",
    "dateOfBirth",
    "gender",
    "firstName",
    "lastName",
    "address1",
    "address2",
    "city",
    "state",
    "zip",
    "country",
    "selectedStateIdx",
    "selectedCountryIdx",
    "phoneNumber"
})
public class PatientGuarantor {

    @JsonProperty("patientRelationship")
    private String patientRelationship;
    @JsonProperty("patientGuarantorId")
    private Integer patientGuarantorId;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("address2")
    private String address2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("country")
    private String country;
    @JsonProperty("selectedStateIdx")
    private Integer selectedStateIdx;
    @JsonProperty("selectedCountryIdx")
    private Integer selectedCountryIdx;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientRelationship")
    public String getPatientRelationship() {
        return patientRelationship;
    }

    @JsonProperty("patientRelationship")
    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public PatientGuarantor withPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
        return this;
    }

    @JsonProperty("patientGuarantorId")
    public Integer getPatientGuarantorId() {
        return patientGuarantorId;
    }

    @JsonProperty("patientGuarantorId")
    public void setPatientGuarantorId(Integer patientGuarantorId) {
        this.patientGuarantorId = patientGuarantorId;
    }

    public PatientGuarantor withPatientGuarantorId(Integer patientGuarantorId) {
        this.patientGuarantorId = patientGuarantorId;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public PatientGuarantor withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public PatientGuarantor withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public PatientGuarantor withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public PatientGuarantor withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public PatientGuarantor withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public PatientGuarantor withAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("address2")
    public String getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public PatientGuarantor withAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public PatientGuarantor withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public PatientGuarantor withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zip")
    public String getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(String zip) {
        this.zip = zip;
    }

    public PatientGuarantor withZip(String zip) {
        this.zip = zip;
        return this;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    public PatientGuarantor withCountry(String country) {
        this.country = country;
        return this;
    }

    @JsonProperty("selectedStateIdx")
    public Integer getSelectedStateIdx() {
        return selectedStateIdx;
    }

    @JsonProperty("selectedStateIdx")
    public void setSelectedStateIdx(Integer selectedStateIdx) {
        this.selectedStateIdx = selectedStateIdx;
    }

    public PatientGuarantor withSelectedStateIdx(Integer selectedStateIdx) {
        this.selectedStateIdx = selectedStateIdx;
        return this;
    }

    @JsonProperty("selectedCountryIdx")
    public Integer getSelectedCountryIdx() {
        return selectedCountryIdx;
    }

    @JsonProperty("selectedCountryIdx")
    public void setSelectedCountryIdx(Integer selectedCountryIdx) {
        this.selectedCountryIdx = selectedCountryIdx;
    }

    public PatientGuarantor withSelectedCountryIdx(Integer selectedCountryIdx) {
        this.selectedCountryIdx = selectedCountryIdx;
        return this;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public PatientGuarantor withPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PatientGuarantor withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientRelationship).append(patientGuarantorId).append(patientId).append(dateOfBirth).append(gender).append(firstName).append(lastName).append(address1).append(address2).append(city).append(state).append(zip).append(country).append(selectedStateIdx).append(selectedCountryIdx).append(phoneNumber).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PatientGuarantor) == false) {
            return false;
        }
        PatientGuarantor rhs = ((PatientGuarantor) other);
        return new EqualsBuilder().append(patientRelationship, rhs.patientRelationship).append(patientGuarantorId, rhs.patientGuarantorId).append(patientId, rhs.patientId).append(dateOfBirth, rhs.dateOfBirth).append(gender, rhs.gender).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(address1, rhs.address1).append(address2, rhs.address2).append(city, rhs.city).append(state, rhs.state).append(zip, rhs.zip).append(country, rhs.country).append(selectedStateIdx, rhs.selectedStateIdx).append(selectedCountryIdx, rhs.selectedCountryIdx).append(phoneNumber, rhs.phoneNumber).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
