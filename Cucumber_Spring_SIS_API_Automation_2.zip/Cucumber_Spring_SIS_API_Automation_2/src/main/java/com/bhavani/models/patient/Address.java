
package com.bhavani.models.patient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientId",
    "line1",
    "line2",
    "city",
    "state",
    "zip",
    "country",
    "county",
    "addressKindName",
    "extendedZip",
    "adtMaintainedFieldArray",
    "sourceIdentifier"
})
public class Address {

    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("line1")
    private Object line1;
    @JsonProperty("line2")
    private Object line2;
    @JsonProperty("city")
    private Object city;
    @JsonProperty("state")
    private Object state;
    @JsonProperty("zip")
    private Object zip;
    @JsonProperty("country")
    private String country;
    @JsonProperty("county")
    private Object county;
    @JsonProperty("addressKindName")
    private String addressKindName;
    @JsonProperty("extendedZip")
    private Object extendedZip;
    @JsonProperty("adtMaintainedFieldArray")
    private Object adtMaintainedFieldArray;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public Address withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("line1")
    public Object getLine1() {
        return line1;
    }

    @JsonProperty("line1")
    public void setLine1(Object line1) {
        this.line1 = line1;
    }

    public Address withLine1(Object line1) {
        this.line1 = line1;
        return this;
    }

    @JsonProperty("line2")
    public Object getLine2() {
        return line2;
    }

    @JsonProperty("line2")
    public void setLine2(Object line2) {
        this.line2 = line2;
    }

    public Address withLine2(Object line2) {
        this.line2 = line2;
        return this;
    }

    @JsonProperty("city")
    public Object getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(Object city) {
        this.city = city;
    }

    public Address withCity(Object city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public Object getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(Object state) {
        this.state = state;
    }

    public Address withState(Object state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zip")
    public Object getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(Object zip) {
        this.zip = zip;
    }

    public Address withZip(Object zip) {
        this.zip = zip;
        return this;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    public Address withCountry(String country) {
        this.country = country;
        return this;
    }

    @JsonProperty("county")
    public Object getCounty() {
        return county;
    }

    @JsonProperty("county")
    public void setCounty(Object county) {
        this.county = county;
    }

    public Address withCounty(Object county) {
        this.county = county;
        return this;
    }

    @JsonProperty("addressKindName")
    public String getAddressKindName() {
        return addressKindName;
    }

    @JsonProperty("addressKindName")
    public void setAddressKindName(String addressKindName) {
        this.addressKindName = addressKindName;
    }

    public Address withAddressKindName(String addressKindName) {
        this.addressKindName = addressKindName;
        return this;
    }

    @JsonProperty("extendedZip")
    public Object getExtendedZip() {
        return extendedZip;
    }

    @JsonProperty("extendedZip")
    public void setExtendedZip(Object extendedZip) {
        this.extendedZip = extendedZip;
    }

    public Address withExtendedZip(Object extendedZip) {
        this.extendedZip = extendedZip;
        return this;
    }

    @JsonProperty("adtMaintainedFieldArray")
    public Object getAdtMaintainedFieldArray() {
        return adtMaintainedFieldArray;
    }

    @JsonProperty("adtMaintainedFieldArray")
    public void setAdtMaintainedFieldArray(Object adtMaintainedFieldArray) {
        this.adtMaintainedFieldArray = adtMaintainedFieldArray;
    }

    public Address withAdtMaintainedFieldArray(Object adtMaintainedFieldArray) {
        this.adtMaintainedFieldArray = adtMaintainedFieldArray;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public Address withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Address withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientId).append(line1).append(line2).append(city).append(state).append(zip).append(country).append(county).append(addressKindName).append(extendedZip).append(adtMaintainedFieldArray).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Address) == false) {
            return false;
        }
        Address rhs = ((Address) other);
        return new EqualsBuilder().append(patientId, rhs.patientId).append(line1, rhs.line1).append(line2, rhs.line2).append(city, rhs.city).append(state, rhs.state).append(zip, rhs.zip).append(country, rhs.country).append(county, rhs.county).append(addressKindName, rhs.addressKindName).append(extendedZip, rhs.extendedZip).append(adtMaintainedFieldArray, rhs.adtMaintainedFieldArray).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
