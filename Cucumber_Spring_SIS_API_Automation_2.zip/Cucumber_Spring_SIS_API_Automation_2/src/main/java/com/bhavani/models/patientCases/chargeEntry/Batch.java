
package com.bhavani.models.patientCases.chargeEntry;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

// @JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "batchId",
    "periodId",
    "batchDescription",
    "batchCreatedDate",
    "batchClosedDate",
    "batchCreatorUsrId",
    "batchCloserUsrId",
    "isActive",
    "openCases",
    "sourceIdentifier",
    "value",
    "label"
})
public class Batch {

    @JsonProperty("batchId")
    private Integer batchId;
    @JsonProperty("periodId")
    private Integer periodId;
    @JsonProperty("batchDescription")
    private String batchDescription;
    @JsonProperty("batchCreatedDate")
    private String batchCreatedDate;
    @JsonProperty("batchClosedDate")
    private Object batchClosedDate;
    @JsonProperty("batchCreatorUsrId")
    private Integer batchCreatorUsrId;
    @JsonProperty("batchCloserUsrId")
    private Object batchCloserUsrId;
    @JsonProperty("isActive")
    private Boolean isActive;
    @JsonProperty("openCases")
    private Integer openCases;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonProperty("value")
    private Integer value;
    @JsonProperty("label")
    private String label;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("batchId")
    public Integer getBatchId() {
        return batchId;
    }

    @JsonProperty("batchId")
    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public Batch withBatchId(Integer batchId) {
        this.batchId = batchId;
        return this;
    }

    @JsonProperty("periodId")
    public Integer getPeriodId() {
        return periodId;
    }

    @JsonProperty("periodId")
    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Batch withPeriodId(Integer periodId) {
        this.periodId = periodId;
        return this;
    }

    @JsonProperty("batchDescription")
    public String getBatchDescription() {
        return batchDescription;
    }

    @JsonProperty("batchDescription")
    public void setBatchDescription(String batchDescription) {
        this.batchDescription = batchDescription;
    }

    public Batch withBatchDescription(String batchDescription) {
        this.batchDescription = batchDescription;
        return this;
    }

    @JsonProperty("batchCreatedDate")
    public String getBatchCreatedDate() {
        return batchCreatedDate;
    }

    @JsonProperty("batchCreatedDate")
    public void setBatchCreatedDate(String batchCreatedDate) {
        this.batchCreatedDate = batchCreatedDate;
    }

    public Batch withBatchCreatedDate(String batchCreatedDate) {
        this.batchCreatedDate = batchCreatedDate;
        return this;
    }

    @JsonProperty("batchClosedDate")
    public Object getBatchClosedDate() {
        return batchClosedDate;
    }

    @JsonProperty("batchClosedDate")
    public void setBatchClosedDate(Object batchClosedDate) {
        this.batchClosedDate = batchClosedDate;
    }

    public Batch withBatchClosedDate(Object batchClosedDate) {
        this.batchClosedDate = batchClosedDate;
        return this;
    }

    @JsonProperty("batchCreatorUsrId")
    public Integer getBatchCreatorUsrId() {
        return batchCreatorUsrId;
    }

    @JsonProperty("batchCreatorUsrId")
    public void setBatchCreatorUsrId(Integer batchCreatorUsrId) {
        this.batchCreatorUsrId = batchCreatorUsrId;
    }

    public Batch withBatchCreatorUsrId(Integer batchCreatorUsrId) {
        this.batchCreatorUsrId = batchCreatorUsrId;
        return this;
    }

    @JsonProperty("batchCloserUsrId")
    public Object getBatchCloserUsrId() {
        return batchCloserUsrId;
    }

    @JsonProperty("batchCloserUsrId")
    public void setBatchCloserUsrId(Object batchCloserUsrId) {
        this.batchCloserUsrId = batchCloserUsrId;
    }

    public Batch withBatchCloserUsrId(Object batchCloserUsrId) {
        this.batchCloserUsrId = batchCloserUsrId;
        return this;
    }

    @JsonProperty("isActive")
    public Boolean getIsActive() {
        return isActive;
    }

    @JsonProperty("isActive")
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Batch withIsActive(Boolean isActive) {
        this.isActive = isActive;
        return this;
    }

    @JsonProperty("openCases")
    public Integer getOpenCases() {
        return openCases;
    }

    @JsonProperty("openCases")
    public void setOpenCases(Integer openCases) {
        this.openCases = openCases;
    }

    public Batch withOpenCases(Integer openCases) {
        this.openCases = openCases;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public Batch withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @JsonProperty("value")
    public Integer getValue() {
        return value;
    }

    @JsonProperty("value")
    public void setValue(Integer value) {
        this.value = value;
    }

    public Batch withValue(Integer value) {
        this.value = value;
        return this;
    }

    @JsonProperty("label")
    public String getLabel() {
        return label;
    }

    @JsonProperty("label")
    public void setLabel(String label) {
        this.label = label;
    }

    public Batch withLabel(String label) {
        this.label = label;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Batch withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(batchId).append(periodId).append(batchDescription).append(batchCreatedDate).append(batchClosedDate).append(batchCreatorUsrId).append(batchCloserUsrId).append(isActive).append(openCases).append(sourceIdentifier).append(value).append(label).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Batch) == false) {
            return false;
        }
        Batch rhs = ((Batch) other);
        return new EqualsBuilder().append(batchId, rhs.batchId).append(periodId, rhs.periodId).append(batchDescription, rhs.batchDescription).append(batchCreatedDate, rhs.batchCreatedDate).append(batchClosedDate, rhs.batchClosedDate).append(batchCreatorUsrId, rhs.batchCreatorUsrId).append(batchCloserUsrId, rhs.batchCloserUsrId).append(isActive, rhs.isActive).append(openCases, rhs.openCases).append(sourceIdentifier, rhs.sourceIdentifier).append(value, rhs.value).append(label, rhs.label).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
