
package com.bhavani.models.room;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "roomId",
    "quickCode",
    "activeTf",
    "organizationId",
    "name",
    "roomTypeId",
    "facilityId",
    "aoDictionaryTf",
    "showInClinicalTf",
    "isAlphabeticalOrder",
    "searchString",
    "pageNumber",
    "isAdded",
    "isUpdated",
    "itemId",
    "itemType",
    "itemName",
    "sourceIdentifier"
})
public class ActiveRoom {

    @JsonProperty("roomId")
    private Integer roomId;
    @JsonProperty("quickCode")
    private String quickCode;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("roomTypeId")
    private Integer roomTypeId;
    @JsonProperty("facilityId")
    private Object facilityId;
    @JsonProperty("aoDictionaryTf")
    private Boolean aoDictionaryTf;
    @JsonProperty("showInClinicalTf")
    private Boolean showInClinicalTf;
    @JsonProperty("isAlphabeticalOrder")
    private Boolean isAlphabeticalOrder;
    @JsonProperty("searchString")
    private Object searchString;
    @JsonProperty("pageNumber")
    private Integer pageNumber;
    @JsonProperty("isAdded")
    private Boolean isAdded;
    @JsonProperty("isUpdated")
    private Boolean isUpdated;
    @JsonProperty("itemId")
    private Integer itemId;
    @JsonProperty("itemType")
    private Object itemType;
    @JsonProperty("itemName")
    private Object itemName;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("roomId")
    public Integer getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public ActiveRoom withRoomId(Integer roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("quickCode")
    public String getQuickCode() {
        return quickCode;
    }

    @JsonProperty("quickCode")
    public void setQuickCode(String quickCode) {
        this.quickCode = quickCode;
    }

    public ActiveRoom withQuickCode(String quickCode) {
        this.quickCode = quickCode;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public ActiveRoom withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public ActiveRoom withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public ActiveRoom withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("roomTypeId")
    public Integer getRoomTypeId() {
        return roomTypeId;
    }

    @JsonProperty("roomTypeId")
    public void setRoomTypeId(Integer roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    public ActiveRoom withRoomTypeId(Integer roomTypeId) {
        this.roomTypeId = roomTypeId;
        return this;
    }

    @JsonProperty("facilityId")
    public Object getFacilityId() {
        return facilityId;
    }

    @JsonProperty("facilityId")
    public void setFacilityId(Object facilityId) {
        this.facilityId = facilityId;
    }

    public ActiveRoom withFacilityId(Object facilityId) {
        this.facilityId = facilityId;
        return this;
    }

    @JsonProperty("aoDictionaryTf")
    public Boolean getAoDictionaryTf() {
        return aoDictionaryTf;
    }

    @JsonProperty("aoDictionaryTf")
    public void setAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
    }

    public ActiveRoom withAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
        return this;
    }

    @JsonProperty("showInClinicalTf")
    public Boolean getShowInClinicalTf() {
        return showInClinicalTf;
    }

    @JsonProperty("showInClinicalTf")
    public void setShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
    }

    public ActiveRoom withShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
        return this;
    }

    @JsonProperty("isAlphabeticalOrder")
    public Boolean getIsAlphabeticalOrder() {
        return isAlphabeticalOrder;
    }

    @JsonProperty("isAlphabeticalOrder")
    public void setIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
    }

    public ActiveRoom withIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
        return this;
    }

    @JsonProperty("searchString")
    public Object getSearchString() {
        return searchString;
    }

    @JsonProperty("searchString")
    public void setSearchString(Object searchString) {
        this.searchString = searchString;
    }

    public ActiveRoom withSearchString(Object searchString) {
        this.searchString = searchString;
        return this;
    }

    @JsonProperty("pageNumber")
    public Integer getPageNumber() {
        return pageNumber;
    }

    @JsonProperty("pageNumber")
    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public ActiveRoom withPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }

    @JsonProperty("isAdded")
    public Boolean getIsAdded() {
        return isAdded;
    }

    @JsonProperty("isAdded")
    public void setIsAdded(Boolean isAdded) {
        this.isAdded = isAdded;
    }

    public ActiveRoom withIsAdded(Boolean isAdded) {
        this.isAdded = isAdded;
        return this;
    }

    @JsonProperty("isUpdated")
    public Boolean getIsUpdated() {
        return isUpdated;
    }

    @JsonProperty("isUpdated")
    public void setIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
    }

    public ActiveRoom withIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
        return this;
    }

    @JsonProperty("itemId")
    public Integer getItemId() {
        return itemId;
    }

    @JsonProperty("itemId")
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public ActiveRoom withItemId(Integer itemId) {
        this.itemId = itemId;
        return this;
    }

    @JsonProperty("itemType")
    public Object getItemType() {
        return itemType;
    }

    @JsonProperty("itemType")
    public void setItemType(Object itemType) {
        this.itemType = itemType;
    }

    public ActiveRoom withItemType(Object itemType) {
        this.itemType = itemType;
        return this;
    }

    @JsonProperty("itemName")
    public Object getItemName() {
        return itemName;
    }

    @JsonProperty("itemName")
    public void setItemName(Object itemName) {
        this.itemName = itemName;
    }

    public ActiveRoom withItemName(Object itemName) {
        this.itemName = itemName;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public ActiveRoom withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ActiveRoom withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(roomId).append(quickCode).append(activeTf).append(organizationId).append(name).append(roomTypeId).append(facilityId).append(aoDictionaryTf).append(showInClinicalTf).append(isAlphabeticalOrder).append(searchString).append(pageNumber).append(isAdded).append(isUpdated).append(itemId).append(itemType).append(itemName).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ActiveRoom) == false) {
            return false;
        }
        ActiveRoom rhs = ((ActiveRoom) other);
        return new EqualsBuilder().append(roomId, rhs.roomId).append(quickCode, rhs.quickCode).append(activeTf, rhs.activeTf).append(organizationId, rhs.organizationId).append(name, rhs.name).append(roomTypeId, rhs.roomTypeId).append(facilityId, rhs.facilityId).append(aoDictionaryTf, rhs.aoDictionaryTf).append(showInClinicalTf, rhs.showInClinicalTf).append(isAlphabeticalOrder, rhs.isAlphabeticalOrder).append(searchString, rhs.searchString).append(pageNumber, rhs.pageNumber).append(isAdded, rhs.isAdded).append(isUpdated, rhs.isUpdated).append(itemId, rhs.itemId).append(itemType, rhs.itemType).append(itemName, rhs.itemName).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
