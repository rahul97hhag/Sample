
package com.bhavani.models.configuration.business.insurance.insuranceResponse;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insuranceCarrierId",
    "insuranceCarrierName",
    "electronicClaim",
    "paperForm",
    "organizationId",
    "insurancePlanSaveDetails",
    "ePayerId",
    "sourceIdentifier"
})
public class SaveInsuranceCarrierResponse {

    @JsonProperty("insuranceCarrierId")
    private Integer insuranceCarrierId;
    @JsonProperty("insuranceCarrierName")
    private String insuranceCarrierName;
    @JsonProperty("electronicClaim")
    private Integer electronicClaim;
    @JsonProperty("paperForm")
    private Integer paperForm;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("insurancePlanSaveDetails")
    private InsurancePlanSaveDetails insurancePlanSaveDetails;
    @JsonProperty("ePayerId")
    private Object ePayerId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insuranceCarrierId")
    public Integer getInsuranceCarrierId() {
        return insuranceCarrierId;
    }

    @JsonProperty("insuranceCarrierId")
    public void setInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
    }

    public SaveInsuranceCarrierResponse withInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
        return this;
    }

    @JsonProperty("insuranceCarrierName")
    public String getInsuranceCarrierName() {
        return insuranceCarrierName;
    }

    @JsonProperty("insuranceCarrierName")
    public void setInsuranceCarrierName(String insuranceCarrierName) {
        this.insuranceCarrierName = insuranceCarrierName;
    }

    public SaveInsuranceCarrierResponse withInsuranceCarrierName(String insuranceCarrierName) {
        this.insuranceCarrierName = insuranceCarrierName;
        return this;
    }

    @JsonProperty("electronicClaim")
    public Integer getElectronicClaim() {
        return electronicClaim;
    }

    @JsonProperty("electronicClaim")
    public void setElectronicClaim(Integer electronicClaim) {
        this.electronicClaim = electronicClaim;
    }

    public SaveInsuranceCarrierResponse withElectronicClaim(Integer electronicClaim) {
        this.electronicClaim = electronicClaim;
        return this;
    }

    @JsonProperty("paperForm")
    public Integer getPaperForm() {
        return paperForm;
    }

    @JsonProperty("paperForm")
    public void setPaperForm(Integer paperForm) {
        this.paperForm = paperForm;
    }

    public SaveInsuranceCarrierResponse withPaperForm(Integer paperForm) {
        this.paperForm = paperForm;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public SaveInsuranceCarrierResponse withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("insurancePlanSaveDetails")
    public InsurancePlanSaveDetails getInsurancePlanSaveDetails() {
        return insurancePlanSaveDetails;
    }

    @JsonProperty("insurancePlanSaveDetails")
    public void setInsurancePlanSaveDetails(InsurancePlanSaveDetails insurancePlanSaveDetails) {
        this.insurancePlanSaveDetails = insurancePlanSaveDetails;
    }

    public SaveInsuranceCarrierResponse withInsurancePlanSaveDetails(InsurancePlanSaveDetails insurancePlanSaveDetails) {
        this.insurancePlanSaveDetails = insurancePlanSaveDetails;
        return this;
    }

    @JsonProperty("ePayerId")
    public Object getEPayerId() {
        return ePayerId;
    }

    @JsonProperty("ePayerId")
    public void setEPayerId(Object ePayerId) {
        this.ePayerId = ePayerId;
    }

    public SaveInsuranceCarrierResponse withEPayerId(Object ePayerId) {
        this.ePayerId = ePayerId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public SaveInsuranceCarrierResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SaveInsuranceCarrierResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insuranceCarrierId).append(insuranceCarrierName).append(electronicClaim).append(paperForm).append(organizationId).append(insurancePlanSaveDetails).append(ePayerId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaveInsuranceCarrierResponse) == false) {
            return false;
        }
        SaveInsuranceCarrierResponse rhs = ((SaveInsuranceCarrierResponse) other);
        return new EqualsBuilder().append(insuranceCarrierId, rhs.insuranceCarrierId).append(insuranceCarrierName, rhs.insuranceCarrierName).append(electronicClaim, rhs.electronicClaim).append(paperForm, rhs.paperForm).append(organizationId, rhs.organizationId).append(insurancePlanSaveDetails, rhs.insurancePlanSaveDetails).append(ePayerId, rhs.ePayerId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
