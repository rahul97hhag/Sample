
package com.bhavani.models.room;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "roomId",
    "quickCode",
    "activeTf",
    "organizationId",
    "name",
    "roomTypeId",
    "facilityId",
    "aoDictionaryTf",
    "showInClinicalTf"
})
public class Room {

    @JsonProperty("roomId")
    private Integer roomId;
    @JsonProperty("quickCode")
    private String quickCode;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("roomTypeId")
    private Integer roomTypeId;
    @JsonProperty("facilityId")
    private Integer facilityId;
    @JsonProperty("aoDictionaryTf")
    private Boolean aoDictionaryTf;
    @JsonProperty("showInClinicalTf")
    private Boolean showInClinicalTf;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("roomId")
    public Integer getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Room withRoomId(Integer roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("quickCode")
    public String getQuickCode() {
        return quickCode;
    }

    @JsonProperty("quickCode")
    public void setQuickCode(String quickCode) {
        this.quickCode = quickCode;
    }

    public Room withQuickCode(String quickCode) {
        this.quickCode = quickCode;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public Room withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Room withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public Room withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("roomTypeId")
    public Integer getRoomTypeId() {
        return roomTypeId;
    }

    @JsonProperty("roomTypeId")
    public void setRoomTypeId(Integer roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    public Room withRoomTypeId(Integer roomTypeId) {
        this.roomTypeId = roomTypeId;
        return this;
    }

    @JsonProperty("facilityId")
    public Integer getFacilityId() {
        return facilityId;
    }

    @JsonProperty("facilityId")
    public void setFacilityId(Integer facilityId) {
        this.facilityId = facilityId;
    }

    public Room withFacilityId(Integer facilityId) {
        this.facilityId = facilityId;
        return this;
    }

    @JsonProperty("aoDictionaryTf")
    public Boolean getAoDictionaryTf() {
        return aoDictionaryTf;
    }

    @JsonProperty("aoDictionaryTf")
    public void setAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
    }

    public Room withAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
        return this;
    }

    @JsonProperty("showInClinicalTf")
    public Boolean getShowInClinicalTf() {
        return showInClinicalTf;
    }

    @JsonProperty("showInClinicalTf")
    public void setShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
    }

    public Room withShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Room withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(roomId).append(quickCode).append(activeTf).append(organizationId).append(name).append(roomTypeId).append(facilityId).append(aoDictionaryTf).append(showInClinicalTf).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Room) == false) {
            return false;
        }
        Room rhs = ((Room) other);
        return new EqualsBuilder().append(roomId, rhs.roomId).append(quickCode, rhs.quickCode).append(activeTf, rhs.activeTf).append(organizationId, rhs.organizationId).append(name, rhs.name).append(roomTypeId, rhs.roomTypeId).append(facilityId, rhs.facilityId).append(aoDictionaryTf, rhs.aoDictionaryTf).append(showInClinicalTf, rhs.showInClinicalTf).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
