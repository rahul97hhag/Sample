
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "electronicClaim",
    "paperForm",
    "insuranceCarrierId",
    "insuranceCarrierName",
    "insurancePlanSaveDetails"
})
public class SaveInsuranceCarrier {

    @JsonProperty("electronicClaim")
    private Integer electronicClaim;
    @JsonProperty("paperForm")
    private Integer paperForm;
    @JsonProperty("insuranceCarrierId")
    private Integer insuranceCarrierId;
    @JsonProperty("insuranceCarrierName")
    private String insuranceCarrierName;
    @JsonProperty("insurancePlanSaveDetails")
    private InsurancePlanSaveDetails insurancePlanSaveDetails;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("electronicClaim")
    public Integer getElectronicClaim() {
        return electronicClaim;
    }

    @JsonProperty("electronicClaim")
    public void setElectronicClaim(Integer electronicClaim) {
        this.electronicClaim = electronicClaim;
    }

    public SaveInsuranceCarrier withElectronicClaim(Integer electronicClaim) {
        this.electronicClaim = electronicClaim;
        return this;
    }

    @JsonProperty("paperForm")
    public Integer getPaperForm() {
        return paperForm;
    }

    @JsonProperty("paperForm")
    public void setPaperForm(Integer paperForm) {
        this.paperForm = paperForm;
    }

    public SaveInsuranceCarrier withPaperForm(Integer paperForm) {
        this.paperForm = paperForm;
        return this;
    }

    @JsonProperty("insuranceCarrierId")
    public Integer getInsuranceCarrierId() {
        return insuranceCarrierId;
    }

    @JsonProperty("insuranceCarrierId")
    public void setInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
    }

    public SaveInsuranceCarrier withInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
        return this;
    }

    @JsonProperty("insuranceCarrierName")
    public String getInsuranceCarrierName() {
        return insuranceCarrierName;
    }

    @JsonProperty("insuranceCarrierName")
    public void setInsuranceCarrierName(String insuranceCarrierName) {
        this.insuranceCarrierName = insuranceCarrierName;
    }

    public SaveInsuranceCarrier withInsuranceCarrierName(String insuranceCarrierName) {
        this.insuranceCarrierName = insuranceCarrierName;
        return this;
    }

    @JsonProperty("insurancePlanSaveDetails")
    public InsurancePlanSaveDetails getInsurancePlanSaveDetails() {
        return insurancePlanSaveDetails;
    }

    @JsonProperty("insurancePlanSaveDetails")
    public void setInsurancePlanSaveDetails(InsurancePlanSaveDetails insurancePlanSaveDetails) {
        this.insurancePlanSaveDetails = insurancePlanSaveDetails;
    }

    public SaveInsuranceCarrier withInsurancePlanSaveDetails(InsurancePlanSaveDetails insurancePlanSaveDetails) {
        this.insurancePlanSaveDetails = insurancePlanSaveDetails;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SaveInsuranceCarrier withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(electronicClaim).append(paperForm).append(insuranceCarrierId).append(insuranceCarrierName).append(insurancePlanSaveDetails).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaveInsuranceCarrier) == false) {
            return false;
        }
        SaveInsuranceCarrier rhs = ((SaveInsuranceCarrier) other);
        return new EqualsBuilder().append(electronicClaim, rhs.electronicClaim).append(paperForm, rhs.paperForm).append(insuranceCarrierId, rhs.insuranceCarrierId).append(insuranceCarrierName, rhs.insuranceCarrierName).append(insurancePlanSaveDetails, rhs.insurancePlanSaveDetails).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
