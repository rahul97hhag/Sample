
package com.bhavani.models.patientCases.chargeEntry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bhavani.models.patientCases.casesToCodeResponse.DiagnosisList;
import com.bhavani.models.scheduledProcedures.FeeScheduleItem;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "unableToCode",
    "panelCollapsed",
    "diagnosisList",
    "primaryInsurancesList",
    "secondaryInsurancesList",
    "tertiaryInsurancesList",
    "controlsModifiedInEditChargeMode",
    "fullChargeCorrectionRequired",
    "generateBillStateModified",
    "performedCaseSupply",
    "selectedSupplyToInventory",
    "isReadOnlyPeriodBatch",
    "resetClosedPeriodBatch",
    "isNewProcedureAdded",
    "isAmountChanged",
    "insuranceModification",
    "guarantorModification",
    "isGCode",
    "isCombinedCodingChargeEntry",
    "isCorrected",
    "diagnosisCodesRemoved",
    "guid",
    "eventSource",
    "performedCaseProcedureId",
    "dateOfSurgery",
    "caseSummaryId",
    "caseProcedureId",
    "cptProcedureId",
    "providerId",
    "referingProviderId",
    "units",
    "allowedAmount",
    "generateBill",
    "cptModifier1Id",
    "cptModifier2Id",
    "cptModifier3Id",
    "cptModifier4Id",
    "sortorder",
    "physicianName",
    "referingProviderName",
    "feeScheduleId",
    "cptProcedureDescription",
    "cptCode",
    "appointmentId",
    "selfPay",
    "patientId",
    "workersCompensation",
    "transactionList",
    "chargeEntryPatientInsMap",
    "chargeAutoCorrected",
    "preopDiagnosisList",
    "performedCaseItemTypeId",
    "lastBilledDate",
    "feeScheduleItem",
    "isCaseProcedureSelfPay",
    "sourceIdentifier",
    "chargeTransactionIndex",
    "chargeTransaction",
    "debitTransaction",
    "writeOffList",
    "periodBatch",
    "batch",
    "primaryInsuranceId",
    "secondaryInsuranceId",
    "tertiaryInsuranceId"
})
public class ChargeEntry {

    @JsonProperty("unableToCode")
    private Boolean unableToCode;
    @JsonProperty("panelCollapsed")
    private Boolean panelCollapsed;
    @JsonProperty("diagnosisList")
    private List<DiagnosisList> diagnosisList = new ArrayList<DiagnosisList>();
    @JsonProperty("primaryInsurancesList")
    private List<InsurancesListItem> primaryInsurancesList = new ArrayList<InsurancesListItem>();
    @JsonProperty("secondaryInsurancesList")
    private List<InsurancesListItem> secondaryInsurancesList = new ArrayList<InsurancesListItem>();
    @JsonProperty("tertiaryInsurancesList")
    private List<InsurancesListItem> tertiaryInsurancesList = new ArrayList<InsurancesListItem>();
    @JsonProperty("controlsModifiedInEditChargeMode")
    private Boolean controlsModifiedInEditChargeMode;
    @JsonProperty("fullChargeCorrectionRequired")
    private Object fullChargeCorrectionRequired;
    @JsonProperty("generateBillStateModified")
    private Boolean generateBillStateModified;
    @JsonProperty("performedCaseSupply")
    private Object performedCaseSupply;
    @JsonProperty("selectedSupplyToInventory")
    private Object selectedSupplyToInventory;
    @JsonProperty("isReadOnlyPeriodBatch")
    private Boolean isReadOnlyPeriodBatch;
    @JsonProperty("resetClosedPeriodBatch")
    private Boolean resetClosedPeriodBatch;
    @JsonProperty("isNewProcedureAdded")
    private Boolean isNewProcedureAdded;
    @JsonProperty("isAmountChanged")
    private Boolean isAmountChanged;
    @JsonProperty("insuranceModification")
    private Integer insuranceModification;
    @JsonProperty("guarantorModification")
    private Integer guarantorModification;
    @JsonProperty("isGCode")
    private Boolean isGCode;
    @JsonProperty("isCombinedCodingChargeEntry")
    private Boolean isCombinedCodingChargeEntry;
    @JsonProperty("isCorrected")
    private Boolean isCorrected;
    @JsonProperty("diagnosisCodesRemoved")
    private Boolean diagnosisCodesRemoved;
    @JsonProperty("guid")
    private String guid;
    @JsonProperty("eventSource")
    private String eventSource;
    @JsonProperty("performedCaseProcedureId")
    private Integer performedCaseProcedureId;
    @JsonProperty("dateOfSurgery")
    private Object dateOfSurgery;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("caseProcedureId")
    private Integer caseProcedureId;
    @JsonProperty("cptProcedureId")
    private Integer cptProcedureId;
    @JsonProperty("providerId")
    private Integer providerId;
    @JsonProperty("referingProviderId")
    private Object referingProviderId;
    @JsonProperty("units")
    private Integer units;
    @JsonProperty("allowedAmount")
    private Object allowedAmount;
    @JsonProperty("generateBill")
    private Boolean generateBill;
    @JsonProperty("cptModifier1Id")
    private Object cptModifier1Id;
    @JsonProperty("cptModifier2Id")
    private Object cptModifier2Id;
    @JsonProperty("cptModifier3Id")
    private Object cptModifier3Id;
    @JsonProperty("cptModifier4Id")
    private Object cptModifier4Id;
    @JsonProperty("sortorder")
    private Integer sortorder;
    @JsonProperty("physicianName")
    private String physicianName;
    @JsonProperty("referingProviderName")
    private Object referingProviderName;
    @JsonProperty("feeScheduleId")
    private Integer feeScheduleId;
    @JsonProperty("cptProcedureDescription")
    private String cptProcedureDescription;
    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("appointmentId")
    private Integer appointmentId;
    @JsonProperty("selfPay")
    private Boolean selfPay;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("workersCompensation")
    private Boolean workersCompensation;
    @JsonProperty("transactionList")
    private List<TransactionList> transactionList = new ArrayList<TransactionList>();
    @JsonProperty("chargeEntryPatientInsMap")
    private List<ChargeEntryPatientInsMap> chargeEntryPatientInsMap = new ArrayList<ChargeEntryPatientInsMap>();
    @JsonProperty("chargeAutoCorrected")
    private Boolean chargeAutoCorrected;
    @JsonProperty("preopDiagnosisList")
    private List<Object> preopDiagnosisList = new ArrayList<Object>();
    @JsonProperty("performedCaseItemTypeId")
    private Integer performedCaseItemTypeId;
    @JsonProperty("lastBilledDate")
    private Object lastBilledDate;
    @JsonProperty("feeScheduleItem")
    private FeeScheduleItem feeScheduleItem;
    @JsonProperty("isCaseProcedureSelfPay")
    private Boolean isCaseProcedureSelfPay;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonProperty("chargeTransactionIndex")
    private Integer chargeTransactionIndex;
    @JsonProperty("chargeTransaction")
    private ChargeTransaction chargeTransaction;
    @JsonProperty("debitTransaction")
    private DebitTransaction debitTransaction;
    @JsonProperty("writeOffList")
    private List<Object> writeOffList = new ArrayList<Object>();
    @JsonProperty("periodBatch")
    private PeriodBatch periodBatch;
    @JsonProperty("batch")
    private Batch batch;
    @JsonProperty("primaryInsuranceId")
    private Integer primaryInsuranceId;
    @JsonProperty("secondaryInsuranceId")
    private Object secondaryInsuranceId;
    @JsonProperty("tertiaryInsuranceId")
    private Object tertiaryInsuranceId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("unableToCode")
    public Boolean getUnableToCode() {
        return unableToCode;
    }

    @JsonProperty("unableToCode")
    public void setUnableToCode(Boolean unableToCode) {
        this.unableToCode = unableToCode;
    }

    public ChargeEntry withUnableToCode(Boolean unableToCode) {
        this.unableToCode = unableToCode;
        return this;
    }

    @JsonProperty("panelCollapsed")
    public Boolean getPanelCollapsed() {
        return panelCollapsed;
    }

    @JsonProperty("panelCollapsed")
    public void setPanelCollapsed(Boolean panelCollapsed) {
        this.panelCollapsed = panelCollapsed;
    }

    public ChargeEntry withPanelCollapsed(Boolean panelCollapsed) {
        this.panelCollapsed = panelCollapsed;
        return this;
    }

    @JsonProperty("diagnosisList")
    public List<DiagnosisList> getDiagnosisList() {
        return diagnosisList;
    }

    @JsonProperty("diagnosisList")
    public void setDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
    }

    public ChargeEntry withDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
        return this;
    }

    @JsonProperty("primaryInsurancesList")
    public List<InsurancesListItem> getPrimaryInsurancesList() {
        return primaryInsurancesList;
    }

    @JsonProperty("primaryInsurancesList")
    public void setPrimaryInsurancesList(List<InsurancesListItem> primaryInsurancesList) {
        this.primaryInsurancesList = primaryInsurancesList;
    }

    public ChargeEntry withPrimaryInsurancesList(List<InsurancesListItem> primaryInsurancesList) {
        this.primaryInsurancesList = primaryInsurancesList;
        return this;
    }

    @JsonProperty("secondaryInsurancesList")
    public List<InsurancesListItem> getSecondaryInsurancesList() {
        return secondaryInsurancesList;
    }

    @JsonProperty("secondaryInsurancesList")
    public void setSecondaryInsurancesList(List<InsurancesListItem> secondaryInsurancesList) {
        this.secondaryInsurancesList = secondaryInsurancesList;
    }

    public ChargeEntry withSecondaryInsurancesList(List<InsurancesListItem> secondaryInsurancesList) {
        this.secondaryInsurancesList = secondaryInsurancesList;
        return this;
    }

    @JsonProperty("tertiaryInsurancesList")
    public List<InsurancesListItem> getTertiaryInsurancesList() {
        return tertiaryInsurancesList;
    }

    @JsonProperty("tertiaryInsurancesList")
    public void setTertiaryInsurancesList(List<InsurancesListItem> tertiaryInsurancesList) {
        this.tertiaryInsurancesList = tertiaryInsurancesList;
    }

    public ChargeEntry withTertiaryInsurancesList(List<InsurancesListItem> tertiaryInsurancesList) {
        this.tertiaryInsurancesList = tertiaryInsurancesList;
        return this;
    }

    @JsonProperty("controlsModifiedInEditChargeMode")
    public Boolean getControlsModifiedInEditChargeMode() {
        return controlsModifiedInEditChargeMode;
    }

    @JsonProperty("controlsModifiedInEditChargeMode")
    public void setControlsModifiedInEditChargeMode(Boolean controlsModifiedInEditChargeMode) {
        this.controlsModifiedInEditChargeMode = controlsModifiedInEditChargeMode;
    }

    public ChargeEntry withControlsModifiedInEditChargeMode(Boolean controlsModifiedInEditChargeMode) {
        this.controlsModifiedInEditChargeMode = controlsModifiedInEditChargeMode;
        return this;
    }

    @JsonProperty("fullChargeCorrectionRequired")
    public Object getFullChargeCorrectionRequired() {
        return fullChargeCorrectionRequired;
    }

    @JsonProperty("fullChargeCorrectionRequired")
    public void setFullChargeCorrectionRequired(Object fullChargeCorrectionRequired) {
        this.fullChargeCorrectionRequired = fullChargeCorrectionRequired;
    }

    public ChargeEntry withFullChargeCorrectionRequired(Object fullChargeCorrectionRequired) {
        this.fullChargeCorrectionRequired = fullChargeCorrectionRequired;
        return this;
    }

    @JsonProperty("generateBillStateModified")
    public Boolean getGenerateBillStateModified() {
        return generateBillStateModified;
    }

    @JsonProperty("generateBillStateModified")
    public void setGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
    }

    public ChargeEntry withGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
        return this;
    }

    @JsonProperty("performedCaseSupply")
    public Object getPerformedCaseSupply() {
        return performedCaseSupply;
    }

    @JsonProperty("performedCaseSupply")
    public void setPerformedCaseSupply(Object performedCaseSupply) {
        this.performedCaseSupply = performedCaseSupply;
    }

    public ChargeEntry withPerformedCaseSupply(Object performedCaseSupply) {
        this.performedCaseSupply = performedCaseSupply;
        return this;
    }

    @JsonProperty("selectedSupplyToInventory")
    public Object getSelectedSupplyToInventory() {
        return selectedSupplyToInventory;
    }

    @JsonProperty("selectedSupplyToInventory")
    public void setSelectedSupplyToInventory(Object selectedSupplyToInventory) {
        this.selectedSupplyToInventory = selectedSupplyToInventory;
    }

    public ChargeEntry withSelectedSupplyToInventory(Object selectedSupplyToInventory) {
        this.selectedSupplyToInventory = selectedSupplyToInventory;
        return this;
    }

    @JsonProperty("isReadOnlyPeriodBatch")
    public Boolean getIsReadOnlyPeriodBatch() {
        return isReadOnlyPeriodBatch;
    }

    @JsonProperty("isReadOnlyPeriodBatch")
    public void setIsReadOnlyPeriodBatch(Boolean isReadOnlyPeriodBatch) {
        this.isReadOnlyPeriodBatch = isReadOnlyPeriodBatch;
    }

    public ChargeEntry withIsReadOnlyPeriodBatch(Boolean isReadOnlyPeriodBatch) {
        this.isReadOnlyPeriodBatch = isReadOnlyPeriodBatch;
        return this;
    }

    @JsonProperty("resetClosedPeriodBatch")
    public Boolean getResetClosedPeriodBatch() {
        return resetClosedPeriodBatch;
    }

    @JsonProperty("resetClosedPeriodBatch")
    public void setResetClosedPeriodBatch(Boolean resetClosedPeriodBatch) {
        this.resetClosedPeriodBatch = resetClosedPeriodBatch;
    }

    public ChargeEntry withResetClosedPeriodBatch(Boolean resetClosedPeriodBatch) {
        this.resetClosedPeriodBatch = resetClosedPeriodBatch;
        return this;
    }

    @JsonProperty("isNewProcedureAdded")
    public Boolean getIsNewProcedureAdded() {
        return isNewProcedureAdded;
    }

    @JsonProperty("isNewProcedureAdded")
    public void setIsNewProcedureAdded(Boolean isNewProcedureAdded) {
        this.isNewProcedureAdded = isNewProcedureAdded;
    }

    public ChargeEntry withIsNewProcedureAdded(Boolean isNewProcedureAdded) {
        this.isNewProcedureAdded = isNewProcedureAdded;
        return this;
    }

    @JsonProperty("isAmountChanged")
    public Boolean getIsAmountChanged() {
        return isAmountChanged;
    }

    @JsonProperty("isAmountChanged")
    public void setIsAmountChanged(Boolean isAmountChanged) {
        this.isAmountChanged = isAmountChanged;
    }

    public ChargeEntry withIsAmountChanged(Boolean isAmountChanged) {
        this.isAmountChanged = isAmountChanged;
        return this;
    }

    @JsonProperty("insuranceModification")
    public Integer getInsuranceModification() {
        return insuranceModification;
    }

    @JsonProperty("insuranceModification")
    public void setInsuranceModification(Integer insuranceModification) {
        this.insuranceModification = insuranceModification;
    }

    public ChargeEntry withInsuranceModification(Integer insuranceModification) {
        this.insuranceModification = insuranceModification;
        return this;
    }

    @JsonProperty("guarantorModification")
    public Integer getGuarantorModification() {
        return guarantorModification;
    }

    @JsonProperty("guarantorModification")
    public void setGuarantorModification(Integer guarantorModification) {
        this.guarantorModification = guarantorModification;
    }

    public ChargeEntry withGuarantorModification(Integer guarantorModification) {
        this.guarantorModification = guarantorModification;
        return this;
    }

    @JsonProperty("isGCode")
    public Boolean getIsGCode() {
        return isGCode;
    }

    @JsonProperty("isGCode")
    public void setIsGCode(Boolean isGCode) {
        this.isGCode = isGCode;
    }

    public ChargeEntry withIsGCode(Boolean isGCode) {
        this.isGCode = isGCode;
        return this;
    }

    @JsonProperty("isCombinedCodingChargeEntry")
    public Boolean getIsCombinedCodingChargeEntry() {
        return isCombinedCodingChargeEntry;
    }

    @JsonProperty("isCombinedCodingChargeEntry")
    public void setIsCombinedCodingChargeEntry(Boolean isCombinedCodingChargeEntry) {
        this.isCombinedCodingChargeEntry = isCombinedCodingChargeEntry;
    }

    public ChargeEntry withIsCombinedCodingChargeEntry(Boolean isCombinedCodingChargeEntry) {
        this.isCombinedCodingChargeEntry = isCombinedCodingChargeEntry;
        return this;
    }

    @JsonProperty("isCorrected")
    public Boolean getIsCorrected() {
        return isCorrected;
    }

    @JsonProperty("isCorrected")
    public void setIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
    }

    public ChargeEntry withIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
        return this;
    }

    @JsonProperty("diagnosisCodesRemoved")
    public Boolean getDiagnosisCodesRemoved() {
        return diagnosisCodesRemoved;
    }

    @JsonProperty("diagnosisCodesRemoved")
    public void setDiagnosisCodesRemoved(Boolean diagnosisCodesRemoved) {
        this.diagnosisCodesRemoved = diagnosisCodesRemoved;
    }

    public ChargeEntry withDiagnosisCodesRemoved(Boolean diagnosisCodesRemoved) {
        this.diagnosisCodesRemoved = diagnosisCodesRemoved;
        return this;
    }

    @JsonProperty("guid")
    public String getGuid() {
        return guid;
    }

    @JsonProperty("guid")
    public void setGuid(String guid) {
        this.guid = guid;
    }

    public ChargeEntry withGuid(String guid) {
        this.guid = guid;
        return this;
    }

    @JsonProperty("eventSource")
    public String getEventSource() {
        return eventSource;
    }

    @JsonProperty("eventSource")
    public void setEventSource(String eventSource) {
        this.eventSource = eventSource;
    }

    public ChargeEntry withEventSource(String eventSource) {
        this.eventSource = eventSource;
        return this;
    }

    @JsonProperty("performedCaseProcedureId")
    public Integer getPerformedCaseProcedureId() {
        return performedCaseProcedureId;
    }

    @JsonProperty("performedCaseProcedureId")
    public void setPerformedCaseProcedureId(Integer performedCaseProcedureId) {
        this.performedCaseProcedureId = performedCaseProcedureId;
    }

    public ChargeEntry withPerformedCaseProcedureId(Integer performedCaseProcedureId) {
        this.performedCaseProcedureId = performedCaseProcedureId;
        return this;
    }

    @JsonProperty("dateOfSurgery")
    public Object getDateOfSurgery() {
        return dateOfSurgery;
    }

    @JsonProperty("dateOfSurgery")
    public void setDateOfSurgery(Object dateOfSurgery) {
        this.dateOfSurgery = dateOfSurgery;
    }

    public ChargeEntry withDateOfSurgery(Object dateOfSurgery) {
        this.dateOfSurgery = dateOfSurgery;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public ChargeEntry withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("caseProcedureId")
    public Integer getCaseProcedureId() {
        return caseProcedureId;
    }

    @JsonProperty("caseProcedureId")
    public void setCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
    }

    public ChargeEntry withCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
        return this;
    }

    @JsonProperty("cptProcedureId")
    public Integer getCptProcedureId() {
        return cptProcedureId;
    }

    @JsonProperty("cptProcedureId")
    public void setCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
    }

    public ChargeEntry withCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
        return this;
    }

    @JsonProperty("providerId")
    public Integer getProviderId() {
        return providerId;
    }

    @JsonProperty("providerId")
    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }

    public ChargeEntry withProviderId(Integer providerId) {
        this.providerId = providerId;
        return this;
    }

    @JsonProperty("referingProviderId")
    public Object getReferingProviderId() {
        return referingProviderId;
    }

    @JsonProperty("referingProviderId")
    public void setReferingProviderId(Object referingProviderId) {
        this.referingProviderId = referingProviderId;
    }

    public ChargeEntry withReferingProviderId(Object referingProviderId) {
        this.referingProviderId = referingProviderId;
        return this;
    }

    @JsonProperty("units")
    public Integer getUnits() {
        return units;
    }

    @JsonProperty("units")
    public void setUnits(Integer units) {
        this.units = units;
    }

    public ChargeEntry withUnits(Integer units) {
        this.units = units;
        return this;
    }

    @JsonProperty("allowedAmount")
    public Object getAllowedAmount() {
        return allowedAmount;
    }

    @JsonProperty("allowedAmount")
    public void setAllowedAmount(Object allowedAmount) {
        this.allowedAmount = allowedAmount;
    }

    public ChargeEntry withAllowedAmount(Object allowedAmount) {
        this.allowedAmount = allowedAmount;
        return this;
    }

    @JsonProperty("generateBill")
    public Boolean getGenerateBill() {
        return generateBill;
    }

    @JsonProperty("generateBill")
    public void setGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
    }

    public ChargeEntry withGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
        return this;
    }

    @JsonProperty("cptModifier1Id")
    public Object getCptModifier1Id() {
        return cptModifier1Id;
    }

    @JsonProperty("cptModifier1Id")
    public void setCptModifier1Id(Object cptModifier1Id) {
        this.cptModifier1Id = cptModifier1Id;
    }

    public ChargeEntry withCptModifier1Id(Object cptModifier1Id) {
        this.cptModifier1Id = cptModifier1Id;
        return this;
    }

    @JsonProperty("cptModifier2Id")
    public Object getCptModifier2Id() {
        return cptModifier2Id;
    }

    @JsonProperty("cptModifier2Id")
    public void setCptModifier2Id(Object cptModifier2Id) {
        this.cptModifier2Id = cptModifier2Id;
    }

    public ChargeEntry withCptModifier2Id(Object cptModifier2Id) {
        this.cptModifier2Id = cptModifier2Id;
        return this;
    }

    @JsonProperty("cptModifier3Id")
    public Object getCptModifier3Id() {
        return cptModifier3Id;
    }

    @JsonProperty("cptModifier3Id")
    public void setCptModifier3Id(Object cptModifier3Id) {
        this.cptModifier3Id = cptModifier3Id;
    }

    public ChargeEntry withCptModifier3Id(Object cptModifier3Id) {
        this.cptModifier3Id = cptModifier3Id;
        return this;
    }

    @JsonProperty("cptModifier4Id")
    public Object getCptModifier4Id() {
        return cptModifier4Id;
    }

    @JsonProperty("cptModifier4Id")
    public void setCptModifier4Id(Object cptModifier4Id) {
        this.cptModifier4Id = cptModifier4Id;
    }

    public ChargeEntry withCptModifier4Id(Object cptModifier4Id) {
        this.cptModifier4Id = cptModifier4Id;
        return this;
    }

    @JsonProperty("sortorder")
    public Integer getSortorder() {
        return sortorder;
    }

    @JsonProperty("sortorder")
    public void setSortorder(Integer sortorder) {
        this.sortorder = sortorder;
    }

    public ChargeEntry withSortorder(Integer sortorder) {
        this.sortorder = sortorder;
        return this;
    }

    @JsonProperty("physicianName")
    public String getPhysicianName() {
        return physicianName;
    }

    @JsonProperty("physicianName")
    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public ChargeEntry withPhysicianName(String physicianName) {
        this.physicianName = physicianName;
        return this;
    }

    @JsonProperty("referingProviderName")
    public Object getReferingProviderName() {
        return referingProviderName;
    }

    @JsonProperty("referingProviderName")
    public void setReferingProviderName(Object referingProviderName) {
        this.referingProviderName = referingProviderName;
    }

    public ChargeEntry withReferingProviderName(Object referingProviderName) {
        this.referingProviderName = referingProviderName;
        return this;
    }

    @JsonProperty("feeScheduleId")
    public Integer getFeeScheduleId() {
        return feeScheduleId;
    }

    @JsonProperty("feeScheduleId")
    public void setFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
    }

    public ChargeEntry withFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
        return this;
    }

    @JsonProperty("cptProcedureDescription")
    public String getCptProcedureDescription() {
        return cptProcedureDescription;
    }

    @JsonProperty("cptProcedureDescription")
    public void setCptProcedureDescription(String cptProcedureDescription) {
        this.cptProcedureDescription = cptProcedureDescription;
    }

    public ChargeEntry withCptProcedureDescription(String cptProcedureDescription) {
        this.cptProcedureDescription = cptProcedureDescription;
        return this;
    }

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public ChargeEntry withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("appointmentId")
    public Integer getAppointmentId() {
        return appointmentId;
    }

    @JsonProperty("appointmentId")
    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public ChargeEntry withAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
        return this;
    }

    @JsonProperty("selfPay")
    public Boolean getSelfPay() {
        return selfPay;
    }

    @JsonProperty("selfPay")
    public void setSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
    }

    public ChargeEntry withSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public ChargeEntry withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("workersCompensation")
    public Boolean getWorkersCompensation() {
        return workersCompensation;
    }

    @JsonProperty("workersCompensation")
    public void setWorkersCompensation(Boolean workersCompensation) {
        this.workersCompensation = workersCompensation;
    }

    public ChargeEntry withWorkersCompensation(Boolean workersCompensation) {
        this.workersCompensation = workersCompensation;
        return this;
    }

    @JsonProperty("transactionList")
    public List<TransactionList> getTransactionList() {
        return transactionList;
    }

    @JsonProperty("transactionList")
    public void setTransactionList(List<TransactionList> transactionList) {
        this.transactionList = transactionList;
    }

    public ChargeEntry withTransactionList(List<TransactionList> transactionList) {
        this.transactionList = transactionList;
        return this;
    }

    @JsonProperty("chargeEntryPatientInsMap")
    public List<ChargeEntryPatientInsMap> getChargeEntryPatientInsMap() {
        return chargeEntryPatientInsMap;
    }

    @JsonProperty("chargeEntryPatientInsMap")
    public void setChargeEntryPatientInsMap(List<ChargeEntryPatientInsMap> chargeEntryPatientInsMap) {
        this.chargeEntryPatientInsMap = chargeEntryPatientInsMap;
    }

    public ChargeEntry withChargeEntryPatientInsMap(List<ChargeEntryPatientInsMap> chargeEntryPatientInsMap) {
        this.chargeEntryPatientInsMap = chargeEntryPatientInsMap;
        return this;
    }

    @JsonProperty("chargeAutoCorrected")
    public Boolean getChargeAutoCorrected() {
        return chargeAutoCorrected;
    }

    @JsonProperty("chargeAutoCorrected")
    public void setChargeAutoCorrected(Boolean chargeAutoCorrected) {
        this.chargeAutoCorrected = chargeAutoCorrected;
    }

    public ChargeEntry withChargeAutoCorrected(Boolean chargeAutoCorrected) {
        this.chargeAutoCorrected = chargeAutoCorrected;
        return this;
    }

    @JsonProperty("preopDiagnosisList")
    public List<Object> getPreopDiagnosisList() {
        return preopDiagnosisList;
    }

    @JsonProperty("preopDiagnosisList")
    public void setPreopDiagnosisList(List<Object> preopDiagnosisList) {
        this.preopDiagnosisList = preopDiagnosisList;
    }

    public ChargeEntry withPreopDiagnosisList(List<Object> preopDiagnosisList) {
        this.preopDiagnosisList = preopDiagnosisList;
        return this;
    }

    @JsonProperty("performedCaseItemTypeId")
    public Integer getPerformedCaseItemTypeId() {
        return performedCaseItemTypeId;
    }

    @JsonProperty("performedCaseItemTypeId")
    public void setPerformedCaseItemTypeId(Integer performedCaseItemTypeId) {
        this.performedCaseItemTypeId = performedCaseItemTypeId;
    }

    public ChargeEntry withPerformedCaseItemTypeId(Integer performedCaseItemTypeId) {
        this.performedCaseItemTypeId = performedCaseItemTypeId;
        return this;
    }

    @JsonProperty("lastBilledDate")
    public Object getLastBilledDate() {
        return lastBilledDate;
    }

    @JsonProperty("lastBilledDate")
    public void setLastBilledDate(Object lastBilledDate) {
        this.lastBilledDate = lastBilledDate;
    }

    public ChargeEntry withLastBilledDate(Object lastBilledDate) {
        this.lastBilledDate = lastBilledDate;
        return this;
    }

    @JsonProperty("feeScheduleItem")
    public FeeScheduleItem getFeeScheduleItem() {
        return feeScheduleItem;
    }

    @JsonProperty("feeScheduleItem")
    public void setFeeScheduleItem(FeeScheduleItem feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
    }

    public ChargeEntry withFeeScheduleItem(FeeScheduleItem feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
        return this;
    }

    @JsonProperty("isCaseProcedureSelfPay")
    public Boolean getIsCaseProcedureSelfPay() {
        return isCaseProcedureSelfPay;
    }

    @JsonProperty("isCaseProcedureSelfPay")
    public void setIsCaseProcedureSelfPay(Boolean isCaseProcedureSelfPay) {
        this.isCaseProcedureSelfPay = isCaseProcedureSelfPay;
    }

    public ChargeEntry withIsCaseProcedureSelfPay(Boolean isCaseProcedureSelfPay) {
        this.isCaseProcedureSelfPay = isCaseProcedureSelfPay;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public ChargeEntry withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @JsonProperty("chargeTransactionIndex")
    public Integer getChargeTransactionIndex() {
        return chargeTransactionIndex;
    }

    @JsonProperty("chargeTransactionIndex")
    public void setChargeTransactionIndex(Integer chargeTransactionIndex) {
        this.chargeTransactionIndex = chargeTransactionIndex;
    }

    public ChargeEntry withChargeTransactionIndex(Integer chargeTransactionIndex) {
        this.chargeTransactionIndex = chargeTransactionIndex;
        return this;
    }

    @JsonProperty("chargeTransaction")
    public ChargeTransaction getChargeTransaction() {
        return chargeTransaction;
    }

    @JsonProperty("chargeTransaction")
    public void setChargeTransaction(ChargeTransaction chargeTransaction) {
        this.chargeTransaction = chargeTransaction;
    }

    public ChargeEntry withChargeTransaction(ChargeTransaction chargeTransaction) {
        this.chargeTransaction = chargeTransaction;
        return this;
    }

    @JsonProperty("debitTransaction")
    public DebitTransaction getDebitTransaction() {
        return debitTransaction;
    }

    @JsonProperty("debitTransaction")
    public void setDebitTransaction(DebitTransaction debitTransaction) {
        this.debitTransaction = debitTransaction;
    }

    public ChargeEntry withDebitTransaction(DebitTransaction debitTransaction) {
        this.debitTransaction = debitTransaction;
        return this;
    }

    @JsonProperty("writeOffList")
    public List<Object> getWriteOffList() {
        return writeOffList;
    }

    @JsonProperty("writeOffList")
    public void setWriteOffList(List<Object> writeOffList) {
        this.writeOffList = writeOffList;
    }

    public ChargeEntry withWriteOffList(List<Object> writeOffList) {
        this.writeOffList = writeOffList;
        return this;
    }

    @JsonProperty("periodBatch")
    public PeriodBatch getPeriodBatch() {
        return periodBatch;
    }

    @JsonProperty("periodBatch")
    public void setPeriodBatch(PeriodBatch periodBatch) {
        this.periodBatch = periodBatch;
    }

    public ChargeEntry withPeriodBatch(PeriodBatch periodBatch) {
        this.periodBatch = periodBatch;
        return this;
    }

    @JsonProperty("batch")
    public Batch getBatch() {
        return batch;
    }

    @JsonProperty("batch")
    public void setBatch(Batch batch) {
        this.batch = batch;
    }

    public ChargeEntry withBatch(Batch batch) {
        this.batch = batch;
        return this;
    }

    @JsonProperty("primaryInsuranceId")
    public Integer getPrimaryInsuranceId() {
        return primaryInsuranceId;
    }

    @JsonProperty("primaryInsuranceId")
    public void setPrimaryInsuranceId(Integer primaryInsuranceId) {
        this.primaryInsuranceId = primaryInsuranceId;
    }

    public ChargeEntry withPrimaryInsuranceId(Integer primaryInsuranceId) {
        this.primaryInsuranceId = primaryInsuranceId;
        return this;
    }

    @JsonProperty("secondaryInsuranceId")
    public Object getSecondaryInsuranceId() {
        return secondaryInsuranceId;
    }

    @JsonProperty("secondaryInsuranceId")
    public void setSecondaryInsuranceId(Object secondaryInsuranceId) {
        this.secondaryInsuranceId = secondaryInsuranceId;
    }

    public ChargeEntry withSecondaryInsuranceId(Object secondaryInsuranceId) {
        this.secondaryInsuranceId = secondaryInsuranceId;
        return this;
    }

    @JsonProperty("tertiaryInsuranceId")
    public Object getTertiaryInsuranceId() {
        return tertiaryInsuranceId;
    }

    @JsonProperty("tertiaryInsuranceId")
    public void setTertiaryInsuranceId(Object tertiaryInsuranceId) {
        this.tertiaryInsuranceId = tertiaryInsuranceId;
    }

    public ChargeEntry withTertiaryInsuranceId(Object tertiaryInsuranceId) {
        this.tertiaryInsuranceId = tertiaryInsuranceId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChargeEntry withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(unableToCode).append(panelCollapsed).append(diagnosisList).append(primaryInsurancesList).append(secondaryInsurancesList).append(tertiaryInsurancesList).append(controlsModifiedInEditChargeMode).append(fullChargeCorrectionRequired).append(generateBillStateModified).append(performedCaseSupply).append(selectedSupplyToInventory).append(isReadOnlyPeriodBatch).append(resetClosedPeriodBatch).append(isNewProcedureAdded).append(isAmountChanged).append(insuranceModification).append(guarantorModification).append(isGCode).append(isCombinedCodingChargeEntry).append(isCorrected).append(diagnosisCodesRemoved).append(guid).append(eventSource).append(performedCaseProcedureId).append(dateOfSurgery).append(caseSummaryId).append(caseProcedureId).append(cptProcedureId).append(providerId).append(referingProviderId).append(units).append(allowedAmount).append(generateBill).append(cptModifier1Id).append(cptModifier2Id).append(cptModifier3Id).append(cptModifier4Id).append(sortorder).append(physicianName).append(referingProviderName).append(feeScheduleId).append(cptProcedureDescription).append(cptCode).append(appointmentId).append(selfPay).append(patientId).append(workersCompensation).append(transactionList).append(chargeEntryPatientInsMap).append(chargeAutoCorrected).append(preopDiagnosisList).append(performedCaseItemTypeId).append(lastBilledDate).append(feeScheduleItem).append(isCaseProcedureSelfPay).append(sourceIdentifier).append(chargeTransactionIndex).append(chargeTransaction).append(debitTransaction).append(writeOffList).append(periodBatch).append(batch).append(primaryInsuranceId).append(secondaryInsuranceId).append(tertiaryInsuranceId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChargeEntry) == false) {
            return false;
        }
        ChargeEntry rhs = ((ChargeEntry) other);
        return new EqualsBuilder().append(unableToCode, rhs.unableToCode).append(panelCollapsed, rhs.panelCollapsed).append(diagnosisList, rhs.diagnosisList).append(primaryInsurancesList, rhs.primaryInsurancesList).append(secondaryInsurancesList, rhs.secondaryInsurancesList).append(tertiaryInsurancesList, rhs.tertiaryInsurancesList).append(controlsModifiedInEditChargeMode, rhs.controlsModifiedInEditChargeMode).append(fullChargeCorrectionRequired, rhs.fullChargeCorrectionRequired).append(generateBillStateModified, rhs.generateBillStateModified).append(performedCaseSupply, rhs.performedCaseSupply).append(selectedSupplyToInventory, rhs.selectedSupplyToInventory).append(isReadOnlyPeriodBatch, rhs.isReadOnlyPeriodBatch).append(resetClosedPeriodBatch, rhs.resetClosedPeriodBatch).append(isNewProcedureAdded, rhs.isNewProcedureAdded).append(isAmountChanged, rhs.isAmountChanged).append(insuranceModification, rhs.insuranceModification).append(guarantorModification, rhs.guarantorModification).append(isGCode, rhs.isGCode).append(isCombinedCodingChargeEntry, rhs.isCombinedCodingChargeEntry).append(isCorrected, rhs.isCorrected).append(diagnosisCodesRemoved, rhs.diagnosisCodesRemoved).append(guid, rhs.guid).append(eventSource, rhs.eventSource).append(performedCaseProcedureId, rhs.performedCaseProcedureId).append(dateOfSurgery, rhs.dateOfSurgery).append(caseSummaryId, rhs.caseSummaryId).append(caseProcedureId, rhs.caseProcedureId).append(cptProcedureId, rhs.cptProcedureId).append(providerId, rhs.providerId).append(referingProviderId, rhs.referingProviderId).append(units, rhs.units).append(allowedAmount, rhs.allowedAmount).append(generateBill, rhs.generateBill).append(cptModifier1Id, rhs.cptModifier1Id).append(cptModifier2Id, rhs.cptModifier2Id).append(cptModifier3Id, rhs.cptModifier3Id).append(cptModifier4Id, rhs.cptModifier4Id).append(sortorder, rhs.sortorder).append(physicianName, rhs.physicianName).append(referingProviderName, rhs.referingProviderName).append(feeScheduleId, rhs.feeScheduleId).append(cptProcedureDescription, rhs.cptProcedureDescription).append(cptCode, rhs.cptCode).append(appointmentId, rhs.appointmentId).append(selfPay, rhs.selfPay).append(patientId, rhs.patientId).append(workersCompensation, rhs.workersCompensation).append(transactionList, rhs.transactionList).append(chargeEntryPatientInsMap, rhs.chargeEntryPatientInsMap).append(chargeAutoCorrected, rhs.chargeAutoCorrected).append(preopDiagnosisList, rhs.preopDiagnosisList).append(performedCaseItemTypeId, rhs.performedCaseItemTypeId).append(lastBilledDate, rhs.lastBilledDate).append(feeScheduleItem, rhs.feeScheduleItem).append(isCaseProcedureSelfPay, rhs.isCaseProcedureSelfPay).append(sourceIdentifier, rhs.sourceIdentifier).append(chargeTransactionIndex, rhs.chargeTransactionIndex).append(chargeTransaction, rhs.chargeTransaction).append(debitTransaction, rhs.debitTransaction).append(writeOffList, rhs.writeOffList).append(periodBatch, rhs.periodBatch).append(batch, rhs.batch).append(primaryInsuranceId, rhs.primaryInsuranceId).append(secondaryInsuranceId, rhs.secondaryInsuranceId).append(tertiaryInsuranceId, rhs.tertiaryInsuranceId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
