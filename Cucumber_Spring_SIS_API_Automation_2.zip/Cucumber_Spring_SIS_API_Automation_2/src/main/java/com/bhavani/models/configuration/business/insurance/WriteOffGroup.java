
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "writeOffGroupId",
    "writeOffGroupCode",
    "description",
    "sourceIdentifier"
})
public class WriteOffGroup {

    @JsonProperty("writeOffGroupId")
    private Integer writeOffGroupId;
    @JsonProperty("writeOffGroupCode")
    private String writeOffGroupCode;
    @JsonProperty("description")
    private String description;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("writeOffGroupId")
    public Integer getWriteOffGroupId() {
        return writeOffGroupId;
    }

    @JsonProperty("writeOffGroupId")
    public void setWriteOffGroupId(Integer writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
    }

    public WriteOffGroup withWriteOffGroupId(Integer writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
        return this;
    }

    @JsonProperty("writeOffGroupCode")
    public String getWriteOffGroupCode() {
        return writeOffGroupCode;
    }

    @JsonProperty("writeOffGroupCode")
    public void setWriteOffGroupCode(String writeOffGroupCode) {
        this.writeOffGroupCode = writeOffGroupCode;
    }

    public WriteOffGroup withWriteOffGroupCode(String writeOffGroupCode) {
        this.writeOffGroupCode = writeOffGroupCode;
        return this;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    public WriteOffGroup withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public WriteOffGroup withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public WriteOffGroup withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(writeOffGroupId).append(writeOffGroupCode).append(description).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof WriteOffGroup) == false) {
            return false;
        }
        WriteOffGroup rhs = ((WriteOffGroup) other);
        return new EqualsBuilder().append(writeOffGroupId, rhs.writeOffGroupId).append(writeOffGroupCode, rhs.writeOffGroupCode).append(description, rhs.description).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
