
package com.bhavani.models.patientCases.chargeEntry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

// @JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "periodId",
    "organizationId",
    "periodName",
    "periodCreatedDate",
    "periodClosedDate",
    "periodCreatorUsrId",
    "openedBy",
    "closedBy",
    "periodCloserUsrId",
    "periodBeginDate",
    "periodEndDate",
    "batches",
    "isActive",
    "sourceIdentifier"
})
public class Period {

    @JsonProperty("periodId")
    private Integer periodId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("periodName")
    private String periodName;
    @JsonProperty("periodCreatedDate")
    private String periodCreatedDate;
    @JsonProperty("periodClosedDate")
    private Object periodClosedDate;
    @JsonProperty("periodCreatorUsrId")
    private Integer periodCreatorUsrId;
    @JsonProperty("openedBy")
    private String openedBy;
    @JsonProperty("closedBy")
    private Object closedBy;
    @JsonProperty("periodCloserUsrId")
    private Object periodCloserUsrId;
    @JsonProperty("periodBeginDate")
    private Object periodBeginDate;
    @JsonProperty("periodEndDate")
    private Object periodEndDate;
    @JsonProperty("batches")
    private List<Batch> batches = new ArrayList<Batch>();
    @JsonProperty("isActive")
    private Boolean isActive;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("periodId")
    public Integer getPeriodId() {
        return periodId;
    }

    @JsonProperty("periodId")
    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Period withPeriodId(Integer periodId) {
        this.periodId = periodId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Period withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("periodName")
    public String getPeriodName() {
        return periodName;
    }

    @JsonProperty("periodName")
    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public Period withPeriodName(String periodName) {
        this.periodName = periodName;
        return this;
    }

    @JsonProperty("periodCreatedDate")
    public String getPeriodCreatedDate() {
        return periodCreatedDate;
    }

    @JsonProperty("periodCreatedDate")
    public void setPeriodCreatedDate(String periodCreatedDate) {
        this.periodCreatedDate = periodCreatedDate;
    }

    public Period withPeriodCreatedDate(String periodCreatedDate) {
        this.periodCreatedDate = periodCreatedDate;
        return this;
    }

    @JsonProperty("periodClosedDate")
    public Object getPeriodClosedDate() {
        return periodClosedDate;
    }

    @JsonProperty("periodClosedDate")
    public void setPeriodClosedDate(Object periodClosedDate) {
        this.periodClosedDate = periodClosedDate;
    }

    public Period withPeriodClosedDate(Object periodClosedDate) {
        this.periodClosedDate = periodClosedDate;
        return this;
    }

    @JsonProperty("periodCreatorUsrId")
    public Integer getPeriodCreatorUsrId() {
        return periodCreatorUsrId;
    }

    @JsonProperty("periodCreatorUsrId")
    public void setPeriodCreatorUsrId(Integer periodCreatorUsrId) {
        this.periodCreatorUsrId = periodCreatorUsrId;
    }

    public Period withPeriodCreatorUsrId(Integer periodCreatorUsrId) {
        this.periodCreatorUsrId = periodCreatorUsrId;
        return this;
    }

    @JsonProperty("openedBy")
    public String getOpenedBy() {
        return openedBy;
    }

    @JsonProperty("openedBy")
    public void setOpenedBy(String openedBy) {
        this.openedBy = openedBy;
    }

    public Period withOpenedBy(String openedBy) {
        this.openedBy = openedBy;
        return this;
    }

    @JsonProperty("closedBy")
    public Object getClosedBy() {
        return closedBy;
    }

    @JsonProperty("closedBy")
    public void setClosedBy(Object closedBy) {
        this.closedBy = closedBy;
    }

    public Period withClosedBy(Object closedBy) {
        this.closedBy = closedBy;
        return this;
    }

    @JsonProperty("periodCloserUsrId")
    public Object getPeriodCloserUsrId() {
        return periodCloserUsrId;
    }

    @JsonProperty("periodCloserUsrId")
    public void setPeriodCloserUsrId(Object periodCloserUsrId) {
        this.periodCloserUsrId = periodCloserUsrId;
    }

    public Period withPeriodCloserUsrId(Object periodCloserUsrId) {
        this.periodCloserUsrId = periodCloserUsrId;
        return this;
    }

    @JsonProperty("periodBeginDate")
    public Object getPeriodBeginDate() {
        return periodBeginDate;
    }

    @JsonProperty("periodBeginDate")
    public void setPeriodBeginDate(Object periodBeginDate) {
        this.periodBeginDate = periodBeginDate;
    }

    public Period withPeriodBeginDate(Object periodBeginDate) {
        this.periodBeginDate = periodBeginDate;
        return this;
    }

    @JsonProperty("periodEndDate")
    public Object getPeriodEndDate() {
        return periodEndDate;
    }

    @JsonProperty("periodEndDate")
    public void setPeriodEndDate(Object periodEndDate) {
        this.periodEndDate = periodEndDate;
    }

    public Period withPeriodEndDate(Object periodEndDate) {
        this.periodEndDate = periodEndDate;
        return this;
    }

    @JsonProperty("batches")
    public List<Batch> getBatches() {
        return batches;
    }

    @JsonProperty("batches")
    public void setBatches(List<Batch> batches) {
        this.batches = batches;
    }

    public Period withBatches(List<Batch> batches) {
        this.batches = batches;
        return this;
    }

    @JsonProperty("isActive")
    public Boolean getIsActive() {
        return isActive;
    }

    @JsonProperty("isActive")
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Period withIsActive(Boolean isActive) {
        this.isActive = isActive;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public Period withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Period withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(periodId).append(organizationId).append(periodName).append(periodCreatedDate).append(periodClosedDate).append(periodCreatorUsrId).append(openedBy).append(closedBy).append(periodCloserUsrId).append(periodBeginDate).append(periodEndDate).append(batches).append(isActive).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Period) == false) {
            return false;
        }
        Period rhs = ((Period) other);
        return new EqualsBuilder().append(periodId, rhs.periodId).append(organizationId, rhs.organizationId).append(periodName, rhs.periodName).append(periodCreatedDate, rhs.periodCreatedDate).append(periodClosedDate, rhs.periodClosedDate).append(periodCreatorUsrId, rhs.periodCreatorUsrId).append(openedBy, rhs.openedBy).append(closedBy, rhs.closedBy).append(periodCloserUsrId, rhs.periodCloserUsrId).append(periodBeginDate, rhs.periodBeginDate).append(periodEndDate, rhs.periodEndDate).append(batches, rhs.batches).append(isActive, rhs.isActive).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
