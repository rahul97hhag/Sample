
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "line1",
    "city",
    "state",
    "zip",
    "extendedZip",
    "name",
    "phone",
    "contactName",
    "insuranceCarrierObjectId"
})
public class InsuranceClaimOffice {

    @JsonProperty("line1")
    private String line1;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("extendedZip")
    private String extendedZip;
    @JsonProperty("name")
    private String name;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("contactName")
    private String contactName;
    @JsonProperty("insuranceCarrierObjectId")
    private Integer insuranceCarrierObjectId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("line1")
    public String getLine1() {
        return line1;
    }

    @JsonProperty("line1")
    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public InsuranceClaimOffice withLine1(String line1) {
        this.line1 = line1;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public InsuranceClaimOffice withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public InsuranceClaimOffice withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zip")
    public String getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(String zip) {
        this.zip = zip;
    }

    public InsuranceClaimOffice withZip(String zip) {
        this.zip = zip;
        return this;
    }

    @JsonProperty("extendedZip")
    public String getExtendedZip() {
        return extendedZip;
    }

    @JsonProperty("extendedZip")
    public void setExtendedZip(String extendedZip) {
        this.extendedZip = extendedZip;
    }

    public InsuranceClaimOffice withExtendedZip(String extendedZip) {
        this.extendedZip = extendedZip;
        return this;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public InsuranceClaimOffice withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public InsuranceClaimOffice withPhone(String phone) {
        this.phone = phone;
        return this;
    }

    @JsonProperty("contactName")
    public String getContactName() {
        return contactName;
    }

    @JsonProperty("contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public InsuranceClaimOffice withContactName(String contactName) {
        this.contactName = contactName;
        return this;
    }

    @JsonProperty("insuranceCarrierObjectId")
    public Integer getInsuranceCarrierObjectId() {
        return insuranceCarrierObjectId;
    }

    @JsonProperty("insuranceCarrierObjectId")
    public void setInsuranceCarrierObjectId(Integer insuranceCarrierObjectId) {
        this.insuranceCarrierObjectId = insuranceCarrierObjectId;
    }

    public InsuranceClaimOffice withInsuranceCarrierObjectId(Integer insuranceCarrierObjectId) {
        this.insuranceCarrierObjectId = insuranceCarrierObjectId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsuranceClaimOffice withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(line1).append(city).append(state).append(zip).append(extendedZip).append(name).append(phone).append(contactName).append(insuranceCarrierObjectId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsuranceClaimOffice) == false) {
            return false;
        }
        InsuranceClaimOffice rhs = ((InsuranceClaimOffice) other);
        return new EqualsBuilder().append(line1, rhs.line1).append(city, rhs.city).append(state, rhs.state).append(zip, rhs.zip).append(extendedZip, rhs.extendedZip).append(name, rhs.name).append(phone, rhs.phone).append(contactName, rhs.contactName).append(insuranceCarrierObjectId, rhs.insuranceCarrierObjectId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
