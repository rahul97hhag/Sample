
package com.bhavani.models.patientCases.chargeEntry;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amount",
    "isDeleted",
    "lastModifiedAmount",
    "isHidden",
    "transactionTypeId",
    "contractProcedureId"
})
public class DebitTransaction {

    @JsonProperty("amount")
    private Integer amount;
    @JsonProperty("isDeleted")
    private Boolean isDeleted;
    @JsonProperty("lastModifiedAmount")
    private Integer lastModifiedAmount;
    @JsonProperty("isHidden")
    private Boolean isHidden;
    @JsonProperty("transactionTypeId")
    private Integer transactionTypeId;
    @JsonProperty("contractProcedureId")
    private Object contractProcedureId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("amount")
    public Integer getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public DebitTransaction withAmount(Integer amount) {
        this.amount = amount;
        return this;
    }

    @JsonProperty("isDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("isDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public DebitTransaction withIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
        return this;
    }

    @JsonProperty("lastModifiedAmount")
    public Integer getLastModifiedAmount() {
        return lastModifiedAmount;
    }

    @JsonProperty("lastModifiedAmount")
    public void setLastModifiedAmount(Integer lastModifiedAmount) {
        this.lastModifiedAmount = lastModifiedAmount;
    }

    public DebitTransaction withLastModifiedAmount(Integer lastModifiedAmount) {
        this.lastModifiedAmount = lastModifiedAmount;
        return this;
    }

    @JsonProperty("isHidden")
    public Boolean getIsHidden() {
        return isHidden;
    }

    @JsonProperty("isHidden")
    public void setIsHidden(Boolean isHidden) {
        this.isHidden = isHidden;
    }

    public DebitTransaction withIsHidden(Boolean isHidden) {
        this.isHidden = isHidden;
        return this;
    }

    @JsonProperty("transactionTypeId")
    public Integer getTransactionTypeId() {
        return transactionTypeId;
    }

    @JsonProperty("transactionTypeId")
    public void setTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    public DebitTransaction withTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
        return this;
    }

    @JsonProperty("contractProcedureId")
    public Object getContractProcedureId() {
        return contractProcedureId;
    }

    @JsonProperty("contractProcedureId")
    public void setContractProcedureId(Object contractProcedureId) {
        this.contractProcedureId = contractProcedureId;
    }

    public DebitTransaction withContractProcedureId(Object contractProcedureId) {
        this.contractProcedureId = contractProcedureId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DebitTransaction withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(amount).append(isDeleted).append(lastModifiedAmount).append(isHidden).append(transactionTypeId).append(contractProcedureId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DebitTransaction) == false) {
            return false;
        }
        DebitTransaction rhs = ((DebitTransaction) other);
        return new EqualsBuilder().append(amount, rhs.amount).append(isDeleted, rhs.isDeleted).append(lastModifiedAmount, rhs.lastModifiedAmount).append(isHidden, rhs.isHidden).append(transactionTypeId, rhs.transactionTypeId).append(contractProcedureId, rhs.contractProcedureId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
