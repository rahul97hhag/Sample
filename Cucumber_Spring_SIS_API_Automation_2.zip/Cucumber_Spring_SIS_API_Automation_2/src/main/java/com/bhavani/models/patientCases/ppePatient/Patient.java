
package com.bhavani.models.patientCases.ppePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "externalPatientId",
    "accountNumber",
    "firstName",
    "lastName",
    "middleInitial",
    "dateOfBirth",
    "gender",
    "email",
    "maritalStatus",
    "address",
    "ssn",
    "mpiPatientPhone",
    "mpiPatientPhoneSecondary"
})
public class Patient {

    @JsonProperty("externalPatientId")
    private String externalPatientId;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("email")
    private String email;
    @JsonProperty("maritalStatus")
    private String maritalStatus;
    @JsonProperty("address")
    private Address address;
    @JsonProperty("ssn")
    private String ssn;
    @JsonProperty("mpiPatientPhone")
    private MpiPatientPhone mpiPatientPhone;
    @JsonProperty("mpiPatientPhoneSecondary")
    private MpiPatientPhone mpiPatientPhoneSecondary;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("externalPatientId")
    public String getExternalPatientId() {
        return externalPatientId;
    }

    @JsonProperty("externalPatientId")
    public void setExternalPatientId(String externalPatientId) {
        this.externalPatientId = externalPatientId;
    }

    public Patient withExternalPatientId(String externalPatientId) {
        this.externalPatientId = externalPatientId;
        return this;
    }

    @JsonProperty("accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Patient withAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Patient withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Patient withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public Patient withMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Patient withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public Patient withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    public Patient withEmail(String email) {
        this.email = email;
        return this;
    }

    @JsonProperty("maritalStatus")
    public String getMaritalStatus() {
        return maritalStatus;
    }

    @JsonProperty("maritalStatus")
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public Patient withMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
        return this;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    public Patient withAddress(Address address) {
        this.address = address;
        return this;
    }

    @JsonProperty("ssn")
    public String getSsn() {
        return ssn;
    }

    @JsonProperty("ssn")
    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public Patient withSsn(String ssn) {
        this.ssn = ssn;
        return this;
    }

    @JsonProperty("mpiPatientPhone")
    public MpiPatientPhone getMpiPatientPhone() {
        return mpiPatientPhone;
    }

    @JsonProperty("mpiPatientPhone")
    public void setMpiPatientPhone(MpiPatientPhone mpiPatientPhone) {
        this.mpiPatientPhone = mpiPatientPhone;
    }

    public Patient withMpiPatientPhone(MpiPatientPhone mpiPatientPhone) {
        this.mpiPatientPhone = mpiPatientPhone;
        return this;
    }

    @JsonProperty("mpiPatientPhoneSecondary")
    public MpiPatientPhone getMpiPatientPhoneSecondary() {
        return mpiPatientPhoneSecondary;
    }

    @JsonProperty("mpiPatientPhoneSecondary")
    public void setMpiPatientPhoneSecondary(MpiPatientPhone mpiPatientPhoneSecondary) {
        this.mpiPatientPhoneSecondary = mpiPatientPhoneSecondary;
    }

    public Patient withMpiPatientPhoneSecondary(MpiPatientPhone mpiPatientPhoneSecondary) {
        this.mpiPatientPhoneSecondary = mpiPatientPhoneSecondary;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Patient withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(externalPatientId).append(accountNumber).append(firstName).append(lastName).append(middleInitial).append(dateOfBirth).append(gender).append(email).append(maritalStatus).append(address).append(ssn).append(mpiPatientPhone).append(mpiPatientPhoneSecondary).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Patient) == false) {
            return false;
        }
        Patient rhs = ((Patient) other);
        return new EqualsBuilder().append(externalPatientId, rhs.externalPatientId).append(accountNumber, rhs.accountNumber).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(dateOfBirth, rhs.dateOfBirth).append(gender, rhs.gender).append(email, rhs.email).append(maritalStatus, rhs.maritalStatus).append(address, rhs.address).append(ssn, rhs.ssn).append(mpiPatientPhone, rhs.mpiPatientPhone).append(mpiPatientPhoneSecondary, rhs.mpiPatientPhoneSecondary).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
