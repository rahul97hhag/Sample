
package com.bhavani.models.patientCases.dischargePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "areaOfCareInformationId",
    "caseSummaryId",
    "moduleId",
    "admissionTime",
    "roomId",
    "admittedViaId",
    "attendedById",
    "admittedById",
    "reportById",
    "anestReportedById",
    "nurseReportedById",
    "responsibleParty",
    "anesStartTime",
    "anesStopTime",
    "admDtDatatype",
    "withdrawalTime",
    "readyForTransferTf",
    "admitTypeValue",
    "admitSourceValue",
    "roomName",
    "roomDictionaryName",
    "admittedViaValue",
    "attendedByValue",
    "admittedByValue",
    "reportByValue",
    "anestReportedByValue",
    "nurseReportedByValue",
    "patientId",
    "transferTime",
    "blockTime",
    "blockTimeNeededTf",
    "procedureAdditionalTimes",
    "overTakeMyLock",
    "lockStatus",
    "lockDescription",
    "blockTimeOutId",
    "transferModuleId",
    "patientHandOffId",
    "sourceIdentifier"
})
public class AreaCareInformationResponse {

    @JsonProperty("areaOfCareInformationId")
    private Integer areaOfCareInformationId;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("moduleId")
    private Integer moduleId;
    @JsonProperty("admissionTime")
    private String admissionTime;
    @JsonProperty("roomId")
    private Object roomId;
    @JsonProperty("admittedViaId")
    private Object admittedViaId;
    @JsonProperty("attendedById")
    private Object attendedById;
    @JsonProperty("admittedById")
    private Object admittedById;
    @JsonProperty("reportById")
    private Object reportById;
    @JsonProperty("anestReportedById")
    private Object anestReportedById;
    @JsonProperty("nurseReportedById")
    private Object nurseReportedById;
    @JsonProperty("responsibleParty")
    private Object responsibleParty;
    @JsonProperty("anesStartTime")
    private Object anesStartTime;
    @JsonProperty("anesStopTime")
    private Object anesStopTime;
    @JsonProperty("admDtDatatype")
    private Object admDtDatatype;
    @JsonProperty("withdrawalTime")
    private Object withdrawalTime;
    @JsonProperty("readyForTransferTf")
    private Boolean readyForTransferTf;
    @JsonProperty("admitTypeValue")
    private String admitTypeValue;
    @JsonProperty("admitSourceValue")
    private String admitSourceValue;
    @JsonProperty("roomName")
    private Object roomName;
    @JsonProperty("roomDictionaryName")
    private Object roomDictionaryName;
    @JsonProperty("admittedViaValue")
    private Object admittedViaValue;
    @JsonProperty("attendedByValue")
    private Object attendedByValue;
    @JsonProperty("admittedByValue")
    private Object admittedByValue;
    @JsonProperty("reportByValue")
    private Object reportByValue;
    @JsonProperty("anestReportedByValue")
    private Object anestReportedByValue;
    @JsonProperty("nurseReportedByValue")
    private Object nurseReportedByValue;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("transferTime")
    private Object transferTime;
    @JsonProperty("blockTime")
    private Object blockTime;
    @JsonProperty("blockTimeNeededTf")
    private Object blockTimeNeededTf;
    @JsonProperty("procedureAdditionalTimes")
    private Object procedureAdditionalTimes;
    @JsonProperty("overTakeMyLock")
    private Boolean overTakeMyLock;
    @JsonProperty("lockStatus")
    private Integer lockStatus;
    @JsonProperty("lockDescription")
    private Object lockDescription;
    @JsonProperty("blockTimeOutId")
    private Object blockTimeOutId;
    @JsonProperty("transferModuleId")
    private Object transferModuleId;
    @JsonProperty("patientHandOffId")
    private Object patientHandOffId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("areaOfCareInformationId")
    public Integer getAreaOfCareInformationId() {
        return areaOfCareInformationId;
    }

    @JsonProperty("areaOfCareInformationId")
    public void setAreaOfCareInformationId(Integer areaOfCareInformationId) {
        this.areaOfCareInformationId = areaOfCareInformationId;
    }

    public AreaCareInformationResponse withAreaOfCareInformationId(Integer areaOfCareInformationId) {
        this.areaOfCareInformationId = areaOfCareInformationId;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public AreaCareInformationResponse withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("moduleId")
    public Integer getModuleId() {
        return moduleId;
    }

    @JsonProperty("moduleId")
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public AreaCareInformationResponse withModuleId(Integer moduleId) {
        this.moduleId = moduleId;
        return this;
    }

    @JsonProperty("admissionTime")
    public String getAdmissionTime() {
        return admissionTime;
    }

    @JsonProperty("admissionTime")
    public void setAdmissionTime(String admissionTime) {
        this.admissionTime = admissionTime;
    }

    public AreaCareInformationResponse withAdmissionTime(String admissionTime) {
        this.admissionTime = admissionTime;
        return this;
    }

    @JsonProperty("roomId")
    public Object getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Object roomId) {
        this.roomId = roomId;
    }

    public AreaCareInformationResponse withRoomId(Object roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("admittedViaId")
    public Object getAdmittedViaId() {
        return admittedViaId;
    }

    @JsonProperty("admittedViaId")
    public void setAdmittedViaId(Object admittedViaId) {
        this.admittedViaId = admittedViaId;
    }

    public AreaCareInformationResponse withAdmittedViaId(Object admittedViaId) {
        this.admittedViaId = admittedViaId;
        return this;
    }

    @JsonProperty("attendedById")
    public Object getAttendedById() {
        return attendedById;
    }

    @JsonProperty("attendedById")
    public void setAttendedById(Object attendedById) {
        this.attendedById = attendedById;
    }

    public AreaCareInformationResponse withAttendedById(Object attendedById) {
        this.attendedById = attendedById;
        return this;
    }

    @JsonProperty("admittedById")
    public Object getAdmittedById() {
        return admittedById;
    }

    @JsonProperty("admittedById")
    public void setAdmittedById(Object admittedById) {
        this.admittedById = admittedById;
    }

    public AreaCareInformationResponse withAdmittedById(Object admittedById) {
        this.admittedById = admittedById;
        return this;
    }

    @JsonProperty("reportById")
    public Object getReportById() {
        return reportById;
    }

    @JsonProperty("reportById")
    public void setReportById(Object reportById) {
        this.reportById = reportById;
    }

    public AreaCareInformationResponse withReportById(Object reportById) {
        this.reportById = reportById;
        return this;
    }

    @JsonProperty("anestReportedById")
    public Object getAnestReportedById() {
        return anestReportedById;
    }

    @JsonProperty("anestReportedById")
    public void setAnestReportedById(Object anestReportedById) {
        this.anestReportedById = anestReportedById;
    }

    public AreaCareInformationResponse withAnestReportedById(Object anestReportedById) {
        this.anestReportedById = anestReportedById;
        return this;
    }

    @JsonProperty("nurseReportedById")
    public Object getNurseReportedById() {
        return nurseReportedById;
    }

    @JsonProperty("nurseReportedById")
    public void setNurseReportedById(Object nurseReportedById) {
        this.nurseReportedById = nurseReportedById;
    }

    public AreaCareInformationResponse withNurseReportedById(Object nurseReportedById) {
        this.nurseReportedById = nurseReportedById;
        return this;
    }

    @JsonProperty("responsibleParty")
    public Object getResponsibleParty() {
        return responsibleParty;
    }

    @JsonProperty("responsibleParty")
    public void setResponsibleParty(Object responsibleParty) {
        this.responsibleParty = responsibleParty;
    }

    public AreaCareInformationResponse withResponsibleParty(Object responsibleParty) {
        this.responsibleParty = responsibleParty;
        return this;
    }

    @JsonProperty("anesStartTime")
    public Object getAnesStartTime() {
        return anesStartTime;
    }

    @JsonProperty("anesStartTime")
    public void setAnesStartTime(Object anesStartTime) {
        this.anesStartTime = anesStartTime;
    }

    public AreaCareInformationResponse withAnesStartTime(Object anesStartTime) {
        this.anesStartTime = anesStartTime;
        return this;
    }

    @JsonProperty("anesStopTime")
    public Object getAnesStopTime() {
        return anesStopTime;
    }

    @JsonProperty("anesStopTime")
    public void setAnesStopTime(Object anesStopTime) {
        this.anesStopTime = anesStopTime;
    }

    public AreaCareInformationResponse withAnesStopTime(Object anesStopTime) {
        this.anesStopTime = anesStopTime;
        return this;
    }

    @JsonProperty("admDtDatatype")
    public Object getAdmDtDatatype() {
        return admDtDatatype;
    }

    @JsonProperty("admDtDatatype")
    public void setAdmDtDatatype(Object admDtDatatype) {
        this.admDtDatatype = admDtDatatype;
    }

    public AreaCareInformationResponse withAdmDtDatatype(Object admDtDatatype) {
        this.admDtDatatype = admDtDatatype;
        return this;
    }

    @JsonProperty("withdrawalTime")
    public Object getWithdrawalTime() {
        return withdrawalTime;
    }

    @JsonProperty("withdrawalTime")
    public void setWithdrawalTime(Object withdrawalTime) {
        this.withdrawalTime = withdrawalTime;
    }

    public AreaCareInformationResponse withWithdrawalTime(Object withdrawalTime) {
        this.withdrawalTime = withdrawalTime;
        return this;
    }

    @JsonProperty("readyForTransferTf")
    public Boolean getReadyForTransferTf() {
        return readyForTransferTf;
    }

    @JsonProperty("readyForTransferTf")
    public void setReadyForTransferTf(Boolean readyForTransferTf) {
        this.readyForTransferTf = readyForTransferTf;
    }

    public AreaCareInformationResponse withReadyForTransferTf(Boolean readyForTransferTf) {
        this.readyForTransferTf = readyForTransferTf;
        return this;
    }

    @JsonProperty("admitTypeValue")
    public String getAdmitTypeValue() {
        return admitTypeValue;
    }

    @JsonProperty("admitTypeValue")
    public void setAdmitTypeValue(String admitTypeValue) {
        this.admitTypeValue = admitTypeValue;
    }

    public AreaCareInformationResponse withAdmitTypeValue(String admitTypeValue) {
        this.admitTypeValue = admitTypeValue;
        return this;
    }

    @JsonProperty("admitSourceValue")
    public String getAdmitSourceValue() {
        return admitSourceValue;
    }

    @JsonProperty("admitSourceValue")
    public void setAdmitSourceValue(String admitSourceValue) {
        this.admitSourceValue = admitSourceValue;
    }

    public AreaCareInformationResponse withAdmitSourceValue(String admitSourceValue) {
        this.admitSourceValue = admitSourceValue;
        return this;
    }

    @JsonProperty("roomName")
    public Object getRoomName() {
        return roomName;
    }

    @JsonProperty("roomName")
    public void setRoomName(Object roomName) {
        this.roomName = roomName;
    }

    public AreaCareInformationResponse withRoomName(Object roomName) {
        this.roomName = roomName;
        return this;
    }

    @JsonProperty("roomDictionaryName")
    public Object getRoomDictionaryName() {
        return roomDictionaryName;
    }

    @JsonProperty("roomDictionaryName")
    public void setRoomDictionaryName(Object roomDictionaryName) {
        this.roomDictionaryName = roomDictionaryName;
    }

    public AreaCareInformationResponse withRoomDictionaryName(Object roomDictionaryName) {
        this.roomDictionaryName = roomDictionaryName;
        return this;
    }

    @JsonProperty("admittedViaValue")
    public Object getAdmittedViaValue() {
        return admittedViaValue;
    }

    @JsonProperty("admittedViaValue")
    public void setAdmittedViaValue(Object admittedViaValue) {
        this.admittedViaValue = admittedViaValue;
    }

    public AreaCareInformationResponse withAdmittedViaValue(Object admittedViaValue) {
        this.admittedViaValue = admittedViaValue;
        return this;
    }

    @JsonProperty("attendedByValue")
    public Object getAttendedByValue() {
        return attendedByValue;
    }

    @JsonProperty("attendedByValue")
    public void setAttendedByValue(Object attendedByValue) {
        this.attendedByValue = attendedByValue;
    }

    public AreaCareInformationResponse withAttendedByValue(Object attendedByValue) {
        this.attendedByValue = attendedByValue;
        return this;
    }

    @JsonProperty("admittedByValue")
    public Object getAdmittedByValue() {
        return admittedByValue;
    }

    @JsonProperty("admittedByValue")
    public void setAdmittedByValue(Object admittedByValue) {
        this.admittedByValue = admittedByValue;
    }

    public AreaCareInformationResponse withAdmittedByValue(Object admittedByValue) {
        this.admittedByValue = admittedByValue;
        return this;
    }

    @JsonProperty("reportByValue")
    public Object getReportByValue() {
        return reportByValue;
    }

    @JsonProperty("reportByValue")
    public void setReportByValue(Object reportByValue) {
        this.reportByValue = reportByValue;
    }

    public AreaCareInformationResponse withReportByValue(Object reportByValue) {
        this.reportByValue = reportByValue;
        return this;
    }

    @JsonProperty("anestReportedByValue")
    public Object getAnestReportedByValue() {
        return anestReportedByValue;
    }

    @JsonProperty("anestReportedByValue")
    public void setAnestReportedByValue(Object anestReportedByValue) {
        this.anestReportedByValue = anestReportedByValue;
    }

    public AreaCareInformationResponse withAnestReportedByValue(Object anestReportedByValue) {
        this.anestReportedByValue = anestReportedByValue;
        return this;
    }

    @JsonProperty("nurseReportedByValue")
    public Object getNurseReportedByValue() {
        return nurseReportedByValue;
    }

    @JsonProperty("nurseReportedByValue")
    public void setNurseReportedByValue(Object nurseReportedByValue) {
        this.nurseReportedByValue = nurseReportedByValue;
    }

    public AreaCareInformationResponse withNurseReportedByValue(Object nurseReportedByValue) {
        this.nurseReportedByValue = nurseReportedByValue;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public AreaCareInformationResponse withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("transferTime")
    public Object getTransferTime() {
        return transferTime;
    }

    @JsonProperty("transferTime")
    public void setTransferTime(Object transferTime) {
        this.transferTime = transferTime;
    }

    public AreaCareInformationResponse withTransferTime(Object transferTime) {
        this.transferTime = transferTime;
        return this;
    }

    @JsonProperty("blockTime")
    public Object getBlockTime() {
        return blockTime;
    }

    @JsonProperty("blockTime")
    public void setBlockTime(Object blockTime) {
        this.blockTime = blockTime;
    }

    public AreaCareInformationResponse withBlockTime(Object blockTime) {
        this.blockTime = blockTime;
        return this;
    }

    @JsonProperty("blockTimeNeededTf")
    public Object getBlockTimeNeededTf() {
        return blockTimeNeededTf;
    }

    @JsonProperty("blockTimeNeededTf")
    public void setBlockTimeNeededTf(Object blockTimeNeededTf) {
        this.blockTimeNeededTf = blockTimeNeededTf;
    }

    public AreaCareInformationResponse withBlockTimeNeededTf(Object blockTimeNeededTf) {
        this.blockTimeNeededTf = blockTimeNeededTf;
        return this;
    }

    @JsonProperty("procedureAdditionalTimes")
    public Object getProcedureAdditionalTimes() {
        return procedureAdditionalTimes;
    }

    @JsonProperty("procedureAdditionalTimes")
    public void setProcedureAdditionalTimes(Object procedureAdditionalTimes) {
        this.procedureAdditionalTimes = procedureAdditionalTimes;
    }

    public AreaCareInformationResponse withProcedureAdditionalTimes(Object procedureAdditionalTimes) {
        this.procedureAdditionalTimes = procedureAdditionalTimes;
        return this;
    }

    @JsonProperty("overTakeMyLock")
    public Boolean getOverTakeMyLock() {
        return overTakeMyLock;
    }

    @JsonProperty("overTakeMyLock")
    public void setOverTakeMyLock(Boolean overTakeMyLock) {
        this.overTakeMyLock = overTakeMyLock;
    }

    public AreaCareInformationResponse withOverTakeMyLock(Boolean overTakeMyLock) {
        this.overTakeMyLock = overTakeMyLock;
        return this;
    }

    @JsonProperty("lockStatus")
    public Integer getLockStatus() {
        return lockStatus;
    }

    @JsonProperty("lockStatus")
    public void setLockStatus(Integer lockStatus) {
        this.lockStatus = lockStatus;
    }

    public AreaCareInformationResponse withLockStatus(Integer lockStatus) {
        this.lockStatus = lockStatus;
        return this;
    }

    @JsonProperty("lockDescription")
    public Object getLockDescription() {
        return lockDescription;
    }

    @JsonProperty("lockDescription")
    public void setLockDescription(Object lockDescription) {
        this.lockDescription = lockDescription;
    }

    public AreaCareInformationResponse withLockDescription(Object lockDescription) {
        this.lockDescription = lockDescription;
        return this;
    }

    @JsonProperty("blockTimeOutId")
    public Object getBlockTimeOutId() {
        return blockTimeOutId;
    }

    @JsonProperty("blockTimeOutId")
    public void setBlockTimeOutId(Object blockTimeOutId) {
        this.blockTimeOutId = blockTimeOutId;
    }

    public AreaCareInformationResponse withBlockTimeOutId(Object blockTimeOutId) {
        this.blockTimeOutId = blockTimeOutId;
        return this;
    }

    @JsonProperty("transferModuleId")
    public Object getTransferModuleId() {
        return transferModuleId;
    }

    @JsonProperty("transferModuleId")
    public void setTransferModuleId(Object transferModuleId) {
        this.transferModuleId = transferModuleId;
    }

    public AreaCareInformationResponse withTransferModuleId(Object transferModuleId) {
        this.transferModuleId = transferModuleId;
        return this;
    }

    @JsonProperty("patientHandOffId")
    public Object getPatientHandOffId() {
        return patientHandOffId;
    }

    @JsonProperty("patientHandOffId")
    public void setPatientHandOffId(Object patientHandOffId) {
        this.patientHandOffId = patientHandOffId;
    }

    public AreaCareInformationResponse withPatientHandOffId(Object patientHandOffId) {
        this.patientHandOffId = patientHandOffId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public AreaCareInformationResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AreaCareInformationResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(areaOfCareInformationId).append(caseSummaryId).append(moduleId).append(admissionTime).append(roomId).append(admittedViaId).append(attendedById).append(admittedById).append(reportById).append(anestReportedById).append(nurseReportedById).append(responsibleParty).append(anesStartTime).append(anesStopTime).append(admDtDatatype).append(withdrawalTime).append(readyForTransferTf).append(admitTypeValue).append(admitSourceValue).append(roomName).append(roomDictionaryName).append(admittedViaValue).append(attendedByValue).append(admittedByValue).append(reportByValue).append(anestReportedByValue).append(nurseReportedByValue).append(patientId).append(transferTime).append(blockTime).append(blockTimeNeededTf).append(procedureAdditionalTimes).append(overTakeMyLock).append(lockStatus).append(lockDescription).append(blockTimeOutId).append(transferModuleId).append(patientHandOffId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AreaCareInformationResponse) == false) {
            return false;
        }
        AreaCareInformationResponse rhs = ((AreaCareInformationResponse) other);
        return new EqualsBuilder().append(areaOfCareInformationId, rhs.areaOfCareInformationId).append(caseSummaryId, rhs.caseSummaryId).append(moduleId, rhs.moduleId).append(admissionTime, rhs.admissionTime).append(roomId, rhs.roomId).append(admittedViaId, rhs.admittedViaId).append(attendedById, rhs.attendedById).append(admittedById, rhs.admittedById).append(reportById, rhs.reportById).append(anestReportedById, rhs.anestReportedById).append(nurseReportedById, rhs.nurseReportedById).append(responsibleParty, rhs.responsibleParty).append(anesStartTime, rhs.anesStartTime).append(anesStopTime, rhs.anesStopTime).append(admDtDatatype, rhs.admDtDatatype).append(withdrawalTime, rhs.withdrawalTime).append(readyForTransferTf, rhs.readyForTransferTf).append(admitTypeValue, rhs.admitTypeValue).append(admitSourceValue, rhs.admitSourceValue).append(roomName, rhs.roomName).append(roomDictionaryName, rhs.roomDictionaryName).append(admittedViaValue, rhs.admittedViaValue).append(attendedByValue, rhs.attendedByValue).append(admittedByValue, rhs.admittedByValue).append(reportByValue, rhs.reportByValue).append(anestReportedByValue, rhs.anestReportedByValue).append(nurseReportedByValue, rhs.nurseReportedByValue).append(patientId, rhs.patientId).append(transferTime, rhs.transferTime).append(blockTime, rhs.blockTime).append(blockTimeNeededTf, rhs.blockTimeNeededTf).append(procedureAdditionalTimes, rhs.procedureAdditionalTimes).append(overTakeMyLock, rhs.overTakeMyLock).append(lockStatus, rhs.lockStatus).append(lockDescription, rhs.lockDescription).append(blockTimeOutId, rhs.blockTimeOutId).append(transferModuleId, rhs.transferModuleId).append(patientHandOffId, rhs.patientHandOffId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
