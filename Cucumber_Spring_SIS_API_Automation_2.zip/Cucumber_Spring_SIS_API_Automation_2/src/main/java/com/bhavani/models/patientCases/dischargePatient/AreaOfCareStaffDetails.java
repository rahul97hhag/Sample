
package com.bhavani.models.patientCases.dischargePatient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "areaofCareStaffId",
    "caseSummaryId",
    "moduleId",
    "staffingNotes",
    "isAdded",
    "isUpdated",
    "areaofCareStaffEntryDetails",
    "patientId",
    "isValidateStaff",
    "isCopyPreviousStaff",
    "isUpdateAllAdmissionDt",
    "isUpdateAllTransferDt",
    "sourceIdentifier"
})
public class AreaOfCareStaffDetails {

    @JsonProperty("areaofCareStaffId")
    private Integer areaofCareStaffId;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("moduleId")
    private Integer moduleId;
    @JsonProperty("staffingNotes")
    private Object staffingNotes;
    @JsonProperty("isAdded")
    private Boolean isAdded;
    @JsonProperty("isUpdated")
    private Boolean isUpdated;
    @JsonProperty("areaofCareStaffEntryDetails")
    private List<AreaofCareStaffEntryDetail> areaofCareStaffEntryDetails = new ArrayList<AreaofCareStaffEntryDetail>();
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("isValidateStaff")
    private Boolean isValidateStaff;
    @JsonProperty("isCopyPreviousStaff")
    private Boolean isCopyPreviousStaff;
    @JsonProperty("isUpdateAllAdmissionDt")
    private Boolean isUpdateAllAdmissionDt;
    @JsonProperty("isUpdateAllTransferDt")
    private Boolean isUpdateAllTransferDt;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("areaofCareStaffId")
    public Integer getAreaofCareStaffId() {
        return areaofCareStaffId;
    }

    @JsonProperty("areaofCareStaffId")
    public void setAreaofCareStaffId(Integer areaofCareStaffId) {
        this.areaofCareStaffId = areaofCareStaffId;
    }

    public AreaOfCareStaffDetails withAreaofCareStaffId(Integer areaofCareStaffId) {
        this.areaofCareStaffId = areaofCareStaffId;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public AreaOfCareStaffDetails withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("moduleId")
    public Integer getModuleId() {
        return moduleId;
    }

    @JsonProperty("moduleId")
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public AreaOfCareStaffDetails withModuleId(Integer moduleId) {
        this.moduleId = moduleId;
        return this;
    }

    @JsonProperty("staffingNotes")
    public Object getStaffingNotes() {
        return staffingNotes;
    }

    @JsonProperty("staffingNotes")
    public void setStaffingNotes(Object staffingNotes) {
        this.staffingNotes = staffingNotes;
    }

    public AreaOfCareStaffDetails withStaffingNotes(Object staffingNotes) {
        this.staffingNotes = staffingNotes;
        return this;
    }

    @JsonProperty("isAdded")
    public Boolean getIsAdded() {
        return isAdded;
    }

    @JsonProperty("isAdded")
    public void setIsAdded(Boolean isAdded) {
        this.isAdded = isAdded;
    }

    public AreaOfCareStaffDetails withIsAdded(Boolean isAdded) {
        this.isAdded = isAdded;
        return this;
    }

    @JsonProperty("isUpdated")
    public Boolean getIsUpdated() {
        return isUpdated;
    }

    @JsonProperty("isUpdated")
    public void setIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
    }

    public AreaOfCareStaffDetails withIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
        return this;
    }

    @JsonProperty("areaofCareStaffEntryDetails")
    public List<AreaofCareStaffEntryDetail> getAreaofCareStaffEntryDetails() {
        return areaofCareStaffEntryDetails;
    }

    @JsonProperty("areaofCareStaffEntryDetails")
    public void setAreaofCareStaffEntryDetails(List<AreaofCareStaffEntryDetail> areaofCareStaffEntryDetails) {
        this.areaofCareStaffEntryDetails = areaofCareStaffEntryDetails;
    }

    public AreaOfCareStaffDetails withAreaofCareStaffEntryDetails(List<AreaofCareStaffEntryDetail> areaofCareStaffEntryDetails) {
        this.areaofCareStaffEntryDetails = areaofCareStaffEntryDetails;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public AreaOfCareStaffDetails withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("isValidateStaff")
    public Boolean getIsValidateStaff() {
        return isValidateStaff;
    }

    @JsonProperty("isValidateStaff")
    public void setIsValidateStaff(Boolean isValidateStaff) {
        this.isValidateStaff = isValidateStaff;
    }

    public AreaOfCareStaffDetails withIsValidateStaff(Boolean isValidateStaff) {
        this.isValidateStaff = isValidateStaff;
        return this;
    }

    @JsonProperty("isCopyPreviousStaff")
    public Boolean getIsCopyPreviousStaff() {
        return isCopyPreviousStaff;
    }

    @JsonProperty("isCopyPreviousStaff")
    public void setIsCopyPreviousStaff(Boolean isCopyPreviousStaff) {
        this.isCopyPreviousStaff = isCopyPreviousStaff;
    }

    public AreaOfCareStaffDetails withIsCopyPreviousStaff(Boolean isCopyPreviousStaff) {
        this.isCopyPreviousStaff = isCopyPreviousStaff;
        return this;
    }

    @JsonProperty("isUpdateAllAdmissionDt")
    public Boolean getIsUpdateAllAdmissionDt() {
        return isUpdateAllAdmissionDt;
    }

    @JsonProperty("isUpdateAllAdmissionDt")
    public void setIsUpdateAllAdmissionDt(Boolean isUpdateAllAdmissionDt) {
        this.isUpdateAllAdmissionDt = isUpdateAllAdmissionDt;
    }

    public AreaOfCareStaffDetails withIsUpdateAllAdmissionDt(Boolean isUpdateAllAdmissionDt) {
        this.isUpdateAllAdmissionDt = isUpdateAllAdmissionDt;
        return this;
    }

    @JsonProperty("isUpdateAllTransferDt")
    public Boolean getIsUpdateAllTransferDt() {
        return isUpdateAllTransferDt;
    }

    @JsonProperty("isUpdateAllTransferDt")
    public void setIsUpdateAllTransferDt(Boolean isUpdateAllTransferDt) {
        this.isUpdateAllTransferDt = isUpdateAllTransferDt;
    }

    public AreaOfCareStaffDetails withIsUpdateAllTransferDt(Boolean isUpdateAllTransferDt) {
        this.isUpdateAllTransferDt = isUpdateAllTransferDt;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public AreaOfCareStaffDetails withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AreaOfCareStaffDetails withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(areaofCareStaffId).append(caseSummaryId).append(moduleId).append(staffingNotes).append(isAdded).append(isUpdated).append(areaofCareStaffEntryDetails).append(patientId).append(isValidateStaff).append(isCopyPreviousStaff).append(isUpdateAllAdmissionDt).append(isUpdateAllTransferDt).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AreaOfCareStaffDetails) == false) {
            return false;
        }
        AreaOfCareStaffDetails rhs = ((AreaOfCareStaffDetails) other);
        return new EqualsBuilder().append(areaofCareStaffId, rhs.areaofCareStaffId).append(caseSummaryId, rhs.caseSummaryId).append(moduleId, rhs.moduleId).append(staffingNotes, rhs.staffingNotes).append(isAdded, rhs.isAdded).append(isUpdated, rhs.isUpdated).append(areaofCareStaffEntryDetails, rhs.areaofCareStaffEntryDetails).append(patientId, rhs.patientId).append(isValidateStaff, rhs.isValidateStaff).append(isCopyPreviousStaff, rhs.isCopyPreviousStaff).append(isUpdateAllAdmissionDt, rhs.isUpdateAllAdmissionDt).append(isUpdateAllTransferDt, rhs.isUpdateAllTransferDt).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
