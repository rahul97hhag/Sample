
package com.bhavani.models.patientCases.newPatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientId",
    "firstName",
    "lastName",
    "middleInitial",
    "dateOfBirth",
    "gender",
    "accountNumber",
    "isPatientExists",
    "isLockExists",
    "fullNameWithTitle",
    "procedureDt",
    "mpiPatientAge"
})
public class CreatePatient {

    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("firstName")
    private Object firstName;
    @JsonProperty("lastName")
    private Object lastName;
    @JsonProperty("middleInitial")
    private Object middleInitial;
    @JsonProperty("dateOfBirth")
    private Object dateOfBirth;
    @JsonProperty("gender")
    private Object gender;
    @JsonProperty("accountNumber")
    private Object accountNumber;
    @JsonProperty("isPatientExists")
    private Boolean isPatientExists;
    @JsonProperty("isLockExists")
    private Boolean isLockExists;
    @JsonProperty("fullNameWithTitle")
    private String fullNameWithTitle;
    @JsonProperty("procedureDt")
    private String procedureDt;
    @JsonProperty("mpiPatientAge")
    private MpiPatientAge mpiPatientAge;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public CreatePatient withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("firstName")
    public Object getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(Object firstName) {
        this.firstName = firstName;
    }

    public CreatePatient withFirstName(Object firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public Object getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(Object lastName) {
        this.lastName = lastName;
    }

    public CreatePatient withLastName(Object lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public Object getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
    }

    public CreatePatient withMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public Object getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(Object dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public CreatePatient withDateOfBirth(Object dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("gender")
    public Object getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(Object gender) {
        this.gender = gender;
    }

    public CreatePatient withGender(Object gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("accountNumber")
    public Object getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(Object accountNumber) {
        this.accountNumber = accountNumber;
    }

    public CreatePatient withAccountNumber(Object accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    @JsonProperty("isPatientExists")
    public Boolean getIsPatientExists() {
        return isPatientExists;
    }

    @JsonProperty("isPatientExists")
    public void setIsPatientExists(Boolean isPatientExists) {
        this.isPatientExists = isPatientExists;
    }

    public CreatePatient withIsPatientExists(Boolean isPatientExists) {
        this.isPatientExists = isPatientExists;
        return this;
    }

    @JsonProperty("isLockExists")
    public Boolean getIsLockExists() {
        return isLockExists;
    }

    @JsonProperty("isLockExists")
    public void setIsLockExists(Boolean isLockExists) {
        this.isLockExists = isLockExists;
    }

    public CreatePatient withIsLockExists(Boolean isLockExists) {
        this.isLockExists = isLockExists;
        return this;
    }

    @JsonProperty("fullNameWithTitle")
    public String getFullNameWithTitle() {
        return fullNameWithTitle;
    }

    @JsonProperty("fullNameWithTitle")
    public void setFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
    }

    public CreatePatient withFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
        return this;
    }

    @JsonProperty("procedureDt")
    public String getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
    }

    public CreatePatient withProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("mpiPatientAge")
    public MpiPatientAge getMpiPatientAge() {
        return mpiPatientAge;
    }

    @JsonProperty("mpiPatientAge")
    public void setMpiPatientAge(MpiPatientAge mpiPatientAge) {
        this.mpiPatientAge = mpiPatientAge;
    }

    public CreatePatient withMpiPatientAge(MpiPatientAge mpiPatientAge) {
        this.mpiPatientAge = mpiPatientAge;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CreatePatient withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientId).append(firstName).append(lastName).append(middleInitial).append(dateOfBirth).append(gender).append(accountNumber).append(isPatientExists).append(isLockExists).append(fullNameWithTitle).append(procedureDt).append(mpiPatientAge).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CreatePatient) == false) {
            return false;
        }
        CreatePatient rhs = ((CreatePatient) other);
        return new EqualsBuilder().append(patientId, rhs.patientId).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(dateOfBirth, rhs.dateOfBirth).append(gender, rhs.gender).append(accountNumber, rhs.accountNumber).append(isPatientExists, rhs.isPatientExists).append(isLockExists, rhs.isLockExists).append(fullNameWithTitle, rhs.fullNameWithTitle).append(procedureDt, rhs.procedureDt).append(mpiPatientAge, rhs.mpiPatientAge).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
