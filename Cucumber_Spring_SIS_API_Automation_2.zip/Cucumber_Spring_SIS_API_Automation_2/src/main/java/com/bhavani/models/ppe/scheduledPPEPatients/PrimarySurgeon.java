
package com.bhavani.models.ppe.scheduledPPEPatients;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "personId",
    "firstName",
    "lastName",
    "middleInitial",
    "title",
    "gender",
    "dateOfBirth",
    "externalId",
    "fullName",
    "isAlphabeticalOrder",
    "isExcludeTitle",
    "itemId",
    "itemName",
    "itemType",
    "organizationId",
    "pageNumber",
    "searchString",
    "staffRoleId",
    "staffId",
    "staffIsActive",
    "staffIsAODictionary",
    "staffRoleName",
    "staffShowInClinical",
    "staffType",
    "ssn",
    "isNonUser",
    "fullNameWithTitle",
    "sourceIdentifier"
})
public class PrimarySurgeon {

    @JsonProperty("personId")
    private Integer personId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("title")
    private String title;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("externalId")
    private Object externalId;
    @JsonProperty("fullName")
    private Object fullName;
    @JsonProperty("isAlphabeticalOrder")
    private Boolean isAlphabeticalOrder;
    @JsonProperty("isExcludeTitle")
    private Boolean isExcludeTitle;
    @JsonProperty("itemId")
    private Integer itemId;
    @JsonProperty("itemName")
    private Object itemName;
    @JsonProperty("itemType")
    private Object itemType;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("pageNumber")
    private Integer pageNumber;
    @JsonProperty("searchString")
    private Object searchString;
    @JsonProperty("staffRoleId")
    private Object staffRoleId;
    @JsonProperty("staffId")
    private Integer staffId;
    @JsonProperty("staffIsActive")
    private Boolean staffIsActive;
    @JsonProperty("staffIsAODictionary")
    private Boolean staffIsAODictionary;
    @JsonProperty("staffRoleName")
    private Object staffRoleName;
    @JsonProperty("staffShowInClinical")
    private Boolean staffShowInClinical;
    @JsonProperty("staffType")
    private Object staffType;
    @JsonProperty("ssn")
    private Object ssn;
    @JsonProperty("isNonUser")
    private Boolean isNonUser;
    @JsonProperty("fullNameWithTitle")
    private String fullNameWithTitle;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("personId")
    public Integer getPersonId() {
        return personId;
    }

    @JsonProperty("personId")
    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public PrimarySurgeon withPersonId(Integer personId) {
        this.personId = personId;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public PrimarySurgeon withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public PrimarySurgeon withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public PrimarySurgeon withMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    public PrimarySurgeon withTitle(String title) {
        this.title = title;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public PrimarySurgeon withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public PrimarySurgeon withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("externalId")
    public Object getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Object externalId) {
        this.externalId = externalId;
    }

    public PrimarySurgeon withExternalId(Object externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("fullName")
    public Object getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(Object fullName) {
        this.fullName = fullName;
    }

    public PrimarySurgeon withFullName(Object fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("isAlphabeticalOrder")
    public Boolean getIsAlphabeticalOrder() {
        return isAlphabeticalOrder;
    }

    @JsonProperty("isAlphabeticalOrder")
    public void setIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
    }

    public PrimarySurgeon withIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
        return this;
    }

    @JsonProperty("isExcludeTitle")
    public Boolean getIsExcludeTitle() {
        return isExcludeTitle;
    }

    @JsonProperty("isExcludeTitle")
    public void setIsExcludeTitle(Boolean isExcludeTitle) {
        this.isExcludeTitle = isExcludeTitle;
    }

    public PrimarySurgeon withIsExcludeTitle(Boolean isExcludeTitle) {
        this.isExcludeTitle = isExcludeTitle;
        return this;
    }

    @JsonProperty("itemId")
    public Integer getItemId() {
        return itemId;
    }

    @JsonProperty("itemId")
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public PrimarySurgeon withItemId(Integer itemId) {
        this.itemId = itemId;
        return this;
    }

    @JsonProperty("itemName")
    public Object getItemName() {
        return itemName;
    }

    @JsonProperty("itemName")
    public void setItemName(Object itemName) {
        this.itemName = itemName;
    }

    public PrimarySurgeon withItemName(Object itemName) {
        this.itemName = itemName;
        return this;
    }

    @JsonProperty("itemType")
    public Object getItemType() {
        return itemType;
    }

    @JsonProperty("itemType")
    public void setItemType(Object itemType) {
        this.itemType = itemType;
    }

    public PrimarySurgeon withItemType(Object itemType) {
        this.itemType = itemType;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public PrimarySurgeon withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("pageNumber")
    public Integer getPageNumber() {
        return pageNumber;
    }

    @JsonProperty("pageNumber")
    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public PrimarySurgeon withPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }

    @JsonProperty("searchString")
    public Object getSearchString() {
        return searchString;
    }

    @JsonProperty("searchString")
    public void setSearchString(Object searchString) {
        this.searchString = searchString;
    }

    public PrimarySurgeon withSearchString(Object searchString) {
        this.searchString = searchString;
        return this;
    }

    @JsonProperty("staffRoleId")
    public Object getStaffRoleId() {
        return staffRoleId;
    }

    @JsonProperty("staffRoleId")
    public void setStaffRoleId(Object staffRoleId) {
        this.staffRoleId = staffRoleId;
    }

    public PrimarySurgeon withStaffRoleId(Object staffRoleId) {
        this.staffRoleId = staffRoleId;
        return this;
    }

    @JsonProperty("staffId")
    public Integer getStaffId() {
        return staffId;
    }

    @JsonProperty("staffId")
    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public PrimarySurgeon withStaffId(Integer staffId) {
        this.staffId = staffId;
        return this;
    }

    @JsonProperty("staffIsActive")
    public Boolean getStaffIsActive() {
        return staffIsActive;
    }

    @JsonProperty("staffIsActive")
    public void setStaffIsActive(Boolean staffIsActive) {
        this.staffIsActive = staffIsActive;
    }

    public PrimarySurgeon withStaffIsActive(Boolean staffIsActive) {
        this.staffIsActive = staffIsActive;
        return this;
    }

    @JsonProperty("staffIsAODictionary")
    public Boolean getStaffIsAODictionary() {
        return staffIsAODictionary;
    }

    @JsonProperty("staffIsAODictionary")
    public void setStaffIsAODictionary(Boolean staffIsAODictionary) {
        this.staffIsAODictionary = staffIsAODictionary;
    }

    public PrimarySurgeon withStaffIsAODictionary(Boolean staffIsAODictionary) {
        this.staffIsAODictionary = staffIsAODictionary;
        return this;
    }

    @JsonProperty("staffRoleName")
    public Object getStaffRoleName() {
        return staffRoleName;
    }

    @JsonProperty("staffRoleName")
    public void setStaffRoleName(Object staffRoleName) {
        this.staffRoleName = staffRoleName;
    }

    public PrimarySurgeon withStaffRoleName(Object staffRoleName) {
        this.staffRoleName = staffRoleName;
        return this;
    }

    @JsonProperty("staffShowInClinical")
    public Boolean getStaffShowInClinical() {
        return staffShowInClinical;
    }

    @JsonProperty("staffShowInClinical")
    public void setStaffShowInClinical(Boolean staffShowInClinical) {
        this.staffShowInClinical = staffShowInClinical;
    }

    public PrimarySurgeon withStaffShowInClinical(Boolean staffShowInClinical) {
        this.staffShowInClinical = staffShowInClinical;
        return this;
    }

    @JsonProperty("staffType")
    public Object getStaffType() {
        return staffType;
    }

    @JsonProperty("staffType")
    public void setStaffType(Object staffType) {
        this.staffType = staffType;
    }

    public PrimarySurgeon withStaffType(Object staffType) {
        this.staffType = staffType;
        return this;
    }

    @JsonProperty("ssn")
    public Object getSsn() {
        return ssn;
    }

    @JsonProperty("ssn")
    public void setSsn(Object ssn) {
        this.ssn = ssn;
    }

    public PrimarySurgeon withSsn(Object ssn) {
        this.ssn = ssn;
        return this;
    }

    @JsonProperty("isNonUser")
    public Boolean getIsNonUser() {
        return isNonUser;
    }

    @JsonProperty("isNonUser")
    public void setIsNonUser(Boolean isNonUser) {
        this.isNonUser = isNonUser;
    }

    public PrimarySurgeon withIsNonUser(Boolean isNonUser) {
        this.isNonUser = isNonUser;
        return this;
    }

    @JsonProperty("fullNameWithTitle")
    public String getFullNameWithTitle() {
        return fullNameWithTitle;
    }

    @JsonProperty("fullNameWithTitle")
    public void setFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
    }

    public PrimarySurgeon withFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public PrimarySurgeon withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PrimarySurgeon withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(personId).append(firstName).append(lastName).append(middleInitial).append(title).append(gender).append(dateOfBirth).append(externalId).append(fullName).append(isAlphabeticalOrder).append(isExcludeTitle).append(itemId).append(itemName).append(itemType).append(organizationId).append(pageNumber).append(searchString).append(staffRoleId).append(staffId).append(staffIsActive).append(staffIsAODictionary).append(staffRoleName).append(staffShowInClinical).append(staffType).append(ssn).append(isNonUser).append(fullNameWithTitle).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PrimarySurgeon) == false) {
            return false;
        }
        PrimarySurgeon rhs = ((PrimarySurgeon) other);
        return new EqualsBuilder().append(personId, rhs.personId).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(title, rhs.title).append(gender, rhs.gender).append(dateOfBirth, rhs.dateOfBirth).append(externalId, rhs.externalId).append(fullName, rhs.fullName).append(isAlphabeticalOrder, rhs.isAlphabeticalOrder).append(isExcludeTitle, rhs.isExcludeTitle).append(itemId, rhs.itemId).append(itemName, rhs.itemName).append(itemType, rhs.itemType).append(organizationId, rhs.organizationId).append(pageNumber, rhs.pageNumber).append(searchString, rhs.searchString).append(staffRoleId, rhs.staffRoleId).append(staffId, rhs.staffId).append(staffIsActive, rhs.staffIsActive).append(staffIsAODictionary, rhs.staffIsAODictionary).append(staffRoleName, rhs.staffRoleName).append(staffShowInClinical, rhs.staffShowInClinical).append(staffType, rhs.staffType).append(ssn, rhs.ssn).append(isNonUser, rhs.isNonUser).append(fullNameWithTitle, rhs.fullNameWithTitle).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
