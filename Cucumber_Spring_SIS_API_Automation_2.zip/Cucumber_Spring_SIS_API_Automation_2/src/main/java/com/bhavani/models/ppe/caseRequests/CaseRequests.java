
package com.bhavani.models.ppe.caseRequests;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "applicationScope",
    "caseRequestId",
    "caseRequestStatus",
    "content",
    "organizationId",
    "primaryPhysicianPersonId",
    "procedureDate",
    "createdByUserId",
    "modifiedByUserId",
    "created",
    "modified",
    "createdByFirstName",
    "createdByMiddleInitial",
    "createdByLastName",
    "modifiedByFirstName",
    "modifiedByMiddleInitial",
    "modifiedByLastName",
    "caseSummaryId",
    "rejectReasonId",
    "rejectReason",
    "sourceIdentifier"
})
public class CaseRequests {

    @JsonProperty("applicationScope")
    private Integer applicationScope;
    @JsonProperty("caseRequestId")
    private Integer caseRequestId;
    @JsonProperty("caseRequestStatus")
    private Integer caseRequestStatus;
    @JsonProperty("content")
    private Content content;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("primaryPhysicianPersonId")
    private Integer primaryPhysicianPersonId;
    @JsonProperty("procedureDate")
    private String procedureDate;
    @JsonProperty("createdByUserId")
    private Integer createdByUserId;
    @JsonProperty("modifiedByUserId")
    private Integer modifiedByUserId;
    @JsonProperty("created")
    private String created;
    @JsonProperty("modified")
    private String modified;
    @JsonProperty("createdByFirstName")
    private String createdByFirstName;
    @JsonProperty("createdByMiddleInitial")
    private String createdByMiddleInitial;
    @JsonProperty("createdByLastName")
    private String createdByLastName;
    @JsonProperty("modifiedByFirstName")
    private String modifiedByFirstName;
    @JsonProperty("modifiedByMiddleInitial")
    private String modifiedByMiddleInitial;
    @JsonProperty("modifiedByLastName")
    private String modifiedByLastName;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("rejectReasonId")
    private Object rejectReasonId;
    @JsonProperty("rejectReason")
    private Object rejectReason;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("applicationScope")
    public Integer getApplicationScope() {
        return applicationScope;
    }

    @JsonProperty("applicationScope")
    public void setApplicationScope(Integer applicationScope) {
        this.applicationScope = applicationScope;
    }

    public CaseRequests withApplicationScope(Integer applicationScope) {
        this.applicationScope = applicationScope;
        return this;
    }

    @JsonProperty("caseRequestId")
    public Integer getCaseRequestId() {
        return caseRequestId;
    }

    @JsonProperty("caseRequestId")
    public void setCaseRequestId(Integer caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public CaseRequests withCaseRequestId(Integer caseRequestId) {
        this.caseRequestId = caseRequestId;
        return this;
    }

    @JsonProperty("caseRequestStatus")
    public Integer getCaseRequestStatus() {
        return caseRequestStatus;
    }

    @JsonProperty("caseRequestStatus")
    public void setCaseRequestStatus(Integer caseRequestStatus) {
        this.caseRequestStatus = caseRequestStatus;
    }

    public CaseRequests withCaseRequestStatus(Integer caseRequestStatus) {
        this.caseRequestStatus = caseRequestStatus;
        return this;
    }

    @JsonProperty("content")
    public Content getContent() {
        return content;
    }

    @JsonProperty("content")
    public void setContent(Content content) {
        this.content = content;
    }

    public CaseRequests withContent(Content content) {
        this.content = content;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public CaseRequests withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("primaryPhysicianPersonId")
    public Integer getPrimaryPhysicianPersonId() {
        return primaryPhysicianPersonId;
    }

    @JsonProperty("primaryPhysicianPersonId")
    public void setPrimaryPhysicianPersonId(Integer primaryPhysicianPersonId) {
        this.primaryPhysicianPersonId = primaryPhysicianPersonId;
    }

    public CaseRequests withPrimaryPhysicianPersonId(Integer primaryPhysicianPersonId) {
        this.primaryPhysicianPersonId = primaryPhysicianPersonId;
        return this;
    }

    @JsonProperty("procedureDate")
    public String getProcedureDate() {
        return procedureDate;
    }

    @JsonProperty("procedureDate")
    public void setProcedureDate(String procedureDate) {
        this.procedureDate = procedureDate;
    }

    public CaseRequests withProcedureDate(String procedureDate) {
        this.procedureDate = procedureDate;
        return this;
    }

    @JsonProperty("createdByUserId")
    public Integer getCreatedByUserId() {
        return createdByUserId;
    }

    @JsonProperty("createdByUserId")
    public void setCreatedByUserId(Integer createdByUserId) {
        this.createdByUserId = createdByUserId;
    }

    public CaseRequests withCreatedByUserId(Integer createdByUserId) {
        this.createdByUserId = createdByUserId;
        return this;
    }

    @JsonProperty("modifiedByUserId")
    public Integer getModifiedByUserId() {
        return modifiedByUserId;
    }

    @JsonProperty("modifiedByUserId")
    public void setModifiedByUserId(Integer modifiedByUserId) {
        this.modifiedByUserId = modifiedByUserId;
    }

    public CaseRequests withModifiedByUserId(Integer modifiedByUserId) {
        this.modifiedByUserId = modifiedByUserId;
        return this;
    }

    @JsonProperty("created")
    public String getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(String created) {
        this.created = created;
    }

    public CaseRequests withCreated(String created) {
        this.created = created;
        return this;
    }

    @JsonProperty("modified")
    public String getModified() {
        return modified;
    }

    @JsonProperty("modified")
    public void setModified(String modified) {
        this.modified = modified;
    }

    public CaseRequests withModified(String modified) {
        this.modified = modified;
        return this;
    }

    @JsonProperty("createdByFirstName")
    public String getCreatedByFirstName() {
        return createdByFirstName;
    }

    @JsonProperty("createdByFirstName")
    public void setCreatedByFirstName(String createdByFirstName) {
        this.createdByFirstName = createdByFirstName;
    }

    public CaseRequests withCreatedByFirstName(String createdByFirstName) {
        this.createdByFirstName = createdByFirstName;
        return this;
    }

    @JsonProperty("createdByMiddleInitial")
    public String getCreatedByMiddleInitial() {
        return createdByMiddleInitial;
    }

    @JsonProperty("createdByMiddleInitial")
    public void setCreatedByMiddleInitial(String createdByMiddleInitial) {
        this.createdByMiddleInitial = createdByMiddleInitial;
    }

    public CaseRequests withCreatedByMiddleInitial(String createdByMiddleInitial) {
        this.createdByMiddleInitial = createdByMiddleInitial;
        return this;
    }

    @JsonProperty("createdByLastName")
    public String getCreatedByLastName() {
        return createdByLastName;
    }

    @JsonProperty("createdByLastName")
    public void setCreatedByLastName(String createdByLastName) {
        this.createdByLastName = createdByLastName;
    }

    public CaseRequests withCreatedByLastName(String createdByLastName) {
        this.createdByLastName = createdByLastName;
        return this;
    }

    @JsonProperty("modifiedByFirstName")
    public String getModifiedByFirstName() {
        return modifiedByFirstName;
    }

    @JsonProperty("modifiedByFirstName")
    public void setModifiedByFirstName(String modifiedByFirstName) {
        this.modifiedByFirstName = modifiedByFirstName;
    }

    public CaseRequests withModifiedByFirstName(String modifiedByFirstName) {
        this.modifiedByFirstName = modifiedByFirstName;
        return this;
    }

    @JsonProperty("modifiedByMiddleInitial")
    public String getModifiedByMiddleInitial() {
        return modifiedByMiddleInitial;
    }

    @JsonProperty("modifiedByMiddleInitial")
    public void setModifiedByMiddleInitial(String modifiedByMiddleInitial) {
        this.modifiedByMiddleInitial = modifiedByMiddleInitial;
    }

    public CaseRequests withModifiedByMiddleInitial(String modifiedByMiddleInitial) {
        this.modifiedByMiddleInitial = modifiedByMiddleInitial;
        return this;
    }

    @JsonProperty("modifiedByLastName")
    public String getModifiedByLastName() {
        return modifiedByLastName;
    }

    @JsonProperty("modifiedByLastName")
    public void setModifiedByLastName(String modifiedByLastName) {
        this.modifiedByLastName = modifiedByLastName;
    }

    public CaseRequests withModifiedByLastName(String modifiedByLastName) {
        this.modifiedByLastName = modifiedByLastName;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public CaseRequests withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("rejectReasonId")
    public Object getRejectReasonId() {
        return rejectReasonId;
    }

    @JsonProperty("rejectReasonId")
    public void setRejectReasonId(Object rejectReasonId) {
        this.rejectReasonId = rejectReasonId;
    }

    public CaseRequests withRejectReasonId(Object rejectReasonId) {
        this.rejectReasonId = rejectReasonId;
        return this;
    }

    @JsonProperty("rejectReason")
    public Object getRejectReason() {
        return rejectReason;
    }

    @JsonProperty("rejectReason")
    public void setRejectReason(Object rejectReason) {
        this.rejectReason = rejectReason;
    }

    public CaseRequests withRejectReason(Object rejectReason) {
        this.rejectReason = rejectReason;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public CaseRequests withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseRequests withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(applicationScope).append(caseRequestId).append(caseRequestStatus).append(content).append(organizationId).append(primaryPhysicianPersonId).append(procedureDate).append(createdByUserId).append(modifiedByUserId).append(created).append(modified).append(createdByFirstName).append(createdByMiddleInitial).append(createdByLastName).append(modifiedByFirstName).append(modifiedByMiddleInitial).append(modifiedByLastName).append(caseSummaryId).append(rejectReasonId).append(rejectReason).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseRequests) == false) {
            return false;
        }
        CaseRequests rhs = ((CaseRequests) other);
        return new EqualsBuilder().append(applicationScope, rhs.applicationScope).append(caseRequestId, rhs.caseRequestId).append(caseRequestStatus, rhs.caseRequestStatus).append(content, rhs.content).append(organizationId, rhs.organizationId).append(primaryPhysicianPersonId, rhs.primaryPhysicianPersonId).append(procedureDate, rhs.procedureDate).append(createdByUserId, rhs.createdByUserId).append(modifiedByUserId, rhs.modifiedByUserId).append(created, rhs.created).append(modified, rhs.modified).append(createdByFirstName, rhs.createdByFirstName).append(createdByMiddleInitial, rhs.createdByMiddleInitial).append(createdByLastName, rhs.createdByLastName).append(modifiedByFirstName, rhs.modifiedByFirstName).append(modifiedByMiddleInitial, rhs.modifiedByMiddleInitial).append(modifiedByLastName, rhs.modifiedByLastName).append(caseSummaryId, rhs.caseSummaryId).append(rejectReasonId, rhs.rejectReasonId).append(rejectReason, rhs.rejectReason).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
