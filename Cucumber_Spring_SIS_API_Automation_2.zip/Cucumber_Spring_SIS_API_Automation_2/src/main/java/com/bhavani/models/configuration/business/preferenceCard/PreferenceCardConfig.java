
package com.bhavani.models.configuration.business.preferenceCard;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "preferenceCardId",
    "preferenceCardName",
    "caseSpecialtyId",
    "caseSpecialtyName",
    "appointmentTypeId",
    "anesthesiaTypeId",
    "anesthesiaTypeName",
    "physicianId",
    "feeSchedules",
    "duration",
    "notes",
    "cleanUpTime",
    "organizationId",
    "consents",
    "dischargeInstructions",
    "orders",
    "opnotes",
    "isSpecialtyModilfied",
    "isPhysianModilfied",
    "isCreateNewCopy",
    "worklistTemplates",
    "implantProstheses",
    "equipment",
    "suppliesInstruments",
    "sourceIdentifier"
})
public class PreferenceCardConfig {

    @JsonProperty("preferenceCardId")
    private Integer preferenceCardId;
    @JsonProperty("preferenceCardName")
    private String preferenceCardName;
    @JsonProperty("caseSpecialtyId")
    private Integer caseSpecialtyId;
    @JsonProperty("caseSpecialtyName")
    private String caseSpecialtyName;
    @JsonProperty("appointmentTypeId")
    private Object appointmentTypeId;
    @JsonProperty("anesthesiaTypeId")
    private Integer anesthesiaTypeId;
    @JsonProperty("anesthesiaTypeName")
    private String anesthesiaTypeName;
    @JsonProperty("physicianId")
    private Integer physicianId;
    @JsonProperty("feeSchedules")
    private Object feeSchedules;
    @JsonProperty("duration")
    private Integer duration;
    @JsonProperty("notes")
    private String notes;
    @JsonProperty("cleanUpTime")
    private Integer cleanUpTime;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("consents")
    private Object consents;
    @JsonProperty("dischargeInstructions")
    private Object dischargeInstructions;
    @JsonProperty("orders")
    private Object orders;
    @JsonProperty("opnotes")
    private Object opnotes;
    @JsonProperty("isSpecialtyModilfied")
    private Boolean isSpecialtyModilfied;
    @JsonProperty("isPhysianModilfied")
    private Boolean isPhysianModilfied;
    @JsonProperty("isCreateNewCopy")
    private Boolean isCreateNewCopy;
    @JsonProperty("worklistTemplates")
    private Object worklistTemplates;
    @JsonProperty("implantProstheses")
    private Object implantProstheses;
    @JsonProperty("equipment")
    private Object equipment;
    @JsonProperty("suppliesInstruments")
    private Object suppliesInstruments;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("preferenceCardId")
    public Integer getPreferenceCardId() {
        return preferenceCardId;
    }

    @JsonProperty("preferenceCardId")
    public void setPreferenceCardId(Integer preferenceCardId) {
        this.preferenceCardId = preferenceCardId;
    }

    public PreferenceCardConfig withPreferenceCardId(Integer preferenceCardId) {
        this.preferenceCardId = preferenceCardId;
        return this;
    }

    @JsonProperty("preferenceCardName")
    public String getPreferenceCardName() {
        return preferenceCardName;
    }

    @JsonProperty("preferenceCardName")
    public void setPreferenceCardName(String preferenceCardName) {
        this.preferenceCardName = preferenceCardName;
    }

    public PreferenceCardConfig withPreferenceCardName(String preferenceCardName) {
        this.preferenceCardName = preferenceCardName;
        return this;
    }

    @JsonProperty("caseSpecialtyId")
    public Integer getCaseSpecialtyId() {
        return caseSpecialtyId;
    }

    @JsonProperty("caseSpecialtyId")
    public void setCaseSpecialtyId(Integer caseSpecialtyId) {
        this.caseSpecialtyId = caseSpecialtyId;
    }

    public PreferenceCardConfig withCaseSpecialtyId(Integer caseSpecialtyId) {
        this.caseSpecialtyId = caseSpecialtyId;
        return this;
    }

    @JsonProperty("caseSpecialtyName")
    public String getCaseSpecialtyName() {
        return caseSpecialtyName;
    }

    @JsonProperty("caseSpecialtyName")
    public void setCaseSpecialtyName(String caseSpecialtyName) {
        this.caseSpecialtyName = caseSpecialtyName;
    }

    public PreferenceCardConfig withCaseSpecialtyName(String caseSpecialtyName) {
        this.caseSpecialtyName = caseSpecialtyName;
        return this;
    }

    @JsonProperty("appointmentTypeId")
    public Object getAppointmentTypeId() {
        return appointmentTypeId;
    }

    @JsonProperty("appointmentTypeId")
    public void setAppointmentTypeId(Object appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
    }

    public PreferenceCardConfig withAppointmentTypeId(Object appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
        return this;
    }

    @JsonProperty("anesthesiaTypeId")
    public Integer getAnesthesiaTypeId() {
        return anesthesiaTypeId;
    }

    @JsonProperty("anesthesiaTypeId")
    public void setAnesthesiaTypeId(Integer anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
    }

    public PreferenceCardConfig withAnesthesiaTypeId(Integer anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
        return this;
    }

    @JsonProperty("anesthesiaTypeName")
    public String getAnesthesiaTypeName() {
        return anesthesiaTypeName;
    }

    @JsonProperty("anesthesiaTypeName")
    public void setAnesthesiaTypeName(String anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
    }

    public PreferenceCardConfig withAnesthesiaTypeName(String anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
        return this;
    }

    @JsonProperty("physicianId")
    public Integer getPhysicianId() {
        return physicianId;
    }

    @JsonProperty("physicianId")
    public void setPhysicianId(Integer physicianId) {
        this.physicianId = physicianId;
    }

    public PreferenceCardConfig withPhysicianId(Integer physicianId) {
        this.physicianId = physicianId;
        return this;
    }

    @JsonProperty("feeSchedules")
    public Object getFeeSchedules() {
        return feeSchedules;
    }

    @JsonProperty("feeSchedules")
    public void setFeeSchedules(Object feeSchedules) {
        this.feeSchedules = feeSchedules;
    }

    public PreferenceCardConfig withFeeSchedules(Object feeSchedules) {
        this.feeSchedules = feeSchedules;
        return this;
    }

    @JsonProperty("duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public PreferenceCardConfig withDuration(Integer duration) {
        this.duration = duration;
        return this;
    }

    @JsonProperty("notes")
    public String getNotes() {
        return notes;
    }

    @JsonProperty("notes")
    public void setNotes(String notes) {
        this.notes = notes;
    }

    public PreferenceCardConfig withNotes(String notes) {
        this.notes = notes;
        return this;
    }

    @JsonProperty("cleanUpTime")
    public Integer getCleanUpTime() {
        return cleanUpTime;
    }

    @JsonProperty("cleanUpTime")
    public void setCleanUpTime(Integer cleanUpTime) {
        this.cleanUpTime = cleanUpTime;
    }

    public PreferenceCardConfig withCleanUpTime(Integer cleanUpTime) {
        this.cleanUpTime = cleanUpTime;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public PreferenceCardConfig withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("consents")
    public Object getConsents() {
        return consents;
    }

    @JsonProperty("consents")
    public void setConsents(Object consents) {
        this.consents = consents;
    }

    public PreferenceCardConfig withConsents(Object consents) {
        this.consents = consents;
        return this;
    }

    @JsonProperty("dischargeInstructions")
    public Object getDischargeInstructions() {
        return dischargeInstructions;
    }

    @JsonProperty("dischargeInstructions")
    public void setDischargeInstructions(Object dischargeInstructions) {
        this.dischargeInstructions = dischargeInstructions;
    }

    public PreferenceCardConfig withDischargeInstructions(Object dischargeInstructions) {
        this.dischargeInstructions = dischargeInstructions;
        return this;
    }

    @JsonProperty("orders")
    public Object getOrders() {
        return orders;
    }

    @JsonProperty("orders")
    public void setOrders(Object orders) {
        this.orders = orders;
    }

    public PreferenceCardConfig withOrders(Object orders) {
        this.orders = orders;
        return this;
    }

    @JsonProperty("opnotes")
    public Object getOpnotes() {
        return opnotes;
    }

    @JsonProperty("opnotes")
    public void setOpnotes(Object opnotes) {
        this.opnotes = opnotes;
    }

    public PreferenceCardConfig withOpnotes(Object opnotes) {
        this.opnotes = opnotes;
        return this;
    }

    @JsonProperty("isSpecialtyModilfied")
    public Boolean getIsSpecialtyModilfied() {
        return isSpecialtyModilfied;
    }

    @JsonProperty("isSpecialtyModilfied")
    public void setIsSpecialtyModilfied(Boolean isSpecialtyModilfied) {
        this.isSpecialtyModilfied = isSpecialtyModilfied;
    }

    public PreferenceCardConfig withIsSpecialtyModilfied(Boolean isSpecialtyModilfied) {
        this.isSpecialtyModilfied = isSpecialtyModilfied;
        return this;
    }

    @JsonProperty("isPhysianModilfied")
    public Boolean getIsPhysianModilfied() {
        return isPhysianModilfied;
    }

    @JsonProperty("isPhysianModilfied")
    public void setIsPhysianModilfied(Boolean isPhysianModilfied) {
        this.isPhysianModilfied = isPhysianModilfied;
    }

    public PreferenceCardConfig withIsPhysianModilfied(Boolean isPhysianModilfied) {
        this.isPhysianModilfied = isPhysianModilfied;
        return this;
    }

    @JsonProperty("isCreateNewCopy")
    public Boolean getIsCreateNewCopy() {
        return isCreateNewCopy;
    }

    @JsonProperty("isCreateNewCopy")
    public void setIsCreateNewCopy(Boolean isCreateNewCopy) {
        this.isCreateNewCopy = isCreateNewCopy;
    }

    public PreferenceCardConfig withIsCreateNewCopy(Boolean isCreateNewCopy) {
        this.isCreateNewCopy = isCreateNewCopy;
        return this;
    }

    @JsonProperty("worklistTemplates")
    public Object getWorklistTemplates() {
        return worklistTemplates;
    }

    @JsonProperty("worklistTemplates")
    public void setWorklistTemplates(Object worklistTemplates) {
        this.worklistTemplates = worklistTemplates;
    }

    public PreferenceCardConfig withWorklistTemplates(Object worklistTemplates) {
        this.worklistTemplates = worklistTemplates;
        return this;
    }

    @JsonProperty("implantProstheses")
    public Object getImplantProstheses() {
        return implantProstheses;
    }

    @JsonProperty("implantProstheses")
    public void setImplantProstheses(Object implantProstheses) {
        this.implantProstheses = implantProstheses;
    }

    public PreferenceCardConfig withImplantProstheses(Object implantProstheses) {
        this.implantProstheses = implantProstheses;
        return this;
    }

    @JsonProperty("equipment")
    public Object getEquipment() {
        return equipment;
    }

    @JsonProperty("equipment")
    public void setEquipment(Object equipment) {
        this.equipment = equipment;
    }

    public PreferenceCardConfig withEquipment(Object equipment) {
        this.equipment = equipment;
        return this;
    }

    @JsonProperty("suppliesInstruments")
    public Object getSuppliesInstruments() {
        return suppliesInstruments;
    }

    @JsonProperty("suppliesInstruments")
    public void setSuppliesInstruments(Object suppliesInstruments) {
        this.suppliesInstruments = suppliesInstruments;
    }

    public PreferenceCardConfig withSuppliesInstruments(Object suppliesInstruments) {
        this.suppliesInstruments = suppliesInstruments;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public PreferenceCardConfig withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PreferenceCardConfig withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(preferenceCardId).append(preferenceCardName).append(caseSpecialtyId).append(caseSpecialtyName).append(appointmentTypeId).append(anesthesiaTypeId).append(anesthesiaTypeName).append(physicianId).append(feeSchedules).append(duration).append(notes).append(cleanUpTime).append(organizationId).append(consents).append(dischargeInstructions).append(orders).append(opnotes).append(isSpecialtyModilfied).append(isPhysianModilfied).append(isCreateNewCopy).append(worklistTemplates).append(implantProstheses).append(equipment).append(suppliesInstruments).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PreferenceCardConfig) == false) {
            return false;
        }
        PreferenceCardConfig rhs = ((PreferenceCardConfig) other);
        return new EqualsBuilder().append(preferenceCardId, rhs.preferenceCardId).append(preferenceCardName, rhs.preferenceCardName).append(caseSpecialtyId, rhs.caseSpecialtyId).append(caseSpecialtyName, rhs.caseSpecialtyName).append(appointmentTypeId, rhs.appointmentTypeId).append(anesthesiaTypeId, rhs.anesthesiaTypeId).append(anesthesiaTypeName, rhs.anesthesiaTypeName).append(physicianId, rhs.physicianId).append(feeSchedules, rhs.feeSchedules).append(duration, rhs.duration).append(notes, rhs.notes).append(cleanUpTime, rhs.cleanUpTime).append(organizationId, rhs.organizationId).append(consents, rhs.consents).append(dischargeInstructions, rhs.dischargeInstructions).append(orders, rhs.orders).append(opnotes, rhs.opnotes).append(isSpecialtyModilfied, rhs.isSpecialtyModilfied).append(isPhysianModilfied, rhs.isPhysianModilfied).append(isCreateNewCopy, rhs.isCreateNewCopy).append(worklistTemplates, rhs.worklistTemplates).append(implantProstheses, rhs.implantProstheses).append(equipment, rhs.equipment).append(suppliesInstruments, rhs.suppliesInstruments).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
