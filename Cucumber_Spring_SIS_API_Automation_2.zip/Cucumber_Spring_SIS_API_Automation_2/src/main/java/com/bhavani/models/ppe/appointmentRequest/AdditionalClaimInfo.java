
package com.bhavani.models.ppe.appointmentRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "valueCodes",
    "conditionCodes",
    "occurenceCodes",
    "eciCodes",
    "occurenceSpanCodes",
    "reasonCodes",
    "ubClaimNoteInfo",
    "ubClaimSuppInfo",
    "hcfaClaimNoteInfo",
    "hcfaClaimSuppInfo"
})
public class AdditionalClaimInfo {

    @JsonProperty("valueCodes")
    private List<Object> valueCodes = new ArrayList<Object>();
    @JsonProperty("conditionCodes")
    private List<Object> conditionCodes = new ArrayList<Object>();
    @JsonProperty("occurenceCodes")
    private List<Object> occurenceCodes = new ArrayList<Object>();
    @JsonProperty("eciCodes")
    private List<Object> eciCodes = new ArrayList<Object>();
    @JsonProperty("occurenceSpanCodes")
    private List<Object> occurenceSpanCodes = new ArrayList<Object>();
    @JsonProperty("reasonCodes")
    private List<Object> reasonCodes = new ArrayList<Object>();
    @JsonProperty("ubClaimNoteInfo")
    private List<Object> ubClaimNoteInfo = new ArrayList<Object>();
    @JsonProperty("ubClaimSuppInfo")
    private List<Object> ubClaimSuppInfo = new ArrayList<Object>();
    @JsonProperty("hcfaClaimNoteInfo")
    private List<Object> hcfaClaimNoteInfo = new ArrayList<Object>();
    @JsonProperty("hcfaClaimSuppInfo")
    private List<Object> hcfaClaimSuppInfo = new ArrayList<Object>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("valueCodes")
    public List<Object> getValueCodes() {
        return valueCodes;
    }

    @JsonProperty("valueCodes")
    public void setValueCodes(List<Object> valueCodes) {
        this.valueCodes = valueCodes;
    }

    public AdditionalClaimInfo withValueCodes(List<Object> valueCodes) {
        this.valueCodes = valueCodes;
        return this;
    }

    @JsonProperty("conditionCodes")
    public List<Object> getConditionCodes() {
        return conditionCodes;
    }

    @JsonProperty("conditionCodes")
    public void setConditionCodes(List<Object> conditionCodes) {
        this.conditionCodes = conditionCodes;
    }

    public AdditionalClaimInfo withConditionCodes(List<Object> conditionCodes) {
        this.conditionCodes = conditionCodes;
        return this;
    }

    @JsonProperty("occurenceCodes")
    public List<Object> getOccurenceCodes() {
        return occurenceCodes;
    }

    @JsonProperty("occurenceCodes")
    public void setOccurenceCodes(List<Object> occurenceCodes) {
        this.occurenceCodes = occurenceCodes;
    }

    public AdditionalClaimInfo withOccurenceCodes(List<Object> occurenceCodes) {
        this.occurenceCodes = occurenceCodes;
        return this;
    }

    @JsonProperty("eciCodes")
    public List<Object> getEciCodes() {
        return eciCodes;
    }

    @JsonProperty("eciCodes")
    public void setEciCodes(List<Object> eciCodes) {
        this.eciCodes = eciCodes;
    }

    public AdditionalClaimInfo withEciCodes(List<Object> eciCodes) {
        this.eciCodes = eciCodes;
        return this;
    }

    @JsonProperty("occurenceSpanCodes")
    public List<Object> getOccurenceSpanCodes() {
        return occurenceSpanCodes;
    }

    @JsonProperty("occurenceSpanCodes")
    public void setOccurenceSpanCodes(List<Object> occurenceSpanCodes) {
        this.occurenceSpanCodes = occurenceSpanCodes;
    }

    public AdditionalClaimInfo withOccurenceSpanCodes(List<Object> occurenceSpanCodes) {
        this.occurenceSpanCodes = occurenceSpanCodes;
        return this;
    }

    @JsonProperty("reasonCodes")
    public List<Object> getReasonCodes() {
        return reasonCodes;
    }

    @JsonProperty("reasonCodes")
    public void setReasonCodes(List<Object> reasonCodes) {
        this.reasonCodes = reasonCodes;
    }

    public AdditionalClaimInfo withReasonCodes(List<Object> reasonCodes) {
        this.reasonCodes = reasonCodes;
        return this;
    }

    @JsonProperty("ubClaimNoteInfo")
    public List<Object> getUbClaimNoteInfo() {
        return ubClaimNoteInfo;
    }

    @JsonProperty("ubClaimNoteInfo")
    public void setUbClaimNoteInfo(List<Object> ubClaimNoteInfo) {
        this.ubClaimNoteInfo = ubClaimNoteInfo;
    }

    public AdditionalClaimInfo withUbClaimNoteInfo(List<Object> ubClaimNoteInfo) {
        this.ubClaimNoteInfo = ubClaimNoteInfo;
        return this;
    }

    @JsonProperty("ubClaimSuppInfo")
    public List<Object> getUbClaimSuppInfo() {
        return ubClaimSuppInfo;
    }

    @JsonProperty("ubClaimSuppInfo")
    public void setUbClaimSuppInfo(List<Object> ubClaimSuppInfo) {
        this.ubClaimSuppInfo = ubClaimSuppInfo;
    }

    public AdditionalClaimInfo withUbClaimSuppInfo(List<Object> ubClaimSuppInfo) {
        this.ubClaimSuppInfo = ubClaimSuppInfo;
        return this;
    }

    @JsonProperty("hcfaClaimNoteInfo")
    public List<Object> getHcfaClaimNoteInfo() {
        return hcfaClaimNoteInfo;
    }

    @JsonProperty("hcfaClaimNoteInfo")
    public void setHcfaClaimNoteInfo(List<Object> hcfaClaimNoteInfo) {
        this.hcfaClaimNoteInfo = hcfaClaimNoteInfo;
    }

    public AdditionalClaimInfo withHcfaClaimNoteInfo(List<Object> hcfaClaimNoteInfo) {
        this.hcfaClaimNoteInfo = hcfaClaimNoteInfo;
        return this;
    }

    @JsonProperty("hcfaClaimSuppInfo")
    public List<Object> getHcfaClaimSuppInfo() {
        return hcfaClaimSuppInfo;
    }

    @JsonProperty("hcfaClaimSuppInfo")
    public void setHcfaClaimSuppInfo(List<Object> hcfaClaimSuppInfo) {
        this.hcfaClaimSuppInfo = hcfaClaimSuppInfo;
    }

    public AdditionalClaimInfo withHcfaClaimSuppInfo(List<Object> hcfaClaimSuppInfo) {
        this.hcfaClaimSuppInfo = hcfaClaimSuppInfo;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AdditionalClaimInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(valueCodes).append(conditionCodes).append(occurenceCodes).append(eciCodes).append(occurenceSpanCodes).append(reasonCodes).append(ubClaimNoteInfo).append(ubClaimSuppInfo).append(hcfaClaimNoteInfo).append(hcfaClaimSuppInfo).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AdditionalClaimInfo) == false) {
            return false;
        }
        AdditionalClaimInfo rhs = ((AdditionalClaimInfo) other);
        return new EqualsBuilder().append(valueCodes, rhs.valueCodes).append(conditionCodes, rhs.conditionCodes).append(occurenceCodes, rhs.occurenceCodes).append(eciCodes, rhs.eciCodes).append(occurenceSpanCodes, rhs.occurenceSpanCodes).append(reasonCodes, rhs.reasonCodes).append(ubClaimNoteInfo, rhs.ubClaimNoteInfo).append(ubClaimSuppInfo, rhs.ubClaimSuppInfo).append(hcfaClaimNoteInfo, rhs.hcfaClaimNoteInfo).append(hcfaClaimSuppInfo, rhs.hcfaClaimSuppInfo).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
