
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sourceOfRevenueId",
    "sourceOfRevenueName",
    "organizationId",
    "discountPercent",
    "transactionCodeId",
    "writeoffGroupId",
    "writeoffReasonId",
    "sourceIdentifier"
})
public class SourceOfRevenue {

    @JsonProperty("sourceOfRevenueId")
    private Integer sourceOfRevenueId;
    @JsonProperty("sourceOfRevenueName")
    private String sourceOfRevenueName;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("discountPercent")
    private Double discountPercent;
    @JsonProperty("transactionCodeId")
    private Integer transactionCodeId;
    @JsonProperty("writeoffGroupId")
    private Integer writeoffGroupId;
    @JsonProperty("writeoffReasonId")
    private Integer writeoffReasonId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("sourceOfRevenueId")
    public Integer getSourceOfRevenueId() {
        return sourceOfRevenueId;
    }

    @JsonProperty("sourceOfRevenueId")
    public void setSourceOfRevenueId(Integer sourceOfRevenueId) {
        this.sourceOfRevenueId = sourceOfRevenueId;
    }

    public SourceOfRevenue withSourceOfRevenueId(Integer sourceOfRevenueId) {
        this.sourceOfRevenueId = sourceOfRevenueId;
        return this;
    }

    @JsonProperty("sourceOfRevenueName")
    public String getSourceOfRevenueName() {
        return sourceOfRevenueName;
    }

    @JsonProperty("sourceOfRevenueName")
    public void setSourceOfRevenueName(String sourceOfRevenueName) {
        this.sourceOfRevenueName = sourceOfRevenueName;
    }

    public SourceOfRevenue withSourceOfRevenueName(String sourceOfRevenueName) {
        this.sourceOfRevenueName = sourceOfRevenueName;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public SourceOfRevenue withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("discountPercent")
    public Double getDiscountPercent() {
        return discountPercent;
    }

    @JsonProperty("discountPercent")
    public void setDiscountPercent(Double discountPercent) {
        this.discountPercent = discountPercent;
    }

    public SourceOfRevenue withDiscountPercent(Double discountPercent) {
        this.discountPercent = discountPercent;
        return this;
    }

    @JsonProperty("transactionCodeId")
    public Integer getTransactionCodeId() {
        return transactionCodeId;
    }

    @JsonProperty("transactionCodeId")
    public void setTransactionCodeId(Integer transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
    }

    public SourceOfRevenue withTransactionCodeId(Integer transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
        return this;
    }

    @JsonProperty("writeoffGroupId")
    public Integer getWriteoffGroupId() {
        return writeoffGroupId;
    }

    @JsonProperty("writeoffGroupId")
    public void setWriteoffGroupId(Integer writeoffGroupId) {
        this.writeoffGroupId = writeoffGroupId;
    }

    public SourceOfRevenue withWriteoffGroupId(Integer writeoffGroupId) {
        this.writeoffGroupId = writeoffGroupId;
        return this;
    }

    @JsonProperty("writeoffReasonId")
    public Integer getWriteoffReasonId() {
        return writeoffReasonId;
    }

    @JsonProperty("writeoffReasonId")
    public void setWriteoffReasonId(Integer writeoffReasonId) {
        this.writeoffReasonId = writeoffReasonId;
    }

    public SourceOfRevenue withWriteoffReasonId(Integer writeoffReasonId) {
        this.writeoffReasonId = writeoffReasonId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public SourceOfRevenue withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SourceOfRevenue withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceOfRevenueId).append(sourceOfRevenueName).append(organizationId).append(discountPercent).append(transactionCodeId).append(writeoffGroupId).append(writeoffReasonId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SourceOfRevenue) == false) {
            return false;
        }
        SourceOfRevenue rhs = ((SourceOfRevenue) other);
        return new EqualsBuilder().append(sourceOfRevenueId, rhs.sourceOfRevenueId).append(sourceOfRevenueName, rhs.sourceOfRevenueName).append(organizationId, rhs.organizationId).append(discountPercent, rhs.discountPercent).append(transactionCodeId, rhs.transactionCodeId).append(writeoffGroupId, rhs.writeoffGroupId).append(writeoffReasonId, rhs.writeoffReasonId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
