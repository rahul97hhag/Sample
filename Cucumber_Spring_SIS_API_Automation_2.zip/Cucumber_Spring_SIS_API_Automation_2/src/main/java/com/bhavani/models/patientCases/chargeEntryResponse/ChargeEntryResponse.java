
package com.bhavani.models.patientCases.chargeEntryResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bhavani.models.scheduledProcedures.FeeScheduleItem;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "eventSource",
    "controlsModifiedInEditChargeMode",
    "performedCaseProcedureId",
    "dateOfSurgery",
    "caseSummaryId",
    "caseProcedureId",
    "cptProcedureId",
    "providerId",
    "referingProviderId",
    "units",
    "allowedAmount",
    "generateBill",
    "cptModifier1Id",
    "cptModifier2Id",
    "cptModifier3Id",
    "cptModifier4Id",
    "sortorder",
    "physicianName",
    "referingProviderName",
    "feeScheduleId",
    "cptProcedureDescription",
    "cptCode",
    "appointmentId",
    "selfPay",
    "patientId",
    "workersCompensation",
    "diagnosisList",
    "transactionList",
    "chargeEntryPatientInsMap",
    "fullChargeCorrectionRequired",
    "chargeAutoCorrected",
    "generateBillStateModified",
    "preopDiagnosisList",
    "performedCaseSupply",
    "performedCaseItemTypeId",
    "lastBilledDate",
    "isCombinedCodingChargeEntry",
    "isCorrected",
    "feeScheduleItem",
    "isCaseProcedureSelfPay",
    "sourceIdentifier"
})
public class ChargeEntryResponse {

    @JsonProperty("eventSource")
    private String eventSource;
    @JsonProperty("controlsModifiedInEditChargeMode")
    private Boolean controlsModifiedInEditChargeMode;
    @JsonProperty("performedCaseProcedureId")
    private Integer performedCaseProcedureId;
    @JsonProperty("dateOfSurgery")
    private Object dateOfSurgery;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("caseProcedureId")
    private Integer caseProcedureId;
    @JsonProperty("cptProcedureId")
    private Integer cptProcedureId;
    @JsonProperty("providerId")
    private Integer providerId;
    @JsonProperty("referingProviderId")
    private Object referingProviderId;
    @JsonProperty("units")
    private Double units;
    @JsonProperty("allowedAmount")
    private Object allowedAmount;
    @JsonProperty("generateBill")
    private Boolean generateBill;
    @JsonProperty("cptModifier1Id")
    private Object cptModifier1Id;
    @JsonProperty("cptModifier2Id")
    private Object cptModifier2Id;
    @JsonProperty("cptModifier3Id")
    private Object cptModifier3Id;
    @JsonProperty("cptModifier4Id")
    private Object cptModifier4Id;
    @JsonProperty("sortorder")
    private Integer sortorder;
    @JsonProperty("physicianName")
    private String physicianName;
    @JsonProperty("referingProviderName")
    private Object referingProviderName;
    @JsonProperty("feeScheduleId")
    private Integer feeScheduleId;
    @JsonProperty("cptProcedureDescription")
    private String cptProcedureDescription;
    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("appointmentId")
    private Integer appointmentId;
    @JsonProperty("selfPay")
    private Boolean selfPay;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("workersCompensation")
    private Boolean workersCompensation;
    @JsonProperty("diagnosisList")
    private List<DiagnosisList> diagnosisList = new ArrayList<DiagnosisList>();
    @JsonProperty("transactionList")
    private List<TransactionList> transactionList = new ArrayList<TransactionList>();
    @JsonProperty("chargeEntryPatientInsMap")
    private List<Object> chargeEntryPatientInsMap = new ArrayList<Object>();
    @JsonProperty("fullChargeCorrectionRequired")
    private Object fullChargeCorrectionRequired;
    @JsonProperty("chargeAutoCorrected")
    private Boolean chargeAutoCorrected;
    @JsonProperty("generateBillStateModified")
    private Boolean generateBillStateModified;
    @JsonProperty("preopDiagnosisList")
    private List<Object> preopDiagnosisList = new ArrayList<Object>();
    @JsonProperty("performedCaseSupply")
    private Object performedCaseSupply;
    @JsonProperty("performedCaseItemTypeId")
    private Integer performedCaseItemTypeId;
    @JsonProperty("lastBilledDate")
    private Object lastBilledDate;
    @JsonProperty("isCombinedCodingChargeEntry")
    private Boolean isCombinedCodingChargeEntry;
    @JsonProperty("isCorrected")
    private Boolean isCorrected;
    @JsonProperty("feeScheduleItem")
    private FeeScheduleItem feeScheduleItem;
    @JsonProperty("isCaseProcedureSelfPay")
    private Boolean isCaseProcedureSelfPay;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("eventSource")
    public String getEventSource() {
        return eventSource;
    }

    @JsonProperty("eventSource")
    public void setEventSource(String eventSource) {
        this.eventSource = eventSource;
    }

    public ChargeEntryResponse withEventSource(String eventSource) {
        this.eventSource = eventSource;
        return this;
    }

    @JsonProperty("controlsModifiedInEditChargeMode")
    public Boolean getControlsModifiedInEditChargeMode() {
        return controlsModifiedInEditChargeMode;
    }

    @JsonProperty("controlsModifiedInEditChargeMode")
    public void setControlsModifiedInEditChargeMode(Boolean controlsModifiedInEditChargeMode) {
        this.controlsModifiedInEditChargeMode = controlsModifiedInEditChargeMode;
    }

    public ChargeEntryResponse withControlsModifiedInEditChargeMode(Boolean controlsModifiedInEditChargeMode) {
        this.controlsModifiedInEditChargeMode = controlsModifiedInEditChargeMode;
        return this;
    }

    @JsonProperty("performedCaseProcedureId")
    public Integer getPerformedCaseProcedureId() {
        return performedCaseProcedureId;
    }

    @JsonProperty("performedCaseProcedureId")
    public void setPerformedCaseProcedureId(Integer performedCaseProcedureId) {
        this.performedCaseProcedureId = performedCaseProcedureId;
    }

    public ChargeEntryResponse withPerformedCaseProcedureId(Integer performedCaseProcedureId) {
        this.performedCaseProcedureId = performedCaseProcedureId;
        return this;
    }

    @JsonProperty("dateOfSurgery")
    public Object getDateOfSurgery() {
        return dateOfSurgery;
    }

    @JsonProperty("dateOfSurgery")
    public void setDateOfSurgery(Object dateOfSurgery) {
        this.dateOfSurgery = dateOfSurgery;
    }

    public ChargeEntryResponse withDateOfSurgery(Object dateOfSurgery) {
        this.dateOfSurgery = dateOfSurgery;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public ChargeEntryResponse withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("caseProcedureId")
    public Integer getCaseProcedureId() {
        return caseProcedureId;
    }

    @JsonProperty("caseProcedureId")
    public void setCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
    }

    public ChargeEntryResponse withCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
        return this;
    }

    @JsonProperty("cptProcedureId")
    public Integer getCptProcedureId() {
        return cptProcedureId;
    }

    @JsonProperty("cptProcedureId")
    public void setCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
    }

    public ChargeEntryResponse withCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
        return this;
    }

    @JsonProperty("providerId")
    public Integer getProviderId() {
        return providerId;
    }

    @JsonProperty("providerId")
    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }

    public ChargeEntryResponse withProviderId(Integer providerId) {
        this.providerId = providerId;
        return this;
    }

    @JsonProperty("referingProviderId")
    public Object getReferingProviderId() {
        return referingProviderId;
    }

    @JsonProperty("referingProviderId")
    public void setReferingProviderId(Object referingProviderId) {
        this.referingProviderId = referingProviderId;
    }

    public ChargeEntryResponse withReferingProviderId(Object referingProviderId) {
        this.referingProviderId = referingProviderId;
        return this;
    }

    @JsonProperty("units")
    public Double getUnits() {
        return units;
    }

    @JsonProperty("units")
    public void setUnits(Double units) {
        this.units = units;
    }

    public ChargeEntryResponse withUnits(Double units) {
        this.units = units;
        return this;
    }

    @JsonProperty("allowedAmount")
    public Object getAllowedAmount() {
        return allowedAmount;
    }

    @JsonProperty("allowedAmount")
    public void setAllowedAmount(Object allowedAmount) {
        this.allowedAmount = allowedAmount;
    }

    public ChargeEntryResponse withAllowedAmount(Object allowedAmount) {
        this.allowedAmount = allowedAmount;
        return this;
    }

    @JsonProperty("generateBill")
    public Boolean getGenerateBill() {
        return generateBill;
    }

    @JsonProperty("generateBill")
    public void setGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
    }

    public ChargeEntryResponse withGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
        return this;
    }

    @JsonProperty("cptModifier1Id")
    public Object getCptModifier1Id() {
        return cptModifier1Id;
    }

    @JsonProperty("cptModifier1Id")
    public void setCptModifier1Id(Object cptModifier1Id) {
        this.cptModifier1Id = cptModifier1Id;
    }

    public ChargeEntryResponse withCptModifier1Id(Object cptModifier1Id) {
        this.cptModifier1Id = cptModifier1Id;
        return this;
    }

    @JsonProperty("cptModifier2Id")
    public Object getCptModifier2Id() {
        return cptModifier2Id;
    }

    @JsonProperty("cptModifier2Id")
    public void setCptModifier2Id(Object cptModifier2Id) {
        this.cptModifier2Id = cptModifier2Id;
    }

    public ChargeEntryResponse withCptModifier2Id(Object cptModifier2Id) {
        this.cptModifier2Id = cptModifier2Id;
        return this;
    }

    @JsonProperty("cptModifier3Id")
    public Object getCptModifier3Id() {
        return cptModifier3Id;
    }

    @JsonProperty("cptModifier3Id")
    public void setCptModifier3Id(Object cptModifier3Id) {
        this.cptModifier3Id = cptModifier3Id;
    }

    public ChargeEntryResponse withCptModifier3Id(Object cptModifier3Id) {
        this.cptModifier3Id = cptModifier3Id;
        return this;
    }

    @JsonProperty("cptModifier4Id")
    public Object getCptModifier4Id() {
        return cptModifier4Id;
    }

    @JsonProperty("cptModifier4Id")
    public void setCptModifier4Id(Object cptModifier4Id) {
        this.cptModifier4Id = cptModifier4Id;
    }

    public ChargeEntryResponse withCptModifier4Id(Object cptModifier4Id) {
        this.cptModifier4Id = cptModifier4Id;
        return this;
    }

    @JsonProperty("sortorder")
    public Integer getSortorder() {
        return sortorder;
    }

    @JsonProperty("sortorder")
    public void setSortorder(Integer sortorder) {
        this.sortorder = sortorder;
    }

    public ChargeEntryResponse withSortorder(Integer sortorder) {
        this.sortorder = sortorder;
        return this;
    }

    @JsonProperty("physicianName")
    public String getPhysicianName() {
        return physicianName;
    }

    @JsonProperty("physicianName")
    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public ChargeEntryResponse withPhysicianName(String physicianName) {
        this.physicianName = physicianName;
        return this;
    }

    @JsonProperty("referingProviderName")
    public Object getReferingProviderName() {
        return referingProviderName;
    }

    @JsonProperty("referingProviderName")
    public void setReferingProviderName(Object referingProviderName) {
        this.referingProviderName = referingProviderName;
    }

    public ChargeEntryResponse withReferingProviderName(Object referingProviderName) {
        this.referingProviderName = referingProviderName;
        return this;
    }

    @JsonProperty("feeScheduleId")
    public Integer getFeeScheduleId() {
        return feeScheduleId;
    }

    @JsonProperty("feeScheduleId")
    public void setFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
    }

    public ChargeEntryResponse withFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
        return this;
    }

    @JsonProperty("cptProcedureDescription")
    public String getCptProcedureDescription() {
        return cptProcedureDescription;
    }

    @JsonProperty("cptProcedureDescription")
    public void setCptProcedureDescription(String cptProcedureDescription) {
        this.cptProcedureDescription = cptProcedureDescription;
    }

    public ChargeEntryResponse withCptProcedureDescription(String cptProcedureDescription) {
        this.cptProcedureDescription = cptProcedureDescription;
        return this;
    }

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public ChargeEntryResponse withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("appointmentId")
    public Integer getAppointmentId() {
        return appointmentId;
    }

    @JsonProperty("appointmentId")
    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public ChargeEntryResponse withAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
        return this;
    }

    @JsonProperty("selfPay")
    public Boolean getSelfPay() {
        return selfPay;
    }

    @JsonProperty("selfPay")
    public void setSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
    }

    public ChargeEntryResponse withSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public ChargeEntryResponse withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("workersCompensation")
    public Boolean getWorkersCompensation() {
        return workersCompensation;
    }

    @JsonProperty("workersCompensation")
    public void setWorkersCompensation(Boolean workersCompensation) {
        this.workersCompensation = workersCompensation;
    }

    public ChargeEntryResponse withWorkersCompensation(Boolean workersCompensation) {
        this.workersCompensation = workersCompensation;
        return this;
    }

    @JsonProperty("diagnosisList")
    public List<DiagnosisList> getDiagnosisList() {
        return diagnosisList;
    }

    @JsonProperty("diagnosisList")
    public void setDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
    }

    public ChargeEntryResponse withDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
        return this;
    }

    @JsonProperty("transactionList")
    public List<TransactionList> getTransactionList() {
        return transactionList;
    }

    @JsonProperty("transactionList")
    public void setTransactionList(List<TransactionList> transactionList) {
        this.transactionList = transactionList;
    }

    public ChargeEntryResponse withTransactionList(List<TransactionList> transactionList) {
        this.transactionList = transactionList;
        return this;
    }

    @JsonProperty("chargeEntryPatientInsMap")
    public List<Object> getChargeEntryPatientInsMap() {
        return chargeEntryPatientInsMap;
    }

    @JsonProperty("chargeEntryPatientInsMap")
    public void setChargeEntryPatientInsMap(List<Object> chargeEntryPatientInsMap) {
        this.chargeEntryPatientInsMap = chargeEntryPatientInsMap;
    }

    public ChargeEntryResponse withChargeEntryPatientInsMap(List<Object> chargeEntryPatientInsMap) {
        this.chargeEntryPatientInsMap = chargeEntryPatientInsMap;
        return this;
    }

    @JsonProperty("fullChargeCorrectionRequired")
    public Object getFullChargeCorrectionRequired() {
        return fullChargeCorrectionRequired;
    }

    @JsonProperty("fullChargeCorrectionRequired")
    public void setFullChargeCorrectionRequired(Object fullChargeCorrectionRequired) {
        this.fullChargeCorrectionRequired = fullChargeCorrectionRequired;
    }

    public ChargeEntryResponse withFullChargeCorrectionRequired(Object fullChargeCorrectionRequired) {
        this.fullChargeCorrectionRequired = fullChargeCorrectionRequired;
        return this;
    }

    @JsonProperty("chargeAutoCorrected")
    public Boolean getChargeAutoCorrected() {
        return chargeAutoCorrected;
    }

    @JsonProperty("chargeAutoCorrected")
    public void setChargeAutoCorrected(Boolean chargeAutoCorrected) {
        this.chargeAutoCorrected = chargeAutoCorrected;
    }

    public ChargeEntryResponse withChargeAutoCorrected(Boolean chargeAutoCorrected) {
        this.chargeAutoCorrected = chargeAutoCorrected;
        return this;
    }

    @JsonProperty("generateBillStateModified")
    public Boolean getGenerateBillStateModified() {
        return generateBillStateModified;
    }

    @JsonProperty("generateBillStateModified")
    public void setGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
    }

    public ChargeEntryResponse withGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
        return this;
    }

    @JsonProperty("preopDiagnosisList")
    public List<Object> getPreopDiagnosisList() {
        return preopDiagnosisList;
    }

    @JsonProperty("preopDiagnosisList")
    public void setPreopDiagnosisList(List<Object> preopDiagnosisList) {
        this.preopDiagnosisList = preopDiagnosisList;
    }

    public ChargeEntryResponse withPreopDiagnosisList(List<Object> preopDiagnosisList) {
        this.preopDiagnosisList = preopDiagnosisList;
        return this;
    }

    @JsonProperty("performedCaseSupply")
    public Object getPerformedCaseSupply() {
        return performedCaseSupply;
    }

    @JsonProperty("performedCaseSupply")
    public void setPerformedCaseSupply(Object performedCaseSupply) {
        this.performedCaseSupply = performedCaseSupply;
    }

    public ChargeEntryResponse withPerformedCaseSupply(Object performedCaseSupply) {
        this.performedCaseSupply = performedCaseSupply;
        return this;
    }

    @JsonProperty("performedCaseItemTypeId")
    public Integer getPerformedCaseItemTypeId() {
        return performedCaseItemTypeId;
    }

    @JsonProperty("performedCaseItemTypeId")
    public void setPerformedCaseItemTypeId(Integer performedCaseItemTypeId) {
        this.performedCaseItemTypeId = performedCaseItemTypeId;
    }

    public ChargeEntryResponse withPerformedCaseItemTypeId(Integer performedCaseItemTypeId) {
        this.performedCaseItemTypeId = performedCaseItemTypeId;
        return this;
    }

    @JsonProperty("lastBilledDate")
    public Object getLastBilledDate() {
        return lastBilledDate;
    }

    @JsonProperty("lastBilledDate")
    public void setLastBilledDate(Object lastBilledDate) {
        this.lastBilledDate = lastBilledDate;
    }

    public ChargeEntryResponse withLastBilledDate(Object lastBilledDate) {
        this.lastBilledDate = lastBilledDate;
        return this;
    }

    @JsonProperty("isCombinedCodingChargeEntry")
    public Boolean getIsCombinedCodingChargeEntry() {
        return isCombinedCodingChargeEntry;
    }

    @JsonProperty("isCombinedCodingChargeEntry")
    public void setIsCombinedCodingChargeEntry(Boolean isCombinedCodingChargeEntry) {
        this.isCombinedCodingChargeEntry = isCombinedCodingChargeEntry;
    }

    public ChargeEntryResponse withIsCombinedCodingChargeEntry(Boolean isCombinedCodingChargeEntry) {
        this.isCombinedCodingChargeEntry = isCombinedCodingChargeEntry;
        return this;
    }

    @JsonProperty("isCorrected")
    public Boolean getIsCorrected() {
        return isCorrected;
    }

    @JsonProperty("isCorrected")
    public void setIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
    }

    public ChargeEntryResponse withIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
        return this;
    }

    @JsonProperty("feeScheduleItem")
    public FeeScheduleItem getFeeScheduleItem() {
        return feeScheduleItem;
    }

    @JsonProperty("feeScheduleItem")
    public void setFeeScheduleItem(FeeScheduleItem feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
    }

    public ChargeEntryResponse withFeeScheduleItem(FeeScheduleItem feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
        return this;
    }

    @JsonProperty("isCaseProcedureSelfPay")
    public Boolean getIsCaseProcedureSelfPay() {
        return isCaseProcedureSelfPay;
    }

    @JsonProperty("isCaseProcedureSelfPay")
    public void setIsCaseProcedureSelfPay(Boolean isCaseProcedureSelfPay) {
        this.isCaseProcedureSelfPay = isCaseProcedureSelfPay;
    }

    public ChargeEntryResponse withIsCaseProcedureSelfPay(Boolean isCaseProcedureSelfPay) {
        this.isCaseProcedureSelfPay = isCaseProcedureSelfPay;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public ChargeEntryResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChargeEntryResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(eventSource).append(controlsModifiedInEditChargeMode).append(performedCaseProcedureId).append(dateOfSurgery).append(caseSummaryId).append(caseProcedureId).append(cptProcedureId).append(providerId).append(referingProviderId).append(units).append(allowedAmount).append(generateBill).append(cptModifier1Id).append(cptModifier2Id).append(cptModifier3Id).append(cptModifier4Id).append(sortorder).append(physicianName).append(referingProviderName).append(feeScheduleId).append(cptProcedureDescription).append(cptCode).append(appointmentId).append(selfPay).append(patientId).append(workersCompensation).append(diagnosisList).append(transactionList).append(chargeEntryPatientInsMap).append(fullChargeCorrectionRequired).append(chargeAutoCorrected).append(generateBillStateModified).append(preopDiagnosisList).append(performedCaseSupply).append(performedCaseItemTypeId).append(lastBilledDate).append(isCombinedCodingChargeEntry).append(isCorrected).append(feeScheduleItem).append(isCaseProcedureSelfPay).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChargeEntryResponse) == false) {
            return false;
        }
        ChargeEntryResponse rhs = ((ChargeEntryResponse) other);
        return new EqualsBuilder().append(eventSource, rhs.eventSource).append(controlsModifiedInEditChargeMode, rhs.controlsModifiedInEditChargeMode).append(performedCaseProcedureId, rhs.performedCaseProcedureId).append(dateOfSurgery, rhs.dateOfSurgery).append(caseSummaryId, rhs.caseSummaryId).append(caseProcedureId, rhs.caseProcedureId).append(cptProcedureId, rhs.cptProcedureId).append(providerId, rhs.providerId).append(referingProviderId, rhs.referingProviderId).append(units, rhs.units).append(allowedAmount, rhs.allowedAmount).append(generateBill, rhs.generateBill).append(cptModifier1Id, rhs.cptModifier1Id).append(cptModifier2Id, rhs.cptModifier2Id).append(cptModifier3Id, rhs.cptModifier3Id).append(cptModifier4Id, rhs.cptModifier4Id).append(sortorder, rhs.sortorder).append(physicianName, rhs.physicianName).append(referingProviderName, rhs.referingProviderName).append(feeScheduleId, rhs.feeScheduleId).append(cptProcedureDescription, rhs.cptProcedureDescription).append(cptCode, rhs.cptCode).append(appointmentId, rhs.appointmentId).append(selfPay, rhs.selfPay).append(patientId, rhs.patientId).append(workersCompensation, rhs.workersCompensation).append(diagnosisList, rhs.diagnosisList).append(transactionList, rhs.transactionList).append(chargeEntryPatientInsMap, rhs.chargeEntryPatientInsMap).append(fullChargeCorrectionRequired, rhs.fullChargeCorrectionRequired).append(chargeAutoCorrected, rhs.chargeAutoCorrected).append(generateBillStateModified, rhs.generateBillStateModified).append(preopDiagnosisList, rhs.preopDiagnosisList).append(performedCaseSupply, rhs.performedCaseSupply).append(performedCaseItemTypeId, rhs.performedCaseItemTypeId).append(lastBilledDate, rhs.lastBilledDate).append(isCombinedCodingChargeEntry, rhs.isCombinedCodingChargeEntry).append(isCorrected, rhs.isCorrected).append(feeScheduleItem, rhs.feeScheduleItem).append(isCaseProcedureSelfPay, rhs.isCaseProcedureSelfPay).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
