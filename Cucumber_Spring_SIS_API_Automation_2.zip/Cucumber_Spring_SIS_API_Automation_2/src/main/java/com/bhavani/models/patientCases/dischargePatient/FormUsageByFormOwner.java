
package com.bhavani.models.patientCases.dischargePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "formUsageId",
    "caseSummaryId",
    "moduleId",
    "formId",
    "staffId",
    "lastUpdated",
    "staffName",
    "executorName",
    "sourceIdentifier"
})
public class FormUsageByFormOwner {

    @JsonProperty("formUsageId")
    private Integer formUsageId;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("moduleId")
    private Integer moduleId;
    @JsonProperty("formId")
    private Integer formId;
    @JsonProperty("staffId")
    private Integer staffId;
    @JsonProperty("lastUpdated")
    private String lastUpdated;
    @JsonProperty("staffName")
    private String staffName;
    @JsonProperty("executorName")
    private Object executorName;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("formUsageId")
    public Integer getFormUsageId() {
        return formUsageId;
    }

    @JsonProperty("formUsageId")
    public void setFormUsageId(Integer formUsageId) {
        this.formUsageId = formUsageId;
    }

    public FormUsageByFormOwner withFormUsageId(Integer formUsageId) {
        this.formUsageId = formUsageId;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public FormUsageByFormOwner withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("moduleId")
    public Integer getModuleId() {
        return moduleId;
    }

    @JsonProperty("moduleId")
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public FormUsageByFormOwner withModuleId(Integer moduleId) {
        this.moduleId = moduleId;
        return this;
    }

    @JsonProperty("formId")
    public Integer getFormId() {
        return formId;
    }

    @JsonProperty("formId")
    public void setFormId(Integer formId) {
        this.formId = formId;
    }

    public FormUsageByFormOwner withFormId(Integer formId) {
        this.formId = formId;
        return this;
    }

    @JsonProperty("staffId")
    public Integer getStaffId() {
        return staffId;
    }

    @JsonProperty("staffId")
    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public FormUsageByFormOwner withStaffId(Integer staffId) {
        this.staffId = staffId;
        return this;
    }

    @JsonProperty("lastUpdated")
    public String getLastUpdated() {
        return lastUpdated;
    }

    @JsonProperty("lastUpdated")
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public FormUsageByFormOwner withLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
        return this;
    }

    @JsonProperty("staffName")
    public String getStaffName() {
        return staffName;
    }

    @JsonProperty("staffName")
    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public FormUsageByFormOwner withStaffName(String staffName) {
        this.staffName = staffName;
        return this;
    }

    @JsonProperty("executorName")
    public Object getExecutorName() {
        return executorName;
    }

    @JsonProperty("executorName")
    public void setExecutorName(Object executorName) {
        this.executorName = executorName;
    }

    public FormUsageByFormOwner withExecutorName(Object executorName) {
        this.executorName = executorName;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public FormUsageByFormOwner withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FormUsageByFormOwner withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(formUsageId).append(caseSummaryId).append(moduleId).append(formId).append(staffId).append(lastUpdated).append(staffName).append(executorName).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FormUsageByFormOwner) == false) {
            return false;
        }
        FormUsageByFormOwner rhs = ((FormUsageByFormOwner) other);
        return new EqualsBuilder().append(formUsageId, rhs.formUsageId).append(caseSummaryId, rhs.caseSummaryId).append(moduleId, rhs.moduleId).append(formId, rhs.formId).append(staffId, rhs.staffId).append(lastUpdated, rhs.lastUpdated).append(staffName, rhs.staffName).append(executorName, rhs.executorName).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
