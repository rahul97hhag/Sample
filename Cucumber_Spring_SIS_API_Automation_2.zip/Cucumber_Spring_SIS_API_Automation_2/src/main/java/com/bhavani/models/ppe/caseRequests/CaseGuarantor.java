
package com.bhavani.models.ppe.caseRequests;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "guarantorMasterId",
    "caseSummaryId",
    "guarantorId",
    "sortOrder",
    "isSelf",
    "patientGuarantorId",
    "patientId",
    "firstName",
    "lastName",
    "gender",
    "dateOfBirth",
    "address1",
    "address2",
    "city",
    "state",
    "zip",
    "patientRelationship",
    "country",
    "phoneNumber",
    "isCaseGuarantorActive",
    "isActive"
})
public class CaseGuarantor {

    @JsonProperty("guarantorMasterId")
    private Integer guarantorMasterId;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("guarantorId")
    private Integer guarantorId;
    @JsonProperty("sortOrder")
    private Integer sortOrder;
    @JsonProperty("isSelf")
    private Object isSelf;
    @JsonProperty("patientGuarantorId")
    private Object patientGuarantorId;
    @JsonProperty("patientId")
    private Object patientId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("gender")
    private Object gender;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("address1")
    private Object address1;
    @JsonProperty("address2")
    private Object address2;
    @JsonProperty("city")
    private Object city;
    @JsonProperty("state")
    private Object state;
    @JsonProperty("zip")
    private Object zip;
    @JsonProperty("patientRelationship")
    private String patientRelationship;
    @JsonProperty("country")
    private String country;
    @JsonProperty("phoneNumber")
    private Object phoneNumber;
    @JsonProperty("isCaseGuarantorActive")
    private Object isCaseGuarantorActive;
    @JsonProperty("isActive")
    private Object isActive;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("guarantorMasterId")
    public Integer getGuarantorMasterId() {
        return guarantorMasterId;
    }

    @JsonProperty("guarantorMasterId")
    public void setGuarantorMasterId(Integer guarantorMasterId) {
        this.guarantorMasterId = guarantorMasterId;
    }

    public CaseGuarantor withGuarantorMasterId(Integer guarantorMasterId) {
        this.guarantorMasterId = guarantorMasterId;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public CaseGuarantor withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("guarantorId")
    public Integer getGuarantorId() {
        return guarantorId;
    }

    @JsonProperty("guarantorId")
    public void setGuarantorId(Integer guarantorId) {
        this.guarantorId = guarantorId;
    }

    public CaseGuarantor withGuarantorId(Integer guarantorId) {
        this.guarantorId = guarantorId;
        return this;
    }

    @JsonProperty("sortOrder")
    public Integer getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public CaseGuarantor withSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("isSelf")
    public Object getIsSelf() {
        return isSelf;
    }

    @JsonProperty("isSelf")
    public void setIsSelf(Object isSelf) {
        this.isSelf = isSelf;
    }

    public CaseGuarantor withIsSelf(Object isSelf) {
        this.isSelf = isSelf;
        return this;
    }

    @JsonProperty("patientGuarantorId")
    public Object getPatientGuarantorId() {
        return patientGuarantorId;
    }

    @JsonProperty("patientGuarantorId")
    public void setPatientGuarantorId(Object patientGuarantorId) {
        this.patientGuarantorId = patientGuarantorId;
    }

    public CaseGuarantor withPatientGuarantorId(Object patientGuarantorId) {
        this.patientGuarantorId = patientGuarantorId;
        return this;
    }

    @JsonProperty("patientId")
    public Object getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Object patientId) {
        this.patientId = patientId;
    }

    public CaseGuarantor withPatientId(Object patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public CaseGuarantor withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public CaseGuarantor withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("gender")
    public Object getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(Object gender) {
        this.gender = gender;
    }

    public CaseGuarantor withGender(Object gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public CaseGuarantor withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("address1")
    public Object getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(Object address1) {
        this.address1 = address1;
    }

    public CaseGuarantor withAddress1(Object address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("address2")
    public Object getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(Object address2) {
        this.address2 = address2;
    }

    public CaseGuarantor withAddress2(Object address2) {
        this.address2 = address2;
        return this;
    }

    @JsonProperty("city")
    public Object getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(Object city) {
        this.city = city;
    }

    public CaseGuarantor withCity(Object city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public Object getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(Object state) {
        this.state = state;
    }

    public CaseGuarantor withState(Object state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zip")
    public Object getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(Object zip) {
        this.zip = zip;
    }

    public CaseGuarantor withZip(Object zip) {
        this.zip = zip;
        return this;
    }

    @JsonProperty("patientRelationship")
    public String getPatientRelationship() {
        return patientRelationship;
    }

    @JsonProperty("patientRelationship")
    public void setPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
    }

    public CaseGuarantor withPatientRelationship(String patientRelationship) {
        this.patientRelationship = patientRelationship;
        return this;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    public CaseGuarantor withCountry(String country) {
        this.country = country;
        return this;
    }

    @JsonProperty("phoneNumber")
    public Object getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public CaseGuarantor withPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("isCaseGuarantorActive")
    public Object getIsCaseGuarantorActive() {
        return isCaseGuarantorActive;
    }

    @JsonProperty("isCaseGuarantorActive")
    public void setIsCaseGuarantorActive(Object isCaseGuarantorActive) {
        this.isCaseGuarantorActive = isCaseGuarantorActive;
    }

    public CaseGuarantor withIsCaseGuarantorActive(Object isCaseGuarantorActive) {
        this.isCaseGuarantorActive = isCaseGuarantorActive;
        return this;
    }

    @JsonProperty("isActive")
    public Object getIsActive() {
        return isActive;
    }

    @JsonProperty("isActive")
    public void setIsActive(Object isActive) {
        this.isActive = isActive;
    }

    public CaseGuarantor withIsActive(Object isActive) {
        this.isActive = isActive;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseGuarantor withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(guarantorMasterId).append(caseSummaryId).append(guarantorId).append(sortOrder).append(isSelf).append(patientGuarantorId).append(patientId).append(firstName).append(lastName).append(gender).append(dateOfBirth).append(address1).append(address2).append(city).append(state).append(zip).append(patientRelationship).append(country).append(phoneNumber).append(isCaseGuarantorActive).append(isActive).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseGuarantor) == false) {
            return false;
        }
        CaseGuarantor rhs = ((CaseGuarantor) other);
        return new EqualsBuilder().append(guarantorMasterId, rhs.guarantorMasterId).append(caseSummaryId, rhs.caseSummaryId).append(guarantorId, rhs.guarantorId).append(sortOrder, rhs.sortOrder).append(isSelf, rhs.isSelf).append(patientGuarantorId, rhs.patientGuarantorId).append(patientId, rhs.patientId).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(gender, rhs.gender).append(dateOfBirth, rhs.dateOfBirth).append(address1, rhs.address1).append(address2, rhs.address2).append(city, rhs.city).append(state, rhs.state).append(zip, rhs.zip).append(patientRelationship, rhs.patientRelationship).append(country, rhs.country).append(phoneNumber, rhs.phoneNumber).append(isCaseGuarantorActive, rhs.isCaseGuarantorActive).append(isActive, rhs.isActive).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
