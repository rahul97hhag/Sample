
package com.bhavani.models.patientCases.ppePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "displayName",
    "relationshipToInsured",
    "groupNumber",
    "groupName",
    "carrier",
    "firstName",
    "lastName",
    "primaryPhone"
})
public class CaseInsurance {

    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("relationshipToInsured")
    private String relationshipToInsured;
    @JsonProperty("groupNumber")
    private String groupNumber;
    @JsonProperty("groupName")
    private String groupName;
    @JsonProperty("carrier")
    private String carrier;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("primaryPhone")
    private String primaryPhone;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public CaseInsurance withDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    @JsonProperty("relationshipToInsured")
    public String getRelationshipToInsured() {
        return relationshipToInsured;
    }

    @JsonProperty("relationshipToInsured")
    public void setRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
    }

    public CaseInsurance withRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
        return this;
    }

    @JsonProperty("groupNumber")
    public String getGroupNumber() {
        return groupNumber;
    }

    @JsonProperty("groupNumber")
    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public CaseInsurance withGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
        return this;
    }

    @JsonProperty("groupName")
    public String getGroupName() {
        return groupName;
    }

    @JsonProperty("groupName")
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public CaseInsurance withGroupName(String groupName) {
        this.groupName = groupName;
        return this;
    }

    @JsonProperty("carrier")
    public String getCarrier() {
        return carrier;
    }

    @JsonProperty("carrier")
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public CaseInsurance withCarrier(String carrier) {
        this.carrier = carrier;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public CaseInsurance withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public CaseInsurance withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("primaryPhone")
    public String getPrimaryPhone() {
        return primaryPhone;
    }

    @JsonProperty("primaryPhone")
    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public CaseInsurance withPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseInsurance withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(displayName).append(relationshipToInsured).append(groupNumber).append(groupName).append(carrier).append(firstName).append(lastName).append(primaryPhone).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseInsurance) == false) {
            return false;
        }
        CaseInsurance rhs = ((CaseInsurance) other);
        return new EqualsBuilder().append(displayName, rhs.displayName).append(relationshipToInsured, rhs.relationshipToInsured).append(groupNumber, rhs.groupNumber).append(groupName, rhs.groupName).append(carrier, rhs.carrier).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(primaryPhone, rhs.primaryPhone).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
