
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "transactionCodeId",
    "transactionCodeName",
    "organizationId",
    "transactionTypeId",
    "transactionType",
    "sourceIdentifier"
})
public class TransactionCodeListByType {

    @JsonProperty("transactionCodeId")
    private Integer transactionCodeId;
    @JsonProperty("transactionCodeName")
    private String transactionCodeName;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("transactionTypeId")
    private Integer transactionTypeId;
    @JsonProperty("transactionType")
    private String transactionType;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("transactionCodeId")
    public Integer getTransactionCodeId() {
        return transactionCodeId;
    }

    @JsonProperty("transactionCodeId")
    public void setTransactionCodeId(Integer transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
    }

    public TransactionCodeListByType withTransactionCodeId(Integer transactionCodeId) {
        this.transactionCodeId = transactionCodeId;
        return this;
    }

    @JsonProperty("transactionCodeName")
    public String getTransactionCodeName() {
        return transactionCodeName;
    }

    @JsonProperty("transactionCodeName")
    public void setTransactionCodeName(String transactionCodeName) {
        this.transactionCodeName = transactionCodeName;
    }

    public TransactionCodeListByType withTransactionCodeName(String transactionCodeName) {
        this.transactionCodeName = transactionCodeName;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public TransactionCodeListByType withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("transactionTypeId")
    public Integer getTransactionTypeId() {
        return transactionTypeId;
    }

    @JsonProperty("transactionTypeId")
    public void setTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    public TransactionCodeListByType withTransactionTypeId(Integer transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
        return this;
    }

    @JsonProperty("transactionType")
    public String getTransactionType() {
        return transactionType;
    }

    @JsonProperty("transactionType")
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public TransactionCodeListByType withTransactionType(String transactionType) {
        this.transactionType = transactionType;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public TransactionCodeListByType withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TransactionCodeListByType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(transactionCodeId).append(transactionCodeName).append(organizationId).append(transactionTypeId).append(transactionType).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TransactionCodeListByType) == false) {
            return false;
        }
        TransactionCodeListByType rhs = ((TransactionCodeListByType) other);
        return new EqualsBuilder().append(transactionCodeId, rhs.transactionCodeId).append(transactionCodeName, rhs.transactionCodeName).append(organizationId, rhs.organizationId).append(transactionTypeId, rhs.transactionTypeId).append(transactionType, rhs.transactionType).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
