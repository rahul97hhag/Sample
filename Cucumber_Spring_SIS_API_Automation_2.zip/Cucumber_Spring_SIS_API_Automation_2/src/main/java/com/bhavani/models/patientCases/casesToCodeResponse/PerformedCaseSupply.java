
package com.bhavani.models.patientCases.casesToCodeResponse;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "performedCaseSupplyId",
    "inventoryId",
    "itemNumber",
    "itemDescription",
    "hcpcsCode",
    "amount",
    "ndcNumber",
    "unitOfMeasure",
    "implantProsthesisId",
    "baseUnits",
    "sourceIdentifier"
})
public class PerformedCaseSupply {

    @JsonProperty("performedCaseSupplyId")
    private Integer performedCaseSupplyId;
    @JsonProperty("inventoryId")
    private Object inventoryId;
    @JsonProperty("itemNumber")
    private Object itemNumber;
    @JsonProperty("itemDescription")
    private Object itemDescription;
    @JsonProperty("hcpcsCode")
    private Object hcpcsCode;
    @JsonProperty("amount")
    private Object amount;
    @JsonProperty("ndcNumber")
    private Object ndcNumber;
    @JsonProperty("unitOfMeasure")
    private Object unitOfMeasure;
    @JsonProperty("implantProsthesisId")
    private Object implantProsthesisId;
    @JsonProperty("baseUnits")
    private Object baseUnits;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("performedCaseSupplyId")
    public Integer getPerformedCaseSupplyId() {
        return performedCaseSupplyId;
    }

    @JsonProperty("performedCaseSupplyId")
    public void setPerformedCaseSupplyId(Integer performedCaseSupplyId) {
        this.performedCaseSupplyId = performedCaseSupplyId;
    }

    public PerformedCaseSupply withPerformedCaseSupplyId(Integer performedCaseSupplyId) {
        this.performedCaseSupplyId = performedCaseSupplyId;
        return this;
    }

    @JsonProperty("inventoryId")
    public Object getInventoryId() {
        return inventoryId;
    }

    @JsonProperty("inventoryId")
    public void setInventoryId(Object inventoryId) {
        this.inventoryId = inventoryId;
    }

    public PerformedCaseSupply withInventoryId(Object inventoryId) {
        this.inventoryId = inventoryId;
        return this;
    }

    @JsonProperty("itemNumber")
    public Object getItemNumber() {
        return itemNumber;
    }

    @JsonProperty("itemNumber")
    public void setItemNumber(Object itemNumber) {
        this.itemNumber = itemNumber;
    }

    public PerformedCaseSupply withItemNumber(Object itemNumber) {
        this.itemNumber = itemNumber;
        return this;
    }

    @JsonProperty("itemDescription")
    public Object getItemDescription() {
        return itemDescription;
    }

    @JsonProperty("itemDescription")
    public void setItemDescription(Object itemDescription) {
        this.itemDescription = itemDescription;
    }

    public PerformedCaseSupply withItemDescription(Object itemDescription) {
        this.itemDescription = itemDescription;
        return this;
    }

    @JsonProperty("hcpcsCode")
    public Object getHcpcsCode() {
        return hcpcsCode;
    }

    @JsonProperty("hcpcsCode")
    public void setHcpcsCode(Object hcpcsCode) {
        this.hcpcsCode = hcpcsCode;
    }

    public PerformedCaseSupply withHcpcsCode(Object hcpcsCode) {
        this.hcpcsCode = hcpcsCode;
        return this;
    }

    @JsonProperty("amount")
    public Object getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Object amount) {
        this.amount = amount;
    }

    public PerformedCaseSupply withAmount(Object amount) {
        this.amount = amount;
        return this;
    }

    @JsonProperty("ndcNumber")
    public Object getNdcNumber() {
        return ndcNumber;
    }

    @JsonProperty("ndcNumber")
    public void setNdcNumber(Object ndcNumber) {
        this.ndcNumber = ndcNumber;
    }

    public PerformedCaseSupply withNdcNumber(Object ndcNumber) {
        this.ndcNumber = ndcNumber;
        return this;
    }

    @JsonProperty("unitOfMeasure")
    public Object getUnitOfMeasure() {
        return unitOfMeasure;
    }

    @JsonProperty("unitOfMeasure")
    public void setUnitOfMeasure(Object unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public PerformedCaseSupply withUnitOfMeasure(Object unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
        return this;
    }

    @JsonProperty("implantProsthesisId")
    public Object getImplantProsthesisId() {
        return implantProsthesisId;
    }

    @JsonProperty("implantProsthesisId")
    public void setImplantProsthesisId(Object implantProsthesisId) {
        this.implantProsthesisId = implantProsthesisId;
    }

    public PerformedCaseSupply withImplantProsthesisId(Object implantProsthesisId) {
        this.implantProsthesisId = implantProsthesisId;
        return this;
    }

    @JsonProperty("baseUnits")
    public Object getBaseUnits() {
        return baseUnits;
    }

    @JsonProperty("baseUnits")
    public void setBaseUnits(Object baseUnits) {
        this.baseUnits = baseUnits;
    }

    public PerformedCaseSupply withBaseUnits(Object baseUnits) {
        this.baseUnits = baseUnits;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public PerformedCaseSupply withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PerformedCaseSupply withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(performedCaseSupplyId).append(inventoryId).append(itemNumber).append(itemDescription).append(hcpcsCode).append(amount).append(ndcNumber).append(unitOfMeasure).append(implantProsthesisId).append(baseUnits).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PerformedCaseSupply) == false) {
            return false;
        }
        PerformedCaseSupply rhs = ((PerformedCaseSupply) other);
        return new EqualsBuilder().append(performedCaseSupplyId, rhs.performedCaseSupplyId).append(inventoryId, rhs.inventoryId).append(itemNumber, rhs.itemNumber).append(itemDescription, rhs.itemDescription).append(hcpcsCode, rhs.hcpcsCode).append(amount, rhs.amount).append(ndcNumber, rhs.ndcNumber).append(unitOfMeasure, rhs.unitOfMeasure).append(implantProsthesisId, rhs.implantProsthesisId).append(baseUnits, rhs.baseUnits).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
