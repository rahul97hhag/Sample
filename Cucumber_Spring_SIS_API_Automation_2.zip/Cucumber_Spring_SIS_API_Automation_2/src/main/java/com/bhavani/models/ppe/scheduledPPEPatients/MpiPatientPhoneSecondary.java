
package com.bhavani.models.ppe.scheduledPPEPatients;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "phoneId",
    "patientId",
    "phoneType",
    "primaryContactTf",
    "phoneNumber",
    "phoneExtension",
    "isCellPhoneTf",
    "adtMaintainedFieldArray",
    "sourceIdentifier"
})
public class MpiPatientPhoneSecondary {

    @JsonProperty("phoneId")
    private Integer phoneId;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("phoneType")
    private Object phoneType;
    @JsonProperty("primaryContactTf")
    private Boolean primaryContactTf;
    @JsonProperty("phoneNumber")
    private Object phoneNumber;
    @JsonProperty("phoneExtension")
    private Object phoneExtension;
    @JsonProperty("isCellPhoneTf")
    private Boolean isCellPhoneTf;
    @JsonProperty("adtMaintainedFieldArray")
    private List<Object> adtMaintainedFieldArray = new ArrayList<Object>();
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("phoneId")
    public Integer getPhoneId() {
        return phoneId;
    }

    @JsonProperty("phoneId")
    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public MpiPatientPhoneSecondary withPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public MpiPatientPhoneSecondary withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("phoneType")
    public Object getPhoneType() {
        return phoneType;
    }

    @JsonProperty("phoneType")
    public void setPhoneType(Object phoneType) {
        this.phoneType = phoneType;
    }

    public MpiPatientPhoneSecondary withPhoneType(Object phoneType) {
        this.phoneType = phoneType;
        return this;
    }

    @JsonProperty("primaryContactTf")
    public Boolean getPrimaryContactTf() {
        return primaryContactTf;
    }

    @JsonProperty("primaryContactTf")
    public void setPrimaryContactTf(Boolean primaryContactTf) {
        this.primaryContactTf = primaryContactTf;
    }

    public MpiPatientPhoneSecondary withPrimaryContactTf(Boolean primaryContactTf) {
        this.primaryContactTf = primaryContactTf;
        return this;
    }

    @JsonProperty("phoneNumber")
    public Object getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public MpiPatientPhoneSecondary withPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("phoneExtension")
    public Object getPhoneExtension() {
        return phoneExtension;
    }

    @JsonProperty("phoneExtension")
    public void setPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public MpiPatientPhoneSecondary withPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
        return this;
    }

    @JsonProperty("isCellPhoneTf")
    public Boolean getIsCellPhoneTf() {
        return isCellPhoneTf;
    }

    @JsonProperty("isCellPhoneTf")
    public void setIsCellPhoneTf(Boolean isCellPhoneTf) {
        this.isCellPhoneTf = isCellPhoneTf;
    }

    public MpiPatientPhoneSecondary withIsCellPhoneTf(Boolean isCellPhoneTf) {
        this.isCellPhoneTf = isCellPhoneTf;
        return this;
    }

    @JsonProperty("adtMaintainedFieldArray")
    public List<Object> getAdtMaintainedFieldArray() {
        return adtMaintainedFieldArray;
    }

    @JsonProperty("adtMaintainedFieldArray")
    public void setAdtMaintainedFieldArray(List<Object> adtMaintainedFieldArray) {
        this.adtMaintainedFieldArray = adtMaintainedFieldArray;
    }

    public MpiPatientPhoneSecondary withAdtMaintainedFieldArray(List<Object> adtMaintainedFieldArray) {
        this.adtMaintainedFieldArray = adtMaintainedFieldArray;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public MpiPatientPhoneSecondary withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MpiPatientPhoneSecondary withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(phoneId).append(patientId).append(phoneType).append(primaryContactTf).append(phoneNumber).append(phoneExtension).append(isCellPhoneTf).append(adtMaintainedFieldArray).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MpiPatientPhoneSecondary) == false) {
            return false;
        }
        MpiPatientPhoneSecondary rhs = ((MpiPatientPhoneSecondary) other);
        return new EqualsBuilder().append(phoneId, rhs.phoneId).append(patientId, rhs.patientId).append(phoneType, rhs.phoneType).append(primaryContactTf, rhs.primaryContactTf).append(phoneNumber, rhs.phoneNumber).append(phoneExtension, rhs.phoneExtension).append(isCellPhoneTf, rhs.isCellPhoneTf).append(adtMaintainedFieldArray, rhs.adtMaintainedFieldArray).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
