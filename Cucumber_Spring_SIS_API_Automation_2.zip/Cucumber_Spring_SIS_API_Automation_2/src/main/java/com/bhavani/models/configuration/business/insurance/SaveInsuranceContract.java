
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insuranceContractName",
    "insuranceContractId",
    "effectiveDate",
    "expirationDate",
    "contractType"
})
public class SaveInsuranceContract {

    @JsonProperty("insuranceContractName")
    private String insuranceContractName;
    @JsonProperty("insuranceContractId")
    private Integer insuranceContractId;
    @JsonProperty("effectiveDate")
    private String effectiveDate;
    @JsonProperty("expirationDate")
    private String expirationDate;
    @JsonProperty("contractType")
    private Integer contractType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insuranceContractName")
    public String getInsuranceContractName() {
        return insuranceContractName;
    }

    @JsonProperty("insuranceContractName")
    public void setInsuranceContractName(String insuranceContractName) {
        this.insuranceContractName = insuranceContractName;
    }

    public SaveInsuranceContract withInsuranceContractName(String insuranceContractName) {
        this.insuranceContractName = insuranceContractName;
        return this;
    }

    @JsonProperty("insuranceContractId")
    public Integer getInsuranceContractId() {
        return insuranceContractId;
    }

    @JsonProperty("insuranceContractId")
    public void setInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
    }

    public SaveInsuranceContract withInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
        return this;
    }

    @JsonProperty("effectiveDate")
    public String getEffectiveDate() {
        return effectiveDate;
    }

    @JsonProperty("effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public SaveInsuranceContract withEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    @JsonProperty("expirationDate")
    public String getExpirationDate() {
        return expirationDate;
    }

    @JsonProperty("expirationDate")
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public SaveInsuranceContract withExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
        return this;
    }

    @JsonProperty("contractType")
    public Integer getContractType() {
        return contractType;
    }

    @JsonProperty("contractType")
    public void setContractType(Integer contractType) {
        this.contractType = contractType;
    }

    public SaveInsuranceContract withContractType(Integer contractType) {
        this.contractType = contractType;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SaveInsuranceContract withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insuranceContractName).append(insuranceContractId).append(effectiveDate).append(expirationDate).append(contractType).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaveInsuranceContract) == false) {
            return false;
        }
        SaveInsuranceContract rhs = ((SaveInsuranceContract) other);
        return new EqualsBuilder().append(insuranceContractName, rhs.insuranceContractName).append(insuranceContractId, rhs.insuranceContractId).append(effectiveDate, rhs.effectiveDate).append(expirationDate, rhs.expirationDate).append(contractType, rhs.contractType).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
