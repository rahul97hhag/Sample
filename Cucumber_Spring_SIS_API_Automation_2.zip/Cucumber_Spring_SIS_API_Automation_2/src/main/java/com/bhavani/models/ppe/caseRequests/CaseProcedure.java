
package com.bhavani.models.ppe.caseRequests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "selfPayTf",
    "physicianId",
    "physician",
    "laterality",
    "lateralityText",
    "preOpDiagnosisCodeId",
    "preOpDiagnosisCode",
    "procedureId",
    "procedureDescription",
    "primaryProcedureTf",
    "appointmentId",
    "procedureSequence",
    "preferenceCardId",
    "feeScheduleId",
    "procedureDisplayName",
    "isEditable",
    "workersCompensation",
    "AnesTypeName",
    "casePackName",
    "dummyCPTId",
    "modifiedProcedureDescription",
    "isDisplayTrashIcon",
    "diagnosisList",
    "cptCode",
    "procedure"
})
public class CaseProcedure {

    @JsonProperty("selfPayTf")
    private Object selfPayTf;
    @JsonProperty("physicianId")
    private Integer physicianId;
    @JsonProperty("physician")
    private String physician;
    @JsonProperty("laterality")
    private Object laterality;
    @JsonProperty("lateralityText")
    private Object lateralityText;
    @JsonProperty("preOpDiagnosisCodeId")
    private Object preOpDiagnosisCodeId;
    @JsonProperty("preOpDiagnosisCode")
    private Object preOpDiagnosisCode;
    @JsonProperty("procedureId")
    private Object procedureId;
    @JsonProperty("procedureDescription")
    private String procedureDescription;
    @JsonProperty("primaryProcedureTf")
    private Boolean primaryProcedureTf;
    @JsonProperty("appointmentId")
    private Object appointmentId;
    @JsonProperty("procedureSequence")
    private Object procedureSequence;
    @JsonProperty("preferenceCardId")
    private Object preferenceCardId;
    @JsonProperty("feeScheduleId")
    private Integer feeScheduleId;
    @JsonProperty("procedureDisplayName")
    private String procedureDisplayName;
    @JsonProperty("isEditable")
    private Boolean isEditable;
    @JsonProperty("workersCompensation")
    private Object workersCompensation;
    @JsonProperty("AnesTypeName")
    private Object anesTypeName;
    @JsonProperty("casePackName")
    private Object casePackName;
    @JsonProperty("dummyCPTId")
    private Object dummyCPTId;
    @JsonProperty("modifiedProcedureDescription")
    private String modifiedProcedureDescription;
    @JsonProperty("isDisplayTrashIcon")
    private Boolean isDisplayTrashIcon;
    @JsonProperty("diagnosisList")
    private List<Object> diagnosisList = new ArrayList<Object>();
    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("procedure")
    private String procedure;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("selfPayTf")
    public Object getSelfPayTf() {
        return selfPayTf;
    }

    @JsonProperty("selfPayTf")
    public void setSelfPayTf(Object selfPayTf) {
        this.selfPayTf = selfPayTf;
    }

    public CaseProcedure withSelfPayTf(Object selfPayTf) {
        this.selfPayTf = selfPayTf;
        return this;
    }

    @JsonProperty("physicianId")
    public Integer getPhysicianId() {
        return physicianId;
    }

    @JsonProperty("physicianId")
    public void setPhysicianId(Integer physicianId) {
        this.physicianId = physicianId;
    }

    public CaseProcedure withPhysicianId(Integer physicianId) {
        this.physicianId = physicianId;
        return this;
    }

    @JsonProperty("physician")
    public String getPhysician() {
        return physician;
    }

    @JsonProperty("physician")
    public void setPhysician(String physician) {
        this.physician = physician;
    }

    public CaseProcedure withPhysician(String physician) {
        this.physician = physician;
        return this;
    }

    @JsonProperty("laterality")
    public Object getLaterality() {
        return laterality;
    }

    @JsonProperty("laterality")
    public void setLaterality(Object laterality) {
        this.laterality = laterality;
    }

    public CaseProcedure withLaterality(Object laterality) {
        this.laterality = laterality;
        return this;
    }

    @JsonProperty("lateralityText")
    public Object getLateralityText() {
        return lateralityText;
    }

    @JsonProperty("lateralityText")
    public void setLateralityText(Object lateralityText) {
        this.lateralityText = lateralityText;
    }

    public CaseProcedure withLateralityText(Object lateralityText) {
        this.lateralityText = lateralityText;
        return this;
    }

    @JsonProperty("preOpDiagnosisCodeId")
    public Object getPreOpDiagnosisCodeId() {
        return preOpDiagnosisCodeId;
    }

    @JsonProperty("preOpDiagnosisCodeId")
    public void setPreOpDiagnosisCodeId(Object preOpDiagnosisCodeId) {
        this.preOpDiagnosisCodeId = preOpDiagnosisCodeId;
    }

    public CaseProcedure withPreOpDiagnosisCodeId(Object preOpDiagnosisCodeId) {
        this.preOpDiagnosisCodeId = preOpDiagnosisCodeId;
        return this;
    }

    @JsonProperty("preOpDiagnosisCode")
    public Object getPreOpDiagnosisCode() {
        return preOpDiagnosisCode;
    }

    @JsonProperty("preOpDiagnosisCode")
    public void setPreOpDiagnosisCode(Object preOpDiagnosisCode) {
        this.preOpDiagnosisCode = preOpDiagnosisCode;
    }

    public CaseProcedure withPreOpDiagnosisCode(Object preOpDiagnosisCode) {
        this.preOpDiagnosisCode = preOpDiagnosisCode;
        return this;
    }

    @JsonProperty("procedureId")
    public Object getProcedureId() {
        return procedureId;
    }

    @JsonProperty("procedureId")
    public void setProcedureId(Object procedureId) {
        this.procedureId = procedureId;
    }

    public CaseProcedure withProcedureId(Object procedureId) {
        this.procedureId = procedureId;
        return this;
    }

    @JsonProperty("procedureDescription")
    public String getProcedureDescription() {
        return procedureDescription;
    }

    @JsonProperty("procedureDescription")
    public void setProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
    }

    public CaseProcedure withProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
        return this;
    }

    @JsonProperty("primaryProcedureTf")
    public Boolean getPrimaryProcedureTf() {
        return primaryProcedureTf;
    }

    @JsonProperty("primaryProcedureTf")
    public void setPrimaryProcedureTf(Boolean primaryProcedureTf) {
        this.primaryProcedureTf = primaryProcedureTf;
    }

    public CaseProcedure withPrimaryProcedureTf(Boolean primaryProcedureTf) {
        this.primaryProcedureTf = primaryProcedureTf;
        return this;
    }

    @JsonProperty("appointmentId")
    public Object getAppointmentId() {
        return appointmentId;
    }

    @JsonProperty("appointmentId")
    public void setAppointmentId(Object appointmentId) {
        this.appointmentId = appointmentId;
    }

    public CaseProcedure withAppointmentId(Object appointmentId) {
        this.appointmentId = appointmentId;
        return this;
    }

    @JsonProperty("procedureSequence")
    public Object getProcedureSequence() {
        return procedureSequence;
    }

    @JsonProperty("procedureSequence")
    public void setProcedureSequence(Object procedureSequence) {
        this.procedureSequence = procedureSequence;
    }

    public CaseProcedure withProcedureSequence(Object procedureSequence) {
        this.procedureSequence = procedureSequence;
        return this;
    }

    @JsonProperty("preferenceCardId")
    public Object getPreferenceCardId() {
        return preferenceCardId;
    }

    @JsonProperty("preferenceCardId")
    public void setPreferenceCardId(Object preferenceCardId) {
        this.preferenceCardId = preferenceCardId;
    }

    public CaseProcedure withPreferenceCardId(Object preferenceCardId) {
        this.preferenceCardId = preferenceCardId;
        return this;
    }

    @JsonProperty("feeScheduleId")
    public Integer getFeeScheduleId() {
        return feeScheduleId;
    }

    @JsonProperty("feeScheduleId")
    public void setFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
    }

    public CaseProcedure withFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
        return this;
    }

    @JsonProperty("procedureDisplayName")
    public String getProcedureDisplayName() {
        return procedureDisplayName;
    }

    @JsonProperty("procedureDisplayName")
    public void setProcedureDisplayName(String procedureDisplayName) {
        this.procedureDisplayName = procedureDisplayName;
    }

    public CaseProcedure withProcedureDisplayName(String procedureDisplayName) {
        this.procedureDisplayName = procedureDisplayName;
        return this;
    }

    @JsonProperty("isEditable")
    public Boolean getIsEditable() {
        return isEditable;
    }

    @JsonProperty("isEditable")
    public void setIsEditable(Boolean isEditable) {
        this.isEditable = isEditable;
    }

    public CaseProcedure withIsEditable(Boolean isEditable) {
        this.isEditable = isEditable;
        return this;
    }

    @JsonProperty("workersCompensation")
    public Object getWorkersCompensation() {
        return workersCompensation;
    }

    @JsonProperty("workersCompensation")
    public void setWorkersCompensation(Object workersCompensation) {
        this.workersCompensation = workersCompensation;
    }

    public CaseProcedure withWorkersCompensation(Object workersCompensation) {
        this.workersCompensation = workersCompensation;
        return this;
    }

    @JsonProperty("AnesTypeName")
    public Object getAnesTypeName() {
        return anesTypeName;
    }

    @JsonProperty("AnesTypeName")
    public void setAnesTypeName(Object anesTypeName) {
        this.anesTypeName = anesTypeName;
    }

    public CaseProcedure withAnesTypeName(Object anesTypeName) {
        this.anesTypeName = anesTypeName;
        return this;
    }

    @JsonProperty("casePackName")
    public Object getCasePackName() {
        return casePackName;
    }

    @JsonProperty("casePackName")
    public void setCasePackName(Object casePackName) {
        this.casePackName = casePackName;
    }

    public CaseProcedure withCasePackName(Object casePackName) {
        this.casePackName = casePackName;
        return this;
    }

    @JsonProperty("dummyCPTId")
    public Object getDummyCPTId() {
        return dummyCPTId;
    }

    @JsonProperty("dummyCPTId")
    public void setDummyCPTId(Object dummyCPTId) {
        this.dummyCPTId = dummyCPTId;
    }

    public CaseProcedure withDummyCPTId(Object dummyCPTId) {
        this.dummyCPTId = dummyCPTId;
        return this;
    }

    @JsonProperty("modifiedProcedureDescription")
    public String getModifiedProcedureDescription() {
        return modifiedProcedureDescription;
    }

    @JsonProperty("modifiedProcedureDescription")
    public void setModifiedProcedureDescription(String modifiedProcedureDescription) {
        this.modifiedProcedureDescription = modifiedProcedureDescription;
    }

    public CaseProcedure withModifiedProcedureDescription(String modifiedProcedureDescription) {
        this.modifiedProcedureDescription = modifiedProcedureDescription;
        return this;
    }

    @JsonProperty("isDisplayTrashIcon")
    public Boolean getIsDisplayTrashIcon() {
        return isDisplayTrashIcon;
    }

    @JsonProperty("isDisplayTrashIcon")
    public void setIsDisplayTrashIcon(Boolean isDisplayTrashIcon) {
        this.isDisplayTrashIcon = isDisplayTrashIcon;
    }

    public CaseProcedure withIsDisplayTrashIcon(Boolean isDisplayTrashIcon) {
        this.isDisplayTrashIcon = isDisplayTrashIcon;
        return this;
    }

    @JsonProperty("diagnosisList")
    public List<Object> getDiagnosisList() {
        return diagnosisList;
    }

    @JsonProperty("diagnosisList")
    public void setDiagnosisList(List<Object> diagnosisList) {
        this.diagnosisList = diagnosisList;
    }

    public CaseProcedure withDiagnosisList(List<Object> diagnosisList) {
        this.diagnosisList = diagnosisList;
        return this;
    }

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public CaseProcedure withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("procedure")
    public String getProcedure() {
        return procedure;
    }

    @JsonProperty("procedure")
    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public CaseProcedure withProcedure(String procedure) {
        this.procedure = procedure;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseProcedure withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(selfPayTf).append(physicianId).append(physician).append(laterality).append(lateralityText).append(preOpDiagnosisCodeId).append(preOpDiagnosisCode).append(procedureId).append(procedureDescription).append(primaryProcedureTf).append(appointmentId).append(procedureSequence).append(preferenceCardId).append(feeScheduleId).append(procedureDisplayName).append(isEditable).append(workersCompensation).append(anesTypeName).append(casePackName).append(dummyCPTId).append(modifiedProcedureDescription).append(isDisplayTrashIcon).append(diagnosisList).append(cptCode).append(procedure).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseProcedure) == false) {
            return false;
        }
        CaseProcedure rhs = ((CaseProcedure) other);
        return new EqualsBuilder().append(selfPayTf, rhs.selfPayTf).append(physicianId, rhs.physicianId).append(physician, rhs.physician).append(laterality, rhs.laterality).append(lateralityText, rhs.lateralityText).append(preOpDiagnosisCodeId, rhs.preOpDiagnosisCodeId).append(preOpDiagnosisCode, rhs.preOpDiagnosisCode).append(procedureId, rhs.procedureId).append(procedureDescription, rhs.procedureDescription).append(primaryProcedureTf, rhs.primaryProcedureTf).append(appointmentId, rhs.appointmentId).append(procedureSequence, rhs.procedureSequence).append(preferenceCardId, rhs.preferenceCardId).append(feeScheduleId, rhs.feeScheduleId).append(procedureDisplayName, rhs.procedureDisplayName).append(isEditable, rhs.isEditable).append(workersCompensation, rhs.workersCompensation).append(anesTypeName, rhs.anesTypeName).append(casePackName, rhs.casePackName).append(dummyCPTId, rhs.dummyCPTId).append(modifiedProcedureDescription, rhs.modifiedProcedureDescription).append(isDisplayTrashIcon, rhs.isDisplayTrashIcon).append(diagnosisList, rhs.diagnosisList).append(cptCode, rhs.cptCode).append(procedure, rhs.procedure).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
