
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "defaultPlanTf",
    "isInsurancePlanValid",
    "claimOfficeId",
    "previousPhoneValue",
    "planName",
    "primaryEmcPayerid",
    "generateClaimTf",
    "classification"
})
public class InsurancePlanSaveDetails {

    @JsonProperty("defaultPlanTf")
    private Boolean defaultPlanTf;
    @JsonProperty("isInsurancePlanValid")
    private Boolean isInsurancePlanValid;
    @JsonProperty("claimOfficeId")
    private Object claimOfficeId;
    @JsonProperty("previousPhoneValue")
    private String previousPhoneValue;
    @JsonProperty("planName")
    private String planName;
    @JsonProperty("primaryEmcPayerid")
    private String primaryEmcPayerid;
    @JsonProperty("generateClaimTf")
    private Boolean generateClaimTf;
    @JsonProperty("classification")
    private String classification;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("defaultPlanTf")
    public Boolean getDefaultPlanTf() {
        return defaultPlanTf;
    }

    @JsonProperty("defaultPlanTf")
    public void setDefaultPlanTf(Boolean defaultPlanTf) {
        this.defaultPlanTf = defaultPlanTf;
    }

    public InsurancePlanSaveDetails withDefaultPlanTf(Boolean defaultPlanTf) {
        this.defaultPlanTf = defaultPlanTf;
        return this;
    }

    @JsonProperty("isInsurancePlanValid")
    public Boolean getIsInsurancePlanValid() {
        return isInsurancePlanValid;
    }

    @JsonProperty("isInsurancePlanValid")
    public void setIsInsurancePlanValid(Boolean isInsurancePlanValid) {
        this.isInsurancePlanValid = isInsurancePlanValid;
    }

    public InsurancePlanSaveDetails withIsInsurancePlanValid(Boolean isInsurancePlanValid) {
        this.isInsurancePlanValid = isInsurancePlanValid;
        return this;
    }

    @JsonProperty("claimOfficeId")
    public Object getClaimOfficeId() {
        return claimOfficeId;
    }

    @JsonProperty("claimOfficeId")
    public void setClaimOfficeId(Object claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
    }

    public InsurancePlanSaveDetails withClaimOfficeId(Object claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
        return this;
    }

    @JsonProperty("previousPhoneValue")
    public String getPreviousPhoneValue() {
        return previousPhoneValue;
    }

    @JsonProperty("previousPhoneValue")
    public void setPreviousPhoneValue(String previousPhoneValue) {
        this.previousPhoneValue = previousPhoneValue;
    }

    public InsurancePlanSaveDetails withPreviousPhoneValue(String previousPhoneValue) {
        this.previousPhoneValue = previousPhoneValue;
        return this;
    }

    @JsonProperty("planName")
    public String getPlanName() {
        return planName;
    }

    @JsonProperty("planName")
    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public InsurancePlanSaveDetails withPlanName(String planName) {
        this.planName = planName;
        return this;
    }

    @JsonProperty("primaryEmcPayerid")
    public String getPrimaryEmcPayerid() {
        return primaryEmcPayerid;
    }

    @JsonProperty("primaryEmcPayerid")
    public void setPrimaryEmcPayerid(String primaryEmcPayerid) {
        this.primaryEmcPayerid = primaryEmcPayerid;
    }

    public InsurancePlanSaveDetails withPrimaryEmcPayerid(String primaryEmcPayerid) {
        this.primaryEmcPayerid = primaryEmcPayerid;
        return this;
    }

    @JsonProperty("generateClaimTf")
    public Boolean getGenerateClaimTf() {
        return generateClaimTf;
    }

    @JsonProperty("generateClaimTf")
    public void setGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
    }

    public InsurancePlanSaveDetails withGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
        return this;
    }

    @JsonProperty("classification")
    public String getClassification() {
        return classification;
    }

    @JsonProperty("classification")
    public void setClassification(String classification) {
        this.classification = classification;
    }

    public InsurancePlanSaveDetails withClassification(String classification) {
        this.classification = classification;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsurancePlanSaveDetails withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(defaultPlanTf).append(isInsurancePlanValid).append(claimOfficeId).append(previousPhoneValue).append(planName).append(primaryEmcPayerid).append(generateClaimTf).append(classification).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsurancePlanSaveDetails) == false) {
            return false;
        }
        InsurancePlanSaveDetails rhs = ((InsurancePlanSaveDetails) other);
        return new EqualsBuilder().append(defaultPlanTf, rhs.defaultPlanTf).append(isInsurancePlanValid, rhs.isInsurancePlanValid).append(claimOfficeId, rhs.claimOfficeId).append(previousPhoneValue, rhs.previousPhoneValue).append(planName, rhs.planName).append(primaryEmcPayerid, rhs.primaryEmcPayerid).append(generateClaimTf, rhs.generateClaimTf).append(classification, rhs.classification).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
