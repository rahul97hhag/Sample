
package com.bhavani.models.configuration.business.dictionaries;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dictionaryId",
    "patientCategory",
    "quickcode",
    "categoryValue",
    "activeFlagTf",
    "systemDictionary",
    "enterpriseLevel",
    "businessLevel",
    "organizationId",
    "aoDictionaryTf",
    "showInClinicalTf",
    "isAlphabeticalOrder",
    "searchString",
    "pageNumber",
    "dict_Ctrl_Type",
    "isAdded",
    "isUpdated",
    "itemId",
    "itemType",
    "itemName",
    "sourceIdentifier"
})
public class PatientRelatedDictionaries {

    @JsonProperty("dictionaryId")
    private Integer dictionaryId;
    @JsonProperty("patientCategory")
    private String patientCategory;
    @JsonProperty("quickcode")
    private Object quickcode;
    @JsonProperty("categoryValue")
    private String categoryValue;
    @JsonProperty("activeFlagTf")
    private Boolean activeFlagTf;
    @JsonProperty("systemDictionary")
    private Boolean systemDictionary;
    @JsonProperty("enterpriseLevel")
    private Boolean enterpriseLevel;
    @JsonProperty("businessLevel")
    private Object businessLevel;
    @JsonProperty("organizationId")
    private Object organizationId;
    @JsonProperty("aoDictionaryTf")
    private Boolean aoDictionaryTf;
    @JsonProperty("showInClinicalTf")
    private Boolean showInClinicalTf;
    @JsonProperty("isAlphabeticalOrder")
    private Boolean isAlphabeticalOrder;
    @JsonProperty("searchString")
    private Object searchString;
    @JsonProperty("pageNumber")
    private Integer pageNumber;
    @JsonProperty("dict_Ctrl_Type")
    private Object dictCtrlType;
    @JsonProperty("isAdded")
    private Boolean isAdded;
    @JsonProperty("isUpdated")
    private Boolean isUpdated;
    @JsonProperty("itemId")
    private Integer itemId;
    @JsonProperty("itemType")
    private String itemType;
    @JsonProperty("itemName")
    private String itemName;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dictionaryId")
    public Integer getDictionaryId() {
        return dictionaryId;
    }

    @JsonProperty("dictionaryId")
    public void setDictionaryId(Integer dictionaryId) {
        this.dictionaryId = dictionaryId;
    }

    public PatientRelatedDictionaries withDictionaryId(Integer dictionaryId) {
        this.dictionaryId = dictionaryId;
        return this;
    }

    @JsonProperty("patientCategory")
    public String getPatientCategory() {
        return patientCategory;
    }

    @JsonProperty("patientCategory")
    public void setPatientCategory(String patientCategory) {
        this.patientCategory = patientCategory;
    }

    public PatientRelatedDictionaries withPatientCategory(String patientCategory) {
        this.patientCategory = patientCategory;
        return this;
    }

    @JsonProperty("quickcode")
    public Object getQuickcode() {
        return quickcode;
    }

    @JsonProperty("quickcode")
    public void setQuickcode(Object quickcode) {
        this.quickcode = quickcode;
    }

    public PatientRelatedDictionaries withQuickcode(Object quickcode) {
        this.quickcode = quickcode;
        return this;
    }

    @JsonProperty("categoryValue")
    public String getCategoryValue() {
        return categoryValue;
    }

    @JsonProperty("categoryValue")
    public void setCategoryValue(String categoryValue) {
        this.categoryValue = categoryValue;
    }

    public PatientRelatedDictionaries withCategoryValue(String categoryValue) {
        this.categoryValue = categoryValue;
        return this;
    }

    @JsonProperty("activeFlagTf")
    public Boolean getActiveFlagTf() {
        return activeFlagTf;
    }

    @JsonProperty("activeFlagTf")
    public void setActiveFlagTf(Boolean activeFlagTf) {
        this.activeFlagTf = activeFlagTf;
    }

    public PatientRelatedDictionaries withActiveFlagTf(Boolean activeFlagTf) {
        this.activeFlagTf = activeFlagTf;
        return this;
    }

    @JsonProperty("systemDictionary")
    public Boolean getSystemDictionary() {
        return systemDictionary;
    }

    @JsonProperty("systemDictionary")
    public void setSystemDictionary(Boolean systemDictionary) {
        this.systemDictionary = systemDictionary;
    }

    public PatientRelatedDictionaries withSystemDictionary(Boolean systemDictionary) {
        this.systemDictionary = systemDictionary;
        return this;
    }

    @JsonProperty("enterpriseLevel")
    public Boolean getEnterpriseLevel() {
        return enterpriseLevel;
    }

    @JsonProperty("enterpriseLevel")
    public void setEnterpriseLevel(Boolean enterpriseLevel) {
        this.enterpriseLevel = enterpriseLevel;
    }

    public PatientRelatedDictionaries withEnterpriseLevel(Boolean enterpriseLevel) {
        this.enterpriseLevel = enterpriseLevel;
        return this;
    }

    @JsonProperty("businessLevel")
    public Object getBusinessLevel() {
        return businessLevel;
    }

    @JsonProperty("businessLevel")
    public void setBusinessLevel(Object businessLevel) {
        this.businessLevel = businessLevel;
    }

    public PatientRelatedDictionaries withBusinessLevel(Object businessLevel) {
        this.businessLevel = businessLevel;
        return this;
    }

    @JsonProperty("organizationId")
    public Object getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Object organizationId) {
        this.organizationId = organizationId;
    }

    public PatientRelatedDictionaries withOrganizationId(Object organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("aoDictionaryTf")
    public Boolean getAoDictionaryTf() {
        return aoDictionaryTf;
    }

    @JsonProperty("aoDictionaryTf")
    public void setAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
    }

    public PatientRelatedDictionaries withAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
        return this;
    }

    @JsonProperty("showInClinicalTf")
    public Boolean getShowInClinicalTf() {
        return showInClinicalTf;
    }

    @JsonProperty("showInClinicalTf")
    public void setShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
    }

    public PatientRelatedDictionaries withShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
        return this;
    }

    @JsonProperty("isAlphabeticalOrder")
    public Boolean getIsAlphabeticalOrder() {
        return isAlphabeticalOrder;
    }

    @JsonProperty("isAlphabeticalOrder")
    public void setIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
    }

    public PatientRelatedDictionaries withIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
        return this;
    }

    @JsonProperty("searchString")
    public Object getSearchString() {
        return searchString;
    }

    @JsonProperty("searchString")
    public void setSearchString(Object searchString) {
        this.searchString = searchString;
    }

    public PatientRelatedDictionaries withSearchString(Object searchString) {
        this.searchString = searchString;
        return this;
    }

    @JsonProperty("pageNumber")
    public Integer getPageNumber() {
        return pageNumber;
    }

    @JsonProperty("pageNumber")
    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public PatientRelatedDictionaries withPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }

    @JsonProperty("dict_Ctrl_Type")
    public Object getDictCtrlType() {
        return dictCtrlType;
    }

    @JsonProperty("dict_Ctrl_Type")
    public void setDictCtrlType(Object dictCtrlType) {
        this.dictCtrlType = dictCtrlType;
    }

    public PatientRelatedDictionaries withDictCtrlType(Object dictCtrlType) {
        this.dictCtrlType = dictCtrlType;
        return this;
    }

    @JsonProperty("isAdded")
    public Boolean getIsAdded() {
        return isAdded;
    }

    @JsonProperty("isAdded")
    public void setIsAdded(Boolean isAdded) {
        this.isAdded = isAdded;
    }

    public PatientRelatedDictionaries withIsAdded(Boolean isAdded) {
        this.isAdded = isAdded;
        return this;
    }

    @JsonProperty("isUpdated")
    public Boolean getIsUpdated() {
        return isUpdated;
    }

    @JsonProperty("isUpdated")
    public void setIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
    }

    public PatientRelatedDictionaries withIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
        return this;
    }

    @JsonProperty("itemId")
    public Integer getItemId() {
        return itemId;
    }

    @JsonProperty("itemId")
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public PatientRelatedDictionaries withItemId(Integer itemId) {
        this.itemId = itemId;
        return this;
    }

    @JsonProperty("itemType")
    public String getItemType() {
        return itemType;
    }

    @JsonProperty("itemType")
    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public PatientRelatedDictionaries withItemType(String itemType) {
        this.itemType = itemType;
        return this;
    }

    @JsonProperty("itemName")
    public String getItemName() {
        return itemName;
    }

    @JsonProperty("itemName")
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public PatientRelatedDictionaries withItemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public PatientRelatedDictionaries withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PatientRelatedDictionaries withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dictionaryId).append(patientCategory).append(quickcode).append(categoryValue).append(activeFlagTf).append(systemDictionary).append(enterpriseLevel).append(businessLevel).append(organizationId).append(aoDictionaryTf).append(showInClinicalTf).append(isAlphabeticalOrder).append(searchString).append(pageNumber).append(dictCtrlType).append(isAdded).append(isUpdated).append(itemId).append(itemType).append(itemName).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PatientRelatedDictionaries) == false) {
            return false;
        }
        PatientRelatedDictionaries rhs = ((PatientRelatedDictionaries) other);
        return new EqualsBuilder().append(dictionaryId, rhs.dictionaryId).append(patientCategory, rhs.patientCategory).append(quickcode, rhs.quickcode).append(categoryValue, rhs.categoryValue).append(activeFlagTf, rhs.activeFlagTf).append(systemDictionary, rhs.systemDictionary).append(enterpriseLevel, rhs.enterpriseLevel).append(businessLevel, rhs.businessLevel).append(organizationId, rhs.organizationId).append(aoDictionaryTf, rhs.aoDictionaryTf).append(showInClinicalTf, rhs.showInClinicalTf).append(isAlphabeticalOrder, rhs.isAlphabeticalOrder).append(searchString, rhs.searchString).append(pageNumber, rhs.pageNumber).append(dictCtrlType, rhs.dictCtrlType).append(isAdded, rhs.isAdded).append(isUpdated, rhs.isUpdated).append(itemId, rhs.itemId).append(itemType, rhs.itemType).append(itemName, rhs.itemName).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
