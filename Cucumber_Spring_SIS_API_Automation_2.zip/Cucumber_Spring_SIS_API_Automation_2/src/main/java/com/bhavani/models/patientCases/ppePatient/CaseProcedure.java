
package com.bhavani.models.patientCases.ppePatient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cptCode",
    "selfPayTf",
    "physicianNPI",
    "lateralityText",
    "modifiedProcedureDescription",
    "diagnosisList"
})
public class CaseProcedure {

    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("selfPayTf")
    private Boolean selfPayTf;
    @JsonProperty("physicianNPI")
    private String physicianNPI;
    @JsonProperty("lateralityText")
    private String lateralityText;
    @JsonProperty("modifiedProcedureDescription")
    private String modifiedProcedureDescription;
    @JsonProperty("diagnosisList")
    private List<DiagnosisList> diagnosisList = new ArrayList<DiagnosisList>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public CaseProcedure withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("selfPayTf")
    public Boolean getSelfPayTf() {
        return selfPayTf;
    }

    @JsonProperty("selfPayTf")
    public void setSelfPayTf(Boolean selfPayTf) {
        this.selfPayTf = selfPayTf;
    }

    public CaseProcedure withSelfPayTf(Boolean selfPayTf) {
        this.selfPayTf = selfPayTf;
        return this;
    }

    @JsonProperty("physicianNPI")
    public String getPhysicianNPI() {
        return physicianNPI;
    }

    @JsonProperty("physicianNPI")
    public void setPhysicianNPI(String physicianNPI) {
        this.physicianNPI = physicianNPI;
    }

    public CaseProcedure withPhysicianNPI(String physicianNPI) {
        this.physicianNPI = physicianNPI;
        return this;
    }

    @JsonProperty("lateralityText")
    public String getLateralityText() {
        return lateralityText;
    }

    @JsonProperty("lateralityText")
    public void setLateralityText(String lateralityText) {
        this.lateralityText = lateralityText;
    }

    public CaseProcedure withLateralityText(String lateralityText) {
        this.lateralityText = lateralityText;
        return this;
    }

    @JsonProperty("modifiedProcedureDescription")
    public String getModifiedProcedureDescription() {
        return modifiedProcedureDescription;
    }

    @JsonProperty("modifiedProcedureDescription")
    public void setModifiedProcedureDescription(String modifiedProcedureDescription) {
        this.modifiedProcedureDescription = modifiedProcedureDescription;
    }

    public CaseProcedure withModifiedProcedureDescription(String modifiedProcedureDescription) {
        this.modifiedProcedureDescription = modifiedProcedureDescription;
        return this;
    }

    @JsonProperty("diagnosisList")
    public List<DiagnosisList> getDiagnosisList() {
        return diagnosisList;
    }

    @JsonProperty("diagnosisList")
    public void setDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
    }

    public CaseProcedure withDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseProcedure withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cptCode).append(selfPayTf).append(physicianNPI).append(lateralityText).append(modifiedProcedureDescription).append(diagnosisList).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseProcedure) == false) {
            return false;
        }
        CaseProcedure rhs = ((CaseProcedure) other);
        return new EqualsBuilder().append(cptCode, rhs.cptCode).append(selfPayTf, rhs.selfPayTf).append(physicianNPI, rhs.physicianNPI).append(lateralityText, rhs.lateralityText).append(modifiedProcedureDescription, rhs.modifiedProcedureDescription).append(diagnosisList, rhs.diagnosisList).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
