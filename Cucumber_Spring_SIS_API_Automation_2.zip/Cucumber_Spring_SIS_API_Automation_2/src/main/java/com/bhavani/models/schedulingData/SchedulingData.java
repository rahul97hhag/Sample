
package com.bhavani.models.schedulingData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caseSummaryID",
    "startTime",
    "endTime",
    "arrivalTime",
    "dischargeTime",
    "scheduledRoom",
    "patient",
    "primarySurgeon",
    "anesthesiaType",
    "primaryProcedure",
    "secondaryProcedures",
    "currentRoom",
    "currentModule",
    "appointmentNote",
    "caseLastUpdated",
    "caseStatus",
    "appointmentId",
    "casePackId",
    "anesthesiaDate",
    "startDate",
    "isActiveCase",
    "appointmentTypeId",
    "primaryProcedureId",
    "organizationId",
    "anesTypeId",
    "cleanupTime",
    "referringPhysicianId",
    "procedureDt",
    "signatureId",
    "signatureDt",
    "externalId",
    "acuteChronicTf",
    "note",
    "cancelCaseReason",
    "cancelDate",
    "caseProcedurePhysName",
    "caseProcedurePhysicians",
    "scheduledCaseCounts",
    "checkedInTime",
    "depositAmount",
    "rescheduleCounter",
    "caseColor",
    "secondaryPhysicianNames",
    "created",
    "caseType",
    "isCaseOrdersEnabled",
    "isCaseBlockNotesEnabled"
})
public class SchedulingData {

    @JsonProperty("caseSummaryID")
    private Integer caseSummaryID;
    @JsonProperty("startTime")
    private String startTime;
    @JsonProperty("endTime")
    private String endTime;
    @JsonProperty("arrivalTime")
    private Object arrivalTime;
    @JsonProperty("dischargeTime")
    private Object dischargeTime;
    @JsonProperty("scheduledRoom")
    private ScheduledRoom scheduledRoom;
    @JsonProperty("patient")
    private Patient patient;
    @JsonProperty("primarySurgeon")
    private PrimarySurgeon primarySurgeon;
    @JsonProperty("anesthesiaType")
    private Object anesthesiaType;
    @JsonProperty("primaryProcedure")
    private String primaryProcedure;
    @JsonProperty("secondaryProcedures")
    private String secondaryProcedures;
    @JsonProperty("currentRoom")
    private Object currentRoom;
    @JsonProperty("currentModule")
    private Object currentModule;
    @JsonProperty("appointmentNote")
    private Object appointmentNote;
    @JsonProperty("caseLastUpdated")
    private String caseLastUpdated;
    @JsonProperty("caseStatus")
    private String caseStatus;
    @JsonProperty("appointmentId")
    private Integer appointmentId;
    @JsonProperty("casePackId")
    private Integer casePackId;
    @JsonProperty("anesthesiaDate")
    private Object anesthesiaDate;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("isActiveCase")
    private Boolean isActiveCase;
    @JsonProperty("appointmentTypeId")
    private Integer appointmentTypeId;
    @JsonProperty("primaryProcedureId")
    private Integer primaryProcedureId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("anesTypeId")
    private Object anesTypeId;
    @JsonProperty("cleanupTime")
    private Object cleanupTime;
    @JsonProperty("referringPhysicianId")
    private Object referringPhysicianId;
    @JsonProperty("procedureDt")
    private String procedureDt;
    @JsonProperty("signatureId")
    private Object signatureId;
    @JsonProperty("signatureDt")
    private Object signatureDt;
    @JsonProperty("externalId")
    private Integer externalId;
    @JsonProperty("acuteChronicTf")
    private Boolean acuteChronicTf;
    @JsonProperty("note")
    private Object note;
    @JsonProperty("cancelCaseReason")
    private Object cancelCaseReason;
    @JsonProperty("cancelDate")
    private Object cancelDate;
    @JsonProperty("caseProcedurePhysName")
    private String caseProcedurePhysName;
    @JsonProperty("caseProcedurePhysicians")
    private List<Integer> caseProcedurePhysicians = new ArrayList<Integer>();
    @JsonProperty("scheduledCaseCounts")
    private ScheduledCaseCounts scheduledCaseCounts;
    @JsonProperty("checkedInTime")
    private Object checkedInTime;
    @JsonProperty("depositAmount")
    private Object depositAmount;
    @JsonProperty("rescheduleCounter")
    private Integer rescheduleCounter;
    @JsonProperty("caseColor")
    private Object caseColor;
    @JsonProperty("secondaryPhysicianNames")
    private String secondaryPhysicianNames;
    @JsonProperty("created")
    private String created;
    @JsonProperty("caseType")
    private Integer caseType;
    @JsonProperty("isCaseOrdersEnabled")
    private Boolean isCaseOrdersEnabled;
    @JsonProperty("isCaseBlockNotesEnabled")
    private Boolean isCaseBlockNotesEnabled;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("caseSummaryID")
    public Integer getCaseSummaryID() {
        return caseSummaryID;
    }

    @JsonProperty("caseSummaryID")
    public void setCaseSummaryID(Integer caseSummaryID) {
        this.caseSummaryID = caseSummaryID;
    }

    public SchedulingData withCaseSummaryID(Integer caseSummaryID) {
        this.caseSummaryID = caseSummaryID;
        return this;
    }

    @JsonProperty("startTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("startTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public SchedulingData withStartTime(String startTime) {
        this.startTime = startTime;
        return this;
    }

    @JsonProperty("endTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("endTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public SchedulingData withEndTime(String endTime) {
        this.endTime = endTime;
        return this;
    }

    @JsonProperty("arrivalTime")
    public Object getArrivalTime() {
        return arrivalTime;
    }

    @JsonProperty("arrivalTime")
    public void setArrivalTime(Object arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public SchedulingData withArrivalTime(Object arrivalTime) {
        this.arrivalTime = arrivalTime;
        return this;
    }

    @JsonProperty("dischargeTime")
    public Object getDischargeTime() {
        return dischargeTime;
    }

    @JsonProperty("dischargeTime")
    public void setDischargeTime(Object dischargeTime) {
        this.dischargeTime = dischargeTime;
    }

    public SchedulingData withDischargeTime(Object dischargeTime) {
        this.dischargeTime = dischargeTime;
        return this;
    }

    @JsonProperty("scheduledRoom")
    public ScheduledRoom getScheduledRoom() {
        return scheduledRoom;
    }

    @JsonProperty("scheduledRoom")
    public void setScheduledRoom(ScheduledRoom scheduledRoom) {
        this.scheduledRoom = scheduledRoom;
    }

    public SchedulingData withScheduledRoom(ScheduledRoom scheduledRoom) {
        this.scheduledRoom = scheduledRoom;
        return this;
    }

    @JsonProperty("patient")
    public Patient getPatient() {
        return patient;
    }

    @JsonProperty("patient")
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public SchedulingData withPatient(Patient patient) {
        this.patient = patient;
        return this;
    }

    @JsonProperty("primarySurgeon")
    public PrimarySurgeon getPrimarySurgeon() {
        return primarySurgeon;
    }

    @JsonProperty("primarySurgeon")
    public void setPrimarySurgeon(PrimarySurgeon primarySurgeon) {
        this.primarySurgeon = primarySurgeon;
    }

    public SchedulingData withPrimarySurgeon(PrimarySurgeon primarySurgeon) {
        this.primarySurgeon = primarySurgeon;
        return this;
    }

    @JsonProperty("anesthesiaType")
    public Object getAnesthesiaType() {
        return anesthesiaType;
    }

    @JsonProperty("anesthesiaType")
    public void setAnesthesiaType(Object anesthesiaType) {
        this.anesthesiaType = anesthesiaType;
    }

    public SchedulingData withAnesthesiaType(Object anesthesiaType) {
        this.anesthesiaType = anesthesiaType;
        return this;
    }

    @JsonProperty("primaryProcedure")
    public String getPrimaryProcedure() {
        return primaryProcedure;
    }

    @JsonProperty("primaryProcedure")
    public void setPrimaryProcedure(String primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
    }

    public SchedulingData withPrimaryProcedure(String primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
        return this;
    }

    @JsonProperty("secondaryProcedures")
    public String getSecondaryProcedures() {
        return secondaryProcedures;
    }

    @JsonProperty("secondaryProcedures")
    public void setSecondaryProcedures(String secondaryProcedures) {
        this.secondaryProcedures = secondaryProcedures;
    }

    public SchedulingData withSecondaryProcedures(String secondaryProcedures) {
        this.secondaryProcedures = secondaryProcedures;
        return this;
    }

    @JsonProperty("currentRoom")
    public Object getCurrentRoom() {
        return currentRoom;
    }

    @JsonProperty("currentRoom")
    public void setCurrentRoom(Object currentRoom) {
        this.currentRoom = currentRoom;
    }

    public SchedulingData withCurrentRoom(Object currentRoom) {
        this.currentRoom = currentRoom;
        return this;
    }

    @JsonProperty("currentModule")
    public Object getCurrentModule() {
        return currentModule;
    }

    @JsonProperty("currentModule")
    public void setCurrentModule(Object currentModule) {
        this.currentModule = currentModule;
    }

    public SchedulingData withCurrentModule(Object currentModule) {
        this.currentModule = currentModule;
        return this;
    }

    @JsonProperty("appointmentNote")
    public Object getAppointmentNote() {
        return appointmentNote;
    }

    @JsonProperty("appointmentNote")
    public void setAppointmentNote(Object appointmentNote) {
        this.appointmentNote = appointmentNote;
    }

    public SchedulingData withAppointmentNote(Object appointmentNote) {
        this.appointmentNote = appointmentNote;
        return this;
    }

    @JsonProperty("caseLastUpdated")
    public String getCaseLastUpdated() {
        return caseLastUpdated;
    }

    @JsonProperty("caseLastUpdated")
    public void setCaseLastUpdated(String caseLastUpdated) {
        this.caseLastUpdated = caseLastUpdated;
    }

    public SchedulingData withCaseLastUpdated(String caseLastUpdated) {
        this.caseLastUpdated = caseLastUpdated;
        return this;
    }

    @JsonProperty("caseStatus")
    public String getCaseStatus() {
        return caseStatus;
    }

    @JsonProperty("caseStatus")
    public void setCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
    }

    public SchedulingData withCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
        return this;
    }

    @JsonProperty("appointmentId")
    public Integer getAppointmentId() {
        return appointmentId;
    }

    @JsonProperty("appointmentId")
    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public SchedulingData withAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
        return this;
    }

    @JsonProperty("casePackId")
    public Integer getCasePackId() {
        return casePackId;
    }

    @JsonProperty("casePackId")
    public void setCasePackId(Integer casePackId) {
        this.casePackId = casePackId;
    }

    public SchedulingData withCasePackId(Integer casePackId) {
        this.casePackId = casePackId;
        return this;
    }

    @JsonProperty("anesthesiaDate")
    public Object getAnesthesiaDate() {
        return anesthesiaDate;
    }

    @JsonProperty("anesthesiaDate")
    public void setAnesthesiaDate(Object anesthesiaDate) {
        this.anesthesiaDate = anesthesiaDate;
    }

    public SchedulingData withAnesthesiaDate(Object anesthesiaDate) {
        this.anesthesiaDate = anesthesiaDate;
        return this;
    }

    @JsonProperty("startDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public SchedulingData withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("isActiveCase")
    public Boolean getIsActiveCase() {
        return isActiveCase;
    }

    @JsonProperty("isActiveCase")
    public void setIsActiveCase(Boolean isActiveCase) {
        this.isActiveCase = isActiveCase;
    }

    public SchedulingData withIsActiveCase(Boolean isActiveCase) {
        this.isActiveCase = isActiveCase;
        return this;
    }

    @JsonProperty("appointmentTypeId")
    public Integer getAppointmentTypeId() {
        return appointmentTypeId;
    }

    @JsonProperty("appointmentTypeId")
    public void setAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
    }

    public SchedulingData withAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
        return this;
    }

    @JsonProperty("primaryProcedureId")
    public Integer getPrimaryProcedureId() {
        return primaryProcedureId;
    }

    @JsonProperty("primaryProcedureId")
    public void setPrimaryProcedureId(Integer primaryProcedureId) {
        this.primaryProcedureId = primaryProcedureId;
    }

    public SchedulingData withPrimaryProcedureId(Integer primaryProcedureId) {
        this.primaryProcedureId = primaryProcedureId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public SchedulingData withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("anesTypeId")
    public Object getAnesTypeId() {
        return anesTypeId;
    }

    @JsonProperty("anesTypeId")
    public void setAnesTypeId(Object anesTypeId) {
        this.anesTypeId = anesTypeId;
    }

    public SchedulingData withAnesTypeId(Object anesTypeId) {
        this.anesTypeId = anesTypeId;
        return this;
    }

    @JsonProperty("cleanupTime")
    public Object getCleanupTime() {
        return cleanupTime;
    }

    @JsonProperty("cleanupTime")
    public void setCleanupTime(Object cleanupTime) {
        this.cleanupTime = cleanupTime;
    }

    public SchedulingData withCleanupTime(Object cleanupTime) {
        this.cleanupTime = cleanupTime;
        return this;
    }

    @JsonProperty("referringPhysicianId")
    public Object getReferringPhysicianId() {
        return referringPhysicianId;
    }

    @JsonProperty("referringPhysicianId")
    public void setReferringPhysicianId(Object referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
    }

    public SchedulingData withReferringPhysicianId(Object referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
        return this;
    }

    @JsonProperty("procedureDt")
    public String getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
    }

    public SchedulingData withProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("signatureId")
    public Object getSignatureId() {
        return signatureId;
    }

    @JsonProperty("signatureId")
    public void setSignatureId(Object signatureId) {
        this.signatureId = signatureId;
    }

    public SchedulingData withSignatureId(Object signatureId) {
        this.signatureId = signatureId;
        return this;
    }

    @JsonProperty("signatureDt")
    public Object getSignatureDt() {
        return signatureDt;
    }

    @JsonProperty("signatureDt")
    public void setSignatureDt(Object signatureDt) {
        this.signatureDt = signatureDt;
    }

    public SchedulingData withSignatureDt(Object signatureDt) {
        this.signatureDt = signatureDt;
        return this;
    }

    @JsonProperty("externalId")
    public Integer getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Integer externalId) {
        this.externalId = externalId;
    }

    public SchedulingData withExternalId(Integer externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("acuteChronicTf")
    public Boolean getAcuteChronicTf() {
        return acuteChronicTf;
    }

    @JsonProperty("acuteChronicTf")
    public void setAcuteChronicTf(Boolean acuteChronicTf) {
        this.acuteChronicTf = acuteChronicTf;
    }

    public SchedulingData withAcuteChronicTf(Boolean acuteChronicTf) {
        this.acuteChronicTf = acuteChronicTf;
        return this;
    }

    @JsonProperty("note")
    public Object getNote() {
        return note;
    }

    @JsonProperty("note")
    public void setNote(Object note) {
        this.note = note;
    }

    public SchedulingData withNote(Object note) {
        this.note = note;
        return this;
    }

    @JsonProperty("cancelCaseReason")
    public Object getCancelCaseReason() {
        return cancelCaseReason;
    }

    @JsonProperty("cancelCaseReason")
    public void setCancelCaseReason(Object cancelCaseReason) {
        this.cancelCaseReason = cancelCaseReason;
    }

    public SchedulingData withCancelCaseReason(Object cancelCaseReason) {
        this.cancelCaseReason = cancelCaseReason;
        return this;
    }

    @JsonProperty("cancelDate")
    public Object getCancelDate() {
        return cancelDate;
    }

    @JsonProperty("cancelDate")
    public void setCancelDate(Object cancelDate) {
        this.cancelDate = cancelDate;
    }

    public SchedulingData withCancelDate(Object cancelDate) {
        this.cancelDate = cancelDate;
        return this;
    }

    @JsonProperty("caseProcedurePhysName")
    public String getCaseProcedurePhysName() {
        return caseProcedurePhysName;
    }

    @JsonProperty("caseProcedurePhysName")
    public void setCaseProcedurePhysName(String caseProcedurePhysName) {
        this.caseProcedurePhysName = caseProcedurePhysName;
    }

    public SchedulingData withCaseProcedurePhysName(String caseProcedurePhysName) {
        this.caseProcedurePhysName = caseProcedurePhysName;
        return this;
    }

    @JsonProperty("caseProcedurePhysicians")
    public List<Integer> getCaseProcedurePhysicians() {
        return caseProcedurePhysicians;
    }

    @JsonProperty("caseProcedurePhysicians")
    public void setCaseProcedurePhysicians(List<Integer> caseProcedurePhysicians) {
        this.caseProcedurePhysicians = caseProcedurePhysicians;
    }

    public SchedulingData withCaseProcedurePhysicians(List<Integer> caseProcedurePhysicians) {
        this.caseProcedurePhysicians = caseProcedurePhysicians;
        return this;
    }

    @JsonProperty("scheduledCaseCounts")
    public ScheduledCaseCounts getScheduledCaseCounts() {
        return scheduledCaseCounts;
    }

    @JsonProperty("scheduledCaseCounts")
    public void setScheduledCaseCounts(ScheduledCaseCounts scheduledCaseCounts) {
        this.scheduledCaseCounts = scheduledCaseCounts;
    }

    public SchedulingData withScheduledCaseCounts(ScheduledCaseCounts scheduledCaseCounts) {
        this.scheduledCaseCounts = scheduledCaseCounts;
        return this;
    }

    @JsonProperty("checkedInTime")
    public Object getCheckedInTime() {
        return checkedInTime;
    }

    @JsonProperty("checkedInTime")
    public void setCheckedInTime(Object checkedInTime) {
        this.checkedInTime = checkedInTime;
    }

    public SchedulingData withCheckedInTime(Object checkedInTime) {
        this.checkedInTime = checkedInTime;
        return this;
    }

    @JsonProperty("depositAmount")
    public Object getDepositAmount() {
        return depositAmount;
    }

    @JsonProperty("depositAmount")
    public void setDepositAmount(Object depositAmount) {
        this.depositAmount = depositAmount;
    }

    public SchedulingData withDepositAmount(Object depositAmount) {
        this.depositAmount = depositAmount;
        return this;
    }

    @JsonProperty("rescheduleCounter")
    public Integer getRescheduleCounter() {
        return rescheduleCounter;
    }

    @JsonProperty("rescheduleCounter")
    public void setRescheduleCounter(Integer rescheduleCounter) {
        this.rescheduleCounter = rescheduleCounter;
    }

    public SchedulingData withRescheduleCounter(Integer rescheduleCounter) {
        this.rescheduleCounter = rescheduleCounter;
        return this;
    }

    @JsonProperty("caseColor")
    public Object getCaseColor() {
        return caseColor;
    }

    @JsonProperty("caseColor")
    public void setCaseColor(Object caseColor) {
        this.caseColor = caseColor;
    }

    public SchedulingData withCaseColor(Object caseColor) {
        this.caseColor = caseColor;
        return this;
    }

    @JsonProperty("secondaryPhysicianNames")
    public String getSecondaryPhysicianNames() {
        return secondaryPhysicianNames;
    }

    @JsonProperty("secondaryPhysicianNames")
    public void setSecondaryPhysicianNames(String secondaryPhysicianNames) {
        this.secondaryPhysicianNames = secondaryPhysicianNames;
    }

    public SchedulingData withSecondaryPhysicianNames(String secondaryPhysicianNames) {
        this.secondaryPhysicianNames = secondaryPhysicianNames;
        return this;
    }

    @JsonProperty("created")
    public String getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(String created) {
        this.created = created;
    }

    public SchedulingData withCreated(String created) {
        this.created = created;
        return this;
    }

    @JsonProperty("caseType")
    public Integer getCaseType() {
        return caseType;
    }

    @JsonProperty("caseType")
    public void setCaseType(Integer caseType) {
        this.caseType = caseType;
    }

    public SchedulingData withCaseType(Integer caseType) {
        this.caseType = caseType;
        return this;
    }

    @JsonProperty("isCaseOrdersEnabled")
    public Boolean getIsCaseOrdersEnabled() {
        return isCaseOrdersEnabled;
    }

    @JsonProperty("isCaseOrdersEnabled")
    public void setIsCaseOrdersEnabled(Boolean isCaseOrdersEnabled) {
        this.isCaseOrdersEnabled = isCaseOrdersEnabled;
    }

    public SchedulingData withIsCaseOrdersEnabled(Boolean isCaseOrdersEnabled) {
        this.isCaseOrdersEnabled = isCaseOrdersEnabled;
        return this;
    }

    @JsonProperty("isCaseBlockNotesEnabled")
    public Boolean getIsCaseBlockNotesEnabled() {
        return isCaseBlockNotesEnabled;
    }

    @JsonProperty("isCaseBlockNotesEnabled")
    public void setIsCaseBlockNotesEnabled(Boolean isCaseBlockNotesEnabled) {
        this.isCaseBlockNotesEnabled = isCaseBlockNotesEnabled;
    }

    public SchedulingData withIsCaseBlockNotesEnabled(Boolean isCaseBlockNotesEnabled) {
        this.isCaseBlockNotesEnabled = isCaseBlockNotesEnabled;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SchedulingData withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(caseSummaryID).append(startTime).append(endTime).append(arrivalTime).append(dischargeTime).append(scheduledRoom).append(patient).append(primarySurgeon).append(anesthesiaType).append(primaryProcedure).append(secondaryProcedures).append(currentRoom).append(currentModule).append(appointmentNote).append(caseLastUpdated).append(caseStatus).append(appointmentId).append(casePackId).append(anesthesiaDate).append(startDate).append(isActiveCase).append(appointmentTypeId).append(primaryProcedureId).append(organizationId).append(anesTypeId).append(cleanupTime).append(referringPhysicianId).append(procedureDt).append(signatureId).append(signatureDt).append(externalId).append(acuteChronicTf).append(note).append(cancelCaseReason).append(cancelDate).append(caseProcedurePhysName).append(caseProcedurePhysicians).append(scheduledCaseCounts).append(checkedInTime).append(depositAmount).append(rescheduleCounter).append(caseColor).append(secondaryPhysicianNames).append(created).append(caseType).append(isCaseOrdersEnabled).append(isCaseBlockNotesEnabled).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SchedulingData) == false) {
            return false;
        }
        SchedulingData rhs = ((SchedulingData) other);
        return new EqualsBuilder().append(caseSummaryID, rhs.caseSummaryID).append(startTime, rhs.startTime).append(endTime, rhs.endTime).append(arrivalTime, rhs.arrivalTime).append(dischargeTime, rhs.dischargeTime).append(scheduledRoom, rhs.scheduledRoom).append(patient, rhs.patient).append(primarySurgeon, rhs.primarySurgeon).append(anesthesiaType, rhs.anesthesiaType).append(primaryProcedure, rhs.primaryProcedure).append(secondaryProcedures, rhs.secondaryProcedures).append(currentRoom, rhs.currentRoom).append(currentModule, rhs.currentModule).append(appointmentNote, rhs.appointmentNote).append(caseLastUpdated, rhs.caseLastUpdated).append(caseStatus, rhs.caseStatus).append(appointmentId, rhs.appointmentId).append(casePackId, rhs.casePackId).append(anesthesiaDate, rhs.anesthesiaDate).append(startDate, rhs.startDate).append(isActiveCase, rhs.isActiveCase).append(appointmentTypeId, rhs.appointmentTypeId).append(primaryProcedureId, rhs.primaryProcedureId).append(organizationId, rhs.organizationId).append(anesTypeId, rhs.anesTypeId).append(cleanupTime, rhs.cleanupTime).append(referringPhysicianId, rhs.referringPhysicianId).append(procedureDt, rhs.procedureDt).append(signatureId, rhs.signatureId).append(signatureDt, rhs.signatureDt).append(externalId, rhs.externalId).append(acuteChronicTf, rhs.acuteChronicTf).append(note, rhs.note).append(cancelCaseReason, rhs.cancelCaseReason).append(cancelDate, rhs.cancelDate).append(caseProcedurePhysName, rhs.caseProcedurePhysName).append(caseProcedurePhysicians, rhs.caseProcedurePhysicians).append(scheduledCaseCounts, rhs.scheduledCaseCounts).append(checkedInTime, rhs.checkedInTime).append(depositAmount, rhs.depositAmount).append(rescheduleCounter, rhs.rescheduleCounter).append(caseColor, rhs.caseColor).append(secondaryPhysicianNames, rhs.secondaryPhysicianNames).append(created, rhs.created).append(caseType, rhs.caseType).append(isCaseOrdersEnabled, rhs.isCaseOrdersEnabled).append(isCaseBlockNotesEnabled, rhs.isCaseBlockNotesEnabled).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
