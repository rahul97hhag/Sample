
package com.bhavani.models.configuration.business.dictionaries;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "visibility",
    "id",
    "dictionary",
    "dictionaryId",
    "value",
    "quickCode",
    "active",
    "searchString",
    "pageNumber",
    "organizationId",
    "includeInactive",
    "aoDictionaryTf",
    "showInClinicalTf",
    "dontFilterByOrganization",
    "onlyClinical",
    "order",
    "additional",
    "externalId",
    "sourceIdentifier"
})
public class DischargeStatus {

    @JsonProperty("visibility")
    private Integer visibility;
    @JsonProperty("id")
    private Integer id;
    @JsonProperty("dictionary")
    private String dictionary;
    @JsonProperty("dictionaryId")
    private Integer dictionaryId;
    @JsonProperty("value")
    private String value;
    @JsonProperty("quickCode")
    private String quickCode;
    @JsonProperty("active")
    private Boolean active;
    @JsonProperty("searchString")
    private Object searchString;
    @JsonProperty("pageNumber")
    private Object pageNumber;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("includeInactive")
    private Boolean includeInactive;
    @JsonProperty("aoDictionaryTf")
    private Boolean aoDictionaryTf;
    @JsonProperty("showInClinicalTf")
    private Boolean showInClinicalTf;
    @JsonProperty("dontFilterByOrganization")
    private Boolean dontFilterByOrganization;
    @JsonProperty("onlyClinical")
    private Boolean onlyClinical;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("additional")
    private Object additional;
    @JsonProperty("externalId")
    private Object externalId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("visibility")
    public Integer getVisibility() {
        return visibility;
    }

    @JsonProperty("visibility")
    public void setVisibility(Integer visibility) {
        this.visibility = visibility;
    }

    public DischargeStatus withVisibility(Integer visibility) {
        this.visibility = visibility;
        return this;
    }

    @JsonProperty("id")
    public Integer getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(Integer id) {
        this.id = id;
    }

    public DischargeStatus withId(Integer id) {
        this.id = id;
        return this;
    }

    @JsonProperty("dictionary")
    public String getDictionary() {
        return dictionary;
    }

    @JsonProperty("dictionary")
    public void setDictionary(String dictionary) {
        this.dictionary = dictionary;
    }

    public DischargeStatus withDictionary(String dictionary) {
        this.dictionary = dictionary;
        return this;
    }

    @JsonProperty("dictionaryId")
    public Integer getDictionaryId() {
        return dictionaryId;
    }

    @JsonProperty("dictionaryId")
    public void setDictionaryId(Integer dictionaryId) {
        this.dictionaryId = dictionaryId;
    }

    public DischargeStatus withDictionaryId(Integer dictionaryId) {
        this.dictionaryId = dictionaryId;
        return this;
    }

    @JsonProperty("value")
    public String getValue() {
        return value;
    }

    @JsonProperty("value")
    public void setValue(String value) {
        this.value = value;
    }

    public DischargeStatus withValue(String value) {
        this.value = value;
        return this;
    }

    @JsonProperty("quickCode")
    public String getQuickCode() {
        return quickCode;
    }

    @JsonProperty("quickCode")
    public void setQuickCode(String quickCode) {
        this.quickCode = quickCode;
    }

    public DischargeStatus withQuickCode(String quickCode) {
        this.quickCode = quickCode;
        return this;
    }

    @JsonProperty("active")
    public Boolean getActive() {
        return active;
    }

    @JsonProperty("active")
    public void setActive(Boolean active) {
        this.active = active;
    }

    public DischargeStatus withActive(Boolean active) {
        this.active = active;
        return this;
    }

    @JsonProperty("searchString")
    public Object getSearchString() {
        return searchString;
    }

    @JsonProperty("searchString")
    public void setSearchString(Object searchString) {
        this.searchString = searchString;
    }

    public DischargeStatus withSearchString(Object searchString) {
        this.searchString = searchString;
        return this;
    }

    @JsonProperty("pageNumber")
    public Object getPageNumber() {
        return pageNumber;
    }

    @JsonProperty("pageNumber")
    public void setPageNumber(Object pageNumber) {
        this.pageNumber = pageNumber;
    }

    public DischargeStatus withPageNumber(Object pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public DischargeStatus withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("includeInactive")
    public Boolean getIncludeInactive() {
        return includeInactive;
    }

    @JsonProperty("includeInactive")
    public void setIncludeInactive(Boolean includeInactive) {
        this.includeInactive = includeInactive;
    }

    public DischargeStatus withIncludeInactive(Boolean includeInactive) {
        this.includeInactive = includeInactive;
        return this;
    }

    @JsonProperty("aoDictionaryTf")
    public Boolean getAoDictionaryTf() {
        return aoDictionaryTf;
    }

    @JsonProperty("aoDictionaryTf")
    public void setAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
    }

    public DischargeStatus withAoDictionaryTf(Boolean aoDictionaryTf) {
        this.aoDictionaryTf = aoDictionaryTf;
        return this;
    }

    @JsonProperty("showInClinicalTf")
    public Boolean getShowInClinicalTf() {
        return showInClinicalTf;
    }

    @JsonProperty("showInClinicalTf")
    public void setShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
    }

    public DischargeStatus withShowInClinicalTf(Boolean showInClinicalTf) {
        this.showInClinicalTf = showInClinicalTf;
        return this;
    }

    @JsonProperty("dontFilterByOrganization")
    public Boolean getDontFilterByOrganization() {
        return dontFilterByOrganization;
    }

    @JsonProperty("dontFilterByOrganization")
    public void setDontFilterByOrganization(Boolean dontFilterByOrganization) {
        this.dontFilterByOrganization = dontFilterByOrganization;
    }

    public DischargeStatus withDontFilterByOrganization(Boolean dontFilterByOrganization) {
        this.dontFilterByOrganization = dontFilterByOrganization;
        return this;
    }

    @JsonProperty("onlyClinical")
    public Boolean getOnlyClinical() {
        return onlyClinical;
    }

    @JsonProperty("onlyClinical")
    public void setOnlyClinical(Boolean onlyClinical) {
        this.onlyClinical = onlyClinical;
    }

    public DischargeStatus withOnlyClinical(Boolean onlyClinical) {
        this.onlyClinical = onlyClinical;
        return this;
    }

    @JsonProperty("order")
    public Integer getOrder() {
        return order;
    }

    @JsonProperty("order")
    public void setOrder(Integer order) {
        this.order = order;
    }

    public DischargeStatus withOrder(Integer order) {
        this.order = order;
        return this;
    }

    @JsonProperty("additional")
    public Object getAdditional() {
        return additional;
    }

    @JsonProperty("additional")
    public void setAdditional(Object additional) {
        this.additional = additional;
    }

    public DischargeStatus withAdditional(Object additional) {
        this.additional = additional;
        return this;
    }

    @JsonProperty("externalId")
    public Object getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Object externalId) {
        this.externalId = externalId;
    }

    public DischargeStatus withExternalId(Object externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public DischargeStatus withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DischargeStatus withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(visibility).append(id).append(dictionary).append(dictionaryId).append(value).append(quickCode).append(active).append(searchString).append(pageNumber).append(organizationId).append(includeInactive).append(aoDictionaryTf).append(showInClinicalTf).append(dontFilterByOrganization).append(onlyClinical).append(order).append(additional).append(externalId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DischargeStatus) == false) {
            return false;
        }
        DischargeStatus rhs = ((DischargeStatus) other);
        return new EqualsBuilder().append(visibility, rhs.visibility).append(id, rhs.id).append(dictionary, rhs.dictionary).append(dictionaryId, rhs.dictionaryId).append(value, rhs.value).append(quickCode, rhs.quickCode).append(active, rhs.active).append(searchString, rhs.searchString).append(pageNumber, rhs.pageNumber).append(organizationId, rhs.organizationId).append(includeInactive, rhs.includeInactive).append(aoDictionaryTf, rhs.aoDictionaryTf).append(showInClinicalTf, rhs.showInClinicalTf).append(dontFilterByOrganization, rhs.dontFilterByOrganization).append(onlyClinical, rhs.onlyClinical).append(order, rhs.order).append(additional, rhs.additional).append(externalId, rhs.externalId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
