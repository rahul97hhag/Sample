
package com.bhavani.models.ppe.appointmentRequest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientInsuranceId",
    "patientId",
    "carrierId",
    "organizationId",
    "insuredId",
    "insuranceId",
    "displayName",
    "relationshipToInsured",
    "planName",
    "groupNumber",
    "groupName",
    "employer",
    "authorizationNumber",
    "insuranceCarrierId",
    "insurancePlanId",
    "claimOfficeId",
    "carrier",
    "firstName",
    "lastName",
    "middleInitial",
    "suffix",
    "gender",
    "dateOfBirth",
    "address1",
    "address2",
    "city",
    "state",
    "zipCode",
    "countyName",
    "countryName",
    "email",
    "primaryPhone",
    "insuranceClaimOfficeId",
    "isAdditionalClaimInfClassification",
    "effectiveFrom",
    "effectiveTo",
    "isMspInsuranceTypeClassification",
    "sortOrder",
    "generateClaimTf",
    "isInsuranceMappedWithCharge",
    "isActive"
})
public class CaseInsurance {

    @JsonProperty("patientInsuranceId")
    private Integer patientInsuranceId;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("carrierId")
    private Integer carrierId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("insuredId")
    private Integer insuredId;
    @JsonProperty("insuranceId")
    private String insuranceId;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("relationshipToInsured")
    private String relationshipToInsured;
    @JsonProperty("planName")
    private String planName;
    @JsonProperty("groupNumber")
    private String groupNumber;
    @JsonProperty("groupName")
    private String groupName;
    @JsonProperty("employer")
    private String employer;
    @JsonProperty("authorizationNumber")
    private String authorizationNumber;
    @JsonProperty("insuranceCarrierId")
    private Object insuranceCarrierId;
    @JsonProperty("insurancePlanId")
    private Object insurancePlanId;
    @JsonProperty("claimOfficeId")
    private Object claimOfficeId;
    @JsonProperty("carrier")
    private String carrier;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("suffix")
    private String suffix;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("dateOfBirth")
    private Object dateOfBirth;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("address2")
    private String address2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("countyName")
    private String countyName;
    @JsonProperty("countryName")
    private String countryName;
    @JsonProperty("email")
    private String email;
    @JsonProperty("primaryPhone")
    private String primaryPhone;
    @JsonProperty("insuranceClaimOfficeId")
    private Integer insuranceClaimOfficeId;
    @JsonProperty("isAdditionalClaimInfClassification")
    private Object isAdditionalClaimInfClassification;
    @JsonProperty("effectiveFrom")
    private Object effectiveFrom;
    @JsonProperty("effectiveTo")
    private Object effectiveTo;
    @JsonProperty("isMspInsuranceTypeClassification")
    private Object isMspInsuranceTypeClassification;
    @JsonProperty("sortOrder")
    private Integer sortOrder;
    @JsonProperty("generateClaimTf")
    private Object generateClaimTf;
    @JsonProperty("isInsuranceMappedWithCharge")
    private Object isInsuranceMappedWithCharge;
    @JsonProperty("isActive")
    private Object isActive;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientInsuranceId")
    public Integer getPatientInsuranceId() {
        return patientInsuranceId;
    }

    @JsonProperty("patientInsuranceId")
    public void setPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
    }

    public CaseInsurance withPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public CaseInsurance withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("carrierId")
    public Integer getCarrierId() {
        return carrierId;
    }

    @JsonProperty("carrierId")
    public void setCarrierId(Integer carrierId) {
        this.carrierId = carrierId;
    }

    public CaseInsurance withCarrierId(Integer carrierId) {
        this.carrierId = carrierId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public CaseInsurance withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("insuredId")
    public Integer getInsuredId() {
        return insuredId;
    }

    @JsonProperty("insuredId")
    public void setInsuredId(Integer insuredId) {
        this.insuredId = insuredId;
    }

    public CaseInsurance withInsuredId(Integer insuredId) {
        this.insuredId = insuredId;
        return this;
    }

    @JsonProperty("insuranceId")
    public String getInsuranceId() {
        return insuranceId;
    }

    @JsonProperty("insuranceId")
    public void setInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
    }

    public CaseInsurance withInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
        return this;
    }

    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public CaseInsurance withDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    @JsonProperty("relationshipToInsured")
    public String getRelationshipToInsured() {
        return relationshipToInsured;
    }

    @JsonProperty("relationshipToInsured")
    public void setRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
    }

    public CaseInsurance withRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
        return this;
    }

    @JsonProperty("planName")
    public String getPlanName() {
        return planName;
    }

    @JsonProperty("planName")
    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public CaseInsurance withPlanName(String planName) {
        this.planName = planName;
        return this;
    }

    @JsonProperty("groupNumber")
    public String getGroupNumber() {
        return groupNumber;
    }

    @JsonProperty("groupNumber")
    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public CaseInsurance withGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
        return this;
    }

    @JsonProperty("groupName")
    public String getGroupName() {
        return groupName;
    }

    @JsonProperty("groupName")
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public CaseInsurance withGroupName(String groupName) {
        this.groupName = groupName;
        return this;
    }

    @JsonProperty("employer")
    public String getEmployer() {
        return employer;
    }

    @JsonProperty("employer")
    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public CaseInsurance withEmployer(String employer) {
        this.employer = employer;
        return this;
    }

    @JsonProperty("authorizationNumber")
    public String getAuthorizationNumber() {
        return authorizationNumber;
    }

    @JsonProperty("authorizationNumber")
    public void setAuthorizationNumber(String authorizationNumber) {
        this.authorizationNumber = authorizationNumber;
    }

    public CaseInsurance withAuthorizationNumber(String authorizationNumber) {
        this.authorizationNumber = authorizationNumber;
        return this;
    }

    @JsonProperty("insuranceCarrierId")
    public Object getInsuranceCarrierId() {
        return insuranceCarrierId;
    }

    @JsonProperty("insuranceCarrierId")
    public void setInsuranceCarrierId(Object insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
    }

    public CaseInsurance withInsuranceCarrierId(Object insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
        return this;
    }

    @JsonProperty("insurancePlanId")
    public Object getInsurancePlanId() {
        return insurancePlanId;
    }

    @JsonProperty("insurancePlanId")
    public void setInsurancePlanId(Object insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
    }

    public CaseInsurance withInsurancePlanId(Object insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
        return this;
    }

    @JsonProperty("claimOfficeId")
    public Object getClaimOfficeId() {
        return claimOfficeId;
    }

    @JsonProperty("claimOfficeId")
    public void setClaimOfficeId(Object claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
    }

    public CaseInsurance withClaimOfficeId(Object claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
        return this;
    }

    @JsonProperty("carrier")
    public String getCarrier() {
        return carrier;
    }

    @JsonProperty("carrier")
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public CaseInsurance withCarrier(String carrier) {
        this.carrier = carrier;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public CaseInsurance withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public CaseInsurance withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public CaseInsurance withMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("suffix")
    public String getSuffix() {
        return suffix;
    }

    @JsonProperty("suffix")
    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public CaseInsurance withSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public CaseInsurance withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public Object getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(Object dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public CaseInsurance withDateOfBirth(Object dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public CaseInsurance withAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("address2")
    public String getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public CaseInsurance withAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public CaseInsurance withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public CaseInsurance withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public CaseInsurance withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("countyName")
    public String getCountyName() {
        return countyName;
    }

    @JsonProperty("countyName")
    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }

    public CaseInsurance withCountyName(String countyName) {
        this.countyName = countyName;
        return this;
    }

    @JsonProperty("countryName")
    public String getCountryName() {
        return countryName;
    }

    @JsonProperty("countryName")
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public CaseInsurance withCountryName(String countryName) {
        this.countryName = countryName;
        return this;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    public CaseInsurance withEmail(String email) {
        this.email = email;
        return this;
    }

    @JsonProperty("primaryPhone")
    public String getPrimaryPhone() {
        return primaryPhone;
    }

    @JsonProperty("primaryPhone")
    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public CaseInsurance withPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
        return this;
    }

    @JsonProperty("insuranceClaimOfficeId")
    public Integer getInsuranceClaimOfficeId() {
        return insuranceClaimOfficeId;
    }

    @JsonProperty("insuranceClaimOfficeId")
    public void setInsuranceClaimOfficeId(Integer insuranceClaimOfficeId) {
        this.insuranceClaimOfficeId = insuranceClaimOfficeId;
    }

    public CaseInsurance withInsuranceClaimOfficeId(Integer insuranceClaimOfficeId) {
        this.insuranceClaimOfficeId = insuranceClaimOfficeId;
        return this;
    }

    @JsonProperty("isAdditionalClaimInfClassification")
    public Object getIsAdditionalClaimInfClassification() {
        return isAdditionalClaimInfClassification;
    }

    @JsonProperty("isAdditionalClaimInfClassification")
    public void setIsAdditionalClaimInfClassification(Object isAdditionalClaimInfClassification) {
        this.isAdditionalClaimInfClassification = isAdditionalClaimInfClassification;
    }

    public CaseInsurance withIsAdditionalClaimInfClassification(Object isAdditionalClaimInfClassification) {
        this.isAdditionalClaimInfClassification = isAdditionalClaimInfClassification;
        return this;
    }

    @JsonProperty("effectiveFrom")
    public Object getEffectiveFrom() {
        return effectiveFrom;
    }

    @JsonProperty("effectiveFrom")
    public void setEffectiveFrom(Object effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
    }

    public CaseInsurance withEffectiveFrom(Object effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
        return this;
    }

    @JsonProperty("effectiveTo")
    public Object getEffectiveTo() {
        return effectiveTo;
    }

    @JsonProperty("effectiveTo")
    public void setEffectiveTo(Object effectiveTo) {
        this.effectiveTo = effectiveTo;
    }

    public CaseInsurance withEffectiveTo(Object effectiveTo) {
        this.effectiveTo = effectiveTo;
        return this;
    }

    @JsonProperty("isMspInsuranceTypeClassification")
    public Object getIsMspInsuranceTypeClassification() {
        return isMspInsuranceTypeClassification;
    }

    @JsonProperty("isMspInsuranceTypeClassification")
    public void setIsMspInsuranceTypeClassification(Object isMspInsuranceTypeClassification) {
        this.isMspInsuranceTypeClassification = isMspInsuranceTypeClassification;
    }

    public CaseInsurance withIsMspInsuranceTypeClassification(Object isMspInsuranceTypeClassification) {
        this.isMspInsuranceTypeClassification = isMspInsuranceTypeClassification;
        return this;
    }

    @JsonProperty("sortOrder")
    public Integer getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public CaseInsurance withSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("generateClaimTf")
    public Object getGenerateClaimTf() {
        return generateClaimTf;
    }

    @JsonProperty("generateClaimTf")
    public void setGenerateClaimTf(Object generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
    }

    public CaseInsurance withGenerateClaimTf(Object generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
        return this;
    }

    @JsonProperty("isInsuranceMappedWithCharge")
    public Object getIsInsuranceMappedWithCharge() {
        return isInsuranceMappedWithCharge;
    }

    @JsonProperty("isInsuranceMappedWithCharge")
    public void setIsInsuranceMappedWithCharge(Object isInsuranceMappedWithCharge) {
        this.isInsuranceMappedWithCharge = isInsuranceMappedWithCharge;
    }

    public CaseInsurance withIsInsuranceMappedWithCharge(Object isInsuranceMappedWithCharge) {
        this.isInsuranceMappedWithCharge = isInsuranceMappedWithCharge;
        return this;
    }

    @JsonProperty("isActive")
    public Object getIsActive() {
        return isActive;
    }

    @JsonProperty("isActive")
    public void setIsActive(Object isActive) {
        this.isActive = isActive;
    }

    public CaseInsurance withIsActive(Object isActive) {
        this.isActive = isActive;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseInsurance withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientInsuranceId).append(patientId).append(carrierId).append(organizationId).append(insuredId).append(insuranceId).append(displayName).append(relationshipToInsured).append(planName).append(groupNumber).append(groupName).append(employer).append(authorizationNumber).append(insuranceCarrierId).append(insurancePlanId).append(claimOfficeId).append(carrier).append(firstName).append(lastName).append(middleInitial).append(suffix).append(gender).append(dateOfBirth).append(address1).append(address2).append(city).append(state).append(zipCode).append(countyName).append(countryName).append(email).append(primaryPhone).append(insuranceClaimOfficeId).append(isAdditionalClaimInfClassification).append(effectiveFrom).append(effectiveTo).append(isMspInsuranceTypeClassification).append(sortOrder).append(generateClaimTf).append(isInsuranceMappedWithCharge).append(isActive).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseInsurance) == false) {
            return false;
        }
        CaseInsurance rhs = ((CaseInsurance) other);
        return new EqualsBuilder().append(patientInsuranceId, rhs.patientInsuranceId).append(patientId, rhs.patientId).append(carrierId, rhs.carrierId).append(organizationId, rhs.organizationId).append(insuredId, rhs.insuredId).append(insuranceId, rhs.insuranceId).append(displayName, rhs.displayName).append(relationshipToInsured, rhs.relationshipToInsured).append(planName, rhs.planName).append(groupNumber, rhs.groupNumber).append(groupName, rhs.groupName).append(employer, rhs.employer).append(authorizationNumber, rhs.authorizationNumber).append(insuranceCarrierId, rhs.insuranceCarrierId).append(insurancePlanId, rhs.insurancePlanId).append(claimOfficeId, rhs.claimOfficeId).append(carrier, rhs.carrier).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(suffix, rhs.suffix).append(gender, rhs.gender).append(dateOfBirth, rhs.dateOfBirth).append(address1, rhs.address1).append(address2, rhs.address2).append(city, rhs.city).append(state, rhs.state).append(zipCode, rhs.zipCode).append(countyName, rhs.countyName).append(countryName, rhs.countryName).append(email, rhs.email).append(primaryPhone, rhs.primaryPhone).append(insuranceClaimOfficeId, rhs.insuranceClaimOfficeId).append(isAdditionalClaimInfClassification, rhs.isAdditionalClaimInfClassification).append(effectiveFrom, rhs.effectiveFrom).append(effectiveTo, rhs.effectiveTo).append(isMspInsuranceTypeClassification, rhs.isMspInsuranceTypeClassification).append(sortOrder, rhs.sortOrder).append(generateClaimTf, rhs.generateClaimTf).append(isInsuranceMappedWithCharge, rhs.isInsuranceMappedWithCharge).append(isActive, rhs.isActive).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
