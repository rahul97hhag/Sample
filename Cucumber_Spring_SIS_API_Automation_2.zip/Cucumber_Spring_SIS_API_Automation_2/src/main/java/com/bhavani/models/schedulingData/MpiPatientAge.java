
package com.bhavani.models.schedulingData;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "years",
    "months",
    "days"
})
public class MpiPatientAge {

    @JsonProperty("years")
    private Integer years;
    @JsonProperty("months")
    private Integer months;
    @JsonProperty("days")
    private Integer days;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("years")
    public Integer getYears() {
        return years;
    }

    @JsonProperty("years")
    public void setYears(Integer years) {
        this.years = years;
    }

    public MpiPatientAge withYears(Integer years) {
        this.years = years;
        return this;
    }

    @JsonProperty("months")
    public Integer getMonths() {
        return months;
    }

    @JsonProperty("months")
    public void setMonths(Integer months) {
        this.months = months;
    }

    public MpiPatientAge withMonths(Integer months) {
        this.months = months;
        return this;
    }

    @JsonProperty("days")
    public Integer getDays() {
        return days;
    }

    @JsonProperty("days")
    public void setDays(Integer days) {
        this.days = days;
    }

    public MpiPatientAge withDays(Integer days) {
        this.days = days;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MpiPatientAge withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(years).append(months).append(days).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MpiPatientAge) == false) {
            return false;
        }
        MpiPatientAge rhs = ((MpiPatientAge) other);
        return new EqualsBuilder().append(years, rhs.years).append(months, rhs.months).append(days, rhs.days).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
