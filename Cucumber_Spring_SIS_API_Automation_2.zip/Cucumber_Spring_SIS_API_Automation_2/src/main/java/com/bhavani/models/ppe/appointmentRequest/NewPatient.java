
package com.bhavani.models.ppe.appointmentRequest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "mpiPatientPhone",
    "mpiPatientPhoneSecondary",
    "patientId",
    "firstName",
    "lastName",
    "middleInitial",
    "title",
    "dateOfBirth",
    "gender",
    "accountNumber",
    "noKnownDrugAllergyTf",
    "noKnownNonDrugAllergyTf",
    "noKnownLatexAllergyTf",
    "noHomeMedicationTf",
    "email",
    "alias",
    "patientLanguage",
    "maritalStatusId",
    "maritalStatus",
    "raceId",
    "race",
    "ethnicityId",
    "ethnicity",
    "occupation",
    "medsLastLoaded",
    "patientImage",
    "address",
    "emergencyContact",
    "isPatientExists",
    "dob",
    "employer",
    "lockingUser",
    "isLockExists",
    "ssn",
    "patientGuarantor",
    "fullName",
    "fullNameWithTitle",
    "procedureDt",
    "primaryProcedure",
    "mpiPatientAge"
})
public class NewPatient {

    @JsonProperty("mpiPatientPhone")
    private MpiPatientPhone mpiPatientPhone;
    @JsonProperty("mpiPatientPhoneSecondary")
    private MpiPatientPhoneSecondary mpiPatientPhoneSecondary;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("title")
    private String title;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("noKnownDrugAllergyTf")
    private Object noKnownDrugAllergyTf;
    @JsonProperty("noKnownNonDrugAllergyTf")
    private Object noKnownNonDrugAllergyTf;
    @JsonProperty("noKnownLatexAllergyTf")
    private Object noKnownLatexAllergyTf;
    @JsonProperty("noHomeMedicationTf")
    private Object noHomeMedicationTf;
    @JsonProperty("email")
    private String email;
    @JsonProperty("alias")
    private String alias;
    @JsonProperty("patientLanguage")
    private Object patientLanguage;
    @JsonProperty("maritalStatusId")
    private Object maritalStatusId;
    @JsonProperty("maritalStatus")
    private String maritalStatus;
    @JsonProperty("raceId")
    private Object raceId;
    @JsonProperty("race")
    private String race;
    @JsonProperty("ethnicityId")
    private Object ethnicityId;
    @JsonProperty("ethnicity")
    private Object ethnicity;
    @JsonProperty("occupation")
    private Object occupation;
    @JsonProperty("medsLastLoaded")
    private Object medsLastLoaded;
    @JsonProperty("patientImage")
    private Object patientImage;
    @JsonProperty("address")
    private Address address;
    @JsonProperty("emergencyContact")
    private Object emergencyContact;
    @JsonProperty("isPatientExists")
    private Object isPatientExists;
    @JsonProperty("dob")
    private Object dob;
    @JsonProperty("employer")
    private Object employer;
    @JsonProperty("lockingUser")
    private Object lockingUser;
    @JsonProperty("isLockExists")
    private Object isLockExists;
    @JsonProperty("ssn")
    private Object ssn;
    @JsonProperty("patientGuarantor")
    private Object patientGuarantor;
    @JsonProperty("fullName")
    private Object fullName;
    @JsonProperty("fullNameWithTitle")
    private Object fullNameWithTitle;
    @JsonProperty("procedureDt")
    private Object procedureDt;
    @JsonProperty("primaryProcedure")
    private Object primaryProcedure;
    @JsonProperty("mpiPatientAge")
    private Object mpiPatientAge;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("mpiPatientPhone")
    public MpiPatientPhone getMpiPatientPhone() {
        return mpiPatientPhone;
    }

    @JsonProperty("mpiPatientPhone")
    public void setMpiPatientPhone(MpiPatientPhone mpiPatientPhone) {
        this.mpiPatientPhone = mpiPatientPhone;
    }

    public NewPatient withMpiPatientPhone(MpiPatientPhone mpiPatientPhone) {
        this.mpiPatientPhone = mpiPatientPhone;
        return this;
    }

    @JsonProperty("mpiPatientPhoneSecondary")
    public MpiPatientPhoneSecondary getMpiPatientPhoneSecondary() {
        return mpiPatientPhoneSecondary;
    }

    @JsonProperty("mpiPatientPhoneSecondary")
    public void setMpiPatientPhoneSecondary(MpiPatientPhoneSecondary mpiPatientPhoneSecondary) {
        this.mpiPatientPhoneSecondary = mpiPatientPhoneSecondary;
    }

    public NewPatient withMpiPatientPhoneSecondary(MpiPatientPhoneSecondary mpiPatientPhoneSecondary) {
        this.mpiPatientPhoneSecondary = mpiPatientPhoneSecondary;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public NewPatient withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public NewPatient withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public NewPatient withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public NewPatient withMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    public NewPatient withTitle(String title) {
        this.title = title;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public NewPatient withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public NewPatient withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public NewPatient withAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    @JsonProperty("noKnownDrugAllergyTf")
    public Object getNoKnownDrugAllergyTf() {
        return noKnownDrugAllergyTf;
    }

    @JsonProperty("noKnownDrugAllergyTf")
    public void setNoKnownDrugAllergyTf(Object noKnownDrugAllergyTf) {
        this.noKnownDrugAllergyTf = noKnownDrugAllergyTf;
    }

    public NewPatient withNoKnownDrugAllergyTf(Object noKnownDrugAllergyTf) {
        this.noKnownDrugAllergyTf = noKnownDrugAllergyTf;
        return this;
    }

    @JsonProperty("noKnownNonDrugAllergyTf")
    public Object getNoKnownNonDrugAllergyTf() {
        return noKnownNonDrugAllergyTf;
    }

    @JsonProperty("noKnownNonDrugAllergyTf")
    public void setNoKnownNonDrugAllergyTf(Object noKnownNonDrugAllergyTf) {
        this.noKnownNonDrugAllergyTf = noKnownNonDrugAllergyTf;
    }

    public NewPatient withNoKnownNonDrugAllergyTf(Object noKnownNonDrugAllergyTf) {
        this.noKnownNonDrugAllergyTf = noKnownNonDrugAllergyTf;
        return this;
    }

    @JsonProperty("noKnownLatexAllergyTf")
    public Object getNoKnownLatexAllergyTf() {
        return noKnownLatexAllergyTf;
    }

    @JsonProperty("noKnownLatexAllergyTf")
    public void setNoKnownLatexAllergyTf(Object noKnownLatexAllergyTf) {
        this.noKnownLatexAllergyTf = noKnownLatexAllergyTf;
    }

    public NewPatient withNoKnownLatexAllergyTf(Object noKnownLatexAllergyTf) {
        this.noKnownLatexAllergyTf = noKnownLatexAllergyTf;
        return this;
    }

    @JsonProperty("noHomeMedicationTf")
    public Object getNoHomeMedicationTf() {
        return noHomeMedicationTf;
    }

    @JsonProperty("noHomeMedicationTf")
    public void setNoHomeMedicationTf(Object noHomeMedicationTf) {
        this.noHomeMedicationTf = noHomeMedicationTf;
    }

    public NewPatient withNoHomeMedicationTf(Object noHomeMedicationTf) {
        this.noHomeMedicationTf = noHomeMedicationTf;
        return this;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    public NewPatient withEmail(String email) {
        this.email = email;
        return this;
    }

    @JsonProperty("alias")
    public String getAlias() {
        return alias;
    }

    @JsonProperty("alias")
    public void setAlias(String alias) {
        this.alias = alias;
    }

    public NewPatient withAlias(String alias) {
        this.alias = alias;
        return this;
    }

    @JsonProperty("patientLanguage")
    public Object getPatientLanguage() {
        return patientLanguage;
    }

    @JsonProperty("patientLanguage")
    public void setPatientLanguage(Object patientLanguage) {
        this.patientLanguage = patientLanguage;
    }

    public NewPatient withPatientLanguage(Object patientLanguage) {
        this.patientLanguage = patientLanguage;
        return this;
    }

    @JsonProperty("maritalStatusId")
    public Object getMaritalStatusId() {
        return maritalStatusId;
    }

    @JsonProperty("maritalStatusId")
    public void setMaritalStatusId(Object maritalStatusId) {
        this.maritalStatusId = maritalStatusId;
    }

    public NewPatient withMaritalStatusId(Object maritalStatusId) {
        this.maritalStatusId = maritalStatusId;
        return this;
    }

    @JsonProperty("maritalStatus")
    public String getMaritalStatus() {
        return maritalStatus;
    }

    @JsonProperty("maritalStatus")
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public NewPatient withMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
        return this;
    }

    @JsonProperty("raceId")
    public Object getRaceId() {
        return raceId;
    }

    @JsonProperty("raceId")
    public void setRaceId(Object raceId) {
        this.raceId = raceId;
    }

    public NewPatient withRaceId(Object raceId) {
        this.raceId = raceId;
        return this;
    }

    @JsonProperty("race")
    public String getRace() {
        return race;
    }

    @JsonProperty("race")
    public void setRace(String race) {
        this.race = race;
    }

    public NewPatient withRace(String race) {
        this.race = race;
        return this;
    }

    @JsonProperty("ethnicityId")
    public Object getEthnicityId() {
        return ethnicityId;
    }

    @JsonProperty("ethnicityId")
    public void setEthnicityId(Object ethnicityId) {
        this.ethnicityId = ethnicityId;
    }

    public NewPatient withEthnicityId(Object ethnicityId) {
        this.ethnicityId = ethnicityId;
        return this;
    }

    @JsonProperty("ethnicity")
    public Object getEthnicity() {
        return ethnicity;
    }

    @JsonProperty("ethnicity")
    public void setEthnicity(Object ethnicity) {
        this.ethnicity = ethnicity;
    }

    public NewPatient withEthnicity(Object ethnicity) {
        this.ethnicity = ethnicity;
        return this;
    }

    @JsonProperty("occupation")
    public Object getOccupation() {
        return occupation;
    }

    @JsonProperty("occupation")
    public void setOccupation(Object occupation) {
        this.occupation = occupation;
    }

    public NewPatient withOccupation(Object occupation) {
        this.occupation = occupation;
        return this;
    }

    @JsonProperty("medsLastLoaded")
    public Object getMedsLastLoaded() {
        return medsLastLoaded;
    }

    @JsonProperty("medsLastLoaded")
    public void setMedsLastLoaded(Object medsLastLoaded) {
        this.medsLastLoaded = medsLastLoaded;
    }

    public NewPatient withMedsLastLoaded(Object medsLastLoaded) {
        this.medsLastLoaded = medsLastLoaded;
        return this;
    }

    @JsonProperty("patientImage")
    public Object getPatientImage() {
        return patientImage;
    }

    @JsonProperty("patientImage")
    public void setPatientImage(Object patientImage) {
        this.patientImage = patientImage;
    }

    public NewPatient withPatientImage(Object patientImage) {
        this.patientImage = patientImage;
        return this;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    public NewPatient withAddress(Address address) {
        this.address = address;
        return this;
    }

    @JsonProperty("emergencyContact")
    public Object getEmergencyContact() {
        return emergencyContact;
    }

    @JsonProperty("emergencyContact")
    public void setEmergencyContact(Object emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public NewPatient withEmergencyContact(Object emergencyContact) {
        this.emergencyContact = emergencyContact;
        return this;
    }

    @JsonProperty("isPatientExists")
    public Object getIsPatientExists() {
        return isPatientExists;
    }

    @JsonProperty("isPatientExists")
    public void setIsPatientExists(Object isPatientExists) {
        this.isPatientExists = isPatientExists;
    }

    public NewPatient withIsPatientExists(Object isPatientExists) {
        this.isPatientExists = isPatientExists;
        return this;
    }

    @JsonProperty("dob")
    public Object getDob() {
        return dob;
    }

    @JsonProperty("dob")
    public void setDob(Object dob) {
        this.dob = dob;
    }

    public NewPatient withDob(Object dob) {
        this.dob = dob;
        return this;
    }

    @JsonProperty("employer")
    public Object getEmployer() {
        return employer;
    }

    @JsonProperty("employer")
    public void setEmployer(Object employer) {
        this.employer = employer;
    }

    public NewPatient withEmployer(Object employer) {
        this.employer = employer;
        return this;
    }

    @JsonProperty("lockingUser")
    public Object getLockingUser() {
        return lockingUser;
    }

    @JsonProperty("lockingUser")
    public void setLockingUser(Object lockingUser) {
        this.lockingUser = lockingUser;
    }

    public NewPatient withLockingUser(Object lockingUser) {
        this.lockingUser = lockingUser;
        return this;
    }

    @JsonProperty("isLockExists")
    public Object getIsLockExists() {
        return isLockExists;
    }

    @JsonProperty("isLockExists")
    public void setIsLockExists(Object isLockExists) {
        this.isLockExists = isLockExists;
    }

    public NewPatient withIsLockExists(Object isLockExists) {
        this.isLockExists = isLockExists;
        return this;
    }

    @JsonProperty("ssn")
    public Object getSsn() {
        return ssn;
    }

    @JsonProperty("ssn")
    public void setSsn(Object ssn) {
        this.ssn = ssn;
    }

    public NewPatient withSsn(Object ssn) {
        this.ssn = ssn;
        return this;
    }

    @JsonProperty("patientGuarantor")
    public Object getPatientGuarantor() {
        return patientGuarantor;
    }

    @JsonProperty("patientGuarantor")
    public void setPatientGuarantor(Object patientGuarantor) {
        this.patientGuarantor = patientGuarantor;
    }

    public NewPatient withPatientGuarantor(Object patientGuarantor) {
        this.patientGuarantor = patientGuarantor;
        return this;
    }

    @JsonProperty("fullName")
    public Object getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(Object fullName) {
        this.fullName = fullName;
    }

    public NewPatient withFullName(Object fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("fullNameWithTitle")
    public Object getFullNameWithTitle() {
        return fullNameWithTitle;
    }

    @JsonProperty("fullNameWithTitle")
    public void setFullNameWithTitle(Object fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
    }

    public NewPatient withFullNameWithTitle(Object fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
        return this;
    }

    @JsonProperty("procedureDt")
    public Object getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(Object procedureDt) {
        this.procedureDt = procedureDt;
    }

    public NewPatient withProcedureDt(Object procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("primaryProcedure")
    public Object getPrimaryProcedure() {
        return primaryProcedure;
    }

    @JsonProperty("primaryProcedure")
    public void setPrimaryProcedure(Object primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
    }

    public NewPatient withPrimaryProcedure(Object primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
        return this;
    }

    @JsonProperty("mpiPatientAge")
    public Object getMpiPatientAge() {
        return mpiPatientAge;
    }

    @JsonProperty("mpiPatientAge")
    public void setMpiPatientAge(Object mpiPatientAge) {
        this.mpiPatientAge = mpiPatientAge;
    }

    public NewPatient withMpiPatientAge(Object mpiPatientAge) {
        this.mpiPatientAge = mpiPatientAge;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public NewPatient withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(mpiPatientPhone).append(mpiPatientPhoneSecondary).append(patientId).append(firstName).append(lastName).append(middleInitial).append(title).append(dateOfBirth).append(gender).append(accountNumber).append(noKnownDrugAllergyTf).append(noKnownNonDrugAllergyTf).append(noKnownLatexAllergyTf).append(noHomeMedicationTf).append(email).append(alias).append(patientLanguage).append(maritalStatusId).append(maritalStatus).append(raceId).append(race).append(ethnicityId).append(ethnicity).append(occupation).append(medsLastLoaded).append(patientImage).append(address).append(emergencyContact).append(isPatientExists).append(dob).append(employer).append(lockingUser).append(isLockExists).append(ssn).append(patientGuarantor).append(fullName).append(fullNameWithTitle).append(procedureDt).append(primaryProcedure).append(mpiPatientAge).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof NewPatient) == false) {
            return false;
        }
        NewPatient rhs = ((NewPatient) other);
        return new EqualsBuilder().append(mpiPatientPhone, rhs.mpiPatientPhone).append(mpiPatientPhoneSecondary, rhs.mpiPatientPhoneSecondary).append(patientId, rhs.patientId).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(title, rhs.title).append(dateOfBirth, rhs.dateOfBirth).append(gender, rhs.gender).append(accountNumber, rhs.accountNumber).append(noKnownDrugAllergyTf, rhs.noKnownDrugAllergyTf).append(noKnownNonDrugAllergyTf, rhs.noKnownNonDrugAllergyTf).append(noKnownLatexAllergyTf, rhs.noKnownLatexAllergyTf).append(noHomeMedicationTf, rhs.noHomeMedicationTf).append(email, rhs.email).append(alias, rhs.alias).append(patientLanguage, rhs.patientLanguage).append(maritalStatusId, rhs.maritalStatusId).append(maritalStatus, rhs.maritalStatus).append(raceId, rhs.raceId).append(race, rhs.race).append(ethnicityId, rhs.ethnicityId).append(ethnicity, rhs.ethnicity).append(occupation, rhs.occupation).append(medsLastLoaded, rhs.medsLastLoaded).append(patientImage, rhs.patientImage).append(address, rhs.address).append(emergencyContact, rhs.emergencyContact).append(isPatientExists, rhs.isPatientExists).append(dob, rhs.dob).append(employer, rhs.employer).append(lockingUser, rhs.lockingUser).append(isLockExists, rhs.isLockExists).append(ssn, rhs.ssn).append(patientGuarantor, rhs.patientGuarantor).append(fullName, rhs.fullName).append(fullNameWithTitle, rhs.fullNameWithTitle).append(procedureDt, rhs.procedureDt).append(primaryProcedure, rhs.primaryProcedure).append(mpiPatientAge, rhs.mpiPatientAge).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
