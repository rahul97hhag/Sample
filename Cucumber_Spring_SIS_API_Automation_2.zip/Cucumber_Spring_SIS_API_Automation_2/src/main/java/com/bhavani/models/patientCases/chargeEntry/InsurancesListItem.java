
package com.bhavani.models.patientCases.chargeEntry;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientInsuranceId",
    "displayName"
})
public class InsurancesListItem {

    @JsonProperty("patientInsuranceId")
    private Integer patientInsuranceId;
    @JsonProperty("displayName")
    private String displayName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientInsuranceId")
    public Integer getPatientInsuranceId() {
        return patientInsuranceId;
    }

    @JsonProperty("patientInsuranceId")
    public void setPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
    }

    public InsurancesListItem withPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
        return this;
    }

    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public InsurancesListItem withDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsurancesListItem withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientInsuranceId).append(displayName).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsurancesListItem) == false) {
            return false;
        }
        InsurancesListItem rhs = ((InsurancesListItem) other);
        return new EqualsBuilder().append(patientInsuranceId, rhs.patientInsuranceId).append(displayName, rhs.displayName).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
