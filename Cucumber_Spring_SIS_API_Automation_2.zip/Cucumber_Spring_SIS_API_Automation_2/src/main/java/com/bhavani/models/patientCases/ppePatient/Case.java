
package com.bhavani.models.patientCases.ppePatient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dateOfService",
    "startTime",
    "endTime",
    "roomName",
    "appointmentNote",
    "anesthesiaTypeName",
    "primaryPhysicianNPI",
    "referringPhysicianNPI",
    "caseGuarantor",
    "caseInsurances",
    "caseProcedures"
})
public class Case {

    @JsonProperty("dateOfService")
    private String dateOfService;
    @JsonProperty("startTime")
    private String startTime;
    @JsonProperty("endTime")
    private String endTime;
    @JsonProperty("roomName")
    private String roomName;
    @JsonProperty("appointmentNote")
    private String appointmentNote;
    @JsonProperty("anesthesiaTypeName")
    private String anesthesiaTypeName;
    @JsonProperty("primaryPhysicianNPI")
    private String primaryPhysicianNPI;
    @JsonProperty("referringPhysicianNPI")
    private String referringPhysicianNPI;
    @JsonProperty("caseGuarantor")
    private List<CaseGuarantor> caseGuarantor = new ArrayList<CaseGuarantor>();
    @JsonProperty("caseInsurances")
    private List<CaseInsurance> caseInsurances = new ArrayList<CaseInsurance>();
    @JsonProperty("caseProcedures")
    private List<CaseProcedure> caseProcedures = new ArrayList<CaseProcedure>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dateOfService")
    public String getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public Case withDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
        return this;
    }

    @JsonProperty("startTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("startTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Case withStartTime(String startTime) {
        this.startTime = startTime;
        return this;
    }

    @JsonProperty("endTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("endTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Case withEndTime(String endTime) {
        this.endTime = endTime;
        return this;
    }

    @JsonProperty("roomName")
    public String getRoomName() {
        return roomName;
    }

    @JsonProperty("roomName")
    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public Case withRoomName(String roomName) {
        this.roomName = roomName;
        return this;
    }

    @JsonProperty("appointmentNote")
    public String getAppointmentNote() {
        return appointmentNote;
    }

    @JsonProperty("appointmentNote")
    public void setAppointmentNote(String appointmentNote) {
        this.appointmentNote = appointmentNote;
    }

    public Case withAppointmentNote(String appointmentNote) {
        this.appointmentNote = appointmentNote;
        return this;
    }

    @JsonProperty("anesthesiaTypeName")
    public String getAnesthesiaTypeName() {
        return anesthesiaTypeName;
    }

    @JsonProperty("anesthesiaTypeName")
    public void setAnesthesiaTypeName(String anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
    }

    public Case withAnesthesiaTypeName(String anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
        return this;
    }

    @JsonProperty("primaryPhysicianNPI")
    public String getPrimaryPhysicianNPI() {
        return primaryPhysicianNPI;
    }

    @JsonProperty("primaryPhysicianNPI")
    public void setPrimaryPhysicianNPI(String primaryPhysicianNPI) {
        this.primaryPhysicianNPI = primaryPhysicianNPI;
    }

    public Case withPrimaryPhysicianNPI(String primaryPhysicianNPI) {
        this.primaryPhysicianNPI = primaryPhysicianNPI;
        return this;
    }

    @JsonProperty("referringPhysicianNPI")
    public String getReferringPhysicianNPI() {
        return referringPhysicianNPI;
    }

    @JsonProperty("referringPhysicianNPI")
    public void setReferringPhysicianNPI(String referringPhysicianNPI) {
        this.referringPhysicianNPI = referringPhysicianNPI;
    }

    public Case withReferringPhysicianNPI(String referringPhysicianNPI) {
        this.referringPhysicianNPI = referringPhysicianNPI;
        return this;
    }

    @JsonProperty("caseGuarantor")
    public List<CaseGuarantor> getCaseGuarantor() {
        return caseGuarantor;
    }

    @JsonProperty("caseGuarantor")
    public void setCaseGuarantor(List<CaseGuarantor> caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
    }

    public Case withCaseGuarantor(List<CaseGuarantor> caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
        return this;
    }

    @JsonProperty("caseInsurances")
    public List<CaseInsurance> getCaseInsurances() {
        return caseInsurances;
    }

    @JsonProperty("caseInsurances")
    public void setCaseInsurances(List<CaseInsurance> caseInsurances) {
        this.caseInsurances = caseInsurances;
    }

    public Case withCaseInsurances(List<CaseInsurance> caseInsurances) {
        this.caseInsurances = caseInsurances;
        return this;
    }

    @JsonProperty("caseProcedures")
    public List<CaseProcedure> getCaseProcedures() {
        return caseProcedures;
    }

    @JsonProperty("caseProcedures")
    public void setCaseProcedures(List<CaseProcedure> caseProcedures) {
        this.caseProcedures = caseProcedures;
    }

    public Case withCaseProcedures(List<CaseProcedure> caseProcedures) {
        this.caseProcedures = caseProcedures;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Case withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dateOfService).append(startTime).append(endTime).append(roomName).append(appointmentNote).append(anesthesiaTypeName).append(primaryPhysicianNPI).append(referringPhysicianNPI).append(caseGuarantor).append(caseInsurances).append(caseProcedures).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Case) == false) {
            return false;
        }
        Case rhs = ((Case) other);
        return new EqualsBuilder().append(dateOfService, rhs.dateOfService).append(startTime, rhs.startTime).append(endTime, rhs.endTime).append(roomName, rhs.roomName).append(appointmentNote, rhs.appointmentNote).append(anesthesiaTypeName, rhs.anesthesiaTypeName).append(primaryPhysicianNPI, rhs.primaryPhysicianNPI).append(referringPhysicianNPI, rhs.referringPhysicianNPI).append(caseGuarantor, rhs.caseGuarantor).append(caseInsurances, rhs.caseInsurances).append(caseProcedures, rhs.caseProcedures).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
