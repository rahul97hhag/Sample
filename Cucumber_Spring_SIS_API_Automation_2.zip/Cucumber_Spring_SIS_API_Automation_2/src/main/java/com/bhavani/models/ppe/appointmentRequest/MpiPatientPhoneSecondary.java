
package com.bhavani.models.ppe.appointmentRequest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "primaryContactTf",
    "phoneNumber",
    "phoneExtension",
    "isCellPhoneTf",
    "phoneType"
})
public class MpiPatientPhoneSecondary {

    @JsonProperty("primaryContactTf")
    private Object primaryContactTf;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("phoneExtension")
    private Object phoneExtension;
    @JsonProperty("isCellPhoneTf")
    private Object isCellPhoneTf;
    @JsonProperty("phoneType")
    private String phoneType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("primaryContactTf")
    public Object getPrimaryContactTf() {
        return primaryContactTf;
    }

    @JsonProperty("primaryContactTf")
    public void setPrimaryContactTf(Object primaryContactTf) {
        this.primaryContactTf = primaryContactTf;
    }

    public MpiPatientPhoneSecondary withPrimaryContactTf(Object primaryContactTf) {
        this.primaryContactTf = primaryContactTf;
        return this;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public MpiPatientPhoneSecondary withPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("phoneExtension")
    public Object getPhoneExtension() {
        return phoneExtension;
    }

    @JsonProperty("phoneExtension")
    public void setPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public MpiPatientPhoneSecondary withPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
        return this;
    }

    @JsonProperty("isCellPhoneTf")
    public Object getIsCellPhoneTf() {
        return isCellPhoneTf;
    }

    @JsonProperty("isCellPhoneTf")
    public void setIsCellPhoneTf(Object isCellPhoneTf) {
        this.isCellPhoneTf = isCellPhoneTf;
    }

    public MpiPatientPhoneSecondary withIsCellPhoneTf(Object isCellPhoneTf) {
        this.isCellPhoneTf = isCellPhoneTf;
        return this;
    }

    @JsonProperty("phoneType")
    public String getPhoneType() {
        return phoneType;
    }

    @JsonProperty("phoneType")
    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public MpiPatientPhoneSecondary withPhoneType(String phoneType) {
        this.phoneType = phoneType;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MpiPatientPhoneSecondary withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(primaryContactTf).append(phoneNumber).append(phoneExtension).append(isCellPhoneTf).append(phoneType).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MpiPatientPhoneSecondary) == false) {
            return false;
        }
        MpiPatientPhoneSecondary rhs = ((MpiPatientPhoneSecondary) other);
        return new EqualsBuilder().append(primaryContactTf, rhs.primaryContactTf).append(phoneNumber, rhs.phoneNumber).append(phoneExtension, rhs.phoneExtension).append(isCellPhoneTf, rhs.isCellPhoneTf).append(phoneType, rhs.phoneType).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
