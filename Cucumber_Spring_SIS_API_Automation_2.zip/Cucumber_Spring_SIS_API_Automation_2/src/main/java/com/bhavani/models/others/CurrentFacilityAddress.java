
package com.bhavani.models.others;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "addressId",
    "addressType",
    "activeTf",
    "addressName1",
    "addressName2",
    "address1",
    "address2",
    "city",
    "state",
    "zipCode",
    "country",
    "county",
    "description",
    "mailingTf",
    "mainTf",
    "phoneNumber",
    "phoneExtension",
    "alterPhoneNumber",
    "alterPhoneExtension",
    "faxNumber",
    "globalAllocationNumber",
    "personId",
    "sourceIdentifier"
})
public class CurrentFacilityAddress {

    @JsonProperty("addressId")
    private Integer addressId;
    @JsonProperty("addressType")
    private Integer addressType;
    @JsonProperty("activeTf")
    private Object activeTf;
    @JsonProperty("addressName1")
    private Object addressName1;
    @JsonProperty("addressName2")
    private Object addressName2;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("address2")
    private String address2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("country")
    private String country;
    @JsonProperty("county")
    private Object county;
    @JsonProperty("description")
    private Object description;
    @JsonProperty("mailingTf")
    private Boolean mailingTf;
    @JsonProperty("mainTf")
    private Object mainTf;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("phoneExtension")
    private Object phoneExtension;
    @JsonProperty("alterPhoneNumber")
    private Object alterPhoneNumber;
    @JsonProperty("alterPhoneExtension")
    private Object alterPhoneExtension;
    @JsonProperty("faxNumber")
    private Object faxNumber;
    @JsonProperty("globalAllocationNumber")
    private Object globalAllocationNumber;
    @JsonProperty("personId")
    private Object personId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("addressId")
    public Integer getAddressId() {
        return addressId;
    }

    @JsonProperty("addressId")
    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    public CurrentFacilityAddress withAddressId(Integer addressId) {
        this.addressId = addressId;
        return this;
    }

    @JsonProperty("addressType")
    public Integer getAddressType() {
        return addressType;
    }

    @JsonProperty("addressType")
    public void setAddressType(Integer addressType) {
        this.addressType = addressType;
    }

    public CurrentFacilityAddress withAddressType(Integer addressType) {
        this.addressType = addressType;
        return this;
    }

    @JsonProperty("activeTf")
    public Object getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Object activeTf) {
        this.activeTf = activeTf;
    }

    public CurrentFacilityAddress withActiveTf(Object activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("addressName1")
    public Object getAddressName1() {
        return addressName1;
    }

    @JsonProperty("addressName1")
    public void setAddressName1(Object addressName1) {
        this.addressName1 = addressName1;
    }

    public CurrentFacilityAddress withAddressName1(Object addressName1) {
        this.addressName1 = addressName1;
        return this;
    }

    @JsonProperty("addressName2")
    public Object getAddressName2() {
        return addressName2;
    }

    @JsonProperty("addressName2")
    public void setAddressName2(Object addressName2) {
        this.addressName2 = addressName2;
    }

    public CurrentFacilityAddress withAddressName2(Object addressName2) {
        this.addressName2 = addressName2;
        return this;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public CurrentFacilityAddress withAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("address2")
    public String getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public CurrentFacilityAddress withAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public CurrentFacilityAddress withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public CurrentFacilityAddress withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public CurrentFacilityAddress withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    public CurrentFacilityAddress withCountry(String country) {
        this.country = country;
        return this;
    }

    @JsonProperty("county")
    public Object getCounty() {
        return county;
    }

    @JsonProperty("county")
    public void setCounty(Object county) {
        this.county = county;
    }

    public CurrentFacilityAddress withCounty(Object county) {
        this.county = county;
        return this;
    }

    @JsonProperty("description")
    public Object getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(Object description) {
        this.description = description;
    }

    public CurrentFacilityAddress withDescription(Object description) {
        this.description = description;
        return this;
    }

    @JsonProperty("mailingTf")
    public Boolean getMailingTf() {
        return mailingTf;
    }

    @JsonProperty("mailingTf")
    public void setMailingTf(Boolean mailingTf) {
        this.mailingTf = mailingTf;
    }

    public CurrentFacilityAddress withMailingTf(Boolean mailingTf) {
        this.mailingTf = mailingTf;
        return this;
    }

    @JsonProperty("mainTf")
    public Object getMainTf() {
        return mainTf;
    }

    @JsonProperty("mainTf")
    public void setMainTf(Object mainTf) {
        this.mainTf = mainTf;
    }

    public CurrentFacilityAddress withMainTf(Object mainTf) {
        this.mainTf = mainTf;
        return this;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public CurrentFacilityAddress withPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("phoneExtension")
    public Object getPhoneExtension() {
        return phoneExtension;
    }

    @JsonProperty("phoneExtension")
    public void setPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public CurrentFacilityAddress withPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
        return this;
    }

    @JsonProperty("alterPhoneNumber")
    public Object getAlterPhoneNumber() {
        return alterPhoneNumber;
    }

    @JsonProperty("alterPhoneNumber")
    public void setAlterPhoneNumber(Object alterPhoneNumber) {
        this.alterPhoneNumber = alterPhoneNumber;
    }

    public CurrentFacilityAddress withAlterPhoneNumber(Object alterPhoneNumber) {
        this.alterPhoneNumber = alterPhoneNumber;
        return this;
    }

    @JsonProperty("alterPhoneExtension")
    public Object getAlterPhoneExtension() {
        return alterPhoneExtension;
    }

    @JsonProperty("alterPhoneExtension")
    public void setAlterPhoneExtension(Object alterPhoneExtension) {
        this.alterPhoneExtension = alterPhoneExtension;
    }

    public CurrentFacilityAddress withAlterPhoneExtension(Object alterPhoneExtension) {
        this.alterPhoneExtension = alterPhoneExtension;
        return this;
    }

    @JsonProperty("faxNumber")
    public Object getFaxNumber() {
        return faxNumber;
    }

    @JsonProperty("faxNumber")
    public void setFaxNumber(Object faxNumber) {
        this.faxNumber = faxNumber;
    }

    public CurrentFacilityAddress withFaxNumber(Object faxNumber) {
        this.faxNumber = faxNumber;
        return this;
    }

    @JsonProperty("globalAllocationNumber")
    public Object getGlobalAllocationNumber() {
        return globalAllocationNumber;
    }

    @JsonProperty("globalAllocationNumber")
    public void setGlobalAllocationNumber(Object globalAllocationNumber) {
        this.globalAllocationNumber = globalAllocationNumber;
    }

    public CurrentFacilityAddress withGlobalAllocationNumber(Object globalAllocationNumber) {
        this.globalAllocationNumber = globalAllocationNumber;
        return this;
    }

    @JsonProperty("personId")
    public Object getPersonId() {
        return personId;
    }

    @JsonProperty("personId")
    public void setPersonId(Object personId) {
        this.personId = personId;
    }

    public CurrentFacilityAddress withPersonId(Object personId) {
        this.personId = personId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public CurrentFacilityAddress withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CurrentFacilityAddress withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(addressId).append(addressType).append(activeTf).append(addressName1).append(addressName2).append(address1).append(address2).append(city).append(state).append(zipCode).append(country).append(county).append(description).append(mailingTf).append(mainTf).append(phoneNumber).append(phoneExtension).append(alterPhoneNumber).append(alterPhoneExtension).append(faxNumber).append(globalAllocationNumber).append(personId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CurrentFacilityAddress) == false) {
            return false;
        }
        CurrentFacilityAddress rhs = ((CurrentFacilityAddress) other);
        return new EqualsBuilder().append(addressId, rhs.addressId).append(addressType, rhs.addressType).append(activeTf, rhs.activeTf).append(addressName1, rhs.addressName1).append(addressName2, rhs.addressName2).append(address1, rhs.address1).append(address2, rhs.address2).append(city, rhs.city).append(state, rhs.state).append(zipCode, rhs.zipCode).append(country, rhs.country).append(county, rhs.county).append(description, rhs.description).append(mailingTf, rhs.mailingTf).append(mainTf, rhs.mainTf).append(phoneNumber, rhs.phoneNumber).append(phoneExtension, rhs.phoneExtension).append(alterPhoneNumber, rhs.alterPhoneNumber).append(alterPhoneExtension, rhs.alterPhoneExtension).append(faxNumber, rhs.faxNumber).append(globalAllocationNumber, rhs.globalAllocationNumber).append(personId, rhs.personId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
