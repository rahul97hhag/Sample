
package com.bhavani.models.ppe.appointmentRequest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "icdCodeId",
    "icdCode",
    "icdCodeDescription",
    "sourceIdentifier"
})
public class DiagnosisList {

    @JsonProperty("icdCodeId")
    private Integer icdCodeId;
    @JsonProperty("icdCode")
    private String icdCode;
    @JsonProperty("icdCodeDescription")
    private String icdCodeDescription;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("icdCodeId")
    public Integer getIcdCodeId() {
        return icdCodeId;
    }

    @JsonProperty("icdCodeId")
    public void setIcdCodeId(Integer icdCodeId) {
        this.icdCodeId = icdCodeId;
    }

    public DiagnosisList withIcdCodeId(Integer icdCodeId) {
        this.icdCodeId = icdCodeId;
        return this;
    }

    @JsonProperty("icdCode")
    public String getIcdCode() {
        return icdCode;
    }

    @JsonProperty("icdCode")
    public void setIcdCode(String icdCode) {
        this.icdCode = icdCode;
    }

    public DiagnosisList withIcdCode(String icdCode) {
        this.icdCode = icdCode;
        return this;
    }

    @JsonProperty("icdCodeDescription")
    public String getIcdCodeDescription() {
        return icdCodeDescription;
    }

    @JsonProperty("icdCodeDescription")
    public void setIcdCodeDescription(String icdCodeDescription) {
        this.icdCodeDescription = icdCodeDescription;
    }

    public DiagnosisList withIcdCodeDescription(String icdCodeDescription) {
        this.icdCodeDescription = icdCodeDescription;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public DiagnosisList withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DiagnosisList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(icdCodeId).append(icdCode).append(icdCodeDescription).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DiagnosisList) == false) {
            return false;
        }
        DiagnosisList rhs = ((DiagnosisList) other);
        return new EqualsBuilder().append(icdCodeId, rhs.icdCodeId).append(icdCode, rhs.icdCode).append(icdCodeDescription, rhs.icdCodeDescription).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
