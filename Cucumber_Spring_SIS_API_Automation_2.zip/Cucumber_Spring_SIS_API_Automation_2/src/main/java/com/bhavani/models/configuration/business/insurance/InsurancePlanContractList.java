
package com.bhavani.models.configuration.business.insurance;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insurancePlanContractId",
    "insurancePlanId",
    "insuranceContractId",
    "insuranceContractName",
    "sortOrder",
    "isSelected"
})
public class InsurancePlanContractList {

    @JsonProperty("insurancePlanContractId")
    private Integer insurancePlanContractId;
    @JsonProperty("insurancePlanId")
    private Integer insurancePlanId;
    @JsonProperty("insuranceContractId")
    private Integer insuranceContractId;
    @JsonProperty("insuranceContractName")
    private String insuranceContractName;
    @JsonProperty("sortOrder")
    private Integer sortOrder;
    @JsonProperty("isSelected")
    private Boolean isSelected;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insurancePlanContractId")
    public Integer getInsurancePlanContractId() {
        return insurancePlanContractId;
    }

    @JsonProperty("insurancePlanContractId")
    public void setInsurancePlanContractId(Integer insurancePlanContractId) {
        this.insurancePlanContractId = insurancePlanContractId;
    }

    public InsurancePlanContractList withInsurancePlanContractId(Integer insurancePlanContractId) {
        this.insurancePlanContractId = insurancePlanContractId;
        return this;
    }

    @JsonProperty("insurancePlanId")
    public Integer getInsurancePlanId() {
        return insurancePlanId;
    }

    @JsonProperty("insurancePlanId")
    public void setInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
    }

    public InsurancePlanContractList withInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
        return this;
    }

    @JsonProperty("insuranceContractId")
    public Integer getInsuranceContractId() {
        return insuranceContractId;
    }

    @JsonProperty("insuranceContractId")
    public void setInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
    }

    public InsurancePlanContractList withInsuranceContractId(Integer insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
        return this;
    }

    @JsonProperty("insuranceContractName")
    public String getInsuranceContractName() {
        return insuranceContractName;
    }

    @JsonProperty("insuranceContractName")
    public void setInsuranceContractName(String insuranceContractName) {
        this.insuranceContractName = insuranceContractName;
    }

    public InsurancePlanContractList withInsuranceContractName(String insuranceContractName) {
        this.insuranceContractName = insuranceContractName;
        return this;
    }

    @JsonProperty("sortOrder")
    public Integer getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public InsurancePlanContractList withSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("isSelected")
    public Boolean getIsSelected() {
        return isSelected;
    }

    @JsonProperty("isSelected")
    public void setIsSelected(Boolean isSelected) {
        this.isSelected = isSelected;
    }

    public InsurancePlanContractList withIsSelected(Boolean isSelected) {
        this.isSelected = isSelected;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsurancePlanContractList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insurancePlanContractId).append(insurancePlanId).append(insuranceContractId).append(insuranceContractName).append(sortOrder).append(isSelected).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsurancePlanContractList) == false) {
            return false;
        }
        InsurancePlanContractList rhs = ((InsurancePlanContractList) other);
        return new EqualsBuilder().append(insurancePlanContractId, rhs.insurancePlanContractId).append(insurancePlanId, rhs.insurancePlanId).append(insuranceContractId, rhs.insuranceContractId).append(insuranceContractName, rhs.insuranceContractName).append(sortOrder, rhs.sortOrder).append(isSelected, rhs.isSelected).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
