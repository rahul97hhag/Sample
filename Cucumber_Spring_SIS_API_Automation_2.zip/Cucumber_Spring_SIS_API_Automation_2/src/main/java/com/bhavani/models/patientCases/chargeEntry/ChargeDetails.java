
package com.bhavani.models.patientCases.chargeEntry;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "peformedCaseProcedureId",
    "balance",
    "actualBalance",
    "chargeEntryLevelTransactionsAmount",
    "typeOfBill",
    "sourceOfRevenueId",
    "selfPay",
    "workersCompensation",
    "revenueCodeId",
    "revenueCode",
    "transactionId",
    "deductibleAmount",
    "coInsuranceAmount",
    "coPaymentAmount",
    "billId",
    "corrected",
    "generateBill",
    "generateBillStateModified",
    "patientResponsibilityCoPayments",
    "sourceIdentifier"
})
public class ChargeDetails {

    @JsonProperty("peformedCaseProcedureId")
    private Integer peformedCaseProcedureId;
    @JsonProperty("balance")
    private Integer balance;
    @JsonProperty("actualBalance")
    private Object actualBalance;
    @JsonProperty("chargeEntryLevelTransactionsAmount")
    private Integer chargeEntryLevelTransactionsAmount;
    @JsonProperty("typeOfBill")
    private String typeOfBill;
    @JsonProperty("sourceOfRevenueId")
    private Object sourceOfRevenueId;
    @JsonProperty("selfPay")
    private Boolean selfPay;
    @JsonProperty("workersCompensation")
    private Boolean workersCompensation;
    @JsonProperty("revenueCodeId")
    private Integer revenueCodeId;
    @JsonProperty("revenueCode")
    private Object revenueCode;
    @JsonProperty("transactionId")
    private Integer transactionId;
    @JsonProperty("deductibleAmount")
    private Object deductibleAmount;
    @JsonProperty("coInsuranceAmount")
    private Object coInsuranceAmount;
    @JsonProperty("coPaymentAmount")
    private Object coPaymentAmount;
    @JsonProperty("billId")
    private Object billId;
    @JsonProperty("corrected")
    private Boolean corrected;
    @JsonProperty("generateBill")
    private Boolean generateBill;
    @JsonProperty("generateBillStateModified")
    private Boolean generateBillStateModified;
    @JsonProperty("patientResponsibilityCoPayments")
    private Object patientResponsibilityCoPayments;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("peformedCaseProcedureId")
    public Integer getPeformedCaseProcedureId() {
        return peformedCaseProcedureId;
    }

    @JsonProperty("peformedCaseProcedureId")
    public void setPeformedCaseProcedureId(Integer peformedCaseProcedureId) {
        this.peformedCaseProcedureId = peformedCaseProcedureId;
    }

    public ChargeDetails withPeformedCaseProcedureId(Integer peformedCaseProcedureId) {
        this.peformedCaseProcedureId = peformedCaseProcedureId;
        return this;
    }

    @JsonProperty("balance")
    public Integer getBalance() {
        return balance;
    }

    @JsonProperty("balance")
    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public ChargeDetails withBalance(Integer balance) {
        this.balance = balance;
        return this;
    }

    @JsonProperty("actualBalance")
    public Object getActualBalance() {
        return actualBalance;
    }

    @JsonProperty("actualBalance")
    public void setActualBalance(Object actualBalance) {
        this.actualBalance = actualBalance;
    }

    public ChargeDetails withActualBalance(Object actualBalance) {
        this.actualBalance = actualBalance;
        return this;
    }

    @JsonProperty("chargeEntryLevelTransactionsAmount")
    public Integer getChargeEntryLevelTransactionsAmount() {
        return chargeEntryLevelTransactionsAmount;
    }

    @JsonProperty("chargeEntryLevelTransactionsAmount")
    public void setChargeEntryLevelTransactionsAmount(Integer chargeEntryLevelTransactionsAmount) {
        this.chargeEntryLevelTransactionsAmount = chargeEntryLevelTransactionsAmount;
    }

    public ChargeDetails withChargeEntryLevelTransactionsAmount(Integer chargeEntryLevelTransactionsAmount) {
        this.chargeEntryLevelTransactionsAmount = chargeEntryLevelTransactionsAmount;
        return this;
    }

    @JsonProperty("typeOfBill")
    public String getTypeOfBill() {
        return typeOfBill;
    }

    @JsonProperty("typeOfBill")
    public void setTypeOfBill(String typeOfBill) {
        this.typeOfBill = typeOfBill;
    }

    public ChargeDetails withTypeOfBill(String typeOfBill) {
        this.typeOfBill = typeOfBill;
        return this;
    }

    @JsonProperty("sourceOfRevenueId")
    public Object getSourceOfRevenueId() {
        return sourceOfRevenueId;
    }

    @JsonProperty("sourceOfRevenueId")
    public void setSourceOfRevenueId(Object sourceOfRevenueId) {
        this.sourceOfRevenueId = sourceOfRevenueId;
    }

    public ChargeDetails withSourceOfRevenueId(Object sourceOfRevenueId) {
        this.sourceOfRevenueId = sourceOfRevenueId;
        return this;
    }

    @JsonProperty("selfPay")
    public Boolean getSelfPay() {
        return selfPay;
    }

    @JsonProperty("selfPay")
    public void setSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
    }

    public ChargeDetails withSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
        return this;
    }

    @JsonProperty("workersCompensation")
    public Boolean getWorkersCompensation() {
        return workersCompensation;
    }

    @JsonProperty("workersCompensation")
    public void setWorkersCompensation(Boolean workersCompensation) {
        this.workersCompensation = workersCompensation;
    }

    public ChargeDetails withWorkersCompensation(Boolean workersCompensation) {
        this.workersCompensation = workersCompensation;
        return this;
    }

    @JsonProperty("revenueCodeId")
    public Integer getRevenueCodeId() {
        return revenueCodeId;
    }

    @JsonProperty("revenueCodeId")
    public void setRevenueCodeId(Integer revenueCodeId) {
        this.revenueCodeId = revenueCodeId;
    }

    public ChargeDetails withRevenueCodeId(Integer revenueCodeId) {
        this.revenueCodeId = revenueCodeId;
        return this;
    }

    @JsonProperty("revenueCode")
    public Object getRevenueCode() {
        return revenueCode;
    }

    @JsonProperty("revenueCode")
    public void setRevenueCode(Object revenueCode) {
        this.revenueCode = revenueCode;
    }

    public ChargeDetails withRevenueCode(Object revenueCode) {
        this.revenueCode = revenueCode;
        return this;
    }

    @JsonProperty("transactionId")
    public Integer getTransactionId() {
        return transactionId;
    }

    @JsonProperty("transactionId")
    public void setTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
    }

    public ChargeDetails withTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
        return this;
    }

    @JsonProperty("deductibleAmount")
    public Object getDeductibleAmount() {
        return deductibleAmount;
    }

    @JsonProperty("deductibleAmount")
    public void setDeductibleAmount(Object deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public ChargeDetails withDeductibleAmount(Object deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
        return this;
    }

    @JsonProperty("coInsuranceAmount")
    public Object getCoInsuranceAmount() {
        return coInsuranceAmount;
    }

    @JsonProperty("coInsuranceAmount")
    public void setCoInsuranceAmount(Object coInsuranceAmount) {
        this.coInsuranceAmount = coInsuranceAmount;
    }

    public ChargeDetails withCoInsuranceAmount(Object coInsuranceAmount) {
        this.coInsuranceAmount = coInsuranceAmount;
        return this;
    }

    @JsonProperty("coPaymentAmount")
    public Object getCoPaymentAmount() {
        return coPaymentAmount;
    }

    @JsonProperty("coPaymentAmount")
    public void setCoPaymentAmount(Object coPaymentAmount) {
        this.coPaymentAmount = coPaymentAmount;
    }

    public ChargeDetails withCoPaymentAmount(Object coPaymentAmount) {
        this.coPaymentAmount = coPaymentAmount;
        return this;
    }

    @JsonProperty("billId")
    public Object getBillId() {
        return billId;
    }

    @JsonProperty("billId")
    public void setBillId(Object billId) {
        this.billId = billId;
    }

    public ChargeDetails withBillId(Object billId) {
        this.billId = billId;
        return this;
    }

    @JsonProperty("corrected")
    public Boolean getCorrected() {
        return corrected;
    }

    @JsonProperty("corrected")
    public void setCorrected(Boolean corrected) {
        this.corrected = corrected;
    }

    public ChargeDetails withCorrected(Boolean corrected) {
        this.corrected = corrected;
        return this;
    }

    @JsonProperty("generateBill")
    public Boolean getGenerateBill() {
        return generateBill;
    }

    @JsonProperty("generateBill")
    public void setGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
    }

    public ChargeDetails withGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
        return this;
    }

    @JsonProperty("generateBillStateModified")
    public Boolean getGenerateBillStateModified() {
        return generateBillStateModified;
    }

    @JsonProperty("generateBillStateModified")
    public void setGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
    }

    public ChargeDetails withGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
        return this;
    }

    @JsonProperty("patientResponsibilityCoPayments")
    public Object getPatientResponsibilityCoPayments() {
        return patientResponsibilityCoPayments;
    }

    @JsonProperty("patientResponsibilityCoPayments")
    public void setPatientResponsibilityCoPayments(Object patientResponsibilityCoPayments) {
        this.patientResponsibilityCoPayments = patientResponsibilityCoPayments;
    }

    public ChargeDetails withPatientResponsibilityCoPayments(Object patientResponsibilityCoPayments) {
        this.patientResponsibilityCoPayments = patientResponsibilityCoPayments;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public ChargeDetails withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ChargeDetails withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(peformedCaseProcedureId).append(balance).append(actualBalance).append(chargeEntryLevelTransactionsAmount).append(typeOfBill).append(sourceOfRevenueId).append(selfPay).append(workersCompensation).append(revenueCodeId).append(revenueCode).append(transactionId).append(deductibleAmount).append(coInsuranceAmount).append(coPaymentAmount).append(billId).append(corrected).append(generateBill).append(generateBillStateModified).append(patientResponsibilityCoPayments).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChargeDetails) == false) {
            return false;
        }
        ChargeDetails rhs = ((ChargeDetails) other);
        return new EqualsBuilder().append(peformedCaseProcedureId, rhs.peformedCaseProcedureId).append(balance, rhs.balance).append(actualBalance, rhs.actualBalance).append(chargeEntryLevelTransactionsAmount, rhs.chargeEntryLevelTransactionsAmount).append(typeOfBill, rhs.typeOfBill).append(sourceOfRevenueId, rhs.sourceOfRevenueId).append(selfPay, rhs.selfPay).append(workersCompensation, rhs.workersCompensation).append(revenueCodeId, rhs.revenueCodeId).append(revenueCode, rhs.revenueCode).append(transactionId, rhs.transactionId).append(deductibleAmount, rhs.deductibleAmount).append(coInsuranceAmount, rhs.coInsuranceAmount).append(coPaymentAmount, rhs.coPaymentAmount).append(billId, rhs.billId).append(corrected, rhs.corrected).append(generateBill, rhs.generateBill).append(generateBillStateModified, rhs.generateBillStateModified).append(patientResponsibilityCoPayments, rhs.patientResponsibilityCoPayments).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
