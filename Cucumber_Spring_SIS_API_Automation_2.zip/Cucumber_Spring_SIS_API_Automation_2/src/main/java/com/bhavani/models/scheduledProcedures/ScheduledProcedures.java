
package com.bhavani.models.scheduledProcedures;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caseSummaryId",
    "caseProcedureId",
    "cptProcedureId",
    "procedureDescription",
    "procedureName",
    "cptCode",
    "cptDescription",
    "laterality",
    "feeScheduleId",
    "physicianId",
    "physicianName",
    "preopDiagnosisList",
    "feeScheduleItem",
    "generateBill",
    "selfPay",
    "sourceIdentifier"
})
public class ScheduledProcedures {

    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("caseProcedureId")
    private Integer caseProcedureId;
    @JsonProperty("cptProcedureId")
    private Integer cptProcedureId;
    @JsonProperty("procedureDescription")
    private String procedureDescription;
    @JsonProperty("procedureName")
    private String procedureName;
    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("cptDescription")
    private String cptDescription;
    @JsonProperty("laterality")
    private Integer laterality;
    @JsonProperty("feeScheduleId")
    private Integer feeScheduleId;
    @JsonProperty("physicianId")
    private Integer physicianId;
    @JsonProperty("physicianName")
    private String physicianName;
    @JsonProperty("preopDiagnosisList")
    private List<Object> preopDiagnosisList = new ArrayList<Object>();
    @JsonProperty("feeScheduleItem")
    private FeeScheduleItem feeScheduleItem;
    @JsonProperty("generateBill")
    private Boolean generateBill;
    @JsonProperty("selfPay")
    private Boolean selfPay;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public ScheduledProcedures withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("caseProcedureId")
    public Integer getCaseProcedureId() {
        return caseProcedureId;
    }

    @JsonProperty("caseProcedureId")
    public void setCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
    }

    public ScheduledProcedures withCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
        return this;
    }

    @JsonProperty("cptProcedureId")
    public Integer getCptProcedureId() {
        return cptProcedureId;
    }

    @JsonProperty("cptProcedureId")
    public void setCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
    }

    public ScheduledProcedures withCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
        return this;
    }

    @JsonProperty("procedureDescription")
    public String getProcedureDescription() {
        return procedureDescription;
    }

    @JsonProperty("procedureDescription")
    public void setProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
    }

    public ScheduledProcedures withProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
        return this;
    }

    @JsonProperty("procedureName")
    public String getProcedureName() {
        return procedureName;
    }

    @JsonProperty("procedureName")
    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public ScheduledProcedures withProcedureName(String procedureName) {
        this.procedureName = procedureName;
        return this;
    }

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public ScheduledProcedures withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("cptDescription")
    public String getCptDescription() {
        return cptDescription;
    }

    @JsonProperty("cptDescription")
    public void setCptDescription(String cptDescription) {
        this.cptDescription = cptDescription;
    }

    public ScheduledProcedures withCptDescription(String cptDescription) {
        this.cptDescription = cptDescription;
        return this;
    }

    @JsonProperty("laterality")
    public Integer getLaterality() {
        return laterality;
    }

    @JsonProperty("laterality")
    public void setLaterality(Integer laterality) {
        this.laterality = laterality;
    }

    public ScheduledProcedures withLaterality(Integer laterality) {
        this.laterality = laterality;
        return this;
    }

    @JsonProperty("feeScheduleId")
    public Integer getFeeScheduleId() {
        return feeScheduleId;
    }

    @JsonProperty("feeScheduleId")
    public void setFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
    }

    public ScheduledProcedures withFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
        return this;
    }

    @JsonProperty("physicianId")
    public Integer getPhysicianId() {
        return physicianId;
    }

    @JsonProperty("physicianId")
    public void setPhysicianId(Integer physicianId) {
        this.physicianId = physicianId;
    }

    public ScheduledProcedures withPhysicianId(Integer physicianId) {
        this.physicianId = physicianId;
        return this;
    }

    @JsonProperty("physicianName")
    public String getPhysicianName() {
        return physicianName;
    }

    @JsonProperty("physicianName")
    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public ScheduledProcedures withPhysicianName(String physicianName) {
        this.physicianName = physicianName;
        return this;
    }

    @JsonProperty("preopDiagnosisList")
    public List<Object> getPreopDiagnosisList() {
        return preopDiagnosisList;
    }

    @JsonProperty("preopDiagnosisList")
    public void setPreopDiagnosisList(List<Object> preopDiagnosisList) {
        this.preopDiagnosisList = preopDiagnosisList;
    }

    public ScheduledProcedures withPreopDiagnosisList(List<Object> preopDiagnosisList) {
        this.preopDiagnosisList = preopDiagnosisList;
        return this;
    }

    @JsonProperty("feeScheduleItem")
    public FeeScheduleItem getFeeScheduleItem() {
        return feeScheduleItem;
    }

    @JsonProperty("feeScheduleItem")
    public void setFeeScheduleItem(FeeScheduleItem feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
    }

    public ScheduledProcedures withFeeScheduleItem(FeeScheduleItem feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
        return this;
    }

    @JsonProperty("generateBill")
    public Boolean getGenerateBill() {
        return generateBill;
    }

    @JsonProperty("generateBill")
    public void setGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
    }

    public ScheduledProcedures withGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
        return this;
    }

    @JsonProperty("selfPay")
    public Boolean getSelfPay() {
        return selfPay;
    }

    @JsonProperty("selfPay")
    public void setSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
    }

    public ScheduledProcedures withSelfPay(Boolean selfPay) {
        this.selfPay = selfPay;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public ScheduledProcedures withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ScheduledProcedures withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(caseSummaryId).append(caseProcedureId).append(cptProcedureId).append(procedureDescription).append(procedureName).append(cptCode).append(cptDescription).append(laterality).append(feeScheduleId).append(physicianId).append(physicianName).append(preopDiagnosisList).append(feeScheduleItem).append(generateBill).append(selfPay).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ScheduledProcedures) == false) {
            return false;
        }
        ScheduledProcedures rhs = ((ScheduledProcedures) other);
        return new EqualsBuilder().append(caseSummaryId, rhs.caseSummaryId).append(caseProcedureId, rhs.caseProcedureId).append(cptProcedureId, rhs.cptProcedureId).append(procedureDescription, rhs.procedureDescription).append(procedureName, rhs.procedureName).append(cptCode, rhs.cptCode).append(cptDescription, rhs.cptDescription).append(laterality, rhs.laterality).append(feeScheduleId, rhs.feeScheduleId).append(physicianId, rhs.physicianId).append(physicianName, rhs.physicianName).append(preopDiagnosisList, rhs.preopDiagnosisList).append(feeScheduleItem, rhs.feeScheduleItem).append(generateBill, rhs.generateBill).append(selfPay, rhs.selfPay).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
