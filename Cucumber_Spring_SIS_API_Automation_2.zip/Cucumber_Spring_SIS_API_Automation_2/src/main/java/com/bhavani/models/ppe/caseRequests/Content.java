
package com.bhavani.models.ppe.caseRequests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patient",
    "case",
    "attachments",
    "random"
})
public class Content {

    @JsonProperty("patient")
    private Patient patient;
    @JsonProperty("case")
    private Case _case;
    @JsonProperty("attachments")
    private List<Object> attachments = new ArrayList<Object>();
    @JsonProperty("random")
    private Object random;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patient")
    public Patient getPatient() {
        return patient;
    }

    @JsonProperty("patient")
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Content withPatient(Patient patient) {
        this.patient = patient;
        return this;
    }

    @JsonProperty("case")
    public Case getCase() {
        return _case;
    }

    @JsonProperty("case")
    public void setCase(Case _case) {
        this._case = _case;
    }

    public Content withCase(Case _case) {
        this._case = _case;
        return this;
    }

    @JsonProperty("attachments")
    public List<Object> getAttachments() {
        return attachments;
    }

    @JsonProperty("attachments")
    public void setAttachments(List<Object> attachments) {
        this.attachments = attachments;
    }

    public Content withAttachments(List<Object> attachments) {
        this.attachments = attachments;
        return this;
    }

    @JsonProperty("random")
    public Object getRandom() {
        return random;
    }

    @JsonProperty("random")
    public void setRandom(Object random) {
        this.random = random;
    }

    public Content withRandom(Object random) {
        this.random = random;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Content withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patient).append(_case).append(attachments).append(random).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Content) == false) {
            return false;
        }
        Content rhs = ((Content) other);
        return new EqualsBuilder().append(patient, rhs.patient).append(_case, rhs._case).append(attachments, rhs.attachments).append(random, rhs.random).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
