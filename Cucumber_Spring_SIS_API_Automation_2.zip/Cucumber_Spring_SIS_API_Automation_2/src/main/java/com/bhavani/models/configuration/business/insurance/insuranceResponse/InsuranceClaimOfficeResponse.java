
package com.bhavani.models.configuration.business.insurance.insuranceResponse;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "claimOfficeId",
    "line1",
    "line2",
    "city",
    "state",
    "zip",
    "country",
    "county",
    "extendedZip",
    "name",
    "phone",
    "contactName",
    "insuranceCarrierObjectId",
    "externalId",
    "sourceIdentifier"
})
public class InsuranceClaimOfficeResponse {

    @JsonProperty("claimOfficeId")
    private Integer claimOfficeId;
    @JsonProperty("line1")
    private String line1;
    @JsonProperty("line2")
    private Object line2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("country")
    private Object country;
    @JsonProperty("county")
    private Object county;
    @JsonProperty("extendedZip")
    private String extendedZip;
    @JsonProperty("name")
    private String name;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("contactName")
    private String contactName;
    @JsonProperty("insuranceCarrierObjectId")
    private Integer insuranceCarrierObjectId;
    @JsonProperty("externalId")
    private Object externalId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("claimOfficeId")
    public Integer getClaimOfficeId() {
        return claimOfficeId;
    }

    @JsonProperty("claimOfficeId")
    public void setClaimOfficeId(Integer claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
    }

    public InsuranceClaimOfficeResponse withClaimOfficeId(Integer claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
        return this;
    }

    @JsonProperty("line1")
    public String getLine1() {
        return line1;
    }

    @JsonProperty("line1")
    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public InsuranceClaimOfficeResponse withLine1(String line1) {
        this.line1 = line1;
        return this;
    }

    @JsonProperty("line2")
    public Object getLine2() {
        return line2;
    }

    @JsonProperty("line2")
    public void setLine2(Object line2) {
        this.line2 = line2;
    }

    public InsuranceClaimOfficeResponse withLine2(Object line2) {
        this.line2 = line2;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public InsuranceClaimOfficeResponse withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public InsuranceClaimOfficeResponse withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zip")
    public String getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(String zip) {
        this.zip = zip;
    }

    public InsuranceClaimOfficeResponse withZip(String zip) {
        this.zip = zip;
        return this;
    }

    @JsonProperty("country")
    public Object getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(Object country) {
        this.country = country;
    }

    public InsuranceClaimOfficeResponse withCountry(Object country) {
        this.country = country;
        return this;
    }

    @JsonProperty("county")
    public Object getCounty() {
        return county;
    }

    @JsonProperty("county")
    public void setCounty(Object county) {
        this.county = county;
    }

    public InsuranceClaimOfficeResponse withCounty(Object county) {
        this.county = county;
        return this;
    }

    @JsonProperty("extendedZip")
    public String getExtendedZip() {
        return extendedZip;
    }

    @JsonProperty("extendedZip")
    public void setExtendedZip(String extendedZip) {
        this.extendedZip = extendedZip;
    }

    public InsuranceClaimOfficeResponse withExtendedZip(String extendedZip) {
        this.extendedZip = extendedZip;
        return this;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public InsuranceClaimOfficeResponse withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public InsuranceClaimOfficeResponse withPhone(String phone) {
        this.phone = phone;
        return this;
    }

    @JsonProperty("contactName")
    public String getContactName() {
        return contactName;
    }

    @JsonProperty("contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public InsuranceClaimOfficeResponse withContactName(String contactName) {
        this.contactName = contactName;
        return this;
    }

    @JsonProperty("insuranceCarrierObjectId")
    public Integer getInsuranceCarrierObjectId() {
        return insuranceCarrierObjectId;
    }

    @JsonProperty("insuranceCarrierObjectId")
    public void setInsuranceCarrierObjectId(Integer insuranceCarrierObjectId) {
        this.insuranceCarrierObjectId = insuranceCarrierObjectId;
    }

    public InsuranceClaimOfficeResponse withInsuranceCarrierObjectId(Integer insuranceCarrierObjectId) {
        this.insuranceCarrierObjectId = insuranceCarrierObjectId;
        return this;
    }

    @JsonProperty("externalId")
    public Object getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Object externalId) {
        this.externalId = externalId;
    }

    public InsuranceClaimOfficeResponse withExternalId(Object externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public InsuranceClaimOfficeResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsuranceClaimOfficeResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(claimOfficeId).append(line1).append(line2).append(city).append(state).append(zip).append(country).append(county).append(extendedZip).append(name).append(phone).append(contactName).append(insuranceCarrierObjectId).append(externalId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsuranceClaimOfficeResponse) == false) {
            return false;
        }
        InsuranceClaimOfficeResponse rhs = ((InsuranceClaimOfficeResponse) other);
        return new EqualsBuilder().append(claimOfficeId, rhs.claimOfficeId).append(line1, rhs.line1).append(line2, rhs.line2).append(city, rhs.city).append(state, rhs.state).append(zip, rhs.zip).append(country, rhs.country).append(county, rhs.county).append(extendedZip, rhs.extendedZip).append(name, rhs.name).append(phone, rhs.phone).append(contactName, rhs.contactName).append(insuranceCarrierObjectId, rhs.insuranceCarrierObjectId).append(externalId, rhs.externalId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
