
package com.bhavani.models.schedulingData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientId",
    "firstName",
    "lastName",
    "middleInitial",
    "title",
    "dateOfBirth",
    "gender",
    "accountNumber",
    "noKnownDrugAllergyTf",
    "noKnownNonDrugAllergyTf",
    "noKnownLatexAllergyTf",
    "noHomeMedicationTf",
    "email",
    "alias",
    "patientLanguage",
    "maritalStatusId",
    "maritalStatus",
    "raceId",
    "race",
    "ethnicityId",
    "ethnicity",
    "occupation",
    "religionId",
    "religion",
    "medsLastLoaded",
    "externalAccountNumber",
    "adtMaintainedFieldArray",
    "adtLockedFieldList",
    "patientPhones",
    "mpiPatientPhone",
    "mpiPatientPhoneSecondary",
    "patientImage",
    "address",
    "emergencyContact",
    "isPatientExists",
    "employer",
    "lockingUser",
    "isLockExists",
    "ssn",
    "patientGuarantor",
    "fullName",
    "fullNameWithTitle",
    "procedureDt",
    "primaryProcedure",
    "mpiPatientAge",
    "sourceIdentifier"
})
public class Patient {

    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private Object middleInitial;
    @JsonProperty("title")
    private Object title;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("noKnownDrugAllergyTf")
    private Object noKnownDrugAllergyTf;
    @JsonProperty("noKnownNonDrugAllergyTf")
    private Object noKnownNonDrugAllergyTf;
    @JsonProperty("noKnownLatexAllergyTf")
    private Object noKnownLatexAllergyTf;
    @JsonProperty("noHomeMedicationTf")
    private Object noHomeMedicationTf;
    @JsonProperty("email")
    private Object email;
    @JsonProperty("alias")
    private Object alias;
    @JsonProperty("patientLanguage")
    private Object patientLanguage;
    @JsonProperty("maritalStatusId")
    private Object maritalStatusId;
    @JsonProperty("maritalStatus")
    private Object maritalStatus;
    @JsonProperty("raceId")
    private Object raceId;
    @JsonProperty("race")
    private Object race;
    @JsonProperty("ethnicityId")
    private Object ethnicityId;
    @JsonProperty("ethnicity")
    private Object ethnicity;
    @JsonProperty("occupation")
    private Object occupation;
    @JsonProperty("religionId")
    private Object religionId;
    @JsonProperty("religion")
    private Object religion;
    @JsonProperty("medsLastLoaded")
    private Object medsLastLoaded;
    @JsonProperty("externalAccountNumber")
    private Object externalAccountNumber;
    @JsonProperty("adtMaintainedFieldArray")
    private List<Object> adtMaintainedFieldArray = new ArrayList<Object>();
    @JsonProperty("adtLockedFieldList")
    private List<Object> adtLockedFieldList = new ArrayList<Object>();
    @JsonProperty("patientPhones")
    private Object patientPhones;
    @JsonProperty("mpiPatientPhone")
    private MpiPatientPhone mpiPatientPhone;
    @JsonProperty("mpiPatientPhoneSecondary")
    private MpiPatientPhoneSecondary mpiPatientPhoneSecondary;
    @JsonProperty("patientImage")
    private Object patientImage;
    @JsonProperty("address")
    private Object address;
    @JsonProperty("emergencyContact")
    private Object emergencyContact;
    @JsonProperty("isPatientExists")
    private Boolean isPatientExists;
    @JsonProperty("employer")
    private Object employer;
    @JsonProperty("lockingUser")
    private Object lockingUser;
    @JsonProperty("isLockExists")
    private Boolean isLockExists;
    @JsonProperty("ssn")
    private Object ssn;
    @JsonProperty("patientGuarantor")
    private Object patientGuarantor;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("fullNameWithTitle")
    private String fullNameWithTitle;
    @JsonProperty("procedureDt")
    private String procedureDt;
    @JsonProperty("primaryProcedure")
    private Object primaryProcedure;
    @JsonProperty("mpiPatientAge")
    private MpiPatientAge mpiPatientAge;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public Patient withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Patient withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Patient withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public Object getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
    }

    public Patient withMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("title")
    public Object getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(Object title) {
        this.title = title;
    }

    public Patient withTitle(Object title) {
        this.title = title;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Patient withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public Patient withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Patient withAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    @JsonProperty("noKnownDrugAllergyTf")
    public Object getNoKnownDrugAllergyTf() {
        return noKnownDrugAllergyTf;
    }

    @JsonProperty("noKnownDrugAllergyTf")
    public void setNoKnownDrugAllergyTf(Object noKnownDrugAllergyTf) {
        this.noKnownDrugAllergyTf = noKnownDrugAllergyTf;
    }

    public Patient withNoKnownDrugAllergyTf(Object noKnownDrugAllergyTf) {
        this.noKnownDrugAllergyTf = noKnownDrugAllergyTf;
        return this;
    }

    @JsonProperty("noKnownNonDrugAllergyTf")
    public Object getNoKnownNonDrugAllergyTf() {
        return noKnownNonDrugAllergyTf;
    }

    @JsonProperty("noKnownNonDrugAllergyTf")
    public void setNoKnownNonDrugAllergyTf(Object noKnownNonDrugAllergyTf) {
        this.noKnownNonDrugAllergyTf = noKnownNonDrugAllergyTf;
    }

    public Patient withNoKnownNonDrugAllergyTf(Object noKnownNonDrugAllergyTf) {
        this.noKnownNonDrugAllergyTf = noKnownNonDrugAllergyTf;
        return this;
    }

    @JsonProperty("noKnownLatexAllergyTf")
    public Object getNoKnownLatexAllergyTf() {
        return noKnownLatexAllergyTf;
    }

    @JsonProperty("noKnownLatexAllergyTf")
    public void setNoKnownLatexAllergyTf(Object noKnownLatexAllergyTf) {
        this.noKnownLatexAllergyTf = noKnownLatexAllergyTf;
    }

    public Patient withNoKnownLatexAllergyTf(Object noKnownLatexAllergyTf) {
        this.noKnownLatexAllergyTf = noKnownLatexAllergyTf;
        return this;
    }

    @JsonProperty("noHomeMedicationTf")
    public Object getNoHomeMedicationTf() {
        return noHomeMedicationTf;
    }

    @JsonProperty("noHomeMedicationTf")
    public void setNoHomeMedicationTf(Object noHomeMedicationTf) {
        this.noHomeMedicationTf = noHomeMedicationTf;
    }

    public Patient withNoHomeMedicationTf(Object noHomeMedicationTf) {
        this.noHomeMedicationTf = noHomeMedicationTf;
        return this;
    }

    @JsonProperty("email")
    public Object getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(Object email) {
        this.email = email;
    }

    public Patient withEmail(Object email) {
        this.email = email;
        return this;
    }

    @JsonProperty("alias")
    public Object getAlias() {
        return alias;
    }

    @JsonProperty("alias")
    public void setAlias(Object alias) {
        this.alias = alias;
    }

    public Patient withAlias(Object alias) {
        this.alias = alias;
        return this;
    }

    @JsonProperty("patientLanguage")
    public Object getPatientLanguage() {
        return patientLanguage;
    }

    @JsonProperty("patientLanguage")
    public void setPatientLanguage(Object patientLanguage) {
        this.patientLanguage = patientLanguage;
    }

    public Patient withPatientLanguage(Object patientLanguage) {
        this.patientLanguage = patientLanguage;
        return this;
    }

    @JsonProperty("maritalStatusId")
    public Object getMaritalStatusId() {
        return maritalStatusId;
    }

    @JsonProperty("maritalStatusId")
    public void setMaritalStatusId(Object maritalStatusId) {
        this.maritalStatusId = maritalStatusId;
    }

    public Patient withMaritalStatusId(Object maritalStatusId) {
        this.maritalStatusId = maritalStatusId;
        return this;
    }

    @JsonProperty("maritalStatus")
    public Object getMaritalStatus() {
        return maritalStatus;
    }

    @JsonProperty("maritalStatus")
    public void setMaritalStatus(Object maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public Patient withMaritalStatus(Object maritalStatus) {
        this.maritalStatus = maritalStatus;
        return this;
    }

    @JsonProperty("raceId")
    public Object getRaceId() {
        return raceId;
    }

    @JsonProperty("raceId")
    public void setRaceId(Object raceId) {
        this.raceId = raceId;
    }

    public Patient withRaceId(Object raceId) {
        this.raceId = raceId;
        return this;
    }

    @JsonProperty("race")
    public Object getRace() {
        return race;
    }

    @JsonProperty("race")
    public void setRace(Object race) {
        this.race = race;
    }

    public Patient withRace(Object race) {
        this.race = race;
        return this;
    }

    @JsonProperty("ethnicityId")
    public Object getEthnicityId() {
        return ethnicityId;
    }

    @JsonProperty("ethnicityId")
    public void setEthnicityId(Object ethnicityId) {
        this.ethnicityId = ethnicityId;
    }

    public Patient withEthnicityId(Object ethnicityId) {
        this.ethnicityId = ethnicityId;
        return this;
    }

    @JsonProperty("ethnicity")
    public Object getEthnicity() {
        return ethnicity;
    }

    @JsonProperty("ethnicity")
    public void setEthnicity(Object ethnicity) {
        this.ethnicity = ethnicity;
    }

    public Patient withEthnicity(Object ethnicity) {
        this.ethnicity = ethnicity;
        return this;
    }

    @JsonProperty("occupation")
    public Object getOccupation() {
        return occupation;
    }

    @JsonProperty("occupation")
    public void setOccupation(Object occupation) {
        this.occupation = occupation;
    }

    public Patient withOccupation(Object occupation) {
        this.occupation = occupation;
        return this;
    }

    @JsonProperty("religionId")
    public Object getReligionId() {
        return religionId;
    }

    @JsonProperty("religionId")
    public void setReligionId(Object religionId) {
        this.religionId = religionId;
    }

    public Patient withReligionId(Object religionId) {
        this.religionId = religionId;
        return this;
    }

    @JsonProperty("religion")
    public Object getReligion() {
        return religion;
    }

    @JsonProperty("religion")
    public void setReligion(Object religion) {
        this.religion = religion;
    }

    public Patient withReligion(Object religion) {
        this.religion = religion;
        return this;
    }

    @JsonProperty("medsLastLoaded")
    public Object getMedsLastLoaded() {
        return medsLastLoaded;
    }

    @JsonProperty("medsLastLoaded")
    public void setMedsLastLoaded(Object medsLastLoaded) {
        this.medsLastLoaded = medsLastLoaded;
    }

    public Patient withMedsLastLoaded(Object medsLastLoaded) {
        this.medsLastLoaded = medsLastLoaded;
        return this;
    }

    @JsonProperty("externalAccountNumber")
    public Object getExternalAccountNumber() {
        return externalAccountNumber;
    }

    @JsonProperty("externalAccountNumber")
    public void setExternalAccountNumber(Object externalAccountNumber) {
        this.externalAccountNumber = externalAccountNumber;
    }

    public Patient withExternalAccountNumber(Object externalAccountNumber) {
        this.externalAccountNumber = externalAccountNumber;
        return this;
    }

    @JsonProperty("adtMaintainedFieldArray")
    public List<Object> getAdtMaintainedFieldArray() {
        return adtMaintainedFieldArray;
    }

    @JsonProperty("adtMaintainedFieldArray")
    public void setAdtMaintainedFieldArray(List<Object> adtMaintainedFieldArray) {
        this.adtMaintainedFieldArray = adtMaintainedFieldArray;
    }

    public Patient withAdtMaintainedFieldArray(List<Object> adtMaintainedFieldArray) {
        this.adtMaintainedFieldArray = adtMaintainedFieldArray;
        return this;
    }

    @JsonProperty("adtLockedFieldList")
    public List<Object> getAdtLockedFieldList() {
        return adtLockedFieldList;
    }

    @JsonProperty("adtLockedFieldList")
    public void setAdtLockedFieldList(List<Object> adtLockedFieldList) {
        this.adtLockedFieldList = adtLockedFieldList;
    }

    public Patient withAdtLockedFieldList(List<Object> adtLockedFieldList) {
        this.adtLockedFieldList = adtLockedFieldList;
        return this;
    }

    @JsonProperty("patientPhones")
    public Object getPatientPhones() {
        return patientPhones;
    }

    @JsonProperty("patientPhones")
    public void setPatientPhones(Object patientPhones) {
        this.patientPhones = patientPhones;
    }

    public Patient withPatientPhones(Object patientPhones) {
        this.patientPhones = patientPhones;
        return this;
    }

    @JsonProperty("mpiPatientPhone")
    public MpiPatientPhone getMpiPatientPhone() {
        return mpiPatientPhone;
    }

    @JsonProperty("mpiPatientPhone")
    public void setMpiPatientPhone(MpiPatientPhone mpiPatientPhone) {
        this.mpiPatientPhone = mpiPatientPhone;
    }

    public Patient withMpiPatientPhone(MpiPatientPhone mpiPatientPhone) {
        this.mpiPatientPhone = mpiPatientPhone;
        return this;
    }

    @JsonProperty("mpiPatientPhoneSecondary")
    public MpiPatientPhoneSecondary getMpiPatientPhoneSecondary() {
        return mpiPatientPhoneSecondary;
    }

    @JsonProperty("mpiPatientPhoneSecondary")
    public void setMpiPatientPhoneSecondary(MpiPatientPhoneSecondary mpiPatientPhoneSecondary) {
        this.mpiPatientPhoneSecondary = mpiPatientPhoneSecondary;
    }

    public Patient withMpiPatientPhoneSecondary(MpiPatientPhoneSecondary mpiPatientPhoneSecondary) {
        this.mpiPatientPhoneSecondary = mpiPatientPhoneSecondary;
        return this;
    }

    @JsonProperty("patientImage")
    public Object getPatientImage() {
        return patientImage;
    }

    @JsonProperty("patientImage")
    public void setPatientImage(Object patientImage) {
        this.patientImage = patientImage;
    }

    public Patient withPatientImage(Object patientImage) {
        this.patientImage = patientImage;
        return this;
    }

    @JsonProperty("address")
    public Object getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Object address) {
        this.address = address;
    }

    public Patient withAddress(Object address) {
        this.address = address;
        return this;
    }

    @JsonProperty("emergencyContact")
    public Object getEmergencyContact() {
        return emergencyContact;
    }

    @JsonProperty("emergencyContact")
    public void setEmergencyContact(Object emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public Patient withEmergencyContact(Object emergencyContact) {
        this.emergencyContact = emergencyContact;
        return this;
    }

    @JsonProperty("isPatientExists")
    public Boolean getIsPatientExists() {
        return isPatientExists;
    }

    @JsonProperty("isPatientExists")
    public void setIsPatientExists(Boolean isPatientExists) {
        this.isPatientExists = isPatientExists;
    }

    public Patient withIsPatientExists(Boolean isPatientExists) {
        this.isPatientExists = isPatientExists;
        return this;
    }

    @JsonProperty("employer")
    public Object getEmployer() {
        return employer;
    }

    @JsonProperty("employer")
    public void setEmployer(Object employer) {
        this.employer = employer;
    }

    public Patient withEmployer(Object employer) {
        this.employer = employer;
        return this;
    }

    @JsonProperty("lockingUser")
    public Object getLockingUser() {
        return lockingUser;
    }

    @JsonProperty("lockingUser")
    public void setLockingUser(Object lockingUser) {
        this.lockingUser = lockingUser;
    }

    public Patient withLockingUser(Object lockingUser) {
        this.lockingUser = lockingUser;
        return this;
    }

    @JsonProperty("isLockExists")
    public Boolean getIsLockExists() {
        return isLockExists;
    }

    @JsonProperty("isLockExists")
    public void setIsLockExists(Boolean isLockExists) {
        this.isLockExists = isLockExists;
    }

    public Patient withIsLockExists(Boolean isLockExists) {
        this.isLockExists = isLockExists;
        return this;
    }

    @JsonProperty("ssn")
    public Object getSsn() {
        return ssn;
    }

    @JsonProperty("ssn")
    public void setSsn(Object ssn) {
        this.ssn = ssn;
    }

    public Patient withSsn(Object ssn) {
        this.ssn = ssn;
        return this;
    }

    @JsonProperty("patientGuarantor")
    public Object getPatientGuarantor() {
        return patientGuarantor;
    }

    @JsonProperty("patientGuarantor")
    public void setPatientGuarantor(Object patientGuarantor) {
        this.patientGuarantor = patientGuarantor;
    }

    public Patient withPatientGuarantor(Object patientGuarantor) {
        this.patientGuarantor = patientGuarantor;
        return this;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Patient withFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("fullNameWithTitle")
    public String getFullNameWithTitle() {
        return fullNameWithTitle;
    }

    @JsonProperty("fullNameWithTitle")
    public void setFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
    }

    public Patient withFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
        return this;
    }

    @JsonProperty("procedureDt")
    public String getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
    }

    public Patient withProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("primaryProcedure")
    public Object getPrimaryProcedure() {
        return primaryProcedure;
    }

    @JsonProperty("primaryProcedure")
    public void setPrimaryProcedure(Object primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
    }

    public Patient withPrimaryProcedure(Object primaryProcedure) {
        this.primaryProcedure = primaryProcedure;
        return this;
    }

    @JsonProperty("mpiPatientAge")
    public MpiPatientAge getMpiPatientAge() {
        return mpiPatientAge;
    }

    @JsonProperty("mpiPatientAge")
    public void setMpiPatientAge(MpiPatientAge mpiPatientAge) {
        this.mpiPatientAge = mpiPatientAge;
    }

    public Patient withMpiPatientAge(MpiPatientAge mpiPatientAge) {
        this.mpiPatientAge = mpiPatientAge;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public Patient withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Patient withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientId).append(firstName).append(lastName).append(middleInitial).append(title).append(dateOfBirth).append(gender).append(accountNumber).append(noKnownDrugAllergyTf).append(noKnownNonDrugAllergyTf).append(noKnownLatexAllergyTf).append(noHomeMedicationTf).append(email).append(alias).append(patientLanguage).append(maritalStatusId).append(maritalStatus).append(raceId).append(race).append(ethnicityId).append(ethnicity).append(occupation).append(religionId).append(religion).append(medsLastLoaded).append(externalAccountNumber).append(adtMaintainedFieldArray).append(adtLockedFieldList).append(patientPhones).append(mpiPatientPhone).append(mpiPatientPhoneSecondary).append(patientImage).append(address).append(emergencyContact).append(isPatientExists).append(employer).append(lockingUser).append(isLockExists).append(ssn).append(patientGuarantor).append(fullName).append(fullNameWithTitle).append(procedureDt).append(primaryProcedure).append(mpiPatientAge).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Patient) == false) {
            return false;
        }
        Patient rhs = ((Patient) other);
        return new EqualsBuilder().append(patientId, rhs.patientId).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(title, rhs.title).append(dateOfBirth, rhs.dateOfBirth).append(gender, rhs.gender).append(accountNumber, rhs.accountNumber).append(noKnownDrugAllergyTf, rhs.noKnownDrugAllergyTf).append(noKnownNonDrugAllergyTf, rhs.noKnownNonDrugAllergyTf).append(noKnownLatexAllergyTf, rhs.noKnownLatexAllergyTf).append(noHomeMedicationTf, rhs.noHomeMedicationTf).append(email, rhs.email).append(alias, rhs.alias).append(patientLanguage, rhs.patientLanguage).append(maritalStatusId, rhs.maritalStatusId).append(maritalStatus, rhs.maritalStatus).append(raceId, rhs.raceId).append(race, rhs.race).append(ethnicityId, rhs.ethnicityId).append(ethnicity, rhs.ethnicity).append(occupation, rhs.occupation).append(religionId, rhs.religionId).append(religion, rhs.religion).append(medsLastLoaded, rhs.medsLastLoaded).append(externalAccountNumber, rhs.externalAccountNumber).append(adtMaintainedFieldArray, rhs.adtMaintainedFieldArray).append(adtLockedFieldList, rhs.adtLockedFieldList).append(patientPhones, rhs.patientPhones).append(mpiPatientPhone, rhs.mpiPatientPhone).append(mpiPatientPhoneSecondary, rhs.mpiPatientPhoneSecondary).append(patientImage, rhs.patientImage).append(address, rhs.address).append(emergencyContact, rhs.emergencyContact).append(isPatientExists, rhs.isPatientExists).append(employer, rhs.employer).append(lockingUser, rhs.lockingUser).append(isLockExists, rhs.isLockExists).append(ssn, rhs.ssn).append(patientGuarantor, rhs.patientGuarantor).append(fullName, rhs.fullName).append(fullNameWithTitle, rhs.fullNameWithTitle).append(procedureDt, rhs.procedureDt).append(primaryProcedure, rhs.primaryProcedure).append(mpiPatientAge, rhs.mpiPatientAge).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
