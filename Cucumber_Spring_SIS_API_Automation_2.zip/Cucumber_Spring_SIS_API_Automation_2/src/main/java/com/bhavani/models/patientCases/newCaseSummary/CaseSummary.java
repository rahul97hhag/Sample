
package com.bhavani.models.patientCases.newCaseSummary;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bhavani.models.patient.Patient;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caseEquipments",
    "today",
    "caseSummaryId",
    "patient",
    "patientId",
    "caseGuarantor",
    "caseInsurances",
    "caseMSPInsuranceTypeMap",
    "caseProcedures",
    "casePreferenceCards",
    "roomId",
    "roomName",
    "procedureStopDt",
    "procedureStartDt",
    "procedureStartTime",
    "procedureStopTime",
    "startTime",
    "endTime",
    "duration",
    "referringPhysicianId",
    "referringPhysicianName",
    "appointmentTypeId",
    "appointmentTypeName",
    "anesthesiaTypeId",
    "anesthesiaTypeName",
    "caseType",
    "procedureDt",
    "dateOfService",
    "additionalClaimInfo",
    "primaryPhysicianId"
})
public class CaseSummary {

    @JsonProperty("caseEquipments")
    private List<Object> caseEquipments = new ArrayList<Object>();
    @JsonProperty("today")
    private String today;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("patient")
    private Patient patient;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("caseGuarantor")
    private List<CaseGuarantor> caseGuarantor = new ArrayList<CaseGuarantor>();
    @JsonProperty("caseInsurances")
    private List<CaseInsurance> caseInsurances = new ArrayList<CaseInsurance>();
    @JsonProperty("caseMSPInsuranceTypeMap")
    private CaseMSPInsuranceTypeMap caseMSPInsuranceTypeMap;
    @JsonProperty("caseProcedures")
    private List<CaseProcedure> caseProcedures = new ArrayList<CaseProcedure>();
    @JsonProperty("casePreferenceCards")
    private List<Object> casePreferenceCards = new ArrayList<Object>();
    @JsonProperty("roomId")
    private Integer roomId;
    @JsonProperty("roomName")
    private String roomName;
    @JsonProperty("procedureStopDt")
    private String procedureStopDt;
    @JsonProperty("procedureStartDt")
    private String procedureStartDt;
    @JsonProperty("procedureStartTime")
    private String procedureStartTime;
    @JsonProperty("procedureStopTime")
    private String procedureStopTime;
    @JsonProperty("startTime")
    private String startTime;
    @JsonProperty("endTime")
    private String endTime;
    @JsonProperty("duration")
    private Integer duration;
    @JsonProperty("referringPhysicianId")
    private Integer referringPhysicianId;
    @JsonProperty("referringPhysicianName")
    private String referringPhysicianName;
    @JsonProperty("appointmentTypeId")
    private Integer appointmentTypeId;
    @JsonProperty("appointmentTypeName")
    private String appointmentTypeName;
    @JsonProperty("anesthesiaTypeId")
    private Integer anesthesiaTypeId;
    @JsonProperty("anesthesiaTypeName")
    private String anesthesiaTypeName;
    @JsonProperty("caseType")
    private Integer caseType;
    @JsonProperty("procedureDt")
    private String procedureDt;
    @JsonProperty("dateOfService")
    private String dateOfService;
    @JsonProperty("additionalClaimInfo")
    private AdditionalClaimInfo additionalClaimInfo;
    @JsonProperty("primaryPhysicianId")
    private Integer primaryPhysicianId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("caseEquipments")
    public List<Object> getCaseEquipments() {
        return caseEquipments;
    }

    @JsonProperty("caseEquipments")
    public void setCaseEquipments(List<Object> caseEquipments) {
        this.caseEquipments = caseEquipments;
    }

    public CaseSummary withCaseEquipments(List<Object> caseEquipments) {
        this.caseEquipments = caseEquipments;
        return this;
    }

    @JsonProperty("today")
    public String getToday() {
        return today;
    }

    @JsonProperty("today")
    public void setToday(String today) {
        this.today = today;
    }

    public CaseSummary withToday(String today) {
        this.today = today;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public CaseSummary withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("patient")
    public Patient getPatient() {
        return patient;
    }

    @JsonProperty("patient")
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public CaseSummary withPatient(Patient patient) {
        this.patient = patient;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public CaseSummary withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("caseGuarantor")
    public List<CaseGuarantor> getCaseGuarantor() {
        return caseGuarantor;
    }

    @JsonProperty("caseGuarantor")
    public void setCaseGuarantor(List<CaseGuarantor> caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
    }

    public CaseSummary withCaseGuarantor(List<CaseGuarantor> caseGuarantor) {
        this.caseGuarantor = caseGuarantor;
        return this;
    }

    @JsonProperty("caseInsurances")
    public List<CaseInsurance> getCaseInsurances() {
        return caseInsurances;
    }

    @JsonProperty("caseInsurances")
    public void setCaseInsurances(List<CaseInsurance> caseInsurances) {
        this.caseInsurances = caseInsurances;
    }

    public CaseSummary withCaseInsurances(List<CaseInsurance> caseInsurances) {
        this.caseInsurances = caseInsurances;
        return this;
    }

    @JsonProperty("caseMSPInsuranceTypeMap")
    public CaseMSPInsuranceTypeMap getCaseMSPInsuranceTypeMap() {
        return caseMSPInsuranceTypeMap;
    }

    @JsonProperty("caseMSPInsuranceTypeMap")
    public void setCaseMSPInsuranceTypeMap(CaseMSPInsuranceTypeMap caseMSPInsuranceTypeMap) {
        this.caseMSPInsuranceTypeMap = caseMSPInsuranceTypeMap;
    }

    public CaseSummary withCaseMSPInsuranceTypeMap(CaseMSPInsuranceTypeMap caseMSPInsuranceTypeMap) {
        this.caseMSPInsuranceTypeMap = caseMSPInsuranceTypeMap;
        return this;
    }

    @JsonProperty("caseProcedures")
    public List<CaseProcedure> getCaseProcedures() {
        return caseProcedures;
    }

    @JsonProperty("caseProcedures")
    public void setCaseProcedures(List<CaseProcedure> caseProcedures) {
        this.caseProcedures = caseProcedures;
    }

    public CaseSummary withCaseProcedures(List<CaseProcedure> caseProcedures) {
        this.caseProcedures = caseProcedures;
        return this;
    }

    @JsonProperty("casePreferenceCards")
    public List<Object> getCasePreferenceCards() {
        return casePreferenceCards;
    }

    @JsonProperty("casePreferenceCards")
    public void setCasePreferenceCards(List<Object> casePreferenceCards) {
        this.casePreferenceCards = casePreferenceCards;
    }

    public CaseSummary withCasePreferenceCards(List<Object> casePreferenceCards) {
        this.casePreferenceCards = casePreferenceCards;
        return this;
    }

    @JsonProperty("roomId")
    public Integer getRoomId() {
        return roomId;
    }

    @JsonProperty("roomId")
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public CaseSummary withRoomId(Integer roomId) {
        this.roomId = roomId;
        return this;
    }

    @JsonProperty("roomName")
    public String getRoomName() {
        return roomName;
    }

    @JsonProperty("roomName")
    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public CaseSummary withRoomName(String roomName) {
        this.roomName = roomName;
        return this;
    }

    @JsonProperty("procedureStopDt")
    public String getProcedureStopDt() {
        return procedureStopDt;
    }

    @JsonProperty("procedureStopDt")
    public void setProcedureStopDt(String procedureStopDt) {
        this.procedureStopDt = procedureStopDt;
    }

    public CaseSummary withProcedureStopDt(String procedureStopDt) {
        this.procedureStopDt = procedureStopDt;
        return this;
    }

    @JsonProperty("procedureStartDt")
    public String getProcedureStartDt() {
        return procedureStartDt;
    }

    @JsonProperty("procedureStartDt")
    public void setProcedureStartDt(String procedureStartDt) {
        this.procedureStartDt = procedureStartDt;
    }

    public CaseSummary withProcedureStartDt(String procedureStartDt) {
        this.procedureStartDt = procedureStartDt;
        return this;
    }

    @JsonProperty("procedureStartTime")
    public String getProcedureStartTime() {
        return procedureStartTime;
    }

    @JsonProperty("procedureStartTime")
    public void setProcedureStartTime(String procedureStartTime) {
        this.procedureStartTime = procedureStartTime;
    }

    public CaseSummary withProcedureStartTime(String procedureStartTime) {
        this.procedureStartTime = procedureStartTime;
        return this;
    }

    @JsonProperty("procedureStopTime")
    public String getProcedureStopTime() {
        return procedureStopTime;
    }

    @JsonProperty("procedureStopTime")
    public void setProcedureStopTime(String procedureStopTime) {
        this.procedureStopTime = procedureStopTime;
    }

    public CaseSummary withProcedureStopTime(String procedureStopTime) {
        this.procedureStopTime = procedureStopTime;
        return this;
    }

    @JsonProperty("startTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("startTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public CaseSummary withStartTime(String startTime) {
        this.startTime = startTime;
        return this;
    }

    @JsonProperty("endTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("endTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public CaseSummary withEndTime(String endTime) {
        this.endTime = endTime;
        return this;
    }

    @JsonProperty("duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public CaseSummary withDuration(Integer duration) {
        this.duration = duration;
        return this;
    }

    @JsonProperty("referringPhysicianId")
    public Integer getReferringPhysicianId() {
        return referringPhysicianId;
    }

    @JsonProperty("referringPhysicianId")
    public void setReferringPhysicianId(Integer referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
    }

    public CaseSummary withReferringPhysicianId(Integer referringPhysicianId) {
        this.referringPhysicianId = referringPhysicianId;
        return this;
    }

    @JsonProperty("referringPhysicianName")
    public String getReferringPhysicianName() {
        return referringPhysicianName;
    }

    @JsonProperty("referringPhysicianName")
    public void setReferringPhysicianName(String referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
    }

    public CaseSummary withReferringPhysicianName(String referringPhysicianName) {
        this.referringPhysicianName = referringPhysicianName;
        return this;
    }

    @JsonProperty("appointmentTypeId")
    public Integer getAppointmentTypeId() {
        return appointmentTypeId;
    }

    @JsonProperty("appointmentTypeId")
    public void setAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
    }

    public CaseSummary withAppointmentTypeId(Integer appointmentTypeId) {
        this.appointmentTypeId = appointmentTypeId;
        return this;
    }

    @JsonProperty("appointmentTypeName")
    public String getAppointmentTypeName() {
        return appointmentTypeName;
    }

    @JsonProperty("appointmentTypeName")
    public void setAppointmentTypeName(String appointmentTypeName) {
        this.appointmentTypeName = appointmentTypeName;
    }

    public CaseSummary withAppointmentTypeName(String appointmentTypeName) {
        this.appointmentTypeName = appointmentTypeName;
        return this;
    }

    @JsonProperty("anesthesiaTypeId")
    public Integer getAnesthesiaTypeId() {
        return anesthesiaTypeId;
    }

    @JsonProperty("anesthesiaTypeId")
    public void setAnesthesiaTypeId(Integer anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
    }

    public CaseSummary withAnesthesiaTypeId(Integer anesthesiaTypeId) {
        this.anesthesiaTypeId = anesthesiaTypeId;
        return this;
    }

    @JsonProperty("anesthesiaTypeName")
    public String getAnesthesiaTypeName() {
        return anesthesiaTypeName;
    }

    @JsonProperty("anesthesiaTypeName")
    public void setAnesthesiaTypeName(String anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
    }

    public CaseSummary withAnesthesiaTypeName(String anesthesiaTypeName) {
        this.anesthesiaTypeName = anesthesiaTypeName;
        return this;
    }

    @JsonProperty("caseType")
    public Integer getCaseType() {
        return caseType;
    }

    @JsonProperty("caseType")
    public void setCaseType(Integer caseType) {
        this.caseType = caseType;
    }

    public CaseSummary withCaseType(Integer caseType) {
        this.caseType = caseType;
        return this;
    }

    @JsonProperty("procedureDt")
    public String getProcedureDt() {
        return procedureDt;
    }

    @JsonProperty("procedureDt")
    public void setProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
    }

    public CaseSummary withProcedureDt(String procedureDt) {
        this.procedureDt = procedureDt;
        return this;
    }

    @JsonProperty("dateOfService")
    public String getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public CaseSummary withDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
        return this;
    }

    @JsonProperty("additionalClaimInfo")
    public AdditionalClaimInfo getAdditionalClaimInfo() {
        return additionalClaimInfo;
    }

    @JsonProperty("additionalClaimInfo")
    public void setAdditionalClaimInfo(AdditionalClaimInfo additionalClaimInfo) {
        this.additionalClaimInfo = additionalClaimInfo;
    }

    public CaseSummary withAdditionalClaimInfo(AdditionalClaimInfo additionalClaimInfo) {
        this.additionalClaimInfo = additionalClaimInfo;
        return this;
    }

    @JsonProperty("primaryPhysicianId")
    public Integer getPrimaryPhysicianId() {
        return primaryPhysicianId;
    }

    @JsonProperty("primaryPhysicianId")
    public void setPrimaryPhysicianId(Integer primaryPhysicianId) {
        this.primaryPhysicianId = primaryPhysicianId;
    }

    public CaseSummary withPrimaryPhysicianId(Integer primaryPhysicianId) {
        this.primaryPhysicianId = primaryPhysicianId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CaseSummary withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(caseEquipments).append(today).append(caseSummaryId).append(patient).append(patientId).append(caseGuarantor).append(caseInsurances).append(caseMSPInsuranceTypeMap).append(caseProcedures).append(casePreferenceCards).append(roomId).append(roomName).append(procedureStopDt).append(procedureStartDt).append(procedureStartTime).append(procedureStopTime).append(startTime).append(endTime).append(duration).append(referringPhysicianId).append(referringPhysicianName).append(appointmentTypeId).append(appointmentTypeName).append(anesthesiaTypeId).append(anesthesiaTypeName).append(caseType).append(procedureDt).append(dateOfService).append(additionalClaimInfo).append(primaryPhysicianId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CaseSummary) == false) {
            return false;
        }
        CaseSummary rhs = ((CaseSummary) other);
        return new EqualsBuilder().append(caseEquipments, rhs.caseEquipments).append(today, rhs.today).append(caseSummaryId, rhs.caseSummaryId).append(patient, rhs.patient).append(patientId, rhs.patientId).append(caseGuarantor, rhs.caseGuarantor).append(caseInsurances, rhs.caseInsurances).append(caseMSPInsuranceTypeMap, rhs.caseMSPInsuranceTypeMap).append(caseProcedures, rhs.caseProcedures).append(casePreferenceCards, rhs.casePreferenceCards).append(roomId, rhs.roomId).append(roomName, rhs.roomName).append(procedureStopDt, rhs.procedureStopDt).append(procedureStartDt, rhs.procedureStartDt).append(procedureStartTime, rhs.procedureStartTime).append(procedureStopTime, rhs.procedureStopTime).append(startTime, rhs.startTime).append(endTime, rhs.endTime).append(duration, rhs.duration).append(referringPhysicianId, rhs.referringPhysicianId).append(referringPhysicianName, rhs.referringPhysicianName).append(appointmentTypeId, rhs.appointmentTypeId).append(appointmentTypeName, rhs.appointmentTypeName).append(anesthesiaTypeId, rhs.anesthesiaTypeId).append(anesthesiaTypeName, rhs.anesthesiaTypeName).append(caseType, rhs.caseType).append(procedureDt, rhs.procedureDt).append(dateOfService, rhs.dateOfService).append(additionalClaimInfo, rhs.additionalClaimInfo).append(primaryPhysicianId, rhs.primaryPhysicianId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
