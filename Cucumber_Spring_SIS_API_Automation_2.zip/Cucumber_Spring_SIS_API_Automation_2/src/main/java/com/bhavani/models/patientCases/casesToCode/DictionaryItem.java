
package com.bhavani.models.patientCases.casesToCode;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "onlyClinical",
    "id",
    "quickCode",
    "value"
})
public class DictionaryItem {

    @JsonProperty("onlyClinical")
    private Boolean onlyClinical;
    @JsonProperty("id")
    private Integer id;
    @JsonProperty("quickCode")
    private String quickCode;
    @JsonProperty("value")
    private String value;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("onlyClinical")
    public Boolean getOnlyClinical() {
        return onlyClinical;
    }

    @JsonProperty("onlyClinical")
    public void setOnlyClinical(Boolean onlyClinical) {
        this.onlyClinical = onlyClinical;
    }

    public DictionaryItem withOnlyClinical(Boolean onlyClinical) {
        this.onlyClinical = onlyClinical;
        return this;
    }

    @JsonProperty("id")
    public Integer getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(Integer id) {
        this.id = id;
    }

    public DictionaryItem withId(Integer id) {
        this.id = id;
        return this;
    }

    @JsonProperty("quickCode")
    public String getQuickCode() {
        return quickCode;
    }

    @JsonProperty("quickCode")
    public void setQuickCode(String quickCode) {
        this.quickCode = quickCode;
    }

    public DictionaryItem withQuickCode(String quickCode) {
        this.quickCode = quickCode;
        return this;
    }

    @JsonProperty("value")
    public String getValue() {
        return value;
    }

    @JsonProperty("value")
    public void setValue(String value) {
        this.value = value;
    }

    public DictionaryItem withValue(String value) {
        this.value = value;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DictionaryItem withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(onlyClinical).append(id).append(quickCode).append(value).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DictionaryItem) == false) {
            return false;
        }
        DictionaryItem rhs = ((DictionaryItem) other);
        return new EqualsBuilder().append(onlyClinical, rhs.onlyClinical).append(id, rhs.id).append(quickCode, rhs.quickCode).append(value, rhs.value).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
