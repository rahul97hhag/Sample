
package com.bhavani.models.patientCases.dischargePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

// @JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientHandoffId",
    "caseSummaryId",
    "moduleId",
    "dischargedToLocationId",
    "transferTime",
    "transferredViaId",
    "transferredById",
    "transferredToId",
    "dischargedViaId",
    "dischargedWithId",
    "dischargedWithName",
    "dischargeDirectedById",
    "dischargeNotes",
    "dischargeNormalTf",
    "abnormalDischargeCircumstance",
    "receivingPartyId",
    "receivingPartyName",
    "receivingPartyNotes",
    "dischargedById",
    "dischargedOnDt",
    "transferModuleId",
    "dischargeSignDt",
    "isUpdated",
    "transferVia_Value",
    "dischargedVia_Value",
    "transferred_By_Value",
    "transferred_To_Value",
    "discharged_To_Value",
    "discharged_With_Value",
    "discharged_Directed_By_Value",
    "receiving_Party_Value",
    "transferTimeWF_Date",
    "transferTimeWF_Time",
    "transferTimeOF_Date",
    "transferTimeOF_Time",
    "discharged_By",
    "discharged_By_Value",
    "patientId",
    "caseStatus",
    "defaultCaseStatusId",
    "sourceIdentifier"
})
public class PatientHandsOffData {

    @JsonProperty("patientHandoffId")
    private Integer patientHandoffId;
    @JsonProperty("caseSummaryId")
    private String caseSummaryId;
    @JsonProperty("moduleId")
    private Integer moduleId;
    @JsonProperty("dischargedToLocationId")
    private Object dischargedToLocationId;
    @JsonProperty("transferTime")
    private String transferTime;
    @JsonProperty("transferredViaId")
    private Object transferredViaId;
    @JsonProperty("transferredById")
    private Object transferredById;
    @JsonProperty("transferredToId")
    private Object transferredToId;
    @JsonProperty("dischargedViaId")
    private Object dischargedViaId;
    @JsonProperty("dischargedWithId")
    private Object dischargedWithId;
    @JsonProperty("dischargedWithName")
    private Object dischargedWithName;
    @JsonProperty("dischargeDirectedById")
    private Object dischargeDirectedById;
    @JsonProperty("dischargeNotes")
    private Object dischargeNotes;
    @JsonProperty("dischargeNormalTf")
    private Boolean dischargeNormalTf;
    @JsonProperty("abnormalDischargeCircumstance")
    private String abnormalDischargeCircumstance;
    @JsonProperty("receivingPartyId")
    private Object receivingPartyId;
    @JsonProperty("receivingPartyName")
    private Object receivingPartyName;
    @JsonProperty("receivingPartyNotes")
    private Object receivingPartyNotes;
    @JsonProperty("dischargedById")
    private Object dischargedById;
    @JsonProperty("dischargedOnDt")
    private String dischargedOnDt;
    @JsonProperty("transferModuleId")
    private Object transferModuleId;
    @JsonProperty("dischargeSignDt")
    private Object dischargeSignDt;
    @JsonProperty("isUpdated")
    private Boolean isUpdated;
    @JsonProperty("transferVia_Value")
    private Object transferViaValue;
    @JsonProperty("dischargedVia_Value")
    private Object dischargedViaValue;
    @JsonProperty("transferred_By_Value")
    private Object transferredByValue;
    @JsonProperty("transferred_To_Value")
    private Object transferredToValue;
    @JsonProperty("discharged_To_Value")
    private Object dischargedToValue;
    @JsonProperty("discharged_With_Value")
    private Object dischargedWithValue;
    @JsonProperty("discharged_Directed_By_Value")
    private Object dischargedDirectedByValue;
    @JsonProperty("receiving_Party_Value")
    private Object receivingPartyValue;
    @JsonProperty("transferTimeWF_Date")
    private Object transferTimeWFDate;
    @JsonProperty("transferTimeWF_Time")
    private String transferTimeWFTime;
    @JsonProperty("transferTimeOF_Date")
    private Object transferTimeOFDate;
    @JsonProperty("transferTimeOF_Time")
    private String transferTimeOFTime;
    @JsonProperty("discharged_By")
    private Object dischargedBy;
    @JsonProperty("discharged_By_Value")
    private Object dischargedByValue;
    @JsonProperty("patientId")
    private Object patientId;
    @JsonProperty("caseStatus")
    private Integer caseStatus;
    @JsonProperty("defaultCaseStatusId")
    private Integer defaultCaseStatusId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientHandoffId")
    public Integer getPatientHandoffId() {
        return patientHandoffId;
    }

    @JsonProperty("patientHandoffId")
    public void setPatientHandoffId(Integer patientHandoffId) {
        this.patientHandoffId = patientHandoffId;
    }

    public PatientHandsOffData withPatientHandoffId(Integer patientHandoffId) {
        this.patientHandoffId = patientHandoffId;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public String getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(String caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public PatientHandsOffData withCaseSummaryId(String caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("moduleId")
    public Integer getModuleId() {
        return moduleId;
    }

    @JsonProperty("moduleId")
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public PatientHandsOffData withModuleId(Integer moduleId) {
        this.moduleId = moduleId;
        return this;
    }

    @JsonProperty("dischargedToLocationId")
    public Object getDischargedToLocationId() {
        return dischargedToLocationId;
    }

    @JsonProperty("dischargedToLocationId")
    public void setDischargedToLocationId(Object dischargedToLocationId) {
        this.dischargedToLocationId = dischargedToLocationId;
    }

    public PatientHandsOffData withDischargedToLocationId(Object dischargedToLocationId) {
        this.dischargedToLocationId = dischargedToLocationId;
        return this;
    }

    @JsonProperty("transferTime")
    public String getTransferTime() {
        return transferTime;
    }

    @JsonProperty("transferTime")
    public void setTransferTime(String transferTime) {
        this.transferTime = transferTime;
    }

    public PatientHandsOffData withTransferTime(String transferTime) {
        this.transferTime = transferTime;
        return this;
    }

    @JsonProperty("transferredViaId")
    public Object getTransferredViaId() {
        return transferredViaId;
    }

    @JsonProperty("transferredViaId")
    public void setTransferredViaId(Object transferredViaId) {
        this.transferredViaId = transferredViaId;
    }

    public PatientHandsOffData withTransferredViaId(Object transferredViaId) {
        this.transferredViaId = transferredViaId;
        return this;
    }

    @JsonProperty("transferredById")
    public Object getTransferredById() {
        return transferredById;
    }

    @JsonProperty("transferredById")
    public void setTransferredById(Object transferredById) {
        this.transferredById = transferredById;
    }

    public PatientHandsOffData withTransferredById(Object transferredById) {
        this.transferredById = transferredById;
        return this;
    }

    @JsonProperty("transferredToId")
    public Object getTransferredToId() {
        return transferredToId;
    }

    @JsonProperty("transferredToId")
    public void setTransferredToId(Object transferredToId) {
        this.transferredToId = transferredToId;
    }

    public PatientHandsOffData withTransferredToId(Object transferredToId) {
        this.transferredToId = transferredToId;
        return this;
    }

    @JsonProperty("dischargedViaId")
    public Object getDischargedViaId() {
        return dischargedViaId;
    }

    @JsonProperty("dischargedViaId")
    public void setDischargedViaId(Object dischargedViaId) {
        this.dischargedViaId = dischargedViaId;
    }

    public PatientHandsOffData withDischargedViaId(Object dischargedViaId) {
        this.dischargedViaId = dischargedViaId;
        return this;
    }

    @JsonProperty("dischargedWithId")
    public Object getDischargedWithId() {
        return dischargedWithId;
    }

    @JsonProperty("dischargedWithId")
    public void setDischargedWithId(Object dischargedWithId) {
        this.dischargedWithId = dischargedWithId;
    }

    public PatientHandsOffData withDischargedWithId(Object dischargedWithId) {
        this.dischargedWithId = dischargedWithId;
        return this;
    }

    @JsonProperty("dischargedWithName")
    public Object getDischargedWithName() {
        return dischargedWithName;
    }

    @JsonProperty("dischargedWithName")
    public void setDischargedWithName(Object dischargedWithName) {
        this.dischargedWithName = dischargedWithName;
    }

    public PatientHandsOffData withDischargedWithName(Object dischargedWithName) {
        this.dischargedWithName = dischargedWithName;
        return this;
    }

    @JsonProperty("dischargeDirectedById")
    public Object getDischargeDirectedById() {
        return dischargeDirectedById;
    }

    @JsonProperty("dischargeDirectedById")
    public void setDischargeDirectedById(Object dischargeDirectedById) {
        this.dischargeDirectedById = dischargeDirectedById;
    }

    public PatientHandsOffData withDischargeDirectedById(Object dischargeDirectedById) {
        this.dischargeDirectedById = dischargeDirectedById;
        return this;
    }

    @JsonProperty("dischargeNotes")
    public Object getDischargeNotes() {
        return dischargeNotes;
    }

    @JsonProperty("dischargeNotes")
    public void setDischargeNotes(Object dischargeNotes) {
        this.dischargeNotes = dischargeNotes;
    }

    public PatientHandsOffData withDischargeNotes(Object dischargeNotes) {
        this.dischargeNotes = dischargeNotes;
        return this;
    }

    @JsonProperty("dischargeNormalTf")
    public Boolean getDischargeNormalTf() {
        return dischargeNormalTf;
    }

    @JsonProperty("dischargeNormalTf")
    public void setDischargeNormalTf(Boolean dischargeNormalTf) {
        this.dischargeNormalTf = dischargeNormalTf;
    }

    public PatientHandsOffData withDischargeNormalTf(Boolean dischargeNormalTf) {
        this.dischargeNormalTf = dischargeNormalTf;
        return this;
    }

    @JsonProperty("abnormalDischargeCircumstance")
    public String getAbnormalDischargeCircumstance() {
        return abnormalDischargeCircumstance;
    }

    @JsonProperty("abnormalDischargeCircumstance")
    public void setAbnormalDischargeCircumstance(String abnormalDischargeCircumstance) {
        this.abnormalDischargeCircumstance = abnormalDischargeCircumstance;
    }

    public PatientHandsOffData withAbnormalDischargeCircumstance(String abnormalDischargeCircumstance) {
        this.abnormalDischargeCircumstance = abnormalDischargeCircumstance;
        return this;
    }

    @JsonProperty("receivingPartyId")
    public Object getReceivingPartyId() {
        return receivingPartyId;
    }

    @JsonProperty("receivingPartyId")
    public void setReceivingPartyId(Object receivingPartyId) {
        this.receivingPartyId = receivingPartyId;
    }

    public PatientHandsOffData withReceivingPartyId(Object receivingPartyId) {
        this.receivingPartyId = receivingPartyId;
        return this;
    }

    @JsonProperty("receivingPartyName")
    public Object getReceivingPartyName() {
        return receivingPartyName;
    }

    @JsonProperty("receivingPartyName")
    public void setReceivingPartyName(Object receivingPartyName) {
        this.receivingPartyName = receivingPartyName;
    }

    public PatientHandsOffData withReceivingPartyName(Object receivingPartyName) {
        this.receivingPartyName = receivingPartyName;
        return this;
    }

    @JsonProperty("receivingPartyNotes")
    public Object getReceivingPartyNotes() {
        return receivingPartyNotes;
    }

    @JsonProperty("receivingPartyNotes")
    public void setReceivingPartyNotes(Object receivingPartyNotes) {
        this.receivingPartyNotes = receivingPartyNotes;
    }

    public PatientHandsOffData withReceivingPartyNotes(Object receivingPartyNotes) {
        this.receivingPartyNotes = receivingPartyNotes;
        return this;
    }

    @JsonProperty("dischargedById")
    public Object getDischargedById() {
        return dischargedById;
    }

    @JsonProperty("dischargedById")
    public void setDischargedById(Object dischargedById) {
        this.dischargedById = dischargedById;
    }

    public PatientHandsOffData withDischargedById(Object dischargedById) {
        this.dischargedById = dischargedById;
        return this;
    }

    @JsonProperty("dischargedOnDt")
    public String getDischargedOnDt() {
        return dischargedOnDt;
    }

    @JsonProperty("dischargedOnDt")
    public void setDischargedOnDt(String dischargedOnDt) {
        this.dischargedOnDt = dischargedOnDt;
    }

    public PatientHandsOffData withDischargedOnDt(String dischargedOnDt) {
        this.dischargedOnDt = dischargedOnDt;
        return this;
    }

    @JsonProperty("transferModuleId")
    public Object getTransferModuleId() {
        return transferModuleId;
    }

    @JsonProperty("transferModuleId")
    public void setTransferModuleId(Object transferModuleId) {
        this.transferModuleId = transferModuleId;
    }

    public PatientHandsOffData withTransferModuleId(Object transferModuleId) {
        this.transferModuleId = transferModuleId;
        return this;
    }

    @JsonProperty("dischargeSignDt")
    public Object getDischargeSignDt() {
        return dischargeSignDt;
    }

    @JsonProperty("dischargeSignDt")
    public void setDischargeSignDt(Object dischargeSignDt) {
        this.dischargeSignDt = dischargeSignDt;
    }

    public PatientHandsOffData withDischargeSignDt(Object dischargeSignDt) {
        this.dischargeSignDt = dischargeSignDt;
        return this;
    }

    @JsonProperty("isUpdated")
    public Boolean getIsUpdated() {
        return isUpdated;
    }

    @JsonProperty("isUpdated")
    public void setIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
    }

    public PatientHandsOffData withIsUpdated(Boolean isUpdated) {
        this.isUpdated = isUpdated;
        return this;
    }

    @JsonProperty("transferVia_Value")
    public Object getTransferViaValue() {
        return transferViaValue;
    }

    @JsonProperty("transferVia_Value")
    public void setTransferViaValue(Object transferViaValue) {
        this.transferViaValue = transferViaValue;
    }

    public PatientHandsOffData withTransferViaValue(Object transferViaValue) {
        this.transferViaValue = transferViaValue;
        return this;
    }

    @JsonProperty("dischargedVia_Value")
    public Object getDischargedViaValue() {
        return dischargedViaValue;
    }

    @JsonProperty("dischargedVia_Value")
    public void setDischargedViaValue(Object dischargedViaValue) {
        this.dischargedViaValue = dischargedViaValue;
    }

    public PatientHandsOffData withDischargedViaValue(Object dischargedViaValue) {
        this.dischargedViaValue = dischargedViaValue;
        return this;
    }

    @JsonProperty("transferred_By_Value")
    public Object getTransferredByValue() {
        return transferredByValue;
    }

    @JsonProperty("transferred_By_Value")
    public void setTransferredByValue(Object transferredByValue) {
        this.transferredByValue = transferredByValue;
    }

    public PatientHandsOffData withTransferredByValue(Object transferredByValue) {
        this.transferredByValue = transferredByValue;
        return this;
    }

    @JsonProperty("transferred_To_Value")
    public Object getTransferredToValue() {
        return transferredToValue;
    }

    @JsonProperty("transferred_To_Value")
    public void setTransferredToValue(Object transferredToValue) {
        this.transferredToValue = transferredToValue;
    }

    public PatientHandsOffData withTransferredToValue(Object transferredToValue) {
        this.transferredToValue = transferredToValue;
        return this;
    }

    @JsonProperty("discharged_To_Value")
    public Object getDischargedToValue() {
        return dischargedToValue;
    }

    @JsonProperty("discharged_To_Value")
    public void setDischargedToValue(Object dischargedToValue) {
        this.dischargedToValue = dischargedToValue;
    }

    public PatientHandsOffData withDischargedToValue(Object dischargedToValue) {
        this.dischargedToValue = dischargedToValue;
        return this;
    }

    @JsonProperty("discharged_With_Value")
    public Object getDischargedWithValue() {
        return dischargedWithValue;
    }

    @JsonProperty("discharged_With_Value")
    public void setDischargedWithValue(Object dischargedWithValue) {
        this.dischargedWithValue = dischargedWithValue;
    }

    public PatientHandsOffData withDischargedWithValue(Object dischargedWithValue) {
        this.dischargedWithValue = dischargedWithValue;
        return this;
    }

    @JsonProperty("discharged_Directed_By_Value")
    public Object getDischargedDirectedByValue() {
        return dischargedDirectedByValue;
    }

    @JsonProperty("discharged_Directed_By_Value")
    public void setDischargedDirectedByValue(Object dischargedDirectedByValue) {
        this.dischargedDirectedByValue = dischargedDirectedByValue;
    }

    public PatientHandsOffData withDischargedDirectedByValue(Object dischargedDirectedByValue) {
        this.dischargedDirectedByValue = dischargedDirectedByValue;
        return this;
    }

    @JsonProperty("receiving_Party_Value")
    public Object getReceivingPartyValue() {
        return receivingPartyValue;
    }

    @JsonProperty("receiving_Party_Value")
    public void setReceivingPartyValue(Object receivingPartyValue) {
        this.receivingPartyValue = receivingPartyValue;
    }

    public PatientHandsOffData withReceivingPartyValue(Object receivingPartyValue) {
        this.receivingPartyValue = receivingPartyValue;
        return this;
    }

    @JsonProperty("transferTimeWF_Date")
    public Object getTransferTimeWFDate() {
        return transferTimeWFDate;
    }

    @JsonProperty("transferTimeWF_Date")
    public void setTransferTimeWFDate(Object transferTimeWFDate) {
        this.transferTimeWFDate = transferTimeWFDate;
    }

    public PatientHandsOffData withTransferTimeWFDate(Object transferTimeWFDate) {
        this.transferTimeWFDate = transferTimeWFDate;
        return this;
    }

    @JsonProperty("transferTimeWF_Time")
    public String getTransferTimeWFTime() {
        return transferTimeWFTime;
    }

    @JsonProperty("transferTimeWF_Time")
    public void setTransferTimeWFTime(String transferTimeWFTime) {
        this.transferTimeWFTime = transferTimeWFTime;
    }

    public PatientHandsOffData withTransferTimeWFTime(String transferTimeWFTime) {
        this.transferTimeWFTime = transferTimeWFTime;
        return this;
    }

    @JsonProperty("transferTimeOF_Date")
    public Object getTransferTimeOFDate() {
        return transferTimeOFDate;
    }

    @JsonProperty("transferTimeOF_Date")
    public void setTransferTimeOFDate(Object transferTimeOFDate) {
        this.transferTimeOFDate = transferTimeOFDate;
    }

    public PatientHandsOffData withTransferTimeOFDate(Object transferTimeOFDate) {
        this.transferTimeOFDate = transferTimeOFDate;
        return this;
    }

    @JsonProperty("transferTimeOF_Time")
    public String getTransferTimeOFTime() {
        return transferTimeOFTime;
    }

    @JsonProperty("transferTimeOF_Time")
    public void setTransferTimeOFTime(String transferTimeOFTime) {
        this.transferTimeOFTime = transferTimeOFTime;
    }

    public PatientHandsOffData withTransferTimeOFTime(String transferTimeOFTime) {
        this.transferTimeOFTime = transferTimeOFTime;
        return this;
    }

    @JsonProperty("discharged_By")
    public Object getDischargedBy() {
        return dischargedBy;
    }

    @JsonProperty("discharged_By")
    public void setDischargedBy(Object dischargedBy) {
        this.dischargedBy = dischargedBy;
    }

    public PatientHandsOffData withDischargedBy(Object dischargedBy) {
        this.dischargedBy = dischargedBy;
        return this;
    }

    @JsonProperty("discharged_By_Value")
    public Object getDischargedByValue() {
        return dischargedByValue;
    }

    @JsonProperty("discharged_By_Value")
    public void setDischargedByValue(Object dischargedByValue) {
        this.dischargedByValue = dischargedByValue;
    }

    public PatientHandsOffData withDischargedByValue(Object dischargedByValue) {
        this.dischargedByValue = dischargedByValue;
        return this;
    }

    @JsonProperty("patientId")
    public Object getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Object patientId) {
        this.patientId = patientId;
    }

    public PatientHandsOffData withPatientId(Object patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("caseStatus")
    public Integer getCaseStatus() {
        return caseStatus;
    }

    @JsonProperty("caseStatus")
    public void setCaseStatus(Integer caseStatus) {
        this.caseStatus = caseStatus;
    }

    public PatientHandsOffData withCaseStatus(Integer caseStatus) {
        this.caseStatus = caseStatus;
        return this;
    }

    @JsonProperty("defaultCaseStatusId")
    public Integer getDefaultCaseStatusId() {
        return defaultCaseStatusId;
    }

    @JsonProperty("defaultCaseStatusId")
    public void setDefaultCaseStatusId(Integer defaultCaseStatusId) {
        this.defaultCaseStatusId = defaultCaseStatusId;
    }

    public PatientHandsOffData withDefaultCaseStatusId(Integer defaultCaseStatusId) {
        this.defaultCaseStatusId = defaultCaseStatusId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public PatientHandsOffData withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PatientHandsOffData withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientHandoffId).append(caseSummaryId).append(moduleId).append(dischargedToLocationId).append(transferTime).append(transferredViaId).append(transferredById).append(transferredToId).append(dischargedViaId).append(dischargedWithId).append(dischargedWithName).append(dischargeDirectedById).append(dischargeNotes).append(dischargeNormalTf).append(abnormalDischargeCircumstance).append(receivingPartyId).append(receivingPartyName).append(receivingPartyNotes).append(dischargedById).append(dischargedOnDt).append(transferModuleId).append(dischargeSignDt).append(isUpdated).append(transferViaValue).append(dischargedViaValue).append(transferredByValue).append(transferredToValue).append(dischargedToValue).append(dischargedWithValue).append(dischargedDirectedByValue).append(receivingPartyValue).append(transferTimeWFDate).append(transferTimeWFTime).append(transferTimeOFDate).append(transferTimeOFTime).append(dischargedBy).append(dischargedByValue).append(patientId).append(caseStatus).append(defaultCaseStatusId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PatientHandsOffData) == false) {
            return false;
        }
        PatientHandsOffData rhs = ((PatientHandsOffData) other);
        return new EqualsBuilder().append(patientHandoffId, rhs.patientHandoffId).append(caseSummaryId, rhs.caseSummaryId).append(moduleId, rhs.moduleId).append(dischargedToLocationId, rhs.dischargedToLocationId).append(transferTime, rhs.transferTime).append(transferredViaId, rhs.transferredViaId).append(transferredById, rhs.transferredById).append(transferredToId, rhs.transferredToId).append(dischargedViaId, rhs.dischargedViaId).append(dischargedWithId, rhs.dischargedWithId).append(dischargedWithName, rhs.dischargedWithName).append(dischargeDirectedById, rhs.dischargeDirectedById).append(dischargeNotes, rhs.dischargeNotes).append(dischargeNormalTf, rhs.dischargeNormalTf).append(abnormalDischargeCircumstance, rhs.abnormalDischargeCircumstance).append(receivingPartyId, rhs.receivingPartyId).append(receivingPartyName, rhs.receivingPartyName).append(receivingPartyNotes, rhs.receivingPartyNotes).append(dischargedById, rhs.dischargedById).append(dischargedOnDt, rhs.dischargedOnDt).append(transferModuleId, rhs.transferModuleId).append(dischargeSignDt, rhs.dischargeSignDt).append(isUpdated, rhs.isUpdated).append(transferViaValue, rhs.transferViaValue).append(dischargedViaValue, rhs.dischargedViaValue).append(transferredByValue, rhs.transferredByValue).append(transferredToValue, rhs.transferredToValue).append(dischargedToValue, rhs.dischargedToValue).append(dischargedWithValue, rhs.dischargedWithValue).append(dischargedDirectedByValue, rhs.dischargedDirectedByValue).append(receivingPartyValue, rhs.receivingPartyValue).append(transferTimeWFDate, rhs.transferTimeWFDate).append(transferTimeWFTime, rhs.transferTimeWFTime).append(transferTimeOFDate, rhs.transferTimeOFDate).append(transferTimeOFTime, rhs.transferTimeOFTime).append(dischargedBy, rhs.dischargedBy).append(dischargedByValue, rhs.dischargedByValue).append(patientId, rhs.patientId).append(caseStatus, rhs.caseStatus).append(defaultCaseStatusId, rhs.defaultCaseStatusId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
