
package com.bhavani.models.patientCases.newCaseSummary;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "patientInsuranceId",
    "patientId",
    "carrierId",
    "organizationId",
    "insuredId",
    "insuranceId",
    "displayName",
    "relationshipToInsured",
    "planName",
    "groupNumber",
    "groupName",
    "employer",
    "authorizationNumber",
    "insuranceCarrierId",
    "insurancePlanId",
    "claimOfficeId",
    "carrier",
    "firstName",
    "lastName",
    "middleInitial",
    "suffix",
    "gender",
    "dateOfBirth",
    "address1",
    "address2",
    "city",
    "state",
    "zipCode",
    "countyName",
    "countryName",
    "email",
    "primaryPhone",
    "insuranceClaimOfficeId",
    "isAdditionalClaimInfClassification",
    "effectiveFrom",
    "effectiveTo",
    "isMspInsuranceTypeClassification",
    "sortOrder",
    "generateClaimTf",
    "isInsuranceMappedWithCharge",
    "isActive",
    "externalId",
    "sourceIdentifier"
})
public class InsertInsuranceToPatientResponse {

    @JsonProperty("patientInsuranceId")
    private Integer patientInsuranceId;
    @JsonProperty("patientId")
    private Integer patientId;
    @JsonProperty("carrierId")
    private Object carrierId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("insuredId")
    private Integer insuredId;
    @JsonProperty("insuranceId")
    private String insuranceId;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("relationshipToInsured")
    private String relationshipToInsured;
    @JsonProperty("planName")
    private String planName;
    @JsonProperty("groupNumber")
    private String groupNumber;
    @JsonProperty("groupName")
    private String groupName;
    @JsonProperty("employer")
    private Object employer;
    @JsonProperty("authorizationNumber")
    private Object authorizationNumber;
    @JsonProperty("insuranceCarrierId")
    private Integer insuranceCarrierId;
    @JsonProperty("insurancePlanId")
    private Integer insurancePlanId;
    @JsonProperty("claimOfficeId")
    private Object claimOfficeId;
    @JsonProperty("carrier")
    private String carrier;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private Object middleInitial;
    @JsonProperty("suffix")
    private Object suffix;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("address2")
    private String address2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("countyName")
    private String countyName;
    @JsonProperty("countryName")
    private String countryName;
    @JsonProperty("email")
    private Object email;
    @JsonProperty("primaryPhone")
    private Object primaryPhone;
    @JsonProperty("insuranceClaimOfficeId")
    private Integer insuranceClaimOfficeId;
    @JsonProperty("isAdditionalClaimInfClassification")
    private Boolean isAdditionalClaimInfClassification;
    @JsonProperty("effectiveFrom")
    private Object effectiveFrom;
    @JsonProperty("effectiveTo")
    private Object effectiveTo;
    @JsonProperty("isMspInsuranceTypeClassification")
    private Boolean isMspInsuranceTypeClassification;
    @JsonProperty("sortOrder")
    private Object sortOrder;
    @JsonProperty("generateClaimTf")
    private Boolean generateClaimTf;
    @JsonProperty("isInsuranceMappedWithCharge")
    private Boolean isInsuranceMappedWithCharge;
    @JsonProperty("isActive")
    private Boolean isActive;
    @JsonProperty("externalId")
    private Object externalId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("patientInsuranceId")
    public Integer getPatientInsuranceId() {
        return patientInsuranceId;
    }

    @JsonProperty("patientInsuranceId")
    public void setPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
    }

    public InsertInsuranceToPatientResponse withPatientInsuranceId(Integer patientInsuranceId) {
        this.patientInsuranceId = patientInsuranceId;
        return this;
    }

    @JsonProperty("patientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public InsertInsuranceToPatientResponse withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("carrierId")
    public Object getCarrierId() {
        return carrierId;
    }

    @JsonProperty("carrierId")
    public void setCarrierId(Object carrierId) {
        this.carrierId = carrierId;
    }

    public InsertInsuranceToPatientResponse withCarrierId(Object carrierId) {
        this.carrierId = carrierId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public InsertInsuranceToPatientResponse withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("insuredId")
    public Integer getInsuredId() {
        return insuredId;
    }

    @JsonProperty("insuredId")
    public void setInsuredId(Integer insuredId) {
        this.insuredId = insuredId;
    }

    public InsertInsuranceToPatientResponse withInsuredId(Integer insuredId) {
        this.insuredId = insuredId;
        return this;
    }

    @JsonProperty("insuranceId")
    public String getInsuranceId() {
        return insuranceId;
    }

    @JsonProperty("insuranceId")
    public void setInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
    }

    public InsertInsuranceToPatientResponse withInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
        return this;
    }

    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public InsertInsuranceToPatientResponse withDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    @JsonProperty("relationshipToInsured")
    public String getRelationshipToInsured() {
        return relationshipToInsured;
    }

    @JsonProperty("relationshipToInsured")
    public void setRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
    }

    public InsertInsuranceToPatientResponse withRelationshipToInsured(String relationshipToInsured) {
        this.relationshipToInsured = relationshipToInsured;
        return this;
    }

    @JsonProperty("planName")
    public String getPlanName() {
        return planName;
    }

    @JsonProperty("planName")
    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public InsertInsuranceToPatientResponse withPlanName(String planName) {
        this.planName = planName;
        return this;
    }

    @JsonProperty("groupNumber")
    public String getGroupNumber() {
        return groupNumber;
    }

    @JsonProperty("groupNumber")
    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public InsertInsuranceToPatientResponse withGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
        return this;
    }

    @JsonProperty("groupName")
    public String getGroupName() {
        return groupName;
    }

    @JsonProperty("groupName")
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public InsertInsuranceToPatientResponse withGroupName(String groupName) {
        this.groupName = groupName;
        return this;
    }

    @JsonProperty("employer")
    public Object getEmployer() {
        return employer;
    }

    @JsonProperty("employer")
    public void setEmployer(Object employer) {
        this.employer = employer;
    }

    public InsertInsuranceToPatientResponse withEmployer(Object employer) {
        this.employer = employer;
        return this;
    }

    @JsonProperty("authorizationNumber")
    public Object getAuthorizationNumber() {
        return authorizationNumber;
    }

    @JsonProperty("authorizationNumber")
    public void setAuthorizationNumber(Object authorizationNumber) {
        this.authorizationNumber = authorizationNumber;
    }

    public InsertInsuranceToPatientResponse withAuthorizationNumber(Object authorizationNumber) {
        this.authorizationNumber = authorizationNumber;
        return this;
    }

    @JsonProperty("insuranceCarrierId")
    public Integer getInsuranceCarrierId() {
        return insuranceCarrierId;
    }

    @JsonProperty("insuranceCarrierId")
    public void setInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
    }

    public InsertInsuranceToPatientResponse withInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
        return this;
    }

    @JsonProperty("insurancePlanId")
    public Integer getInsurancePlanId() {
        return insurancePlanId;
    }

    @JsonProperty("insurancePlanId")
    public void setInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
    }

    public InsertInsuranceToPatientResponse withInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
        return this;
    }

    @JsonProperty("claimOfficeId")
    public Object getClaimOfficeId() {
        return claimOfficeId;
    }

    @JsonProperty("claimOfficeId")
    public void setClaimOfficeId(Object claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
    }

    public InsertInsuranceToPatientResponse withClaimOfficeId(Object claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
        return this;
    }

    @JsonProperty("carrier")
    public String getCarrier() {
        return carrier;
    }

    @JsonProperty("carrier")
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public InsertInsuranceToPatientResponse withCarrier(String carrier) {
        this.carrier = carrier;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public InsertInsuranceToPatientResponse withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public InsertInsuranceToPatientResponse withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public Object getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
    }

    public InsertInsuranceToPatientResponse withMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("suffix")
    public Object getSuffix() {
        return suffix;
    }

    @JsonProperty("suffix")
    public void setSuffix(Object suffix) {
        this.suffix = suffix;
    }

    public InsertInsuranceToPatientResponse withSuffix(Object suffix) {
        this.suffix = suffix;
        return this;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    public InsertInsuranceToPatientResponse withGender(String gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public InsertInsuranceToPatientResponse withDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public InsertInsuranceToPatientResponse withAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("address2")
    public String getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public InsertInsuranceToPatientResponse withAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public InsertInsuranceToPatientResponse withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public InsertInsuranceToPatientResponse withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public InsertInsuranceToPatientResponse withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("countyName")
    public String getCountyName() {
        return countyName;
    }

    @JsonProperty("countyName")
    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }

    public InsertInsuranceToPatientResponse withCountyName(String countyName) {
        this.countyName = countyName;
        return this;
    }

    @JsonProperty("countryName")
    public String getCountryName() {
        return countryName;
    }

    @JsonProperty("countryName")
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public InsertInsuranceToPatientResponse withCountryName(String countryName) {
        this.countryName = countryName;
        return this;
    }

    @JsonProperty("email")
    public Object getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(Object email) {
        this.email = email;
    }

    public InsertInsuranceToPatientResponse withEmail(Object email) {
        this.email = email;
        return this;
    }

    @JsonProperty("primaryPhone")
    public Object getPrimaryPhone() {
        return primaryPhone;
    }

    @JsonProperty("primaryPhone")
    public void setPrimaryPhone(Object primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public InsertInsuranceToPatientResponse withPrimaryPhone(Object primaryPhone) {
        this.primaryPhone = primaryPhone;
        return this;
    }

    @JsonProperty("insuranceClaimOfficeId")
    public Integer getInsuranceClaimOfficeId() {
        return insuranceClaimOfficeId;
    }

    @JsonProperty("insuranceClaimOfficeId")
    public void setInsuranceClaimOfficeId(Integer insuranceClaimOfficeId) {
        this.insuranceClaimOfficeId = insuranceClaimOfficeId;
    }

    public InsertInsuranceToPatientResponse withInsuranceClaimOfficeId(Integer insuranceClaimOfficeId) {
        this.insuranceClaimOfficeId = insuranceClaimOfficeId;
        return this;
    }

    @JsonProperty("isAdditionalClaimInfClassification")
    public Boolean getIsAdditionalClaimInfClassification() {
        return isAdditionalClaimInfClassification;
    }

    @JsonProperty("isAdditionalClaimInfClassification")
    public void setIsAdditionalClaimInfClassification(Boolean isAdditionalClaimInfClassification) {
        this.isAdditionalClaimInfClassification = isAdditionalClaimInfClassification;
    }

    public InsertInsuranceToPatientResponse withIsAdditionalClaimInfClassification(Boolean isAdditionalClaimInfClassification) {
        this.isAdditionalClaimInfClassification = isAdditionalClaimInfClassification;
        return this;
    }

    @JsonProperty("effectiveFrom")
    public Object getEffectiveFrom() {
        return effectiveFrom;
    }

    @JsonProperty("effectiveFrom")
    public void setEffectiveFrom(Object effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
    }

    public InsertInsuranceToPatientResponse withEffectiveFrom(Object effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
        return this;
    }

    @JsonProperty("effectiveTo")
    public Object getEffectiveTo() {
        return effectiveTo;
    }

    @JsonProperty("effectiveTo")
    public void setEffectiveTo(Object effectiveTo) {
        this.effectiveTo = effectiveTo;
    }

    public InsertInsuranceToPatientResponse withEffectiveTo(Object effectiveTo) {
        this.effectiveTo = effectiveTo;
        return this;
    }

    @JsonProperty("isMspInsuranceTypeClassification")
    public Boolean getIsMspInsuranceTypeClassification() {
        return isMspInsuranceTypeClassification;
    }

    @JsonProperty("isMspInsuranceTypeClassification")
    public void setIsMspInsuranceTypeClassification(Boolean isMspInsuranceTypeClassification) {
        this.isMspInsuranceTypeClassification = isMspInsuranceTypeClassification;
    }

    public InsertInsuranceToPatientResponse withIsMspInsuranceTypeClassification(Boolean isMspInsuranceTypeClassification) {
        this.isMspInsuranceTypeClassification = isMspInsuranceTypeClassification;
        return this;
    }

    @JsonProperty("sortOrder")
    public Object getSortOrder() {
        return sortOrder;
    }

    @JsonProperty("sortOrder")
    public void setSortOrder(Object sortOrder) {
        this.sortOrder = sortOrder;
    }

    public InsertInsuranceToPatientResponse withSortOrder(Object sortOrder) {
        this.sortOrder = sortOrder;
        return this;
    }

    @JsonProperty("generateClaimTf")
    public Boolean getGenerateClaimTf() {
        return generateClaimTf;
    }

    @JsonProperty("generateClaimTf")
    public void setGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
    }

    public InsertInsuranceToPatientResponse withGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
        return this;
    }

    @JsonProperty("isInsuranceMappedWithCharge")
    public Boolean getIsInsuranceMappedWithCharge() {
        return isInsuranceMappedWithCharge;
    }

    @JsonProperty("isInsuranceMappedWithCharge")
    public void setIsInsuranceMappedWithCharge(Boolean isInsuranceMappedWithCharge) {
        this.isInsuranceMappedWithCharge = isInsuranceMappedWithCharge;
    }

    public InsertInsuranceToPatientResponse withIsInsuranceMappedWithCharge(Boolean isInsuranceMappedWithCharge) {
        this.isInsuranceMappedWithCharge = isInsuranceMappedWithCharge;
        return this;
    }

    @JsonProperty("isActive")
    public Boolean getIsActive() {
        return isActive;
    }

    @JsonProperty("isActive")
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public InsertInsuranceToPatientResponse withIsActive(Boolean isActive) {
        this.isActive = isActive;
        return this;
    }

    @JsonProperty("externalId")
    public Object getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Object externalId) {
        this.externalId = externalId;
    }

    public InsertInsuranceToPatientResponse withExternalId(Object externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public InsertInsuranceToPatientResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InsertInsuranceToPatientResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientInsuranceId).append(patientId).append(carrierId).append(organizationId).append(insuredId).append(insuranceId).append(displayName).append(relationshipToInsured).append(planName).append(groupNumber).append(groupName).append(employer).append(authorizationNumber).append(insuranceCarrierId).append(insurancePlanId).append(claimOfficeId).append(carrier).append(firstName).append(lastName).append(middleInitial).append(suffix).append(gender).append(dateOfBirth).append(address1).append(address2).append(city).append(state).append(zipCode).append(countyName).append(countryName).append(email).append(primaryPhone).append(insuranceClaimOfficeId).append(isAdditionalClaimInfClassification).append(effectiveFrom).append(effectiveTo).append(isMspInsuranceTypeClassification).append(sortOrder).append(generateClaimTf).append(isInsuranceMappedWithCharge).append(isActive).append(externalId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InsertInsuranceToPatientResponse) == false) {
            return false;
        }
        InsertInsuranceToPatientResponse rhs = ((InsertInsuranceToPatientResponse) other);
        return new EqualsBuilder().append(patientInsuranceId, rhs.patientInsuranceId).append(patientId, rhs.patientId).append(carrierId, rhs.carrierId).append(organizationId, rhs.organizationId).append(insuredId, rhs.insuredId).append(insuranceId, rhs.insuranceId).append(displayName, rhs.displayName).append(relationshipToInsured, rhs.relationshipToInsured).append(planName, rhs.planName).append(groupNumber, rhs.groupNumber).append(groupName, rhs.groupName).append(employer, rhs.employer).append(authorizationNumber, rhs.authorizationNumber).append(insuranceCarrierId, rhs.insuranceCarrierId).append(insurancePlanId, rhs.insurancePlanId).append(claimOfficeId, rhs.claimOfficeId).append(carrier, rhs.carrier).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(suffix, rhs.suffix).append(gender, rhs.gender).append(dateOfBirth, rhs.dateOfBirth).append(address1, rhs.address1).append(address2, rhs.address2).append(city, rhs.city).append(state, rhs.state).append(zipCode, rhs.zipCode).append(countyName, rhs.countyName).append(countryName, rhs.countryName).append(email, rhs.email).append(primaryPhone, rhs.primaryPhone).append(insuranceClaimOfficeId, rhs.insuranceClaimOfficeId).append(isAdditionalClaimInfClassification, rhs.isAdditionalClaimInfClassification).append(effectiveFrom, rhs.effectiveFrom).append(effectiveTo, rhs.effectiveTo).append(isMspInsuranceTypeClassification, rhs.isMspInsuranceTypeClassification).append(sortOrder, rhs.sortOrder).append(generateClaimTf, rhs.generateClaimTf).append(isInsuranceMappedWithCharge, rhs.isInsuranceMappedWithCharge).append(isActive, rhs.isActive).append(externalId, rhs.externalId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
