
package com.bhavani.models.ppe.appointmentRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "phoneId",
    "patientId",
    "adtMaintainedFieldArray",
    "primaryContactTf",
    "phoneNumber",
    "phoneExtension",
    "isCellPhoneTf",
    "phoneType"
})
public class MpiPatientPhone {

    @JsonProperty("phoneId")
    private int phoneId;
    @JsonProperty("patientId")
    private int patientId;
    @JsonProperty("primaryContactTf")
    private boolean primaryContactTf;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("phoneExtension")
    private Object phoneExtension;
    @JsonProperty("isCellPhoneTf")
    private boolean isCellPhoneTf;
    @JsonProperty("phoneType")
    private String phoneType;
    @JsonProperty("adtMaintainedFieldArray")
    private List<Object> adtMaintainedFieldArray;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("primaryContactTf")
    public Object getPrimaryContactTf() {
        return primaryContactTf;
    }

    @JsonProperty("primaryContactTf")
    public void setPrimaryContactTf(boolean primaryContactTf) {
        this.primaryContactTf = primaryContactTf;
    }

    public MpiPatientPhone withPrimaryContactTf(boolean primaryContactTf) {
        this.primaryContactTf = primaryContactTf;
        return this;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public MpiPatientPhone withPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("phoneExtension")
    public Object getPhoneExtension() {
        return phoneExtension;
    }

    @JsonProperty("phoneExtension")
    public void setPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    public MpiPatientPhone withPhoneExtension(Object phoneExtension) {
        this.phoneExtension = phoneExtension;
        return this;
    }

    @JsonProperty("isCellPhoneTf")
    public Object getIsCellPhoneTf() {
        return isCellPhoneTf;
    }

    @JsonProperty("isCellPhoneTf")
    public void setIsCellPhoneTf(boolean isCellPhoneTf) {
        this.isCellPhoneTf = isCellPhoneTf;
    }

    public MpiPatientPhone withIsCellPhoneTf(boolean isCellPhoneTf) {
        this.isCellPhoneTf = isCellPhoneTf;
        return this;
    }

    @JsonProperty("phoneId")
    public int getPhoneId() {
        return phoneId;
    }

    @JsonProperty("phoneId")
    public void setPhoneId(int phoneId) {
        this.phoneId = phoneId;
    }

    public MpiPatientPhone withPhoneId(int phoneId) {
        this.phoneId = phoneId;
        return this;
    }

    @JsonProperty("patientId")
    public int getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public MpiPatientPhone withPatientId(int patientId) {
        this.phoneType = phoneType;
        return this;
    }

    @JsonProperty("phoneType")
    public String getPhoneType() {
        return phoneType;
    }

    @JsonProperty("phoneType")
    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public MpiPatientPhone withPhoneType(String phoneType) {
        this.phoneType = phoneType;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MpiPatientPhone withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(primaryContactTf).append(phoneNumber).append(phoneExtension).append(isCellPhoneTf).append(phoneType).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MpiPatientPhone) == false) {
            return false;
        }
        MpiPatientPhone rhs = ((MpiPatientPhone) other);
        return new EqualsBuilder().append(primaryContactTf, rhs.primaryContactTf).append(phoneNumber, rhs.phoneNumber).append(phoneExtension, rhs.phoneExtension).append(isCellPhoneTf, rhs.isCellPhoneTf).append(phoneType, rhs.phoneType).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
