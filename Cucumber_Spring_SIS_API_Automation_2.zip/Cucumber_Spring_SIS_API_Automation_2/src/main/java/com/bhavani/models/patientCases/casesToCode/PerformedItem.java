
package com.bhavani.models.patientCases.casesToCode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bhavani.models.configuration.business.feeSchedule.FeeSchedule;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "unableToCode",
    "panelCollapsed",
    "diagnosisList",
    "primaryInsurancesList",
    "secondaryInsurancesList",
    "tertiaryInsurancesList",
    "controlsModifiedInEditChargeMode",
    "fullChargeCorrectionRequired",
    "generateBillStateModified",
    "performedCaseSupply",
    "selectedSupplyToInventory",
    "isReadOnlyPeriodBatch",
    "resetClosedPeriodBatch",
    "isNewProcedureAdded",
    "isAmountChanged",
    "insuranceModification",
    "guarantorModification",
    "isGCode",
    "isCombinedCodingChargeEntry",
    "isCorrected",
    "hovered",
    "diagnosisCodesRemoved",
    "guid",
    "caseSummaryId",
    "caseProcedureId",
    "cptProcedureId",
    "cptCode",
    "cptProcedureDescription",
    "providerId",
    "physicianName",
    "feeScheduleId",
    "generateBill",
    "feeScheduleItem",
    "units",
    "performedCaseItemTypeId",
    "sortorder"
})
public class PerformedItem {

    @JsonProperty("unableToCode")
    private Boolean unableToCode;
    @JsonProperty("panelCollapsed")
    private Boolean panelCollapsed;
    @JsonProperty("diagnosisList")
    private List<DiagnosisList> diagnosisList = new ArrayList<DiagnosisList>();
    @JsonProperty("primaryInsurancesList")
    private List<Object> primaryInsurancesList = new ArrayList<Object>();
    @JsonProperty("secondaryInsurancesList")
    private List<Object> secondaryInsurancesList = new ArrayList<Object>();
    @JsonProperty("tertiaryInsurancesList")
    private List<Object> tertiaryInsurancesList = new ArrayList<Object>();
    @JsonProperty("controlsModifiedInEditChargeMode")
    private Boolean controlsModifiedInEditChargeMode;
    @JsonProperty("fullChargeCorrectionRequired")
    private Boolean fullChargeCorrectionRequired;
    @JsonProperty("generateBillStateModified")
    private Boolean generateBillStateModified;
    @JsonProperty("performedCaseSupply")
    private PerformedCaseSupply performedCaseSupply;
    @JsonProperty("selectedSupplyToInventory")
    private Object selectedSupplyToInventory;
    @JsonProperty("isReadOnlyPeriodBatch")
    private Boolean isReadOnlyPeriodBatch;
    @JsonProperty("resetClosedPeriodBatch")
    private Boolean resetClosedPeriodBatch;
    @JsonProperty("isNewProcedureAdded")
    private Boolean isNewProcedureAdded;
    @JsonProperty("isAmountChanged")
    private Boolean isAmountChanged;
    @JsonProperty("insuranceModification")
    private Integer insuranceModification;
    @JsonProperty("guarantorModification")
    private Integer guarantorModification;
    @JsonProperty("isGCode")
    private Boolean isGCode;
    @JsonProperty("hovered")
    private Boolean hovered;
    @JsonProperty("isCombinedCodingChargeEntry")
    private Boolean isCombinedCodingChargeEntry;
    @JsonProperty("isCorrected")
    private Boolean isCorrected;
    @JsonProperty("diagnosisCodesRemoved")
    private Boolean diagnosisCodesRemoved;
    @JsonProperty("guid")
    private String guid;
    @JsonProperty("caseSummaryId")
    private Integer caseSummaryId;
    @JsonProperty("caseProcedureId")
    private Integer caseProcedureId;
    @JsonProperty("cptProcedureId")
    private Integer cptProcedureId;
    @JsonProperty("cptCode")
    private String cptCode;
    @JsonProperty("cptProcedureDescription")
    private String cptProcedureDescription;
    @JsonProperty("providerId")
    private Integer providerId;
    @JsonProperty("physicianName")
    private String physicianName;
    @JsonProperty("feeScheduleId")
    private Integer feeScheduleId;
    @JsonProperty("generateBill")
    private Boolean generateBill;
    @JsonProperty("feeScheduleItem")
    private FeeSchedule feeScheduleItem;
    @JsonProperty("units")
    private Integer units;
    @JsonProperty("performedCaseItemTypeId")
    private Integer performedCaseItemTypeId;
    @JsonProperty("sortorder")
    private Integer sortorder;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("unableToCode")
    public Boolean getUnableToCode() {
        return unableToCode;
    }

    @JsonProperty("unableToCode")
    public void setUnableToCode(Boolean unableToCode) {
        this.unableToCode = unableToCode;
    }

    public PerformedItem withUnableToCode(Boolean unableToCode) {
        this.unableToCode = unableToCode;
        return this;
    }

    @JsonProperty("panelCollapsed")
    public Boolean getPanelCollapsed() {
        return panelCollapsed;
    }

    @JsonProperty("panelCollapsed")
    public void setPanelCollapsed(Boolean panelCollapsed) {
        this.panelCollapsed = panelCollapsed;
    }

    public PerformedItem withPanelCollapsed(Boolean panelCollapsed) {
        this.panelCollapsed = panelCollapsed;
        return this;
    }

    @JsonProperty("diagnosisList")
    public List<DiagnosisList> getDiagnosisList() {
        return diagnosisList;
    }

    @JsonProperty("diagnosisList")
    public void setDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
    }

    public PerformedItem withDiagnosisList(List<DiagnosisList> diagnosisList) {
        this.diagnosisList = diagnosisList;
        return this;
    }

    @JsonProperty("primaryInsurancesList")
    public List<Object> getPrimaryInsurancesList() {
        return primaryInsurancesList;
    }

    @JsonProperty("primaryInsurancesList")
    public void setPrimaryInsurancesList(List<Object> primaryInsurancesList) {
        this.primaryInsurancesList = primaryInsurancesList;
    }

    public PerformedItem withPrimaryInsurancesList(List<Object> primaryInsurancesList) {
        this.primaryInsurancesList = primaryInsurancesList;
        return this;
    }

    @JsonProperty("secondaryInsurancesList")
    public List<Object> getSecondaryInsurancesList() {
        return secondaryInsurancesList;
    }

    @JsonProperty("secondaryInsurancesList")
    public void setSecondaryInsurancesList(List<Object> secondaryInsurancesList) {
        this.secondaryInsurancesList = secondaryInsurancesList;
    }

    public PerformedItem withSecondaryInsurancesList(List<Object> secondaryInsurancesList) {
        this.secondaryInsurancesList = secondaryInsurancesList;
        return this;
    }

    @JsonProperty("tertiaryInsurancesList")
    public List<Object> getTertiaryInsurancesList() {
        return tertiaryInsurancesList;
    }

    @JsonProperty("tertiaryInsurancesList")
    public void setTertiaryInsurancesList(List<Object> tertiaryInsurancesList) {
        this.tertiaryInsurancesList = tertiaryInsurancesList;
    }

    public PerformedItem withTertiaryInsurancesList(List<Object> tertiaryInsurancesList) {
        this.tertiaryInsurancesList = tertiaryInsurancesList;
        return this;
    }

    @JsonProperty("controlsModifiedInEditChargeMode")
    public Boolean getControlsModifiedInEditChargeMode() {
        return controlsModifiedInEditChargeMode;
    }

    @JsonProperty("controlsModifiedInEditChargeMode")
    public void setControlsModifiedInEditChargeMode(Boolean controlsModifiedInEditChargeMode) {
        this.controlsModifiedInEditChargeMode = controlsModifiedInEditChargeMode;
    }

    public PerformedItem withControlsModifiedInEditChargeMode(Boolean controlsModifiedInEditChargeMode) {
        this.controlsModifiedInEditChargeMode = controlsModifiedInEditChargeMode;
        return this;
    }

    @JsonProperty("fullChargeCorrectionRequired")
    public Boolean getFullChargeCorrectionRequired() {
        return fullChargeCorrectionRequired;
    }

    @JsonProperty("fullChargeCorrectionRequired")
    public void setFullChargeCorrectionRequired(Boolean fullChargeCorrectionRequired) {
        this.fullChargeCorrectionRequired = fullChargeCorrectionRequired;
    }

    public PerformedItem withFullChargeCorrectionRequired(Boolean fullChargeCorrectionRequired) {
        this.fullChargeCorrectionRequired = fullChargeCorrectionRequired;
        return this;
    }

    @JsonProperty("generateBillStateModified")
    public Boolean getGenerateBillStateModified() {
        return generateBillStateModified;
    }

    @JsonProperty("generateBillStateModified")
    public void setGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
    }

    public PerformedItem withGenerateBillStateModified(Boolean generateBillStateModified) {
        this.generateBillStateModified = generateBillStateModified;
        return this;
    }

    @JsonProperty("performedCaseSupply")
    public PerformedCaseSupply getPerformedCaseSupply() {
        return performedCaseSupply;
    }

    @JsonProperty("performedCaseSupply")
    public void setPerformedCaseSupply(PerformedCaseSupply performedCaseSupply) {
        this.performedCaseSupply = performedCaseSupply;
    }

    public PerformedItem withPerformedCaseSupply(PerformedCaseSupply performedCaseSupply) {
        this.performedCaseSupply = performedCaseSupply;
        return this;
    }

    @JsonProperty("selectedSupplyToInventory")
    public Object getSelectedSupplyToInventory() {
        return selectedSupplyToInventory;
    }

    @JsonProperty("selectedSupplyToInventory")
    public void setSelectedSupplyToInventory(Object selectedSupplyToInventory) {
        this.selectedSupplyToInventory = selectedSupplyToInventory;
    }

    public PerformedItem withSelectedSupplyToInventory(Object selectedSupplyToInventory) {
        this.selectedSupplyToInventory = selectedSupplyToInventory;
        return this;
    }

    @JsonProperty("isReadOnlyPeriodBatch")
    public Boolean getIsReadOnlyPeriodBatch() {
        return isReadOnlyPeriodBatch;
    }

    @JsonProperty("isReadOnlyPeriodBatch")
    public void setIsReadOnlyPeriodBatch(Boolean isReadOnlyPeriodBatch) {
        this.isReadOnlyPeriodBatch = isReadOnlyPeriodBatch;
    }

    public PerformedItem withIsReadOnlyPeriodBatch(Boolean isReadOnlyPeriodBatch) {
        this.isReadOnlyPeriodBatch = isReadOnlyPeriodBatch;
        return this;
    }

    @JsonProperty("resetClosedPeriodBatch")
    public Boolean getResetClosedPeriodBatch() {
        return resetClosedPeriodBatch;
    }

    @JsonProperty("resetClosedPeriodBatch")
    public void setResetClosedPeriodBatch(Boolean resetClosedPeriodBatch) {
        this.resetClosedPeriodBatch = resetClosedPeriodBatch;
    }

    public PerformedItem withResetClosedPeriodBatch(Boolean resetClosedPeriodBatch) {
        this.resetClosedPeriodBatch = resetClosedPeriodBatch;
        return this;
    }

    @JsonProperty("isNewProcedureAdded")
    public Boolean getIsNewProcedureAdded() {
        return isNewProcedureAdded;
    }

    @JsonProperty("isNewProcedureAdded")
    public void setIsNewProcedureAdded(Boolean isNewProcedureAdded) {
        this.isNewProcedureAdded = isNewProcedureAdded;
    }

    public PerformedItem withIsNewProcedureAdded(Boolean isNewProcedureAdded) {
        this.isNewProcedureAdded = isNewProcedureAdded;
        return this;
    }

    @JsonProperty("hovered")
    public Boolean getHovered() {
        return hovered;
    }

    @JsonProperty("hovered")
    public void setHovered(Boolean hovered) {
        this.hovered = hovered;
    }

    public PerformedItem withIsHovered(Boolean hovered) {
        this.hovered = hovered;
        return this;
    }

    @JsonProperty("isAmountChanged")
    public Boolean getIsAmountChanged() {
        return isAmountChanged;
    }

    @JsonProperty("isAmountChanged")
    public void setIsAmountChanged(Boolean isAmountChanged) {
        this.isAmountChanged = isAmountChanged;
    }

    public PerformedItem withIsAmountChanged(Boolean isAmountChanged) {
        this.isAmountChanged = isAmountChanged;
        return this;
    }

    @JsonProperty("insuranceModification")
    public Integer getInsuranceModification() {
        return insuranceModification;
    }

    @JsonProperty("insuranceModification")
    public void setInsuranceModification(Integer insuranceModification) {
        this.insuranceModification = insuranceModification;
    }

    public PerformedItem withInsuranceModification(Integer insuranceModification) {
        this.insuranceModification = insuranceModification;
        return this;
    }

    @JsonProperty("guarantorModification")
    public Integer getGuarantorModification() {
        return guarantorModification;
    }

    @JsonProperty("guarantorModification")
    public void setGuarantorModification(Integer guarantorModification) {
        this.guarantorModification = guarantorModification;
    }

    public PerformedItem withGuarantorModification(Integer guarantorModification) {
        this.guarantorModification = guarantorModification;
        return this;
    }

    @JsonProperty("isGCode")
    public Boolean getIsGCode() {
        return isGCode;
    }

    @JsonProperty("isGCode")
    public void setIsGCode(Boolean isGCode) {
        this.isGCode = isGCode;
    }

    public PerformedItem withIsGCode(Boolean isGCode) {
        this.isGCode = isGCode;
        return this;
    }

    @JsonProperty("isCombinedCodingChargeEntry")
    public Boolean getIsCombinedCodingChargeEntry() {
        return isCombinedCodingChargeEntry;
    }

    @JsonProperty("isCombinedCodingChargeEntry")
    public void setIsCombinedCodingChargeEntry(Boolean isCombinedCodingChargeEntry) {
        this.isCombinedCodingChargeEntry = isCombinedCodingChargeEntry;
    }

    public PerformedItem withIsCombinedCodingChargeEntry(Boolean isCombinedCodingChargeEntry) {
        this.isCombinedCodingChargeEntry = isCombinedCodingChargeEntry;
        return this;
    }

    @JsonProperty("isCorrected")
    public Boolean getIsCorrected() {
        return isCorrected;
    }

    @JsonProperty("isCorrected")
    public void setIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
    }

    public PerformedItem withIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
        return this;
    }

    @JsonProperty("diagnosisCodesRemoved")
    public Boolean getDiagnosisCodesRemoved() {
        return diagnosisCodesRemoved;
    }

    @JsonProperty("diagnosisCodesRemoved")
    public void setDiagnosisCodesRemoved(Boolean diagnosisCodesRemoved) {
        this.diagnosisCodesRemoved = diagnosisCodesRemoved;
    }

    public PerformedItem withDiagnosisCodesRemoved(Boolean diagnosisCodesRemoved) {
        this.diagnosisCodesRemoved = diagnosisCodesRemoved;
        return this;
    }

    @JsonProperty("guid")
    public String getGuid() {
        return guid;
    }

    @JsonProperty("guid")
    public void setGuid(String guid) {
        this.guid = guid;
    }

    public PerformedItem withGuid(String guid) {
        this.guid = guid;
        return this;
    }

    @JsonProperty("caseSummaryId")
    public Integer getCaseSummaryId() {
        return caseSummaryId;
    }

    @JsonProperty("caseSummaryId")
    public void setCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
    }

    public PerformedItem withCaseSummaryId(Integer caseSummaryId) {
        this.caseSummaryId = caseSummaryId;
        return this;
    }

    @JsonProperty("caseProcedureId")
    public Integer getCaseProcedureId() {
        return caseProcedureId;
    }

    @JsonProperty("caseProcedureId")
    public void setCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
    }

    public PerformedItem withCaseProcedureId(Integer caseProcedureId) {
        this.caseProcedureId = caseProcedureId;
        return this;
    }

    @JsonProperty("cptProcedureId")
    public Integer getCptProcedureId() {
        return cptProcedureId;
    }

    @JsonProperty("cptProcedureId")
    public void setCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
    }

    public PerformedItem withCptProcedureId(Integer cptProcedureId) {
        this.cptProcedureId = cptProcedureId;
        return this;
    }

    @JsonProperty("cptCode")
    public String getCptCode() {
        return cptCode;
    }

    @JsonProperty("cptCode")
    public void setCptCode(String cptCode) {
        this.cptCode = cptCode;
    }

    public PerformedItem withCptCode(String cptCode) {
        this.cptCode = cptCode;
        return this;
    }

    @JsonProperty("cptProcedureDescription")
    public String getCptProcedureDescription() {
        return cptProcedureDescription;
    }

    @JsonProperty("cptProcedureDescription")
    public void setCptProcedureDescription(String cptProcedureDescription) {
        this.cptProcedureDescription = cptProcedureDescription;
    }

    public PerformedItem withCptProcedureDescription(String cptProcedureDescription) {
        this.cptProcedureDescription = cptProcedureDescription;
        return this;
    }

    @JsonProperty("providerId")
    public Integer getProviderId() {
        return providerId;
    }

    @JsonProperty("providerId")
    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }

    public PerformedItem withProviderId(Integer providerId) {
        this.providerId = providerId;
        return this;
    }

    @JsonProperty("physicianName")
    public String getPhysicianName() {
        return physicianName;
    }

    @JsonProperty("physicianName")
    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public PerformedItem withPhysicianName(String physicianName) {
        this.physicianName = physicianName;
        return this;
    }

    @JsonProperty("feeScheduleId")
    public Integer getFeeScheduleId() {
        return feeScheduleId;
    }

    @JsonProperty("feeScheduleId")
    public void setFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
    }

    public PerformedItem withFeeScheduleId(Integer feeScheduleId) {
        this.feeScheduleId = feeScheduleId;
        return this;
    }

    @JsonProperty("generateBill")
    public Boolean getGenerateBill() {
        return generateBill;
    }

    @JsonProperty("generateBill")
    public void setGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
    }

    public PerformedItem withGenerateBill(Boolean generateBill) {
        this.generateBill = generateBill;
        return this;
    }

    @JsonProperty("feeScheduleItem")
    public FeeSchedule getFeeScheduleItem() {
        return feeScheduleItem;
    }

    @JsonProperty("feeScheduleItem")
    public void setFeeScheduleItem(FeeSchedule feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
    }

    public PerformedItem withFeeScheduleItem(FeeSchedule feeScheduleItem) {
        this.feeScheduleItem = feeScheduleItem;
        return this;
    }

    @JsonProperty("units")
    public Integer getUnits() {
        return units;
    }

    @JsonProperty("units")
    public void setUnits(Integer units) {
        this.units = units;
    }

    public PerformedItem withUnits(Integer units) {
        this.units = units;
        return this;
    }

    @JsonProperty("performedCaseItemTypeId")
    public Integer getPerformedCaseItemTypeId() {
        return performedCaseItemTypeId;
    }

    @JsonProperty("performedCaseItemTypeId")
    public void setPerformedCaseItemTypeId(Integer performedCaseItemTypeId) {
        this.performedCaseItemTypeId = performedCaseItemTypeId;
    }

    public PerformedItem withPerformedCaseItemTypeId(Integer performedCaseItemTypeId) {
        this.performedCaseItemTypeId = performedCaseItemTypeId;
        return this;
    }

    @JsonProperty("sortorder")
    public Integer getSortorder() {
        return sortorder;
    }

    @JsonProperty("sortorder")
    public void setSortorder(Integer sortorder) {
        this.sortorder = sortorder;
    }

    public PerformedItem withSortorder(Integer sortorder) {
        this.sortorder = sortorder;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PerformedItem withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(unableToCode).append(panelCollapsed).append(diagnosisList).append(primaryInsurancesList).append(secondaryInsurancesList).append(tertiaryInsurancesList).append(controlsModifiedInEditChargeMode).append(fullChargeCorrectionRequired).append(generateBillStateModified).append(performedCaseSupply).append(selectedSupplyToInventory).append(isReadOnlyPeriodBatch).append(resetClosedPeriodBatch).append(isNewProcedureAdded).append(isAmountChanged).append(insuranceModification).append(guarantorModification).append(isGCode).append(isCombinedCodingChargeEntry).append(isCorrected).append(diagnosisCodesRemoved).append(guid).append(caseSummaryId).append(caseProcedureId).append(cptProcedureId).append(cptCode).append(cptProcedureDescription).append(providerId).append(physicianName).append(feeScheduleId).append(generateBill).append(feeScheduleItem).append(units).append(performedCaseItemTypeId).append(sortorder).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PerformedItem) == false) {
            return false;
        }
        PerformedItem rhs = ((PerformedItem) other);
        return new EqualsBuilder().append(unableToCode, rhs.unableToCode).append(panelCollapsed, rhs.panelCollapsed).append(diagnosisList, rhs.diagnosisList).append(primaryInsurancesList, rhs.primaryInsurancesList).append(secondaryInsurancesList, rhs.secondaryInsurancesList).append(tertiaryInsurancesList, rhs.tertiaryInsurancesList).append(controlsModifiedInEditChargeMode, rhs.controlsModifiedInEditChargeMode).append(fullChargeCorrectionRequired, rhs.fullChargeCorrectionRequired).append(generateBillStateModified, rhs.generateBillStateModified).append(performedCaseSupply, rhs.performedCaseSupply).append(selectedSupplyToInventory, rhs.selectedSupplyToInventory).append(isReadOnlyPeriodBatch, rhs.isReadOnlyPeriodBatch).append(resetClosedPeriodBatch, rhs.resetClosedPeriodBatch).append(isNewProcedureAdded, rhs.isNewProcedureAdded).append(isAmountChanged, rhs.isAmountChanged).append(insuranceModification, rhs.insuranceModification).append(guarantorModification, rhs.guarantorModification).append(isGCode, rhs.isGCode).append(isCombinedCodingChargeEntry, rhs.isCombinedCodingChargeEntry).append(isCorrected, rhs.isCorrected).append(diagnosisCodesRemoved, rhs.diagnosisCodesRemoved).append(guid, rhs.guid).append(caseSummaryId, rhs.caseSummaryId).append(caseProcedureId, rhs.caseProcedureId).append(cptProcedureId, rhs.cptProcedureId).append(cptCode, rhs.cptCode).append(cptProcedureDescription, rhs.cptProcedureDescription).append(providerId, rhs.providerId).append(physicianName, rhs.physicianName).append(feeScheduleId, rhs.feeScheduleId).append(generateBill, rhs.generateBill).append(feeScheduleItem, rhs.feeScheduleItem).append(units, rhs.units).append(performedCaseItemTypeId, rhs.performedCaseItemTypeId).append(sortorder, rhs.sortorder).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
