
package com.bhavani.models.patientCases.dischargePatient;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "state",
    "formId",
    "formName",
    "moduleOptionId",
    "formOrder",
    "featureTypeId",
    "sourceIdentifier"
})
public class FormByName {

    @JsonProperty("state")
    private Object state;
    @JsonProperty("formId")
    private Integer formId;
    @JsonProperty("formName")
    private String formName;
    @JsonProperty("moduleOptionId")
    private Integer moduleOptionId;
    @JsonProperty("formOrder")
    private Integer formOrder;
    @JsonProperty("featureTypeId")
    private Object featureTypeId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("state")
    public Object getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(Object state) {
        this.state = state;
    }

    public FormByName withState(Object state) {
        this.state = state;
        return this;
    }

    @JsonProperty("formId")
    public Integer getFormId() {
        return formId;
    }

    @JsonProperty("formId")
    public void setFormId(Integer formId) {
        this.formId = formId;
    }

    public FormByName withFormId(Integer formId) {
        this.formId = formId;
        return this;
    }

    @JsonProperty("formName")
    public String getFormName() {
        return formName;
    }

    @JsonProperty("formName")
    public void setFormName(String formName) {
        this.formName = formName;
    }

    public FormByName withFormName(String formName) {
        this.formName = formName;
        return this;
    }

    @JsonProperty("moduleOptionId")
    public Integer getModuleOptionId() {
        return moduleOptionId;
    }

    @JsonProperty("moduleOptionId")
    public void setModuleOptionId(Integer moduleOptionId) {
        this.moduleOptionId = moduleOptionId;
    }

    public FormByName withModuleOptionId(Integer moduleOptionId) {
        this.moduleOptionId = moduleOptionId;
        return this;
    }

    @JsonProperty("formOrder")
    public Integer getFormOrder() {
        return formOrder;
    }

    @JsonProperty("formOrder")
    public void setFormOrder(Integer formOrder) {
        this.formOrder = formOrder;
    }

    public FormByName withFormOrder(Integer formOrder) {
        this.formOrder = formOrder;
        return this;
    }

    @JsonProperty("featureTypeId")
    public Object getFeatureTypeId() {
        return featureTypeId;
    }

    @JsonProperty("featureTypeId")
    public void setFeatureTypeId(Object featureTypeId) {
        this.featureTypeId = featureTypeId;
    }

    public FormByName withFeatureTypeId(Object featureTypeId) {
        this.featureTypeId = featureTypeId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public FormByName withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FormByName withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(state).append(formId).append(formName).append(moduleOptionId).append(formOrder).append(featureTypeId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FormByName) == false) {
            return false;
        }
        FormByName rhs = ((FormByName) other);
        return new EqualsBuilder().append(state, rhs.state).append(formId, rhs.formId).append(formName, rhs.formName).append(moduleOptionId, rhs.moduleOptionId).append(formOrder, rhs.formOrder).append(featureTypeId, rhs.featureTypeId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
