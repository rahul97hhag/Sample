
package com.bhavani.models.configuration.business.insurance.insuranceResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "insurancePlanId",
    "insuranceCarrierId",
    "planName",
    "savedPlanName",
    "classification",
    "planType",
    "groupInsuranceid",
    "primaryEmcPayerid",
    "secondaryEmcPayerid",
    "primaryHpId",
    "secondaryHpId",
    "defaultPlanTf",
    "acceptAssignmentTf",
    "generateClaimTf",
    "billPrimaryGuarantorTf",
    "contract",
    "address1",
    "city",
    "state",
    "zipCode",
    "extendedZipCode",
    "phoneNumber",
    "contactName",
    "isPlanExist",
    "claimOfficeId",
    "insuranceContractId",
    "insurancePlanIds",
    "paymentTransactionCodeId",
    "paymentTransactionCodeName",
    "writeOffTransactionCodeId",
    "writeOffTransactionCodeName",
    "writeOffGroupId",
    "writeOffGroupName",
    "writeOffReasonId",
    "writeOffReasonName",
    "insurancePlanContractList",
    "sourceIdentifier"
})
public class SaveInsurancePlanResponse {

    @JsonProperty("insurancePlanId")
    private Integer insurancePlanId;
    @JsonProperty("insuranceCarrierId")
    private Integer insuranceCarrierId;
    @JsonProperty("planName")
    private String planName;
    @JsonProperty("savedPlanName")
    private Object savedPlanName;
    @JsonProperty("classification")
    private String classification;
    @JsonProperty("planType")
    private Object planType;
    @JsonProperty("groupInsuranceid")
    private String groupInsuranceid;
    @JsonProperty("primaryEmcPayerid")
    private String primaryEmcPayerid;
    @JsonProperty("secondaryEmcPayerid")
    private String secondaryEmcPayerid;
    @JsonProperty("primaryHpId")
    private String primaryHpId;
    @JsonProperty("secondaryHpId")
    private String secondaryHpId;
    @JsonProperty("defaultPlanTf")
    private Boolean defaultPlanTf;
    @JsonProperty("acceptAssignmentTf")
    private Object acceptAssignmentTf;
    @JsonProperty("generateClaimTf")
    private Boolean generateClaimTf;
    @JsonProperty("billPrimaryGuarantorTf")
    private Object billPrimaryGuarantorTf;
    @JsonProperty("contract")
    private Object contract;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("extendedZipCode")
    private String extendedZipCode;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("contactName")
    private String contactName;
    @JsonProperty("isPlanExist")
    private Boolean isPlanExist;
    @JsonProperty("claimOfficeId")
    private Integer claimOfficeId;
    @JsonProperty("insuranceContractId")
    private Object insuranceContractId;
    @JsonProperty("insurancePlanIds")
    private Object insurancePlanIds;
    @JsonProperty("paymentTransactionCodeId")
    private Object paymentTransactionCodeId;
    @JsonProperty("paymentTransactionCodeName")
    private Object paymentTransactionCodeName;
    @JsonProperty("writeOffTransactionCodeId")
    private Object writeOffTransactionCodeId;
    @JsonProperty("writeOffTransactionCodeName")
    private Object writeOffTransactionCodeName;
    @JsonProperty("writeOffGroupId")
    private Object writeOffGroupId;
    @JsonProperty("writeOffGroupName")
    private Object writeOffGroupName;
    @JsonProperty("writeOffReasonId")
    private Object writeOffReasonId;
    @JsonProperty("writeOffReasonName")
    private Object writeOffReasonName;
    @JsonProperty("insurancePlanContractList")
    private List<Object> insurancePlanContractList = new ArrayList<Object>();
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("insurancePlanId")
    public Integer getInsurancePlanId() {
        return insurancePlanId;
    }

    @JsonProperty("insurancePlanId")
    public void setInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
    }

    public SaveInsurancePlanResponse withInsurancePlanId(Integer insurancePlanId) {
        this.insurancePlanId = insurancePlanId;
        return this;
    }

    @JsonProperty("insuranceCarrierId")
    public Integer getInsuranceCarrierId() {
        return insuranceCarrierId;
    }

    @JsonProperty("insuranceCarrierId")
    public void setInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
    }

    public SaveInsurancePlanResponse withInsuranceCarrierId(Integer insuranceCarrierId) {
        this.insuranceCarrierId = insuranceCarrierId;
        return this;
    }

    @JsonProperty("planName")
    public String getPlanName() {
        return planName;
    }

    @JsonProperty("planName")
    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public SaveInsurancePlanResponse withPlanName(String planName) {
        this.planName = planName;
        return this;
    }

    @JsonProperty("savedPlanName")
    public Object getSavedPlanName() {
        return savedPlanName;
    }

    @JsonProperty("savedPlanName")
    public void setSavedPlanName(Object savedPlanName) {
        this.savedPlanName = savedPlanName;
    }

    public SaveInsurancePlanResponse withSavedPlanName(Object savedPlanName) {
        this.savedPlanName = savedPlanName;
        return this;
    }

    @JsonProperty("classification")
    public String getClassification() {
        return classification;
    }

    @JsonProperty("classification")
    public void setClassification(String classification) {
        this.classification = classification;
    }

    public SaveInsurancePlanResponse withClassification(String classification) {
        this.classification = classification;
        return this;
    }

    @JsonProperty("planType")
    public Object getPlanType() {
        return planType;
    }

    @JsonProperty("planType")
    public void setPlanType(Object planType) {
        this.planType = planType;
    }

    public SaveInsurancePlanResponse withPlanType(Object planType) {
        this.planType = planType;
        return this;
    }

    @JsonProperty("groupInsuranceid")
    public String getGroupInsuranceid() {
        return groupInsuranceid;
    }

    @JsonProperty("groupInsuranceid")
    public void setGroupInsuranceid(String groupInsuranceid) {
        this.groupInsuranceid = groupInsuranceid;
    }

    public SaveInsurancePlanResponse withGroupInsuranceid(String groupInsuranceid) {
        this.groupInsuranceid = groupInsuranceid;
        return this;
    }

    @JsonProperty("primaryEmcPayerid")
    public String getPrimaryEmcPayerid() {
        return primaryEmcPayerid;
    }

    @JsonProperty("primaryEmcPayerid")
    public void setPrimaryEmcPayerid(String primaryEmcPayerid) {
        this.primaryEmcPayerid = primaryEmcPayerid;
    }

    public SaveInsurancePlanResponse withPrimaryEmcPayerid(String primaryEmcPayerid) {
        this.primaryEmcPayerid = primaryEmcPayerid;
        return this;
    }

    @JsonProperty("secondaryEmcPayerid")
    public String getSecondaryEmcPayerid() {
        return secondaryEmcPayerid;
    }

    @JsonProperty("secondaryEmcPayerid")
    public void setSecondaryEmcPayerid(String secondaryEmcPayerid) {
        this.secondaryEmcPayerid = secondaryEmcPayerid;
    }

    public SaveInsurancePlanResponse withSecondaryEmcPayerid(String secondaryEmcPayerid) {
        this.secondaryEmcPayerid = secondaryEmcPayerid;
        return this;
    }

    @JsonProperty("primaryHpId")
    public String getPrimaryHpId() {
        return primaryHpId;
    }

    @JsonProperty("primaryHpId")
    public void setPrimaryHpId(String primaryHpId) {
        this.primaryHpId = primaryHpId;
    }

    public SaveInsurancePlanResponse withPrimaryHpId(String primaryHpId) {
        this.primaryHpId = primaryHpId;
        return this;
    }

    @JsonProperty("secondaryHpId")
    public String getSecondaryHpId() {
        return secondaryHpId;
    }

    @JsonProperty("secondaryHpId")
    public void setSecondaryHpId(String secondaryHpId) {
        this.secondaryHpId = secondaryHpId;
    }

    public SaveInsurancePlanResponse withSecondaryHpId(String secondaryHpId) {
        this.secondaryHpId = secondaryHpId;
        return this;
    }

    @JsonProperty("defaultPlanTf")
    public Boolean getDefaultPlanTf() {
        return defaultPlanTf;
    }

    @JsonProperty("defaultPlanTf")
    public void setDefaultPlanTf(Boolean defaultPlanTf) {
        this.defaultPlanTf = defaultPlanTf;
    }

    public SaveInsurancePlanResponse withDefaultPlanTf(Boolean defaultPlanTf) {
        this.defaultPlanTf = defaultPlanTf;
        return this;
    }

    @JsonProperty("acceptAssignmentTf")
    public Object getAcceptAssignmentTf() {
        return acceptAssignmentTf;
    }

    @JsonProperty("acceptAssignmentTf")
    public void setAcceptAssignmentTf(Object acceptAssignmentTf) {
        this.acceptAssignmentTf = acceptAssignmentTf;
    }

    public SaveInsurancePlanResponse withAcceptAssignmentTf(Object acceptAssignmentTf) {
        this.acceptAssignmentTf = acceptAssignmentTf;
        return this;
    }

    @JsonProperty("generateClaimTf")
    public Boolean getGenerateClaimTf() {
        return generateClaimTf;
    }

    @JsonProperty("generateClaimTf")
    public void setGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
    }

    public SaveInsurancePlanResponse withGenerateClaimTf(Boolean generateClaimTf) {
        this.generateClaimTf = generateClaimTf;
        return this;
    }

    @JsonProperty("billPrimaryGuarantorTf")
    public Object getBillPrimaryGuarantorTf() {
        return billPrimaryGuarantorTf;
    }

    @JsonProperty("billPrimaryGuarantorTf")
    public void setBillPrimaryGuarantorTf(Object billPrimaryGuarantorTf) {
        this.billPrimaryGuarantorTf = billPrimaryGuarantorTf;
    }

    public SaveInsurancePlanResponse withBillPrimaryGuarantorTf(Object billPrimaryGuarantorTf) {
        this.billPrimaryGuarantorTf = billPrimaryGuarantorTf;
        return this;
    }

    @JsonProperty("contract")
    public Object getContract() {
        return contract;
    }

    @JsonProperty("contract")
    public void setContract(Object contract) {
        this.contract = contract;
    }

    public SaveInsurancePlanResponse withContract(Object contract) {
        this.contract = contract;
        return this;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public SaveInsurancePlanResponse withAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    public SaveInsurancePlanResponse withCity(String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    public SaveInsurancePlanResponse withState(String state) {
        this.state = state;
        return this;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public SaveInsurancePlanResponse withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("extendedZipCode")
    public String getExtendedZipCode() {
        return extendedZipCode;
    }

    @JsonProperty("extendedZipCode")
    public void setExtendedZipCode(String extendedZipCode) {
        this.extendedZipCode = extendedZipCode;
    }

    public SaveInsurancePlanResponse withExtendedZipCode(String extendedZipCode) {
        this.extendedZipCode = extendedZipCode;
        return this;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public SaveInsurancePlanResponse withPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    @JsonProperty("contactName")
    public String getContactName() {
        return contactName;
    }

    @JsonProperty("contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public SaveInsurancePlanResponse withContactName(String contactName) {
        this.contactName = contactName;
        return this;
    }

    @JsonProperty("isPlanExist")
    public Boolean getIsPlanExist() {
        return isPlanExist;
    }

    @JsonProperty("isPlanExist")
    public void setIsPlanExist(Boolean isPlanExist) {
        this.isPlanExist = isPlanExist;
    }

    public SaveInsurancePlanResponse withIsPlanExist(Boolean isPlanExist) {
        this.isPlanExist = isPlanExist;
        return this;
    }

    @JsonProperty("claimOfficeId")
    public Integer getClaimOfficeId() {
        return claimOfficeId;
    }

    @JsonProperty("claimOfficeId")
    public void setClaimOfficeId(Integer claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
    }

    public SaveInsurancePlanResponse withClaimOfficeId(Integer claimOfficeId) {
        this.claimOfficeId = claimOfficeId;
        return this;
    }

    @JsonProperty("insuranceContractId")
    public Object getInsuranceContractId() {
        return insuranceContractId;
    }

    @JsonProperty("insuranceContractId")
    public void setInsuranceContractId(Object insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
    }

    public SaveInsurancePlanResponse withInsuranceContractId(Object insuranceContractId) {
        this.insuranceContractId = insuranceContractId;
        return this;
    }

    @JsonProperty("insurancePlanIds")
    public Object getInsurancePlanIds() {
        return insurancePlanIds;
    }

    @JsonProperty("insurancePlanIds")
    public void setInsurancePlanIds(Object insurancePlanIds) {
        this.insurancePlanIds = insurancePlanIds;
    }

    public SaveInsurancePlanResponse withInsurancePlanIds(Object insurancePlanIds) {
        this.insurancePlanIds = insurancePlanIds;
        return this;
    }

    @JsonProperty("paymentTransactionCodeId")
    public Object getPaymentTransactionCodeId() {
        return paymentTransactionCodeId;
    }

    @JsonProperty("paymentTransactionCodeId")
    public void setPaymentTransactionCodeId(Object paymentTransactionCodeId) {
        this.paymentTransactionCodeId = paymentTransactionCodeId;
    }

    public SaveInsurancePlanResponse withPaymentTransactionCodeId(Object paymentTransactionCodeId) {
        this.paymentTransactionCodeId = paymentTransactionCodeId;
        return this;
    }

    @JsonProperty("paymentTransactionCodeName")
    public Object getPaymentTransactionCodeName() {
        return paymentTransactionCodeName;
    }

    @JsonProperty("paymentTransactionCodeName")
    public void setPaymentTransactionCodeName(Object paymentTransactionCodeName) {
        this.paymentTransactionCodeName = paymentTransactionCodeName;
    }

    public SaveInsurancePlanResponse withPaymentTransactionCodeName(Object paymentTransactionCodeName) {
        this.paymentTransactionCodeName = paymentTransactionCodeName;
        return this;
    }

    @JsonProperty("writeOffTransactionCodeId")
    public Object getWriteOffTransactionCodeId() {
        return writeOffTransactionCodeId;
    }

    @JsonProperty("writeOffTransactionCodeId")
    public void setWriteOffTransactionCodeId(Object writeOffTransactionCodeId) {
        this.writeOffTransactionCodeId = writeOffTransactionCodeId;
    }

    public SaveInsurancePlanResponse withWriteOffTransactionCodeId(Object writeOffTransactionCodeId) {
        this.writeOffTransactionCodeId = writeOffTransactionCodeId;
        return this;
    }

    @JsonProperty("writeOffTransactionCodeName")
    public Object getWriteOffTransactionCodeName() {
        return writeOffTransactionCodeName;
    }

    @JsonProperty("writeOffTransactionCodeName")
    public void setWriteOffTransactionCodeName(Object writeOffTransactionCodeName) {
        this.writeOffTransactionCodeName = writeOffTransactionCodeName;
    }

    public SaveInsurancePlanResponse withWriteOffTransactionCodeName(Object writeOffTransactionCodeName) {
        this.writeOffTransactionCodeName = writeOffTransactionCodeName;
        return this;
    }

    @JsonProperty("writeOffGroupId")
    public Object getWriteOffGroupId() {
        return writeOffGroupId;
    }

    @JsonProperty("writeOffGroupId")
    public void setWriteOffGroupId(Object writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
    }

    public SaveInsurancePlanResponse withWriteOffGroupId(Object writeOffGroupId) {
        this.writeOffGroupId = writeOffGroupId;
        return this;
    }

    @JsonProperty("writeOffGroupName")
    public Object getWriteOffGroupName() {
        return writeOffGroupName;
    }

    @JsonProperty("writeOffGroupName")
    public void setWriteOffGroupName(Object writeOffGroupName) {
        this.writeOffGroupName = writeOffGroupName;
    }

    public SaveInsurancePlanResponse withWriteOffGroupName(Object writeOffGroupName) {
        this.writeOffGroupName = writeOffGroupName;
        return this;
    }

    @JsonProperty("writeOffReasonId")
    public Object getWriteOffReasonId() {
        return writeOffReasonId;
    }

    @JsonProperty("writeOffReasonId")
    public void setWriteOffReasonId(Object writeOffReasonId) {
        this.writeOffReasonId = writeOffReasonId;
    }

    public SaveInsurancePlanResponse withWriteOffReasonId(Object writeOffReasonId) {
        this.writeOffReasonId = writeOffReasonId;
        return this;
    }

    @JsonProperty("writeOffReasonName")
    public Object getWriteOffReasonName() {
        return writeOffReasonName;
    }

    @JsonProperty("writeOffReasonName")
    public void setWriteOffReasonName(Object writeOffReasonName) {
        this.writeOffReasonName = writeOffReasonName;
    }

    public SaveInsurancePlanResponse withWriteOffReasonName(Object writeOffReasonName) {
        this.writeOffReasonName = writeOffReasonName;
        return this;
    }

    @JsonProperty("insurancePlanContractList")
    public List<Object> getInsurancePlanContractList() {
        return insurancePlanContractList;
    }

    @JsonProperty("insurancePlanContractList")
    public void setInsurancePlanContractList(List<Object> insurancePlanContractList) {
        this.insurancePlanContractList = insurancePlanContractList;
    }

    public SaveInsurancePlanResponse withInsurancePlanContractList(List<Object> insurancePlanContractList) {
        this.insurancePlanContractList = insurancePlanContractList;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public SaveInsurancePlanResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SaveInsurancePlanResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(insurancePlanId).append(insuranceCarrierId).append(planName).append(savedPlanName).append(classification).append(planType).append(groupInsuranceid).append(primaryEmcPayerid).append(secondaryEmcPayerid).append(primaryHpId).append(secondaryHpId).append(defaultPlanTf).append(acceptAssignmentTf).append(generateClaimTf).append(billPrimaryGuarantorTf).append(contract).append(address1).append(city).append(state).append(zipCode).append(extendedZipCode).append(phoneNumber).append(contactName).append(isPlanExist).append(claimOfficeId).append(insuranceContractId).append(insurancePlanIds).append(paymentTransactionCodeId).append(paymentTransactionCodeName).append(writeOffTransactionCodeId).append(writeOffTransactionCodeName).append(writeOffGroupId).append(writeOffGroupName).append(writeOffReasonId).append(writeOffReasonName).append(insurancePlanContractList).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaveInsurancePlanResponse) == false) {
            return false;
        }
        SaveInsurancePlanResponse rhs = ((SaveInsurancePlanResponse) other);
        return new EqualsBuilder().append(insurancePlanId, rhs.insurancePlanId).append(insuranceCarrierId, rhs.insuranceCarrierId).append(planName, rhs.planName).append(savedPlanName, rhs.savedPlanName).append(classification, rhs.classification).append(planType, rhs.planType).append(groupInsuranceid, rhs.groupInsuranceid).append(primaryEmcPayerid, rhs.primaryEmcPayerid).append(secondaryEmcPayerid, rhs.secondaryEmcPayerid).append(primaryHpId, rhs.primaryHpId).append(secondaryHpId, rhs.secondaryHpId).append(defaultPlanTf, rhs.defaultPlanTf).append(acceptAssignmentTf, rhs.acceptAssignmentTf).append(generateClaimTf, rhs.generateClaimTf).append(billPrimaryGuarantorTf, rhs.billPrimaryGuarantorTf).append(contract, rhs.contract).append(address1, rhs.address1).append(city, rhs.city).append(state, rhs.state).append(zipCode, rhs.zipCode).append(extendedZipCode, rhs.extendedZipCode).append(phoneNumber, rhs.phoneNumber).append(contactName, rhs.contactName).append(isPlanExist, rhs.isPlanExist).append(claimOfficeId, rhs.claimOfficeId).append(insuranceContractId, rhs.insuranceContractId).append(insurancePlanIds, rhs.insurancePlanIds).append(paymentTransactionCodeId, rhs.paymentTransactionCodeId).append(paymentTransactionCodeName, rhs.paymentTransactionCodeName).append(writeOffTransactionCodeId, rhs.writeOffTransactionCodeId).append(writeOffTransactionCodeName, rhs.writeOffTransactionCodeName).append(writeOffGroupId, rhs.writeOffGroupId).append(writeOffGroupName, rhs.writeOffGroupName).append(writeOffReasonId, rhs.writeOffReasonId).append(writeOffReasonName, rhs.writeOffReasonName).append(insurancePlanContractList, rhs.insurancePlanContractList).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
