
package com.bhavani.models.patientCases.casesToCodeResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "deletedPerformedItems",
    "performedItems",
    "sourceIdentifier"
})
public class CasesToCodeResponse {

    @JsonProperty("deletedPerformedItems")
    private List<Object> deletedPerformedItems = new ArrayList<Object>();
    @JsonProperty("performedItems")
    private List<PerformedItem> performedItems = new ArrayList<PerformedItem>();
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("deletedPerformedItems")
    public List<Object> getDeletedPerformedItems() {
        return deletedPerformedItems;
    }

    @JsonProperty("deletedPerformedItems")
    public void setDeletedPerformedItems(List<Object> deletedPerformedItems) {
        this.deletedPerformedItems = deletedPerformedItems;
    }

    public CasesToCodeResponse withDeletedPerformedItems(List<Object> deletedPerformedItems) {
        this.deletedPerformedItems = deletedPerformedItems;
        return this;
    }

    @JsonProperty("performedItems")
    public List<PerformedItem> getPerformedItems() {
        return performedItems;
    }

    @JsonProperty("performedItems")
    public void setPerformedItems(List<PerformedItem> performedItems) {
        this.performedItems = performedItems;
    }

    public CasesToCodeResponse withPerformedItems(List<PerformedItem> performedItems) {
        this.performedItems = performedItems;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public CasesToCodeResponse withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CasesToCodeResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(deletedPerformedItems).append(performedItems).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CasesToCodeResponse) == false) {
            return false;
        }
        CasesToCodeResponse rhs = ((CasesToCodeResponse) other);
        return new EqualsBuilder().append(deletedPerformedItems, rhs.deletedPerformedItems).append(performedItems, rhs.performedItems).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
