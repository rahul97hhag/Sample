
package com.bhavani.models.staff;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "personId",
    "firstName",
    "lastName",
    "middleInitial",
    "title",
    "gender",
    "dateOfBirth",
    "externalId",
    "fullName",
    "isAlphabeticalOrder",
    "isExcludeTitle",
    "itemId",
    "itemName",
    "itemType",
    "organizationId",
    "pageNumber",
    "searchString",
    "staffRoleId",
    "staffId",
    "staffIsActive",
    "staffIsAODictionary",
    "staffRoleName",
    "staffShowInClinical",
    "staffType",
    "ssn",
    "isNonUser",
    "fullNameWithTitle",
    "sourceIdentifier"
})
public class StaffByRole {

    @JsonProperty("personId")
    private Integer personId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleInitial")
    private Object middleInitial;
    @JsonProperty("title")
    private Object title;
    @JsonProperty("gender")
    private Object gender;
    @JsonProperty("dateOfBirth")
    private Object dateOfBirth;
    @JsonProperty("externalId")
    private Object externalId;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("isAlphabeticalOrder")
    private Boolean isAlphabeticalOrder;
    @JsonProperty("isExcludeTitle")
    private Boolean isExcludeTitle;
    @JsonProperty("itemId")
    private Integer itemId;
    @JsonProperty("itemName")
    private String itemName;
    @JsonProperty("itemType")
    private Object itemType;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("pageNumber")
    private Integer pageNumber;
    @JsonProperty("searchString")
    private Object searchString;
    @JsonProperty("staffRoleId")
    private Object staffRoleId;
    @JsonProperty("staffId")
    private Integer staffId;
    @JsonProperty("staffIsActive")
    private Boolean staffIsActive;
    @JsonProperty("staffIsAODictionary")
    private Boolean staffIsAODictionary;
    @JsonProperty("staffRoleName")
    private Object staffRoleName;
    @JsonProperty("staffShowInClinical")
    private Boolean staffShowInClinical;
    @JsonProperty("staffType")
    private Object staffType;
    @JsonProperty("ssn")
    private Object ssn;
    @JsonProperty("isNonUser")
    private Boolean isNonUser;
    @JsonProperty("fullNameWithTitle")
    private String fullNameWithTitle;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("personId")
    public Integer getPersonId() {
        return personId;
    }

    @JsonProperty("personId")
    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public StaffByRole withPersonId(Integer personId) {
        this.personId = personId;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public StaffByRole withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public StaffByRole withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public Object getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
    }

    public StaffByRole withMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("title")
    public Object getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(Object title) {
        this.title = title;
    }

    public StaffByRole withTitle(Object title) {
        this.title = title;
        return this;
    }

    @JsonProperty("gender")
    public Object getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(Object gender) {
        this.gender = gender;
    }

    public StaffByRole withGender(Object gender) {
        this.gender = gender;
        return this;
    }

    @JsonProperty("dateOfBirth")
    public Object getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(Object dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public StaffByRole withDateOfBirth(Object dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    @JsonProperty("externalId")
    public Object getExternalId() {
        return externalId;
    }

    @JsonProperty("externalId")
    public void setExternalId(Object externalId) {
        this.externalId = externalId;
    }

    public StaffByRole withExternalId(Object externalId) {
        this.externalId = externalId;
        return this;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public StaffByRole withFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("isAlphabeticalOrder")
    public Boolean getIsAlphabeticalOrder() {
        return isAlphabeticalOrder;
    }

    @JsonProperty("isAlphabeticalOrder")
    public void setIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
    }

    public StaffByRole withIsAlphabeticalOrder(Boolean isAlphabeticalOrder) {
        this.isAlphabeticalOrder = isAlphabeticalOrder;
        return this;
    }

    @JsonProperty("isExcludeTitle")
    public Boolean getIsExcludeTitle() {
        return isExcludeTitle;
    }

    @JsonProperty("isExcludeTitle")
    public void setIsExcludeTitle(Boolean isExcludeTitle) {
        this.isExcludeTitle = isExcludeTitle;
    }

    public StaffByRole withIsExcludeTitle(Boolean isExcludeTitle) {
        this.isExcludeTitle = isExcludeTitle;
        return this;
    }

    @JsonProperty("itemId")
    public Integer getItemId() {
        return itemId;
    }

    @JsonProperty("itemId")
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public StaffByRole withItemId(Integer itemId) {
        this.itemId = itemId;
        return this;
    }

    @JsonProperty("itemName")
    public String getItemName() {
        return itemName;
    }

    @JsonProperty("itemName")
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public StaffByRole withItemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    @JsonProperty("itemType")
    public Object getItemType() {
        return itemType;
    }

    @JsonProperty("itemType")
    public void setItemType(Object itemType) {
        this.itemType = itemType;
    }

    public StaffByRole withItemType(Object itemType) {
        this.itemType = itemType;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public StaffByRole withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("pageNumber")
    public Integer getPageNumber() {
        return pageNumber;
    }

    @JsonProperty("pageNumber")
    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public StaffByRole withPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }

    @JsonProperty("searchString")
    public Object getSearchString() {
        return searchString;
    }

    @JsonProperty("searchString")
    public void setSearchString(Object searchString) {
        this.searchString = searchString;
    }

    public StaffByRole withSearchString(Object searchString) {
        this.searchString = searchString;
        return this;
    }

    @JsonProperty("staffRoleId")
    public Object getStaffRoleId() {
        return staffRoleId;
    }

    @JsonProperty("staffRoleId")
    public void setStaffRoleId(Object staffRoleId) {
        this.staffRoleId = staffRoleId;
    }

    public StaffByRole withStaffRoleId(Object staffRoleId) {
        this.staffRoleId = staffRoleId;
        return this;
    }

    @JsonProperty("staffId")
    public Integer getStaffId() {
        return staffId;
    }

    @JsonProperty("staffId")
    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public StaffByRole withStaffId(Integer staffId) {
        this.staffId = staffId;
        return this;
    }

    @JsonProperty("staffIsActive")
    public Boolean getStaffIsActive() {
        return staffIsActive;
    }

    @JsonProperty("staffIsActive")
    public void setStaffIsActive(Boolean staffIsActive) {
        this.staffIsActive = staffIsActive;
    }

    public StaffByRole withStaffIsActive(Boolean staffIsActive) {
        this.staffIsActive = staffIsActive;
        return this;
    }

    @JsonProperty("staffIsAODictionary")
    public Boolean getStaffIsAODictionary() {
        return staffIsAODictionary;
    }

    @JsonProperty("staffIsAODictionary")
    public void setStaffIsAODictionary(Boolean staffIsAODictionary) {
        this.staffIsAODictionary = staffIsAODictionary;
    }

    public StaffByRole withStaffIsAODictionary(Boolean staffIsAODictionary) {
        this.staffIsAODictionary = staffIsAODictionary;
        return this;
    }

    @JsonProperty("staffRoleName")
    public Object getStaffRoleName() {
        return staffRoleName;
    }

    @JsonProperty("staffRoleName")
    public void setStaffRoleName(Object staffRoleName) {
        this.staffRoleName = staffRoleName;
    }

    public StaffByRole withStaffRoleName(Object staffRoleName) {
        this.staffRoleName = staffRoleName;
        return this;
    }

    @JsonProperty("staffShowInClinical")
    public Boolean getStaffShowInClinical() {
        return staffShowInClinical;
    }

    @JsonProperty("staffShowInClinical")
    public void setStaffShowInClinical(Boolean staffShowInClinical) {
        this.staffShowInClinical = staffShowInClinical;
    }

    public StaffByRole withStaffShowInClinical(Boolean staffShowInClinical) {
        this.staffShowInClinical = staffShowInClinical;
        return this;
    }

    @JsonProperty("staffType")
    public Object getStaffType() {
        return staffType;
    }

    @JsonProperty("staffType")
    public void setStaffType(Object staffType) {
        this.staffType = staffType;
    }

    public StaffByRole withStaffType(Object staffType) {
        this.staffType = staffType;
        return this;
    }

    @JsonProperty("ssn")
    public Object getSsn() {
        return ssn;
    }

    @JsonProperty("ssn")
    public void setSsn(Object ssn) {
        this.ssn = ssn;
    }

    public StaffByRole withSsn(Object ssn) {
        this.ssn = ssn;
        return this;
    }

    @JsonProperty("isNonUser")
    public Boolean getIsNonUser() {
        return isNonUser;
    }

    @JsonProperty("isNonUser")
    public void setIsNonUser(Boolean isNonUser) {
        this.isNonUser = isNonUser;
    }

    public StaffByRole withIsNonUser(Boolean isNonUser) {
        this.isNonUser = isNonUser;
        return this;
    }

    @JsonProperty("fullNameWithTitle")
    public String getFullNameWithTitle() {
        return fullNameWithTitle;
    }

    @JsonProperty("fullNameWithTitle")
    public void setFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
    }

    public StaffByRole withFullNameWithTitle(String fullNameWithTitle) {
        this.fullNameWithTitle = fullNameWithTitle;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public StaffByRole withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StaffByRole withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(personId).append(firstName).append(lastName).append(middleInitial).append(title).append(gender).append(dateOfBirth).append(externalId).append(fullName).append(isAlphabeticalOrder).append(isExcludeTitle).append(itemId).append(itemName).append(itemType).append(organizationId).append(pageNumber).append(searchString).append(staffRoleId).append(staffId).append(staffIsActive).append(staffIsAODictionary).append(staffRoleName).append(staffShowInClinical).append(staffType).append(ssn).append(isNonUser).append(fullNameWithTitle).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StaffByRole) == false) {
            return false;
        }
        StaffByRole rhs = ((StaffByRole) other);
        return new EqualsBuilder().append(personId, rhs.personId).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(title, rhs.title).append(gender, rhs.gender).append(dateOfBirth, rhs.dateOfBirth).append(externalId, rhs.externalId).append(fullName, rhs.fullName).append(isAlphabeticalOrder, rhs.isAlphabeticalOrder).append(isExcludeTitle, rhs.isExcludeTitle).append(itemId, rhs.itemId).append(itemName, rhs.itemName).append(itemType, rhs.itemType).append(organizationId, rhs.organizationId).append(pageNumber, rhs.pageNumber).append(searchString, rhs.searchString).append(staffRoleId, rhs.staffRoleId).append(staffId, rhs.staffId).append(staffIsActive, rhs.staffIsActive).append(staffIsAODictionary, rhs.staffIsAODictionary).append(staffRoleName, rhs.staffRoleName).append(staffShowInClinical, rhs.staffShowInClinical).append(staffType, rhs.staffType).append(ssn, rhs.ssn).append(isNonUser, rhs.isNonUser).append(fullNameWithTitle, rhs.fullNameWithTitle).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
