
package com.bhavani.models.commons;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "parentId",
    "name",
    "childOrgs",
    "firstName",
    "lastName",
    "middleInitial",
    "userName",
    "fullName",
    "userAccessLevel",
    "userPicture",
    "imageUserId",
    "title",
    "isUserPassword",
    "roleName",
    "employeeTypeId",
    "staffId",
    "personId",
    "isUserExist",
    "userNameText",
    "statusValue",
    "physicianDetails",
    "userTypeId",
    "userTypeName",
    "facilityDesktopViewName",
    "userOrgMapActiveTf",
    "clinicalDesktopTf",
    "businessDesktopTf",
    "emailAddress",
    "primaryPhone",
    "usrId",
    "organizationId",
    "activeTf",
    "levelId",
    "lockedTf",
    "facilityDesktopViewId",
    "profileLevelId",
    "roleId",
    "averageCostPerMin",
    "sureScriptId",
    "sourceIdentifier"
})
public class MappedOrganizations {

    @JsonProperty("parentId")
    private Integer parentId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("childOrgs")
    private List<ChildOrganizations> childOrgs = new ArrayList<ChildOrganizations>();
    @JsonProperty("firstName")
    private Object firstName;
    @JsonProperty("lastName")
    private Object lastName;
    @JsonProperty("middleInitial")
    private Object middleInitial;
    @JsonProperty("userName")
    private Object userName;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("userAccessLevel")
    private Object userAccessLevel;
    @JsonProperty("userPicture")
    private Object userPicture;
    @JsonProperty("imageUserId")
    private Object imageUserId;
    @JsonProperty("title")
    private Object title;
    @JsonProperty("isUserPassword")
    private Boolean isUserPassword;
    @JsonProperty("roleName")
    private Object roleName;
    @JsonProperty("employeeTypeId")
    private Object employeeTypeId;
    @JsonProperty("staffId")
    private Object staffId;
    @JsonProperty("personId")
    private Integer personId;
    @JsonProperty("isUserExist")
    private Boolean isUserExist;
    @JsonProperty("userNameText")
    private Object userNameText;
    @JsonProperty("statusValue")
    private Object statusValue;
    @JsonProperty("physicianDetails")
    private Object physicianDetails;
    @JsonProperty("userTypeId")
    private Integer userTypeId;
    @JsonProperty("userTypeName")
    private Object userTypeName;
    @JsonProperty("facilityDesktopViewName")
    private Object facilityDesktopViewName;
    @JsonProperty("userOrgMapActiveTf")
    private Object userOrgMapActiveTf;
    @JsonProperty("clinicalDesktopTf")
    private Object clinicalDesktopTf;
    @JsonProperty("businessDesktopTf")
    private Object businessDesktopTf;
    @JsonProperty("emailAddress")
    private Object emailAddress;
    @JsonProperty("primaryPhone")
    private Object primaryPhone;
    @JsonProperty("usrId")
    private Integer usrId;
    @JsonProperty("organizationId")
    private Integer organizationId;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("levelId")
    private Integer levelId;
    @JsonProperty("lockedTf")
    private Boolean lockedTf;
    @JsonProperty("facilityDesktopViewId")
    private Object facilityDesktopViewId;
    @JsonProperty("profileLevelId")
    private Integer profileLevelId;
    @JsonProperty("roleId")
    private Object roleId;
    @JsonProperty("averageCostPerMin")
    private Object averageCostPerMin;
    @JsonProperty("sureScriptId")
    private Object sureScriptId;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("parentId")
    public Integer getParentId() {
        return parentId;
    }

    @JsonProperty("parentId")
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public MappedOrganizations withParentId(Integer parentId) {
        this.parentId = parentId;
        return this;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public MappedOrganizations withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("childOrgs")
    public List<ChildOrganizations> getChildOrgs() {
        return childOrgs;
    }

    @JsonProperty("childOrgs")
    public void setChildOrgs(List<ChildOrganizations> childOrgs) {
        this.childOrgs = childOrgs;
    }

    public MappedOrganizations withChildOrgs(List<ChildOrganizations> childOrgs) {
        this.childOrgs = childOrgs;
        return this;
    }

    @JsonProperty("firstName")
    public Object getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(Object firstName) {
        this.firstName = firstName;
    }

    public MappedOrganizations withFirstName(Object firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("lastName")
    public Object getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(Object lastName) {
        this.lastName = lastName;
    }

    public MappedOrganizations withLastName(Object lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middleInitial")
    public Object getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
    }

    public MappedOrganizations withMiddleInitial(Object middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("userName")
    public Object getUserName() {
        return userName;
    }

    @JsonProperty("userName")
    public void setUserName(Object userName) {
        this.userName = userName;
    }

    public MappedOrganizations withUserName(Object userName) {
        this.userName = userName;
        return this;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public MappedOrganizations withFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("userAccessLevel")
    public Object getUserAccessLevel() {
        return userAccessLevel;
    }

    @JsonProperty("userAccessLevel")
    public void setUserAccessLevel(Object userAccessLevel) {
        this.userAccessLevel = userAccessLevel;
    }

    public MappedOrganizations withUserAccessLevel(Object userAccessLevel) {
        this.userAccessLevel = userAccessLevel;
        return this;
    }

    @JsonProperty("userPicture")
    public Object getUserPicture() {
        return userPicture;
    }

    @JsonProperty("userPicture")
    public void setUserPicture(Object userPicture) {
        this.userPicture = userPicture;
    }

    public MappedOrganizations withUserPicture(Object userPicture) {
        this.userPicture = userPicture;
        return this;
    }

    @JsonProperty("imageUserId")
    public Object getImageUserId() {
        return imageUserId;
    }

    @JsonProperty("imageUserId")
    public void setImageUserId(Object imageUserId) {
        this.imageUserId = imageUserId;
    }

    public MappedOrganizations withImageUserId(Object imageUserId) {
        this.imageUserId = imageUserId;
        return this;
    }

    @JsonProperty("title")
    public Object getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(Object title) {
        this.title = title;
    }

    public MappedOrganizations withTitle(Object title) {
        this.title = title;
        return this;
    }

    @JsonProperty("isUserPassword")
    public Boolean getIsUserPassword() {
        return isUserPassword;
    }

    @JsonProperty("isUserPassword")
    public void setIsUserPassword(Boolean isUserPassword) {
        this.isUserPassword = isUserPassword;
    }

    public MappedOrganizations withIsUserPassword(Boolean isUserPassword) {
        this.isUserPassword = isUserPassword;
        return this;
    }

    @JsonProperty("roleName")
    public Object getRoleName() {
        return roleName;
    }

    @JsonProperty("roleName")
    public void setRoleName(Object roleName) {
        this.roleName = roleName;
    }

    public MappedOrganizations withRoleName(Object roleName) {
        this.roleName = roleName;
        return this;
    }

    @JsonProperty("employeeTypeId")
    public Object getEmployeeTypeId() {
        return employeeTypeId;
    }

    @JsonProperty("employeeTypeId")
    public void setEmployeeTypeId(Object employeeTypeId) {
        this.employeeTypeId = employeeTypeId;
    }

    public MappedOrganizations withEmployeeTypeId(Object employeeTypeId) {
        this.employeeTypeId = employeeTypeId;
        return this;
    }

    @JsonProperty("staffId")
    public Object getStaffId() {
        return staffId;
    }

    @JsonProperty("staffId")
    public void setStaffId(Object staffId) {
        this.staffId = staffId;
    }

    public MappedOrganizations withStaffId(Object staffId) {
        this.staffId = staffId;
        return this;
    }

    @JsonProperty("personId")
    public Integer getPersonId() {
        return personId;
    }

    @JsonProperty("personId")
    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public MappedOrganizations withPersonId(Integer personId) {
        this.personId = personId;
        return this;
    }

    @JsonProperty("isUserExist")
    public Boolean getIsUserExist() {
        return isUserExist;
    }

    @JsonProperty("isUserExist")
    public void setIsUserExist(Boolean isUserExist) {
        this.isUserExist = isUserExist;
    }

    public MappedOrganizations withIsUserExist(Boolean isUserExist) {
        this.isUserExist = isUserExist;
        return this;
    }

    @JsonProperty("userNameText")
    public Object getUserNameText() {
        return userNameText;
    }

    @JsonProperty("userNameText")
    public void setUserNameText(Object userNameText) {
        this.userNameText = userNameText;
    }

    public MappedOrganizations withUserNameText(Object userNameText) {
        this.userNameText = userNameText;
        return this;
    }

    @JsonProperty("statusValue")
    public Object getStatusValue() {
        return statusValue;
    }

    @JsonProperty("statusValue")
    public void setStatusValue(Object statusValue) {
        this.statusValue = statusValue;
    }

    public MappedOrganizations withStatusValue(Object statusValue) {
        this.statusValue = statusValue;
        return this;
    }

    @JsonProperty("physicianDetails")
    public Object getPhysicianDetails() {
        return physicianDetails;
    }

    @JsonProperty("physicianDetails")
    public void setPhysicianDetails(Object physicianDetails) {
        this.physicianDetails = physicianDetails;
    }

    public MappedOrganizations withPhysicianDetails(Object physicianDetails) {
        this.physicianDetails = physicianDetails;
        return this;
    }

    @JsonProperty("userTypeId")
    public Integer getUserTypeId() {
        return userTypeId;
    }

    @JsonProperty("userTypeId")
    public void setUserTypeId(Integer userTypeId) {
        this.userTypeId = userTypeId;
    }

    public MappedOrganizations withUserTypeId(Integer userTypeId) {
        this.userTypeId = userTypeId;
        return this;
    }

    @JsonProperty("userTypeName")
    public Object getUserTypeName() {
        return userTypeName;
    }

    @JsonProperty("userTypeName")
    public void setUserTypeName(Object userTypeName) {
        this.userTypeName = userTypeName;
    }

    public MappedOrganizations withUserTypeName(Object userTypeName) {
        this.userTypeName = userTypeName;
        return this;
    }

    @JsonProperty("facilityDesktopViewName")
    public Object getFacilityDesktopViewName() {
        return facilityDesktopViewName;
    }

    @JsonProperty("facilityDesktopViewName")
    public void setFacilityDesktopViewName(Object facilityDesktopViewName) {
        this.facilityDesktopViewName = facilityDesktopViewName;
    }

    public MappedOrganizations withFacilityDesktopViewName(Object facilityDesktopViewName) {
        this.facilityDesktopViewName = facilityDesktopViewName;
        return this;
    }

    @JsonProperty("userOrgMapActiveTf")
    public Object getUserOrgMapActiveTf() {
        return userOrgMapActiveTf;
    }

    @JsonProperty("userOrgMapActiveTf")
    public void setUserOrgMapActiveTf(Object userOrgMapActiveTf) {
        this.userOrgMapActiveTf = userOrgMapActiveTf;
    }

    public MappedOrganizations withUserOrgMapActiveTf(Object userOrgMapActiveTf) {
        this.userOrgMapActiveTf = userOrgMapActiveTf;
        return this;
    }

    @JsonProperty("clinicalDesktopTf")
    public Object getClinicalDesktopTf() {
        return clinicalDesktopTf;
    }

    @JsonProperty("clinicalDesktopTf")
    public void setClinicalDesktopTf(Object clinicalDesktopTf) {
        this.clinicalDesktopTf = clinicalDesktopTf;
    }

    public MappedOrganizations withClinicalDesktopTf(Object clinicalDesktopTf) {
        this.clinicalDesktopTf = clinicalDesktopTf;
        return this;
    }

    @JsonProperty("businessDesktopTf")
    public Object getBusinessDesktopTf() {
        return businessDesktopTf;
    }

    @JsonProperty("businessDesktopTf")
    public void setBusinessDesktopTf(Object businessDesktopTf) {
        this.businessDesktopTf = businessDesktopTf;
    }

    public MappedOrganizations withBusinessDesktopTf(Object businessDesktopTf) {
        this.businessDesktopTf = businessDesktopTf;
        return this;
    }

    @JsonProperty("emailAddress")
    public Object getEmailAddress() {
        return emailAddress;
    }

    @JsonProperty("emailAddress")
    public void setEmailAddress(Object emailAddress) {
        this.emailAddress = emailAddress;
    }

    public MappedOrganizations withEmailAddress(Object emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    @JsonProperty("primaryPhone")
    public Object getPrimaryPhone() {
        return primaryPhone;
    }

    @JsonProperty("primaryPhone")
    public void setPrimaryPhone(Object primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public MappedOrganizations withPrimaryPhone(Object primaryPhone) {
        this.primaryPhone = primaryPhone;
        return this;
    }

    @JsonProperty("usrId")
    public Integer getUsrId() {
        return usrId;
    }

    @JsonProperty("usrId")
    public void setUsrId(Integer usrId) {
        this.usrId = usrId;
    }

    public MappedOrganizations withUsrId(Integer usrId) {
        this.usrId = usrId;
        return this;
    }

    @JsonProperty("organizationId")
    public Integer getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public MappedOrganizations withOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public MappedOrganizations withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("levelId")
    public Integer getLevelId() {
        return levelId;
    }

    @JsonProperty("levelId")
    public void setLevelId(Integer levelId) {
        this.levelId = levelId;
    }

    public MappedOrganizations withLevelId(Integer levelId) {
        this.levelId = levelId;
        return this;
    }

    @JsonProperty("lockedTf")
    public Boolean getLockedTf() {
        return lockedTf;
    }

    @JsonProperty("lockedTf")
    public void setLockedTf(Boolean lockedTf) {
        this.lockedTf = lockedTf;
    }

    public MappedOrganizations withLockedTf(Boolean lockedTf) {
        this.lockedTf = lockedTf;
        return this;
    }

    @JsonProperty("facilityDesktopViewId")
    public Object getFacilityDesktopViewId() {
        return facilityDesktopViewId;
    }

    @JsonProperty("facilityDesktopViewId")
    public void setFacilityDesktopViewId(Object facilityDesktopViewId) {
        this.facilityDesktopViewId = facilityDesktopViewId;
    }

    public MappedOrganizations withFacilityDesktopViewId(Object facilityDesktopViewId) {
        this.facilityDesktopViewId = facilityDesktopViewId;
        return this;
    }

    @JsonProperty("profileLevelId")
    public Integer getProfileLevelId() {
        return profileLevelId;
    }

    @JsonProperty("profileLevelId")
    public void setProfileLevelId(Integer profileLevelId) {
        this.profileLevelId = profileLevelId;
    }

    public MappedOrganizations withProfileLevelId(Integer profileLevelId) {
        this.profileLevelId = profileLevelId;
        return this;
    }

    @JsonProperty("roleId")
    public Object getRoleId() {
        return roleId;
    }

    @JsonProperty("roleId")
    public void setRoleId(Object roleId) {
        this.roleId = roleId;
    }

    public MappedOrganizations withRoleId(Object roleId) {
        this.roleId = roleId;
        return this;
    }

    @JsonProperty("averageCostPerMin")
    public Object getAverageCostPerMin() {
        return averageCostPerMin;
    }

    @JsonProperty("averageCostPerMin")
    public void setAverageCostPerMin(Object averageCostPerMin) {
        this.averageCostPerMin = averageCostPerMin;
    }

    public MappedOrganizations withAverageCostPerMin(Object averageCostPerMin) {
        this.averageCostPerMin = averageCostPerMin;
        return this;
    }

    @JsonProperty("sureScriptId")
    public Object getSureScriptId() {
        return sureScriptId;
    }

    @JsonProperty("sureScriptId")
    public void setSureScriptId(Object sureScriptId) {
        this.sureScriptId = sureScriptId;
    }

    public MappedOrganizations withSureScriptId(Object sureScriptId) {
        this.sureScriptId = sureScriptId;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public MappedOrganizations withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MappedOrganizations withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(parentId).append(name).append(childOrgs).append(firstName).append(lastName).append(middleInitial).append(userName).append(fullName).append(userAccessLevel).append(userPicture).append(imageUserId).append(title).append(isUserPassword).append(roleName).append(employeeTypeId).append(staffId).append(personId).append(isUserExist).append(userNameText).append(statusValue).append(physicianDetails).append(userTypeId).append(userTypeName).append(facilityDesktopViewName).append(userOrgMapActiveTf).append(clinicalDesktopTf).append(businessDesktopTf).append(emailAddress).append(primaryPhone).append(usrId).append(organizationId).append(activeTf).append(levelId).append(lockedTf).append(facilityDesktopViewId).append(profileLevelId).append(roleId).append(averageCostPerMin).append(sureScriptId).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MappedOrganizations) == false) {
            return false;
        }
        MappedOrganizations rhs = ((MappedOrganizations) other);
        return new EqualsBuilder().append(parentId, rhs.parentId).append(name, rhs.name).append(childOrgs, rhs.childOrgs).append(firstName, rhs.firstName).append(lastName, rhs.lastName).append(middleInitial, rhs.middleInitial).append(userName, rhs.userName).append(fullName, rhs.fullName).append(userAccessLevel, rhs.userAccessLevel).append(userPicture, rhs.userPicture).append(imageUserId, rhs.imageUserId).append(title, rhs.title).append(isUserPassword, rhs.isUserPassword).append(roleName, rhs.roleName).append(employeeTypeId, rhs.employeeTypeId).append(staffId, rhs.staffId).append(personId, rhs.personId).append(isUserExist, rhs.isUserExist).append(userNameText, rhs.userNameText).append(statusValue, rhs.statusValue).append(physicianDetails, rhs.physicianDetails).append(userTypeId, rhs.userTypeId).append(userTypeName, rhs.userTypeName).append(facilityDesktopViewName, rhs.facilityDesktopViewName).append(userOrgMapActiveTf, rhs.userOrgMapActiveTf).append(clinicalDesktopTf, rhs.clinicalDesktopTf).append(businessDesktopTf, rhs.businessDesktopTf).append(emailAddress, rhs.emailAddress).append(primaryPhone, rhs.primaryPhone).append(usrId, rhs.usrId).append(organizationId, rhs.organizationId).append(activeTf, rhs.activeTf).append(levelId, rhs.levelId).append(lockedTf, rhs.lockedTf).append(facilityDesktopViewId, rhs.facilityDesktopViewId).append(profileLevelId, rhs.profileLevelId).append(roleId, rhs.roleId).append(averageCostPerMin, rhs.averageCostPerMin).append(sureScriptId, rhs.sureScriptId).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
