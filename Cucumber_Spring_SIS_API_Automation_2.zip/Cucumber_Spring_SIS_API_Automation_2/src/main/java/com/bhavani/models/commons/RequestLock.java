
package com.bhavani.models.commons;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PatientId",
    "RecordLockTypeId",
    "ObjectId",
    "ModuleId"
})
public class RequestLock {

    @JsonProperty("PatientId")
    private Integer patientId;
    @JsonProperty("RecordLockTypeId")
    private Integer recordLockTypeId;
    @JsonProperty("ObjectId")
    private Integer objectId;
    @JsonProperty("ModuleId")
    private Integer moduleId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("PatientId")
    public Integer getPatientId() {
        return patientId;
    }

    @JsonProperty("PatientId")
    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public RequestLock withPatientId(Integer patientId) {
        this.patientId = patientId;
        return this;
    }

    @JsonProperty("RecordLockTypeId")
    public Integer getRecordLockTypeId() {
        return recordLockTypeId;
    }

    @JsonProperty("RecordLockTypeId")
    public void setRecordLockTypeId(Integer recordLockTypeId) {
        this.recordLockTypeId = recordLockTypeId;
    }

    public RequestLock withRecordLockTypeId(Integer recordLockTypeId) {
        this.recordLockTypeId = recordLockTypeId;
        return this;
    }

    @JsonProperty("ObjectId")
    public Integer getObjectId() {
        return objectId;
    }

    @JsonProperty("ObjectId")
    public void setObjectId(Integer objectId) {
        this.objectId = objectId;
    }

    public RequestLock withObjectId(Integer objectId) {
        this.objectId = objectId;
        return this;
    }

    @JsonProperty("ModuleId")
    public Integer getModuleId() {
        return moduleId;
    }

    @JsonProperty("ModuleId")
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public RequestLock withModuleId(Integer moduleId) {
        this.moduleId = moduleId;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RequestLock withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(patientId).append(recordLockTypeId).append(objectId).append(moduleId).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RequestLock) == false) {
            return false;
        }
        RequestLock rhs = ((RequestLock) other);
        return new EqualsBuilder().append(patientId, rhs.patientId).append(recordLockTypeId, rhs.recordLockTypeId).append(objectId, rhs.objectId).append(moduleId, rhs.moduleId).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
