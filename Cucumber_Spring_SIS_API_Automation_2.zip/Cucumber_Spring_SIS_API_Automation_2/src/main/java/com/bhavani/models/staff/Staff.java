
package com.bhavani.models.staff;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "staffId",
    "personId",
    "roleId",
    "roleName",
    "firstName",
    "middleInitial",
    "lastName",
    "title",
    "fullName",
    "primaryPhone",
    "emailAddress",
    "sourceIdentifier"
})
public class Staff {

    @JsonProperty("staffId")
    private Integer staffId;
    @JsonProperty("personId")
    private Integer personId;
    @JsonProperty("roleId")
    private Integer roleId;
    @JsonProperty("roleName")
    private String roleName;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("middleInitial")
    private String middleInitial;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("title")
    private String title;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("primaryPhone")
    private Object primaryPhone;
    @JsonProperty("emailAddress")
    private Object emailAddress;
    @JsonProperty("sourceIdentifier")
    private String sourceIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("staffId")
    public Integer getStaffId() {
        return staffId;
    }

    @JsonProperty("staffId")
    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public Staff withStaffId(Integer staffId) {
        this.staffId = staffId;
        return this;
    }

    @JsonProperty("personId")
    public Integer getPersonId() {
        return personId;
    }

    @JsonProperty("personId")
    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public Staff withPersonId(Integer personId) {
        this.personId = personId;
        return this;
    }

    @JsonProperty("roleId")
    public Integer getRoleId() {
        return roleId;
    }

    @JsonProperty("roleId")
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Staff withRoleId(Integer roleId) {
        this.roleId = roleId;
        return this;
    }

    @JsonProperty("roleName")
    public String getRoleName() {
        return roleName;
    }

    @JsonProperty("roleName")
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Staff withRoleName(String roleName) {
        this.roleName = roleName;
        return this;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Staff withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("middleInitial")
    public String getMiddleInitial() {
        return middleInitial;
    }

    @JsonProperty("middleInitial")
    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public Staff withMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
        return this;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Staff withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    public Staff withTitle(String title) {
        this.title = title;
        return this;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Staff withFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("primaryPhone")
    public Object getPrimaryPhone() {
        return primaryPhone;
    }

    @JsonProperty("primaryPhone")
    public void setPrimaryPhone(Object primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public Staff withPrimaryPhone(Object primaryPhone) {
        this.primaryPhone = primaryPhone;
        return this;
    }

    @JsonProperty("emailAddress")
    public Object getEmailAddress() {
        return emailAddress;
    }

    @JsonProperty("emailAddress")
    public void setEmailAddress(Object emailAddress) {
        this.emailAddress = emailAddress;
    }

    public Staff withEmailAddress(Object emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    @JsonProperty("sourceIdentifier")
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }

    @JsonProperty("sourceIdentifier")
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }

    public Staff withSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Staff withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(staffId).append(personId).append(roleId).append(roleName).append(firstName).append(middleInitial).append(lastName).append(title).append(fullName).append(primaryPhone).append(emailAddress).append(sourceIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Staff) == false) {
            return false;
        }
        Staff rhs = ((Staff) other);
        return new EqualsBuilder().append(staffId, rhs.staffId).append(personId, rhs.personId).append(roleId, rhs.roleId).append(roleName, rhs.roleName).append(firstName, rhs.firstName).append(middleInitial, rhs.middleInitial).append(lastName, rhs.lastName).append(title, rhs.title).append(fullName, rhs.fullName).append(primaryPhone, rhs.primaryPhone).append(emailAddress, rhs.emailAddress).append(sourceIdentifier, rhs.sourceIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
