package com.bhavani;

import cucumber.api.java.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static junit.framework.TestCase.assertTrue;

/**
 * Unit test for simple App.
 */

/*
@RunWith(SpringRunner.class)
@SpringBootTest
*/
public class ApplicationTest
{
    /*
    private static final Logger LOG = LoggerFactory.getLogger(ApplicationTest.class);


    @Test
    public void contextLoads() {
    }

    @Before
    public void initCucumber()
    {
        LOG.info("------------------Cucumber Initialized Successfully--------------------");
    }
    */
}
