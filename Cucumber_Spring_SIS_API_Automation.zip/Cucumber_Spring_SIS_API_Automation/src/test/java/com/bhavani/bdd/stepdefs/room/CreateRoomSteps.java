package com.bhavani.bdd.stepdefs.room;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import com.bhavani.builder.RoomObjects;
import com.bhavani.models.room.Room;
import com.bhavani.models.room.RoomType;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class CreateRoomSteps extends AbstractSteps implements En {

    private static Logger LOG = LoggerFactory.getLogger(CreateRoomSteps.class);

    public CreateRoomSteps() {


        When("I added room with name {string}", (String roomName) -> {
            LOG.info("18 " + roomName);

            int roomTypeId = Integer.parseInt(RandomStringUtils.randomNumeric(6));
            int roomId = Integer.parseInt(RandomStringUtils.randomNumeric(6));
            String roomTypeName = "RT" + roomName;
            RoomType roomType = RoomObjects.getRoomType(roomTypeId, roomName);
            String organizationId = super.testContext().get("organizationId").toString();
            Room room = RoomObjects.getRoom(roomId, organizationId, roomName, roomType);
            LOG.info("Adding room " + roomName);

            ObjectMapper objectMapper = new ObjectMapper();
            String roomTypeRequestBody = null;
            String roomRequestBody = null;
            try {
                roomTypeRequestBody = objectMapper.writeValueAsString(roomType);
                roomRequestBody = objectMapper.writeValueAsString(room);
                LOG.info(roomTypeRequestBody);
                LOG.info(roomRequestBody);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            LOG.info(room.toString());

            JSONObject roomTypeJSONObject = new JSONObject(roomTypeRequestBody);
            LOG.info(roomTypeJSONObject.toString(4));
            JSONObject roomJSONObject = new JSONObject(roomRequestBody);
            LOG.info(roomJSONObject.toString(4));
            super.testContext().setPayload(roomTypeJSONObject);
            super.executePost("api/RoomType/Add");

            Response addNewRoomTypeResponse = super.testContext().getResponse();

            LOG.info(addNewRoomTypeResponse.asString());
            LOG.info(""+addNewRoomTypeResponse.statusCode());
            LOG.info(""+addNewRoomTypeResponse.statusLine());

            super.testContext().setPayload(roomJSONObject);
            super.executePost("api/Room/Add");
            Response addNewRoomResponse = super.testContext().getResponse();
            LOG.info(addNewRoomResponse.toString());
            LOG.info(addNewRoomResponse.asString());
            LOG.info(""+addNewRoomResponse.statusCode());
            LOG.info(""+addNewRoomResponse.statusLine());


        });

        Then("I should see the room created", () -> {
            LOG.info("22 ");
        });

    }

}