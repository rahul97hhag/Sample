package com.bhavani.bdd;

import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
@RunWith(CucumberReportRunner.class)
@CucumberOptions(features = "classpath:features",
        plugin = {"pretty",
        "json:target/cucumber-report.json",
        "html:target/cucumber-html"},
      //  "com.cucumber.listener.ExtentCucumberFormatter:output/report.html"},
        glue = {"com.bhavani.bdd"},
        monochrome = true,
        tags = {})
public class CucumberTest {
}