package com.bhavani.bdd;

import com.bhavani.Application;
import cucumber.api.java.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootContextLoader;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
@SpringBootTest
@ContextConfiguration(classes = Application.class, loader = SpringBootContextLoader.class)
public class CucumberContextConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(CucumberContextConfiguration.class);

    @Before
    public void setUp() {
        LOG.info("-------------- Spring Context Initialized For Executing Cucumber Tests --------------");
    }
}