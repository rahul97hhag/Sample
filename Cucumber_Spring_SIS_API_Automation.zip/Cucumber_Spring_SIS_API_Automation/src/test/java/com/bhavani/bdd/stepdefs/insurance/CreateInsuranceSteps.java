package com.bhavani.bdd.stepdefs.insurance;

import com.bhavani.bdd.stepdefs.AbstractSteps;
import cucumber.api.java8.En;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class CreateInsuranceSteps extends AbstractSteps implements En {

    private static Logger LOG = LoggerFactory.getLogger(CreateInsuranceSteps.class);

    public CreateInsuranceSteps() {

        Then("I should see the insurance created", () -> {
            LOG.info("12 ");
        });
    }
    /*
    api/InsuranceCarrierObject/GetInsuranceCarriers
    api/InsuranceCarrierObject/SaveInsuranceCarrier
    api/Insurance/InsertInsuranceClaimOffice
    api/InsurancePlan/SaveInsurancePlan
    api/Insurance/UpdateInsuranceClaimOffice
     */
}