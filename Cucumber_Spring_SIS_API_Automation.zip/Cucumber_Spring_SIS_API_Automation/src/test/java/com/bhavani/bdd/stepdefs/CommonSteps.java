package com.bhavani.bdd.stepdefs;

import com.bhavani.models.Login;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class CommonSteps extends AbstractSteps implements En {

    private static Logger LOG = LoggerFactory.getLogger(CommonSteps.class);

    public static String loginRequest = "";

    public CommonSteps() {

        Given("I login with username {string} password {string} and Facility {string}", (String username, String password, String facility) -> {
            // LOG.info("17  "+username + " " + password + " " + facility);
            testContext().reset();

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("UserName", "MercAdmin");
            jsonObject.put("Password", "M3rcAdmin!");

            /*
            Login login = new Login();
            login.setUserName("MercAdmin");
            login.setPassword("M3rcAdmin!");
            super.testContext().setPayload(login);
            */
            super.testContext().setPayload(jsonObject);
            super.executePost("api/Login/LoginUser");
            Response loginResponse = testContext().getResponse();
            String token = loginResponse.asString();
            token = token.replaceAll("\"", "");
            LOG.info(token);
            super.testContext().set("token", token);
            super.executeGet("api/User/UserOrgMap");
            Response getUserOrgMapResponse = testContext().getResponse();
           // LOG.info(getUserOrgMapResponse.asString());

            String userOrgResponse = getUserOrgMapResponse.asString();
            try {
                JSONArray jsonArray = new JSONArray(userOrgResponse);
                JSONObject childJSONObject = jsonArray.getJSONObject(0);
                JSONArray childOrgsArray = childJSONObject.getJSONArray("childOrgs");
                for(int i = 0; i < childOrgsArray.length(); i++) {
                    JSONObject childObject = childOrgsArray.getJSONObject(i);
                    if(childObject.getString("name").equalsIgnoreCase(facility)) {
                        super.testContext().set("organizationId", childObject.get("organizationId"));
                    }
                }
                //  logger.info(jsonArray.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }

            super.executePost("api/UserSession/UserSessionOrg/" + super.testContext().get("organizationId").toString());
            Response mapUserResponse = super.testContext().getResponse();
            LOG.info(mapUserResponse.asString());

        });
    }
}