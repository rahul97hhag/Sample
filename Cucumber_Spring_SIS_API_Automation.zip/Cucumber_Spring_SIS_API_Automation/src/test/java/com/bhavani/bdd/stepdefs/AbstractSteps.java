package com.bhavani.bdd.stepdefs;

import com.bhavani.bdd.CucumberTestContext;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
public class AbstractSteps {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractSteps.class);

    private CucumberTestContext CONTEXT = CucumberTestContext.CONTEXT;

    protected String baseUrl() {
        return "https://sisenterpriseapi164381-g.azurewebsites.net/";
    }

    protected CucumberTestContext testContext() {
        return CONTEXT;
    }

      protected void executePost(String apiPath) {
        executePost(apiPath, null, null);
      }

      protected void executePost(String apiPath, Map<String, String> pathParams) {
        executePost(apiPath, pathParams, null);
      }

      protected void executePost(String apiPath, Map<String, String> pathParams, Map<String, String> queryParamas) {
        final RequestSpecification request = CONTEXT.getRequest();
        // final Object payload = CONTEXT.getPayload();
        final Object payload = CONTEXT.getPayloadFromJSONObject();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParamas, request);

        try {
          if(testContext().get("token").toString().length() > 1) {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("token", testContext().get("token").toString());
            setHeaders(headers, request);
          }
        } catch (Exception e) {

        }
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");

        Response response = null;
        if(avoidLogMessages(apiPath)) {
          response = request.accept(ContentType.JSON)
                  .post(url);
        } else {
          response = request.accept(ContentType.JSON)
                  .log()
                  .all()
                  .post(url);
          logResponse(response);
        }

        /*
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .post(url);
        */
        logResponse(response);
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<<");

        CONTEXT.setResponse(response);
      }

      protected void executeMultiPartPost(String apiPath) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");
        Response response = request.multiPart("fuelTransfer", payload, "application/json")
          .log()
          .all()
          .post(url);

        logResponse(response);
        CONTEXT.setResponse(response);
      }

      protected void executeDelete(String apiPath) {
        executeDelete(apiPath, null, null);
      }

      protected void executeDelete(String apiPath, Map<String, String> pathParams) {
        executeDelete(apiPath, pathParams, null);
      }

      protected void executeDelete(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .delete(url);

        logResponse(response);
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<<");
        CONTEXT.setResponse(response);
      }

      protected void executePut(String apiPath) {
        executePut(apiPath, null, null);
      }

      protected void executePut(String apiPath, Map<String, String> pathParams) {
        executePut(apiPath, pathParams, null);
      }

      protected void executePut(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .put(url);

        logResponse(response);
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<<");
        CONTEXT.setResponse(response);
      }

      protected void executePatch(String apiPath) {
        executePatch(apiPath, null, null);
      }

      protected void executePatch(String apiPath, Map<String, String> pathParams) {
        executePatch(apiPath, pathParams, null);
      }

      protected void executePatch(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final Object payload = CONTEXT.getPayload();
        final String url = baseUrl() + apiPath;

        setPayload(request, payload);
        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");
        Response response = request.accept(ContentType.JSON)
          .log()
          .all()
          .patch(url);

        logResponse(response);
        CONTEXT.setResponse(response);
      }

      protected void executeGet(String apiPath) {
        executeGet(apiPath, null, null);
      }

      protected void executeGet(String apiPath, Map<String, String> pathParams) {
        executeGet(apiPath, pathParams, null);
      }

      protected void executeGet(String apiPath, Map<String, String> pathParams, Map<String, String> queryParams) {
        final RequestSpecification request = CONTEXT.getRequest();
        final String url = baseUrl() + apiPath;

        setQueryParams(pathParams, request);
        setPathParams(queryParams, request);
        setHeaders(getHeaders(), request);

        Response response = null;
        LOG.info(">>>>>>>>>>>>>> Currently executing request <<<<<<<<<<<<<<");
        if(avoidLogMessages(apiPath)) {
          response = request.accept(ContentType.JSON)
                  .get(url);
        } else {
          response = request.accept(ContentType.JSON)
                  .log()
                  .all()
                  .get(url);
          logResponse(response);
        }


        /*
        response = request.accept(ContentType.JSON)
                .log()
                .all()
                .get(url);
        logResponse(response);
        */
        LOG.info(">>>>>>>>>>>>>> Completed executing request <<<<<<<<<<<<<<");
        CONTEXT.setResponse(response);
      }

      private void logResponse(Response response) {
        response.then()
          .log()
          .all();
      }

      private void setPathParams(Map<String, String> queryParamas, RequestSpecification request) {
        if (null != queryParamas) {
          request.queryParams(queryParamas);
        }
      }

      private void setQueryParams(Map<String, String> pathParams, RequestSpecification request) {
        if (null != pathParams) {
          request.pathParams(pathParams);
        }
      }

      private void setHeaders(Map<String, String> headers, RequestSpecification request) {
        if (null != headers) {
          request.headers(headers);
        }
      }

      private void setPayload(RequestSpecification request, Object payload) {
        if (null != payload) {
          request.contentType(ContentType.JSON)
            .body(payload);
        }
      }

      private Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("token", testContext().get("token").toString());
        return headers;
      }

      private boolean avoidLogMessages(String requestPath) {
        switch (requestPath) {
          case "api/User/UserOrgMap":
            return true;
          default:
            return false;
        }
      }
}