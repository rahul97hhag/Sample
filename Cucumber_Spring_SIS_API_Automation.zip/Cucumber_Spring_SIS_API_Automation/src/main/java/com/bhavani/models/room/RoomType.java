
package com.bhavani.models.room;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "roomTypeId",
    "businessGroupId",
    "roomTypeDesc",
    "quickCode",
    "activeTf",
    "classification"
})
public class RoomType {

    @JsonProperty("roomTypeId")
    private Integer roomTypeId;
    @JsonProperty("businessGroupId")
    private Integer businessGroupId;
    @JsonProperty("roomTypeDesc")
    private String roomTypeDesc;
    @JsonProperty("quickCode")
    private String quickCode;
    @JsonProperty("activeTf")
    private Boolean activeTf;
    @JsonProperty("classification")
    private String classification;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("roomTypeId")
    public Integer getRoomTypeId() {
        return roomTypeId;
    }

    @JsonProperty("roomTypeId")
    public void setRoomTypeId(Integer roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    public RoomType withRoomTypeId(Integer roomTypeId) {
        this.roomTypeId = roomTypeId;
        return this;
    }

    @JsonProperty("businessGroupId")
    public Integer getBusinessGroupId() {
        return businessGroupId;
    }

    @JsonProperty("businessGroupId")
    public void setBusinessGroupId(Integer businessGroupId) {
        this.businessGroupId = businessGroupId;
    }

    public RoomType withBusinessGroupId(Integer businessGroupId) {
        this.businessGroupId = businessGroupId;
        return this;
    }

    @JsonProperty("roomTypeDesc")
    public String getRoomTypeDesc() {
        return roomTypeDesc;
    }

    @JsonProperty("roomTypeDesc")
    public void setRoomTypeDesc(String roomTypeDesc) {
        this.roomTypeDesc = roomTypeDesc;
    }

    public RoomType withRoomTypeDesc(String roomTypeDesc) {
        this.roomTypeDesc = roomTypeDesc;
        return this;
    }

    @JsonProperty("quickCode")
    public String getQuickCode() {
        return quickCode;
    }

    @JsonProperty("quickCode")
    public void setQuickCode(String quickCode) {
        this.quickCode = quickCode;
    }

    public RoomType withQuickCode(String quickCode) {
        this.quickCode = quickCode;
        return this;
    }

    @JsonProperty("activeTf")
    public Boolean getActiveTf() {
        return activeTf;
    }

    @JsonProperty("activeTf")
    public void setActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
    }

    public RoomType withActiveTf(Boolean activeTf) {
        this.activeTf = activeTf;
        return this;
    }

    @JsonProperty("classification")
    public String getClassification() {
        return classification;
    }

    @JsonProperty("classification")
    public void setClassification(String classification) {
        this.classification = classification;
    }

    public RoomType withClassification(String classification) {
        this.classification = classification;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RoomType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(roomTypeId).append(businessGroupId).append(roomTypeDesc).append(quickCode).append(activeTf).append(classification).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RoomType) == false) {
            return false;
        }
        RoomType rhs = ((RoomType) other);
        return new EqualsBuilder().append(roomTypeId, rhs.roomTypeId).append(businessGroupId, rhs.businessGroupId).append(roomTypeDesc, rhs.roomTypeDesc).append(quickCode, rhs.quickCode).append(activeTf, rhs.activeTf).append(classification, rhs.classification).append(additionalProperties, rhs.additionalProperties).isEquals();
    }
}
