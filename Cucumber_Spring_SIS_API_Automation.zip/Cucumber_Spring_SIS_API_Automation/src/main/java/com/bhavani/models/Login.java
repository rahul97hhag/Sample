package com.bhavani.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by BhavaniPrasadReddy on 6/10/2020.
 */
@Getter
@Setter
public class Login {

    public String UserName;
    public String Password;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

}